﻿using System;
namespace DawnLib.Framework
{
    /// <summary>
    /// 设置数据
    /// </summary>
    public interface IData
    {
        void SetData(params object[] _params);
    }
}