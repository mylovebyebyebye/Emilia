﻿using UnityEngine;
using System.Collections;

public interface IManager
{
    void Clear();
}
