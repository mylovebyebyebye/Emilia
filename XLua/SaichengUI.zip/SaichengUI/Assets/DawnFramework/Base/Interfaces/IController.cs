﻿using System;
using System.Collections.Generic;

namespace DawnLib.Framework
{
    /// <summary>
    /// 控制器接口
    /// </summary>
    public interface IController
    {
        void RegisterCommand(string messageName, Type commandType);
        void RegisterViewCommand(IView view, params string[] commandNames);

        void ExecuteCommand(IMessage message);

        void RemoveCommand(string messageName);
        void RemoveViewCommand(IView view, params string[] commandNames);

        bool HasCommand(string messageName);
    }
}