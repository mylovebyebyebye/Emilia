﻿using System;

namespace DawnLib.Framework
{
    /// <summary>
    /// 命令接口
    /// </summary>
    public interface ICommand
    {
        void Execute(IMessage message);
    }
}
