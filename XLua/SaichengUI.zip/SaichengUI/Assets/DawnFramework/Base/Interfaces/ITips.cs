﻿using System.Collections.Generic;

namespace DawnLib.Framework
{
    public interface ITips
    {
        void Show();
        System.Action[] BottonHandles { set; get; }
    }
}
