﻿using System;
namespace DawnLib.Framework
{
    /// <summary>
    /// 视图接口
    /// </summary>
    public interface IView
    {
        void OnMessage(IMessage message);
    }
}