﻿using UnityEngine;
using System.Collections;
using DawnLib.ComDefine;

namespace DawnLib.Framework
{
    public class AppFacade : Facade
    {
        private static AppFacade _instance;

        public AppFacade()
            : base()
        {
        }

        public static AppFacade Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AppFacade();
                }
                return _instance;
            }
        }

        override protected void InitFramework()
        {
            base.InitFramework();

            //-----------------关联命令-----------------------
            this.RegisterCommand(NotiConst.START_UP, typeof(AppStartUpCommand));
        }
        /// <summary>
        /// 启动框架
        /// </summary>
        public void StartUp()
        {
            this.SendMessageOnce(NotiConst.START_UP);
        }
        public void ClearMemory()
        {
            System.GC.Collect();

            this.ClearManagers();

            Resources.UnloadUnusedAssets();
        }
    }
}
