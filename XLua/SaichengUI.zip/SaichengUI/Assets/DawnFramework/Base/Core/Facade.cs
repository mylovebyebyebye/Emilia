﻿using System;
using System.Collections.Generic;
using UnityEngine;
using DawnLib.ComDefine;

namespace DawnLib.Framework
{
    public class Facade
    {
        protected IController m_controller;
        static GameObject m_GameManager;
        static Dictionary<string, IManager> m_Managers = new Dictionary<string, IManager>();
        public GameObject AppGameManager
        {
            get
            {
                if (m_GameManager == null)
                    m_GameManager = GameObject.FindGameObjectWithTag(Tags.Control);
                return m_GameManager;
            }
        }

        protected Facade()
        {
            InitFramework();
        }
        protected virtual void InitFramework()
        {
            if (m_controller != null) return;
            m_controller = Controller.Instance;
        }

        public virtual void RegisterCommand(string commandName, Type commandType)
        {
            m_controller.RegisterCommand(commandName, commandType);
        }

        public virtual void RemoveCommand(string commandName)
        {
            m_controller.RemoveCommand(commandName);
        }

        public virtual bool HasCommand(string commandName)
        {
            return m_controller.HasCommand(commandName);
        }

        public void RegisterMultiCommand(Type commandType, params string[] commandNames)
        {
            int count = commandNames.Length;
            for (int i = 0; i < count; i++)
                RegisterCommand(commandNames[i], commandType);
        }

        public void RemoveMultiCommand(params string[] commandName)
        {
            int count = commandName.Length;
            for (int i = 0; i < count; i++)
                RemoveCommand(commandName[i]);
        }

        public void SendMessage(string message, object body = null)
        {
            Message _message = Message.create(message, body);

            m_controller.ExecuteCommand(_message);

            _message.Destroy();
            _message = null;
        }
        /// <summary>
        /// 发送一次信息，发送后卸载Command
        /// </summary>
        public void SendMessageOnce(string message, object body = null)
        {
            SendMessage(message, body);
            RemoveCommand(message);
        }

        /// <summary>
        /// 添加管理器
        /// </summary>
        public void AddManager(string typeName, IManager obj)
        {
            if (!m_Managers.ContainsKey(typeName))
                m_Managers.Add(typeName, obj);
        }

        /// <summary>
        /// 添加Unity对象
        /// </summary>
        public T AddManager<T>(string typeName) where T : Component
        {
            IManager result = null;
            if (m_Managers.TryGetValue(typeName, out result))
                return (T)result;

            result = (IManager) AppGameManager.AddComponent<T>();
            m_Managers.Add(typeName, result);

            return (T)result;
        }

        /// <summary>
        /// 获取系统管理器
        /// </summary>
        public T GetManager<T>(string typeName) where T : IManager
        {
            IManager manager = null;

            if (!m_Managers.TryGetValue(typeName, out manager))
                return default(T);

            return (T)manager;
        }

        /// <summary>
        /// 删除管理器
        /// </summary>
        public void RemoveManager(string typeName)
        {
            IManager manager = null;
            if (!m_Managers.TryGetValue(typeName, out manager))
                return;
            Type type = manager.GetType();
            if (type.IsSubclassOf(typeof(MonoBehaviour)))
                GameObject.Destroy((Component)manager);

            m_Managers.Remove(typeName);
        }

        public void ClearManagers()
        {
            foreach(var mgr in m_Managers)
            {
                mgr.Value.Clear();
            }
        }
    }
}