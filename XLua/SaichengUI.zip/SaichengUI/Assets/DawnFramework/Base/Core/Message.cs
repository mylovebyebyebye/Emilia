﻿using System;
using System.Collections.Generic;

namespace DawnLib.Framework
{
    public class Message : IMessage
    {
        static Stack<Message> messagePool;
        const int poolLimit = 10;
        private Message() { }

        public static Message create(string name, object body = null, string type = null)
        {
            Message _message = null;
            if (messagePool != null && messagePool.Count > 0)
                _message = messagePool.Pop();
            else
                _message = new Message();

            _message.m_name = name;
            _message.m_body = body;
            _message.m_type = type;

            return _message;
        }
        public void Destroy()
        {
            if (messagePool == null)
                messagePool = new Stack<Message>();

            if (messagePool.Count < poolLimit)
                messagePool.Push(this);
        }
        /// <summary>
        /// Get the string representation of the <c>Notification instance</c>
        /// </summary>
        /// <returns>The string representation of the <c>Notification</c> instance</returns>
        public override string ToString()
        {
            string msg = "Notification Name: " + Name;
            msg += "\nBody:" + ((Body == null) ? "null" : Body.ToString());
            msg += "\nType:" + ((Type == null) ? "null" : Type);
            return msg;
        }

        /// <summary>
        /// The name of the <c>Notification</c> instance
        /// </summary>
        public virtual string Name
        {
            get { return m_name; }
        }

        /// <summary>
        /// The body of the <c>Notification</c> instance
        /// </summary>
        /// <remarks>This accessor is thread safe</remarks>
        public virtual object Body
        {
            get
            {
                // Setting and getting of reference types is atomic, no need to lock here
                return m_body;
            }
            set
            {
                // Setting and getting of reference types is atomic, no need to lock here
                m_body = value;
            }
        }

        /// <summary>
        /// The type of the <c>Notification</c> instance
        /// </summary>
        /// <remarks>This accessor is thread safe</remarks>
        public virtual string Type
        {
            get
            {
                // Setting and getting of reference types is atomic, no need to lock here
                return m_type;
            }
            set
            {
                // Setting and getting of reference types is atomic, no need to lock here
                m_type = value;
            }
        }

        /// <summary>
        /// The name of the notification instance 
        /// </summary>
        private string m_name;

        /// <summary>
        /// The type of the notification instance
        /// </summary>
        private string m_type;

        /// <summary>
        /// The body of the notification instance
        /// </summary>
        private object m_body;
    }
}
