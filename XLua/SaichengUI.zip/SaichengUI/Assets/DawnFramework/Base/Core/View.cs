﻿using UnityEngine;
using System.Collections;

namespace DawnLib.Framework
{
    public class View : MonoBehaviour, IView
    {
        public void OnMessage(IMessage message)
        {
            MessageHandle(message as Message);
        }
        protected virtual void MessageHandle(Message message)
        {

        }
        protected void RegisterListener(params string[] messages)
        {
            if (messages == null || messages.Length == 0) return;
            Controller.Instance.RegisterViewCommand(this, messages);
        }

        protected void RemoveListener(params string[] messages)
        {
            if (messages == null || messages.Length == 0) return;
            Controller.Instance.RemoveViewCommand(this, messages);
        }

    }
}
