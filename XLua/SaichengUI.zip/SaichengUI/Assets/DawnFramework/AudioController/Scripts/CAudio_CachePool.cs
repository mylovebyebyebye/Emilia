﻿using UnityEngine;
using System.Collections.Generic;

namespace DawnLib.Framework
{
    /***************************************
     * 音频文件缓冲池
     * *************************************/
    public class CAudio_CachePool : MonoBehaviour
    {
        [System.Serializable]
        public class AudioCache
        {
            public string NameOrPath { get { return m_NameOrPath; } set { m_NameOrPath = value; } }
            [HideInInspector]
            [SerializeField]
            string m_NameOrPath = null;
            public AudioClip AudioFile { get { return m_AudioFile; } set { m_AudioFile = value; } }
            [HideInInspector]
            [SerializeField]
            AudioClip m_AudioFile = null;
            [System.NonSerialized]
            public int RetainCount = 0;
        }
        private static List<AudioCache> m_objectPool = new List<AudioCache>();
        public static AudioClip GetAndLoad(string _name)
        {
            AudioCache _cache = m_objectPool.Find(x => x.NameOrPath == _name);//查找缓存//
            if (_cache == null)//如果没有缓存尝试从资源管理器中查找//
            {
                var _clip = CGlobal.ResMgr.GetResource<AudioClip>(_name);
                if (_clip)
                {
                    _cache = new AudioCache();
                    _cache.NameOrPath = _name;
                    _cache.AudioFile = _clip;

                    m_objectPool.Add(_cache);
                }
                else
                    return null;
            }
            if (_cache != null)
            {
                if (_cache.AudioFile == null)//默认不初始化音频文件//
                {
                    _cache.AudioFile = CGlobal.ResMgr.GetResource<AudioClip>(_cache.NameOrPath);

                    if (_cache.AudioFile == null)//读取音频文件失败//
                    {
                        Debug.LogError("<AudiosCachePool> 缓存音乐组件失败" + _cache.NameOrPath);
                        CAudio_CachePool.Release(_cache.NameOrPath);

                        _cache = null;

                        return null;
                    }
                }
                //一切正常增加引用//
                _cache.RetainCount++;
                return _cache.AudioFile;
            }
            return null;
        }
        public static void Release(string _name)
        {
            AudioCache _cache = m_objectPool.Find(x => x.NameOrPath == _name);
            if (_cache != null)
            {
                _cache.RetainCount--;

                if (_cache.RetainCount <= 0)
                {
                    CGlobal.ResMgr.UnLoadAsset(_cache.AudioFile);
                    m_objectPool.Remove(_cache);
                }
            }
        }
        public AudioPlayer DefaultPlayer { get { return m_DefaultItem; } set { m_DefaultItem = value; } }
        [HideInInspector]
        [SerializeField]
        AudioPlayer m_DefaultItem = null;
        public static AudioPlayer DefaultItem = null;
        public AudioPlayer Sound3dPlayer { get { return m_Sound3dPlayer; } set { m_Sound3dPlayer = value; } }
        [HideInInspector]
        [SerializeField]
        AudioPlayer m_Sound3dPlayer = null;
        public static AudioPlayer Sound3dItem = null;
        public List<AudioCache> LAudioCaches { get { return m_Caches; } set { m_Caches = value; } }
        [HideInInspector]
        [SerializeField]
        List<AudioCache> m_Caches;
        void Awake()
        {
            if (m_DefaultItem)
                DefaultItem = m_DefaultItem;
            else
                m_DefaultItem = DefaultItem;

            if (m_Sound3dPlayer)
                Sound3dItem = m_Sound3dPlayer;
            else
                m_Sound3dPlayer = Sound3dItem;

            if (m_Caches != null)
                for (int i = 0; i < m_Caches.Count; i++)
                {
                    var _obj = m_Caches[i];

                    if (string.IsNullOrEmpty(_obj.NameOrPath))
                        continue;

                    var _oldObj = m_objectPool.Find(x => x.NameOrPath == _obj.NameOrPath);
                    if (_oldObj != null)
                    {
                        _oldObj.RetainCount++;
                        continue;
                    }
                    _obj.RetainCount++;
                    m_objectPool.Add(_obj);
                }
        }
        void OnDestroy()
        {
            if (m_Caches != null)
                for (int i = 0; i < m_Caches.Count; i++)
                {
                    if (m_Caches[i] == null)
                        continue;

                    var _audio = m_objectPool.Find(x => x.NameOrPath == m_Caches[i].NameOrPath);

                    if (_audio == null)
                        continue;

                    _audio.RetainCount--;
                    if (_audio.RetainCount <= 0)
                        m_objectPool.Remove(_audio);
                }
            m_Caches = null;
        }
    }
}