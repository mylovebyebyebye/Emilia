﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace DawnLib.Framework
{
    /***************************************
     * 用于播放音乐的脚本
     * *************************************/
    public class CAudio_Music : MonoBehaviour
    {
        [SerializeField]
        AudioManager.AudioPlayInfo m_Bgm = new AudioManager.AudioPlayInfo();
        [SerializeField]
        AudioManager.AudioPlayInfo[] m_NormalSounds = { };

        void OnEnable()
        {
            //确保主音频控制器准备完成//
            CGlobal.AudioMgr.PlayMusic(m_Bgm);

            for (int i = 0; i < m_NormalSounds.Length; i++)
            {
                CGlobal.AudioMgr.Play(m_NormalSounds[i], transform);
            }
        }
        void OnDisable()
        {
            CGlobal.AudioMgr.Stop(m_Bgm);
            for (int i = 0; i < m_NormalSounds.Length; i++)
                CGlobal.AudioMgr.Stop(m_NormalSounds[i]);
        }
        public void PlayAudioEvents(string _audioName)//用于各类事件回调//
        {
            CGlobal.AudioMgr.Play(_audioName, transform);
        }
    }
}