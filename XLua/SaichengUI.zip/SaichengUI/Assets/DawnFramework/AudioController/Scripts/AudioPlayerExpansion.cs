﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace DawnLib.Framework
{
    public static class AudioPlayerExpansion
    {
        class FadeAudio : ScheduleBase
        {
            static Stack<FadeAudio> m_FadeAudioPool;
            public static FadeAudio create(bool _isIn, float _dur)
            {
                FadeAudio _fade = null;
                if (m_FadeAudioPool != null && m_FadeAudioPool.Count > 0)
                    _fade = m_FadeAudioPool.Pop();
                else
                    _fade = new FadeAudio();

                _fade.InitValue(_isIn, _dur);

                return _fade;
            }
            bool m_bIsFadeIn;
            AudioPlayer m_AudioObject;
            private FadeAudio() { }
            private void InitValue(bool _isIn, float _dur)
            {
                m_bIsFadeIn = _isIn;
                m_DurationTime = Mathf.Max(0.01f, _dur);
            }
            public override bool InitFunction()
            {
                base.InitFunction();

                m_AudioObject = Sender.GetComponent<AudioPlayer>();

                return m_AudioObject;
            }
            public override void UpdateFunction(float _dt)
            {
                base.UpdateFunction(_dt);

                if (m_AudioObject == null)
                    IsOver = true;

                if (m_bIsFadeIn)
                    m_AudioObject.volume = 1 - fDurationTime / DurationTime;
                else
                    m_AudioObject.volume = fDurationTime / DurationTime;
            }
            public override void TimeOverFunction()
            {
                base.TimeOverFunction();
                m_AudioObject.Stop();

                if (m_FadeAudioPool == null)
                    m_FadeAudioPool = new Stack<FadeAudio>();

                if (m_FadeAudioPool.Count < 5)
                    m_FadeAudioPool.Push(this);
            }
        }

        public static void Stop(this AudioPlayer _player, float _fadeOut)
        {
            if (_fadeOut > 0)
                CGlobal.Sche.Schedule(FadeAudio.create(false, _fadeOut), _player.gameObject);
        }
        public static bool Play(this AudioPlayer _player, string _audioName, float _fadeIn)
        {
            if (_player.Play(_audioName))
            {
                if (_fadeIn > 0)
                    CGlobal.Sche.Schedule(FadeAudio.create(true, _fadeIn), _player.gameObject);

                return true;
            }
            return false;
        }
    }
}