﻿using UnityEngine;
using System.Collections;

namespace DawnLib.Framework
{
    [RequireComponent(typeof(AudioSource))]
    public class AudioPlayer : MonoBehaviour
    {
        public System.Action<AudioPlayer> OverCallback;
        public string NameOrPath { get { return m_audioName; } }
        public bool IsPlaying { get { return m_AudioSource.isPlaying; } }
        public float volume { set { m_AudioSource.volume = value; } get { return m_AudioSource.volume; } }
        public bool IsLoop { set { m_AudioSource.loop = value; } get { return m_AudioSource.loop; } }
        private AudioSource m_AudioSource = null;
        private string m_audioName = null;
        void Awake()
        {
            m_AudioSource = this.GetComponent<AudioSource>();
            m_AudioSource.Stop();
        }
        void OnEnable()
        {
            CGlobal.AudioMgr.AddAudioObject(this);
        }
        void Update()
        {
            if (m_AudioSource.isPlaying == false)
            {
                if (OverCallback != null)
                    OverCallback(this);

                GameObject.Destroy(gameObject);
            }
        }
        void OnDisable()
        {
            CGlobal.AudioMgr.RemoveAudioObject(this);
        }
        void OnDestroy()
        {
            if (string.IsNullOrEmpty(m_audioName) == false)
                CAudio_CachePool.Release(m_audioName);
        }
        public bool Play(string _audioName)
        {
            if (string.IsNullOrEmpty(_audioName) == false)
            {
                if (m_audioName != _audioName)
                {
                    if (string.IsNullOrEmpty(m_audioName) == false)
                        CAudio_CachePool.Release(m_audioName);

                    AudioClip _clip = CAudio_CachePool.GetAndLoad(_audioName);
                    if (_clip)
                    {
                        m_audioName = _audioName;
                        m_AudioSource.clip = _clip;
                    }
                    else
                    {
                        m_audioName = null;
                        Debug.LogWarning("<Audio Play> 没有缓存音频：" + _audioName);
                        return false;
                    }
                }
                m_AudioSource.Play();
                gameObject.name = "Audio#" + _audioName;
                return true;
            }
            return false;
        }
        public void Stop()
        {
            m_AudioSource.Stop();
        }
        public void Pause()
        {
            m_AudioSource.Pause();
        }
        public void Resume()
        {
            m_AudioSource.UnPause();
        }
    }
}