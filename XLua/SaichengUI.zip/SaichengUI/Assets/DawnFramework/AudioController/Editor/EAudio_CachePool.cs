﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

namespace DawnLib.Framework
{
    [CustomEditor(typeof(CAudio_CachePool))]
    // 在编辑模式下执行脚本，这里用处不大可以删除//
    [ExecuteInEditMode]
    public class EAudio_CachePool : Editor
    {
        List<CAudio_CachePool.AudioCache> m_AudioCaches;
        int m_SelectedIndex = -1;
        CAudio_CachePool m_target = null;
        void Awake()
        {
            m_target = target as CAudio_CachePool;

            if (m_target.LAudioCaches != null)
                m_AudioCaches = m_target.LAudioCaches;
            else
                m_AudioCaches = new List<CAudio_CachePool.AudioCache>();

            m_target.LAudioCaches = m_AudioCaches;
        }
        public override void OnInspectorGUI()
        {
            m_target.DefaultPlayer = EditorGUILayout.ObjectField("默认音频播放组件：", m_target.DefaultPlayer, typeof(AudioPlayer), true) as AudioPlayer;
            m_target.Sound3dPlayer = EditorGUILayout.ObjectField("Sound3D音频播放组件：", m_target.Sound3dPlayer, typeof(AudioPlayer), true) as AudioPlayer;

            for (int i = 0; i < m_AudioCaches.Count; i++)
            {
                GUILayout.BeginHorizontal();
                if (GUILayout.Button(m_AudioCaches[i].NameOrPath))
                {
                    if (m_SelectedIndex == i)
                        m_SelectedIndex = -1;
                    else
                        m_SelectedIndex = i;
                }
                if (GUILayout.Button("移除组件"))
                {
                    m_AudioCaches.RemoveAt(i);
                    return;
                }
                GUILayout.EndHorizontal();

                if (m_SelectedIndex == i)
                {
                    m_AudioCaches[i].NameOrPath = EditorGUILayout.TextField("音频路径或名称", m_AudioCaches[i].NameOrPath);
                    m_AudioCaches[i].AudioFile = EditorGUILayout.ObjectField("音频文件", m_AudioCaches[i].AudioFile, typeof(AudioClip), true) as AudioClip;
                }
            }

            if (GUILayout.Button("添加新组件"))
            {
                m_SelectedIndex = m_AudioCaches.Count;

                m_AudioCaches.Add(new CAudio_CachePool.AudioCache());

                m_AudioCaches[m_SelectedIndex].NameOrPath = "New";
            }
        }
    }
}
