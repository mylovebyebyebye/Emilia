﻿using UnityEngine;
using UnityEngine.Networking;

using System.Xml;
using System.Collections;
using System.Collections.Generic;

using DawnLib.ComDefine;

namespace DawnLib.Framework
{
    /// <summary>
    /// 加载类
    /// </summary>
    public class AssetbundleDownloader : System.IDisposable
    {
        /// <summary>
        /// 加载失败event param1：失败原因，param2：失败的资源
        /// </summary>
        public static event System.Action<string, string> Failed;
        /// <summary>
        /// 如果开始下载则会触发的event
        /// </summary>
        public static event System.Action<AssetbundleDownloader> Download;
        public float DownloadProgress
        {
            get
            {
                if (m_lRequests.Count == 0)
                    return 1;

                float _result = 0;

                for (int i = 0; i < m_lRequests.Count; i++)
                {
                    _result += m_lRequests[i].downloadProgress;
                }
                return _result / m_lRequests.Count;
            }
        }
        public ulong DownloadBytes
        {
            get
            {
                ulong _allbytes = 0;

                for (int i = 0; i < m_lRequests.Count; i++)
                {
                    _allbytes += m_lRequests[i].downloadedBytes;
                }
                return _allbytes;
            }
        }
        public bool IsEnable { get { return _CheckReady(); } }
        #region /***成员变量***/
        //版本信息//
        class AssetbundleVerInfo
        {
            public int versionNum;
            public uint crc;
        }
        //Bundle缓存//
        class AssetbundleRef
        {
            //内存敏感级别//
            private const int KeepCount = 2;

            public AssetBundle data;
            public int RetainCount { get { return m_retainCount; } }
            private int m_retainCount = -1;
            public bool Retain() { return ++m_retainCount == 0; }
            public bool Release() { return --m_retainCount <= -KeepCount; }
        }
        private Dictionary<string, AssetbundleVerInfo> m_dicVersionInfos = new Dictionary<string, AssetbundleVerInfo>();
        private Dictionary<string, AssetbundleRef> m_dicRefCache = new Dictionary<string, AssetbundleRef>();

        private List<UnityWebRequest> m_lRequests = new List<UnityWebRequest>();

        private string m_AssetsDownloadRoot = null;
        private AssetBundleManifest m_MainManifest = null;
        #endregion
        /// <summary>
        /// 初始化加载器
        /// </summary>
        /// <param name="_resVer">资源版本号</param>
        /// <param name="_resRoot">资源根路径</param>
        public IEnumerator InitDownloader(int _resVer, string _resRoot)
        {
            m_AssetsDownloadRoot = _resRoot;
            yield return _DownLoadVersionData(_resVer, _resRoot + "/Version/VersionNum.xml");
        }
        /// <summary>
        /// 判断是否存在该资源
        /// </summary>
        /// <param name="_fullName"></param>
        /// <returns>是否缓存过该资源</returns>
        public bool hasAsset(string _fullName)
        {
            return _CheckReady() && _GetVersionNum(AssetBundleNameTools.ConvertToAssetBundleName(_fullName)) >= 0;
        }
        public Object GetAsset(string _assetPath)
        {
            string _assetBundleName = AssetBundleNameTools.ConvertToAssetBundleName(_assetPath);
            string _assetName = AssetBundleNameTools.GetFileName(_assetPath);

            AssetbundleRef _ref;
            if (m_dicRefCache.TryGetValue(_assetBundleName, out _ref))
            {
                return _ref.data.LoadAsset(_assetName); ;
            }
            return null;
        }
        public T GetAsset<T>(string _assetPath) where T : Object
        {
            return GetAsset(_assetPath) as T;
        }
        public AssetBundle GetAssetBundle(string _assetBundleName)
        {
            AssetbundleRef _ref;
            if (m_dicRefCache.TryGetValue(_assetBundleName, out _ref))
            {
                m_dicRefCache.Remove(_assetBundleName);

                return _ref.data;
            }
            return null;
        }
        /// <summary>
        /// 加载资源
        /// </summary>
        /// <param name="_assetPath">基于下载根目录的的完整路径</param>
        public IEnumerator LoadAsset(string _assetPath)
        {
            while (_CheckReady() == false)
                yield return null;

            string _assetBundleName = AssetBundleNameTools.ConvertToAssetBundleName(_assetPath);

            yield return _LoadAssetBundleAndDependentBundles(_assetBundleName);
        }
        /// <summary>
        /// 卸载资源
        /// </summary>
        /// <param name="_assetPath"></param>
        public void UnLoadAsset(string _assetPath)
        {
            string _assetBundleName = AssetBundleNameTools.ConvertToAssetBundleName(_assetPath);
            _UnLoadAssetBundleAndDependentBundles(_assetBundleName);
        }
        /// <summary>
        /// 清理计数小于0的资源，可用于二次删除
        /// 仅卸载ab,不删除引用
        /// </summary>
        public void ClearUnusedAsset()
        {
            List<string> _toClearList = new List<string>();

            foreach (var _keyValue in m_dicRefCache)
            {
                if (_keyValue.Value.data == null || _keyValue.Value.RetainCount <= 0)
                {
                    _toClearList.Add(_keyValue.Key);
                }
            }
            for(int i =0 ;i<_toClearList.Count ;i++)
            {
                _UnLoadAssetBundleAndDependentBundles(_toClearList[i]);
            }
        }
        public void Dispose()
        {
            foreach (var _keyValue in m_dicRefCache)
            {
                _keyValue.Value.data.Unload(true);
            }
        }
        #region /***成员函数***/
        private void _UnLoadAssetBundleAndDependentBundles(string _assetBundleName)
        {
            AssetbundleRef _ref;
            if (m_dicRefCache.TryGetValue(_assetBundleName, out _ref))
            {
                if (_ref.Release())
                {
                    //获取所有依赖包名//
                    string[] _DependenciesName = m_MainManifest.GetAllDependencies(_assetBundleName);

                    for (int i = 0; i < _DependenciesName.Length; i++)
                    {
                        _UnLoadAssetBundleAndDependentBundles(_DependenciesName[i]);
                    }

                    _UnLoadAssetBundle(_assetBundleName, false);
                }
            }
        }
        private IEnumerator _LoadAssetBundleAndDependentBundles(string _assetBundleName)
        {
            yield return _LoadAssetBundle(_assetBundleName);

            AssetbundleRef _targetAbRef = m_dicRefCache[_assetBundleName];

            if (_targetAbRef.Retain())
            {
                //获取所有依赖包名//
                string[] _DependenciesName = m_MainManifest.GetAllDependencies(_assetBundleName);

                for (int i = 0; i < _DependenciesName.Length; i++)
                {
                    if (!m_dicRefCache.ContainsKey(_DependenciesName[i]))
                        yield return _LoadAssetBundleAndDependentBundles(_DependenciesName[i]);

                    m_dicRefCache[_DependenciesName[i]].Retain();
                }
            }
        }
        private IEnumerator _DownLoadVersionData(int version, string _url)
        {
            if (_url.Contains("://") == false)
            {
                Debug.LogError("<_InitWithVersionData>  Url Error :" + _url);
                yield break;
            }
            using (var request = UnityWebRequest.Get(_url))
            {
                m_lRequests.Add(request);

                yield return request.Send();

                if (request.isError)
                {
                    Debug.Log(request.error);
                    yield break;
                }
                if (!request.isError)
                    _InitWithVersionData(request.downloadHandler.text);
                else if (Failed != null)
                    Failed(ConstText.CheckVersionFailed, request.error);
                else
                    Debug.LogError(ConstText.CheckVersionFailed + " :" + request.error);

                m_lRequests.Remove(request);
            }
            //加载依赖文件//
            yield return _LoadAssetBundle(AssetBundleNameTools.GetAssetBundleManifestName());

            m_MainManifest = this.GetAssetBundle(AssetBundleNameTools.GetAssetBundleManifestName()).LoadAsset<AssetBundleManifest>("AssetBundleManifest");

            _UnLoadAssetBundle(AssetBundleNameTools.GetAssetBundleManifestName(), false);
        }
        private void _InitWithVersionData(string _xml)
        {
            //根据XML加载版本信息//
            XmlDocument XmlDoc = new XmlDocument();
            XmlDoc.LoadXml(_xml);
            XmlElement XmlRoot = XmlDoc.DocumentElement;
            foreach (XmlNode node in XmlRoot.ChildNodes)
            {
                if ((node is XmlElement) == false)
                    continue;
                string file = (node as XmlElement).GetAttribute("FileName");

                var _info = new AssetbundleVerInfo();
                _info.versionNum = int.Parse((node as XmlElement).GetAttribute("Num"));
                _info.crc = uint.Parse((node as XmlElement).GetAttribute("CRC")); ;

                if (m_dicVersionInfos.ContainsKey(file) == false)
                    m_dicVersionInfos.Add(file, _info);
                else
                    m_dicVersionInfos[file] = _info;
            }
            XmlDoc = null;
            XmlRoot = null;
        }
        private void _UnLoadAssetBundle(string _assetBundleName, bool _isNeedClean)
        {
            if (!m_dicRefCache.ContainsKey(_assetBundleName))
                return;

            var _targetBundle = m_dicRefCache[_assetBundleName];
            if (_targetBundle.data != null)
                 _targetBundle.data.Unload(_isNeedClean);

            m_dicRefCache.Remove(_assetBundleName);
            _targetBundle = null;
        }
        public IEnumerator _LoadAssetBundle(string _assetBundleName)
        {
            if (m_dicRefCache.ContainsKey(_assetBundleName))
                yield break;

            //根据包名，获取完整路径//
            string url = _ConverToUrlPath(_assetBundleName);
            //获取版本号//
            int verNum = _GetVersionNum(_assetBundleName);

            if (verNum <= 0)
            {
                if (Failed != null)
                    Failed(ConstText.CheckVersionFailed, _assetBundleName);

                Debug.Log("<VersionNum>获取版本号失败 没有资源包：" + _assetBundleName);
                yield break;
            }
            if (Caching.IsVersionCached(url, verNum) == false)
            {
#if UNITY_EDITOR
                Debug.Log("Start Download :" + url);
#endif
                if (Download != null)
                    Download(this);
            }
            uint crc = _GetAssetbundleCrc(_assetBundleName);
            using (UnityWebRequest _request = UnityWebRequest.GetAssetBundle(url, (uint)verNum, crc))
            {
                m_lRequests.Add(_request);
                yield return _request.Send();

                if (_request.isError)
                {
                    if (Failed != null)
                        Failed(ConstText.DownloadFailed, _request.error);

                    Debug.Log(ConstText.DownloadFailed + " File: " + _assetBundleName + " error:" + _request.error);
                }
                else
                {
                    AssetbundleRef _ref = new AssetbundleRef();
                    _ref.data = DownloadHandlerAssetBundle.GetContent(_request);
                    m_dicRefCache.Add(_assetBundleName, _ref);
                }
                m_lRequests.Remove(_request);
            }
        }
        //获取资源包路径//
        private string _ConverToUrlPath(string _assetName)
        {
            return string.Format("{0}/{1}", m_AssetsDownloadRoot, _assetName);
        }
        //获取资源包版本号//
        private uint _GetAssetbundleCrc(string _assetName)
        {
            AssetbundleVerInfo _info;
            if (m_dicVersionInfos.TryGetValue(_assetName, out _info))
                return _info.crc;

            return 0;
        }
        //获取资源包版本号//
        private int _GetVersionNum(string _assetName)
        {
            AssetbundleVerInfo _info;
            if (m_dicVersionInfos.TryGetValue(_assetName, out _info))
                return _info.versionNum;

            return -1;
        }
        private bool _CheckReady() { return m_MainManifest != null; }
        #endregion
    }
}