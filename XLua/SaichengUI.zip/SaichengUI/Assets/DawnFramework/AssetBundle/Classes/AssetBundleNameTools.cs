﻿using UnityEngine;
using System.Collections;
namespace DawnLib.Framework
{
    public static class AssetBundleNameTools
    {
        const string _subChar = "_";

        //根据文件名找到对应包名//
        public static string ConvertToAssetBundleName(string _fileName)
        {
            int _endIndex = _fileName.LastIndexOf("/");

            if (_endIndex > 0)
            {
                return _fileName.Substring(0, _endIndex).Replace('/', '_').ToLower() + ABConstValue.BundlesSuffix;
            }

            return string.Empty;
        }
        //获取依赖文件名（一般是打包输出的文件夹名）详见DawnLib.AssetBundleMaker.ConsteValue//
        public static string GetAssetBundleManifestName()
        {
            if (Application.platform == RuntimePlatform.WindowsEditor)
                return ABConstValue.TargetsStr[2];
            else if (Application.platform == RuntimePlatform.IPhonePlayer)
                return ABConstValue.TargetsStr[0];
            else if (Application.platform == RuntimePlatform.Android)
                return ABConstValue.TargetsStr[1];
            else
                return string.Empty;
        }
        //根据路径提取文件裸名//
        public static string GetFileName(string _filePath)
        {
            int _startIndex = _filePath.LastIndexOf("/") + 1;
            int _endIndex = _filePath.IndexOf('.', _startIndex);

            if (_endIndex < 0)
                _endIndex = _filePath.Length;

            return _filePath.Substring(_startIndex, _endIndex - _startIndex);
        }
    }
}