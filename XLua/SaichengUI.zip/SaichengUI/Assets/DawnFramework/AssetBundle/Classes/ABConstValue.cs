﻿using UnityEngine;

namespace DawnLib.Framework
{
    public static class ABConstValue
    {
        //文件夹名会用于生成MD5的字符判断，所有带有Version的路径/文件都不会生成MD5信息//
        public const string FolderName = "Version";
        public const string NumFile = "VersionNum.xml";
        public const string NumAssetBundle = "VersionNum.assetbundle";
        public const string MD5FileName = "/VersionMD5.xml";
        public const string MD5FileName_old = "/VersionMD5-old.xml";

        public const string CRCFileName = "/VersionCRC.xml";

        public static string PathSet = Application.dataPath + "/DawnFramework/AssetBundle/Editor/Paths.xml";

        public static string[] TargetsStr = { "iOS", "Android", "Win" };
        public static string[] packageSuffix = { ".ipa", ".apk", ".exe" };
        public const string BundlesSuffix = ".unity3d";
    }
}