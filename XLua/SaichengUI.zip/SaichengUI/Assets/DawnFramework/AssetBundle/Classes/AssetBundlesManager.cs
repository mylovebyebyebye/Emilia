﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Xml;
using DawnLib;

namespace DawnLib.Framework
{
    /// <summary>
    /// 已弃用的WWW加载方式的资源管理
    /// </summary>
    public class AssetBundlesManager
    {
        public delegate IEnumerator LoadOverCallback(string _resName);
        public bool IsAllReady { get { return MainManifest && m_dicVersionNum.Count > 0; } }
        public float LoadProgress
        {
            get
            {
                if (m_dicLoadingReq.Count > 0)
                {
                    float _progress = 0;

                    for (int i = 0; i < m_dicLoadingReq.Count; i++)
                        _progress += m_dicLoadingReq[i].progress;

                    return _progress / m_dicLoadingReq.Count;
                }
                else
                    return 1;
            }
        }
        public string LoadingTarget
        {
            get
            {
                for (int i = 0; i < m_dicLoadingReq.Count; i++)
                    if (m_dicLoadingReq[i].progress > 0 && m_dicLoadingReq[i].progress < 1)
                        return m_dicLoadingReq[i].assetBundleName;

                return string.Empty;
            }
        }
        //-------------------------------------------------------------------------------//
        #region /***私有成员***/
        class WWWLoader
        {
            private WWWLoader() { }
            static Stack<WWWLoader> m_loaderPool;
            public static WWWLoader create(string _assertBundleName)
            {
                WWWLoader _pRet = null;
                if (m_loaderPool != null && m_loaderPool.Count > 0)
                    _pRet = m_loaderPool.Pop();
                else
                    _pRet = new WWWLoader();

                _pRet.assetBundleName = _assertBundleName;

                return _pRet;
            }
            AssetBundle m_AssetBundle;
            WWW m_WWW;
            private int _retainCount = 0;
            public string assetBundleName { private set; get; }
            public bool IsDone { get { return m_WWW != null && m_WWW.isDone && m_AssetBundle != null; } }
            public float progress { get { if (m_WWW == null) return 0; if (IsDone) return 1; return m_WWW.progress; } }
            public AssetBundle assetBundle { get { return m_AssetBundle; } }
            public IEnumerator LoadAndRetain(string _url, int _version)
            {
                if (m_WWW == null)
                {
                    _retainCount = 1;

                    if (_version > 0)
                    {
                        m_WWW = WWW.LoadFromCacheOrDownload(_url, _version);

                        while (m_WWW.isDone == false)
                            yield return null;
                    }
                    else
                    {
                        m_WWW = new WWW(_url);
                        yield return m_WWW;
                    }
                    m_AssetBundle = m_WWW.assetBundle;

                    //
                }
                else
                {
                    _retainCount++;

                    while (m_WWW.isDone == false)
                        yield return null;
                }
            }
            public bool Remove(bool isUnloadAB = true)
            {
                _retainCount--;
                if (_retainCount <= 0)
                {
                    if (m_AssetBundle && isUnloadAB)
                        m_AssetBundle.Unload(false);

                    m_WWW.Dispose();
                    m_WWW = null;

                    if (m_loaderPool == null)
                        m_loaderPool = new Stack<WWWLoader>();
                    m_loaderPool.Push(this);
                    return true;
                }
                return false;
            }
        }
        class LoadRequest
        {
            public LoadRequest(string _resName, string _bundleName, LoadOverCallback _callback)
            {
                ResName = _resName;
                OverCallback = _callback;
                BundleName = _bundleName;
            }
            public string ResName;
            public string BundleName;
            public LoadOverCallback OverCallback;
        }
        // 已解压的Asset列表 [prefabPath, asset]//
        private Dictionary<string, Object> m_dicAssets = new Dictionary<string, Object>();
        // "正在"加载的资源列表 [bundleName, www]//
        private List<WWWLoader> m_dicLoadingReq = new List<WWWLoader>();
        private Dictionary<string, int> m_dicVersionNum = new Dictionary<string, int>();
        private AssetBundleManifest MainManifest { get { return this.GetResource<AssetBundleManifest>(m_manifestName); } }
        private List<LoadRequest> m_vecLoadRequests;
        private string m_AssetUrl;
        private const string m_manifestName = "AssetBundleManifest";
        #endregion
        //-------------------------------------------------------------------------------//
        public void InitABMgr(int _resversion, string _url)
        {
            if (string.IsNullOrEmpty(_url))
                Debug.LogError("<AssetBundlesManager> URL == null");

            m_AssetUrl = _url;
            CGlobal.Sche.StartCoroutine(_InitWithVersionData(_resversion, m_AssetUrl + "/Version/VersionNum.xml"));
        }
        public bool IsHadVersion(string _asset)
        {
            return IsAllReady && _GetVersionNum(AssetBundleNameTools.ConvertToAssetBundleName(_asset)) > 0;
        }
        public T GetResource<T>(string _name) where T : Object
        {
            return GetResource(_name) as T;
        }
        public Object GetResource(string _name)
        {
            Object obj = null;

            _name = AssetBundleNameTools.GetFileName(_name);

            if (m_dicAssets.TryGetValue(_name, out obj) == false)
            {
                if (_name == m_manifestName)
                    Debug.Log("<GetResource> 依赖文件加载中.....");
                else
                    Debug.LogWarning("<GetResource>没有找到资源： " + _name);
            }
            return obj;
        }
        public IEnumerator SimpleLoadAssetBundle(string _assetBundleName, System.Action<AssetBundle> _callback)//
        {
            while (IsAllReady == false)
                yield return null;

            yield return _Load(_assetBundleName, null);

            WWWLoader _wwwloader;
            if (_GetLoadingWWW(_assetBundleName, out _wwwloader))
                _callback(_wwwloader.assetBundle);

            if (_wwwloader.Remove(false))//近移除Loader不移除AB//
                m_dicLoadingReq.Remove(_wwwloader);
        }
        public IEnumerator LoadAsset(string _name)
        {
            while (IsAllReady == false)
                yield return null;

            if (IsResLoaded(_name) == false)
            {
                string _assetBundleName = AssetBundleNameTools.ConvertToAssetBundleName(_name);

                _name = AssetBundleNameTools.GetFileName(_name);

                if (string.IsNullOrEmpty(_assetBundleName) == false)
                {
                    yield return _LoadAssets(_assetBundleName, _name, null);
                }
            }

        }
        public IEnumerator LoadAssets(string[] _names)
        {
            while (IsAllReady == false)
                yield return null;

            List<string> _lassetName = new List<string>();
            for (int i = 0; i < _names.Length; i++)
            {
                string _name = AssetBundleNameTools.GetFileName(_names[i]);
                string _assetBundleName = AssetBundleNameTools.ConvertToAssetBundleName(_names[i]);

                if (string.IsNullOrEmpty(_assetBundleName) == false && IsResLoaded(_name) == false)
                {
                    yield return _Load(_assetBundleName, _name);

                    WWWLoader _wwwloader;
                    if (_GetLoadingWWW(_assetBundleName, out _wwwloader))
                    {
                        //缓存目标资源//
                        this._AddAssetCache(_wwwloader.assetBundle, _name);

                        if (_lassetName.Contains(_assetBundleName) == false)
                            _lassetName.Add(_assetBundleName);
                    }
                }
            }
            for (int i = 0; i < _lassetName.Count; i++)
                _RemoveBundleLoader(_lassetName[i]);

        }
        public void LoadAsset(string _name, LoadOverCallback _callback)
        {
            string _assetBundleName = AssetBundleNameTools.ConvertToAssetBundleName(_name);
            _name = AssetBundleNameTools.GetFileName(_name);

            if (string.IsNullOrEmpty(_assetBundleName))
                return;


            if (IsAllReady == false)
            {
                if (m_vecLoadRequests == null)
                    m_vecLoadRequests = new List<LoadRequest>();

                if (!m_vecLoadRequests.Exists((x) => { return x.ResName == _name; }))
                    m_vecLoadRequests.Add(new LoadRequest(_name, _assetBundleName, _callback));

                return;
            }
            if (IsResLoaded(_name))
                CGlobal.Sche.StartCoroutine(_callback(_name));
            else
                CGlobal.Sche.StartCoroutine(_LoadAssets(_assetBundleName, _name, _callback));
        }
        public void UnLoadAsset(Object _target)
        {

            foreach (var _pair in m_dicAssets)
            {
                if (_pair.Value == _target)
                {
                    this._RemoveBundleLoader(AssetBundleNameTools.ConvertToAssetBundleName(_pair.Key));
                    m_dicAssets.Remove(_pair.Key);
                    return;
                }
            }
        }
        public void UnLoadAsset(string _name)
        {
            this._RemoveBundleLoader(AssetBundleNameTools.ConvertToAssetBundleName(_name));

            m_dicAssets.Remove(AssetBundleNameTools.GetFileName(_name));
        }
        public bool IsResLoaded(string _name)
        {
            return m_dicAssets.ContainsKey(_name);
        }
        public IEnumerator GetVersionDownloadList(List<string> _download)
        {
            while (IsAllReady == false)//等待版本文件加载成功//
                yield return null;

            _download.Clear();
            foreach (var _keyValue in m_dicVersionNum)
            {
                //根据包名，获取完整路径//
                string url = _ConverToUrlPath(_keyValue.Key);
                //获取版本号//
                int verNum = _keyValue.Value;

                if (Caching.IsVersionCached(url, verNum) == false)
                {
                    _download.Add(_keyValue.Key);
                }
            }
        }
        public IEnumerator Download(string _assetBundleName)
        {
            WWWLoader _wwwloader;

            if (_GetLoadingWWW(_assetBundleName, out _wwwloader) == false)
            {
                _wwwloader = WWWLoader.create(_assetBundleName);
            }
            //根据包名，获取完整路径//
            string url = _ConverToUrlPath(_assetBundleName);
            //获取版本号//
            int verNum = _GetVersionNum(_assetBundleName);

            yield return _wwwloader.LoadAndRetain(url, verNum);

            if (_wwwloader.Remove())
                m_dicLoadingReq.Remove(_wwwloader);
        }
        public void Clear()
        {
            if (IsAllReady == false)
                return;

            var _manifest = MainManifest;
            m_dicAssets.Clear();
            m_dicAssets.Add(m_manifestName, _manifest);
        }
        //-------------------------------------------------------------------------------//
        #region /***私有函数***/
        private IEnumerator _InitWithVersionData(int version, string _url)
        {
            if (_url.Contains("://") == false)
            {
                Debug.LogError("<_InitWithVersionData>  Url Error");
                yield break;
            }

            using (WWW www = WWW.LoadFromCacheOrDownload(_url, version))
            {
                yield return www;

                // 如果文件不存在，则直接返回//
                if (!string.IsNullOrEmpty(www.text))
                {
                    //根据XML加载版本信息//
                    XmlDocument XmlDoc = new XmlDocument();
                    XmlDoc.LoadXml(www.text);
                    XmlElement XmlRoot = XmlDoc.DocumentElement;

                    foreach (XmlNode node in XmlRoot.ChildNodes)
                    {
                        if ((node is XmlElement) == false)
                            continue;
                        string file = (node as XmlElement).GetAttribute("FileName");
                        int num = int.Parse((node as XmlElement).GetAttribute("Num"));

                        if (m_dicVersionNum.ContainsKey(file) == false)
                        {
                            m_dicVersionNum.Add(file, num);
                        }
                        else
                            m_dicVersionNum[file] = num;
                    }
                    XmlDoc = null;
                }
                else
                    Debug.LogError("<AssetBundlesManager> 版本文件获取失败，检查路径资源包文件是否健全\n" + www.error);
            }
            //加载依赖文件//
            yield return _LoadAssets(AssetBundleNameTools.GetAssetBundleManifestName(), "AssetBundleManifest", null);

            //等待前置工作全部完成//
            while (IsAllReady == false)
                yield return null;

            if (m_vecLoadRequests != null && m_dicVersionNum.Count != 0)
            {
                for (int i = 0; i < m_vecLoadRequests.Count; i++)
                {
                    var _request = m_vecLoadRequests[i];

                    yield return _LoadAssets(_request.BundleName, _request.ResName, _request.OverCallback);
                }
                m_vecLoadRequests = null;
            }
        }
        //-------------------------------------------------------------------------------//
        private IEnumerator _LoadAssets(string _assetBundleName, string _name, LoadOverCallback _callback)
        {
            yield return _Load(_assetBundleName, _name);

            WWWLoader _wwwloader;

            if (_GetLoadingWWW(_assetBundleName, out _wwwloader))
            {
                //Loading主资源//
                this._AddAssetCache(_wwwloader.assetBundle, _name);

                if (_callback != null)
                    yield return _callback(_name);

                this._RemoveBundleLoader(_assetBundleName);
            }
        }
        private IEnumerator _Load(string _assetBundleName, string _name)
        {
            //根据包名，获取完整路径//
            string url = _ConverToUrlPath(_assetBundleName);
            //获取版本号//
            int verNum = _GetVersionNum(_assetBundleName);

            if (verNum <= 0)
                Debug.Log("<VersionNum>获取版本号失败 没有资源包：" + _assetBundleName);
            else
            {
                //判断版本是否已经被缓存//
                if (Caching.IsVersionCached(url, verNum) == false)
                {
#if UNITY_EDITOR
                    Debug.Log("Version Is not Cached, which will download from net!" + url);
#endif
                }
                //创建或获取加载器//
                WWWLoader _wwwloader;

                if (_GetLoadingWWW(_assetBundleName, out _wwwloader) == false)
                {
                    _wwwloader = WWWLoader.create(_assetBundleName);
                    m_dicLoadingReq.Add(_wwwloader);
#if UNITY_EDITOR
                    Debug.Log("<开始加载> 资源包：" + _assetBundleName);
#endif
                }
                yield return _wwwloader.LoadAndRetain(url, verNum);

                // 加载所有的依赖资源//
                if (MainManifest != null)
                {
                    string[] _DependenciesName = MainManifest.GetAllDependencies(_assetBundleName);
                    for (int i = 0; i < _DependenciesName.Length; i++)
                        yield return _Load(_DependenciesName[i], string.Empty);
                }

#if UNITY_EDITOR
                Debug.Log("<完毕> 资源包：" + _assetBundleName);
#endif
            }
        }
        private void _RemoveBundleLoader(string _assetBundleName)
        {
            if (string.IsNullOrEmpty(_assetBundleName))
                return;

            WWWLoader _wwwloader;

            if (_GetLoadingWWW(_assetBundleName, out _wwwloader) && _wwwloader.Remove())
            {
                m_dicLoadingReq.Remove(_wwwloader);

                // 加载所有的依赖资源//
                string[] _DependenciesName = MainManifest.GetAllDependencies(_assetBundleName);

                for (int i = 0; i < _DependenciesName.Length; i++)
                    this._RemoveBundleLoader(_DependenciesName[i]);
            }
        }
        private void _AddAssetCache(AssetBundle _bundle, string _resName)
        {
            if (!string.IsNullOrEmpty(_resName) && _bundle)
            {
#if UNITY_EDITOR
                Debug.Log("<Loading> _AddAssetCache 资源：" + _resName);
#endif
                Object _res = _bundle.LoadAsset(_resName);

                if (_res)
                    m_dicAssets.Add(_resName, _res);
            }
        }
        //-------------------------------------------------------------------------------//
        //获取资源包路径//
        private string _ConverToUrlPath(string _assetName)
        {
            return string.Format("{0}/{1}", m_AssetUrl, _assetName);
        }
        //获取资源包版本号//
        private int _GetVersionNum(string _assetName)
        {
            int _num;
            m_dicVersionNum.TryGetValue(_assetName, out _num);
            return _num;
        }
        private bool _GetLoadingWWW(string _assetBundleName, out WWWLoader _loader)
        {
            _loader = m_dicLoadingReq.Find(x => x.assetBundleName == _assetBundleName);
            return _loader != null;
        }
        #endregion
        //-------------------------------------------------------------------------------//
    }
}