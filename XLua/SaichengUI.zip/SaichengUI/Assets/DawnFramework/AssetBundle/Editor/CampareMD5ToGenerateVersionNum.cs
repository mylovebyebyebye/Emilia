﻿using System.Xml;
using System.Collections.Generic;
/************************** 
     * 文件名:CampareMD5ToGenerateVersionNum.cs; 
     * 文件描述:对比MD5码生成版本号
     * 创建日期:2016/11/23; 
     * Author:董峻铭; 
     ***************************/
namespace DawnLib.Framework.AssetBundleMaker
{
    public class CampareMD5ToGenerateVersionNum
    {
        // 对比对应版本目录下的VersionMD5和VersionMD5-old，得到最新的版本号文件VersionNum.xml
        public static void Execute(string _outPath)
        {
            _outPath = _outPath + "/";

            // 获取MD5记录文件路径 *2//
            //新//
            string newVersionMD5 = _outPath + ABConstValue.FolderName + ABConstValue.MD5FileName;
            //旧//
            string oldVersionMD5 = _outPath + ABConstValue.FolderName + ABConstValue.MD5FileName_old;

            Dictionary<string, string> dicNewMD5Info = ReadMD5File(newVersionMD5);
            Dictionary<string, string> dicOldMD5Info = ReadMD5File(oldVersionMD5);

            // 读取版本号记录文件VersinNum.xml
            string _VersionNumPath = _outPath + ABConstValue.FolderName + '/' + ABConstValue.NumFile;

            Dictionary<string, int> dicVersionNumInfo = ReadVersionNumFile(_VersionNumPath);
            Dictionary<string, uint> dicFileCrc = new Dictionary<string, uint>();

            // 对比新旧MD5信息，并更新版本号，即对比dicNewMD5Info&&dicOldMD5Info来更新dicVersionNumInfo
            foreach (KeyValuePair<string, string> newPair in dicNewMD5Info)
            {
#if UNITY_5_5_OR_NEWER
                string _fileName = _outPath + newPair.Key;
                uint fileCrc;
                if (UnityEditor.BuildPipeline.GetCRCForAssetBundle(_fileName, out fileCrc))
                    dicFileCrc.Add(newPair.Key, fileCrc);
#endif
                // 旧版本中有
                if (dicOldMD5Info.ContainsKey(newPair.Key))
                {
                    // MD5一样，则不变
                    // MD5不一样，则+1
                    // 容错：如果新旧MD5都有，但是还没有版本号记录的，则直接添加新纪录，并且将版本号设为1
                    if (dicVersionNumInfo.ContainsKey(newPair.Key) == false)
                    {
                        dicVersionNumInfo.Add(newPair.Key, 1);
                    }
                    else if (newPair.Value != dicOldMD5Info[newPair.Key])
                    {
                        dicVersionNumInfo[newPair.Key]++;
                    }
                }
                else if (dicVersionNumInfo.ContainsKey(newPair.Key) == false)
                {
                    // 旧版本中没有，则添加新纪录，并=1//
                    dicVersionNumInfo.Add(newPair.Key, 1);
                }
            }
            // 不可能出现旧版本中有，而新版本中没有的情况，原因见生成MD5List的处理逻辑//

            // 存储最新的VersionNum.xml
            SaveVersionNumFile(dicVersionNumInfo,dicFileCrc, _VersionNumPath);
        }

        static Dictionary<string, string> ReadMD5File(string fileName)
        {
            Dictionary<string, string> DicMD5 = new Dictionary<string, string>();

            // 如果文件不存在，则直接返回//
            if (System.IO.File.Exists(fileName) == false)
                return DicMD5;

            XmlDocument XmlDoc = new XmlDocument();
            XmlDoc.Load(fileName);
            XmlElement XmlRoot = XmlDoc.DocumentElement;

            foreach (XmlNode node in XmlRoot.ChildNodes)
            {
                if ((node is XmlElement) == false)
                    continue;

                string file = (node as XmlElement).GetAttribute("FileName");
                string md5 = (node as XmlElement).GetAttribute("MD5");

                if (DicMD5.ContainsKey(file) == false)
                {
                    DicMD5.Add(file, md5);
                }
            }

            XmlRoot = null;
            XmlDoc = null;

            return DicMD5;
        }

        static Dictionary<string, int> ReadVersionNumFile(string fileName)
        {
            Dictionary<string, int> DicVersionNum = new Dictionary<string, int>();

            // 如果文件不存在，则直接返回
            if (System.IO.File.Exists(fileName) == false)
                return DicVersionNum;

            XmlDocument XmlDoc = new XmlDocument();
            XmlDoc.Load(fileName);
            XmlElement XmlRoot = XmlDoc.DocumentElement;

            foreach (XmlNode node in XmlRoot.ChildNodes)
            {
                if ((node is XmlElement) == false)
                    continue;

                string file = (node as XmlElement).GetAttribute("FileName");
                int num = XmlConvert.ToInt32((node as XmlElement).GetAttribute("Num"));

                if (DicVersionNum.ContainsKey(file) == false)
                {
                    DicVersionNum.Add(file, num);
                }
            }

            XmlRoot = null;
            XmlDoc = null;

            return DicVersionNum;
        }

        static void SaveVersionNumFile(Dictionary<string, int> data,Dictionary<string,uint> crcData, string savePath)
        {
            XmlDocument XmlDoc = new XmlDocument();
            XmlElement XmlRoot = XmlDoc.CreateElement(ABConstValue.NumFile);
            XmlDoc.AppendChild(XmlRoot);

            foreach (KeyValuePair<string, int> pair in data)
            {
                XmlElement xmlElem = XmlDoc.CreateElement("File");
                XmlRoot.AppendChild(xmlElem);
                xmlElem.SetAttribute("FileName", pair.Key);
                xmlElem.SetAttribute("Num", XmlConvert.ToString(pair.Value));
#if UNITY_5_5_OR_NEWER
                if (crcData.ContainsKey(pair.Key))
                    xmlElem.SetAttribute("CRC", XmlConvert.ToString(crcData[pair.Key]));
                else
                    xmlElem.SetAttribute("CRC", "0");
#endif
            }

            XmlDoc.Save(savePath);
            XmlRoot = null;
            XmlDoc = null;
        }

    }
}