﻿using UnityEngine;
using UnityEditor;
using System.IO;

namespace DawnLib.Framework.AssetBundleMaker
{
    public class ToPackageMenu : ScriptableObject
    {
        [MenuItem("DawnLib/Package/Editor", false, -1000)]
        public static void OpenPackageEditor()
        {
            Caching.CleanCache();

            EditorWindow _window = EditorWindow.GetWindow(typeof(ToPackageWindow), true, "打包配置");
            _window.Show();
        }
        [MenuItem("DawnLib/Package/AssetsPaths", false, -900)]
        static void OpenAssetBundlePathsEditor()
        {
            ToPackagePathWindow _window = EditorWindow.GetWindow(typeof(ToPackagePathWindow), true, "路径设置") as ToPackagePathWindow;
            _window.InitWindow();
            _window.Show();
        }
        [MenuItem("DawnLib/Package/Move to tempDir", false, 500)]
        static void MoveToTempDir()
        {
            string _targetDir = Application.dataPath + "/temp/";
            foreach (var _dir in ToPackagePathWindow.GetPackagePaths())
            {
                if (Directory.Exists(_dir))
                {
                    string _newDir = _targetDir + _dir.Replace(Application.dataPath, "").Replace("/", "_");

                    if (Directory.Exists(_newDir) == false)
                        Directory.CreateDirectory(_newDir);

                    _seekMoveFiles(_dir, _newDir);

                    Directory.Delete(_dir, true);
                }
            }
            AssetDatabase.Refresh();

            Debug.Log("<MoveToTempDir> 成功把资源文件移除，打包完毕后要将其归位");
        }
        [MenuItem("DawnLib/Package/Move to ResourceDir", false, 501)]
        static void MoveToSourceDir()
        {
            string _targetDir = Application.dataPath + "/temp/";

            if (!Directory.Exists(_targetDir))
                return;

            foreach (var dir in ToPackagePathWindow.GetPackagePaths())
            {
                string _newDir = _targetDir + dir.Replace(Application.dataPath, "").Replace("/", "_");

                if (Directory.Exists(_newDir) == false)
                    Directory.CreateDirectory(_newDir);

                _seekMoveFiles(_newDir, dir);
            }
            Directory.Delete(_targetDir, true);

            AssetDatabase.Refresh();
        }
        static void _seekMoveFiles(string _from, string _to)
        {
            if (Directory.Exists(_to) == false)
                Directory.CreateDirectory(_to);

            string[] _folders = Directory.GetDirectories(_from);

            foreach (var folder in _folders)
            {
                string _toFolder = _to + folder.Substring(_from.Length, folder.Length - _from.Length);

                _seekMoveFiles(folder, _toFolder);
            }

            string[] _files = Directory.GetFiles(_from);

            foreach (var file in _files)
            {
                if (file.EndsWith(".meta"))
                    continue;

                string _fileName = file.Substring(_from.Length, file.Length - _from.Length);
                string _toPath = _to + _fileName;

                System.IO.File.Move(file, _toPath);
            }
        }

        [MenuItem("DawnLib/Package/CleanUp", false, 1000)]
        static void ClearCache()
        {
            Caching.CleanCache();

            if (Directory.Exists(PlayerPrefs.GetString("AssetUrl")))
            {
                Directory.Delete(PlayerPrefs.GetString("AssetUrl"), true);
            }

            if (Directory.Exists(Application.streamingAssetsPath))
                Directory.Delete(Application.streamingAssetsPath, true);

            if (Directory.Exists(Application.dataPath+"/temp"))
                Directory.Delete(Application.dataPath + "/temp", true);

            AssetDatabase.Refresh();
        }
    }
}