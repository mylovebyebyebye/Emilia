﻿using UnityEngine;
using UnityEditor;
using DawnLib.Framework;
using System.IO;
/************************** 
     * 文件名:AutoSetAssetsBundleName.cs; 
     * 文件描述:自动设置AssetbundleName 
     * 创建日期:2015/10/13; 
     * Author:董峻铭; 
     ***************************/
namespace DawnLib.Framework.AssetBundleMaker
{
    public class AutoSetAssetsBundleName
    {
        public static void Execute(bool setOrClear, bool isLog = false)
        {
            var _pathList = ToPackagePathWindow.GetPackagePaths();

            for (int i = 0; i < _pathList.Count; i++)
            {
                if (!Directory.Exists(_pathList[i]))
                    Debug.LogError("<AutoSetAssetsBundleName>没有找到打包路径 确认是否在Temp中");

                _SeekFilesSetAssertBundleName(_pathList[i], _pathList[i], isLog, setOrClear);
            }
        }
        static void _SeekFilesSetAssertBundleName(string root, string _currentFolder, bool isLog, bool setOrClear)
        {
            string[] childrenFolder = Directory.GetDirectories(_currentFolder);
            for (int i = 0; i < childrenFolder.Length; i++)
                _SeekFilesSetAssertBundleName(root, childrenFolder[i], isLog, setOrClear);

            string[] files = Directory.GetFiles(_currentFolder);

            for (int i = 0; i < files.Length; i++)
            {
                AssetImporter importer = AssetImporter.GetAtPath(files[i].Replace(Application.dataPath, "Assets"));

                if (importer == null)
                    continue;
                if (!setOrClear)
                {
                    importer.assetBundleName = null;
                    continue;
                }
                string assetPath = files[i].Replace("\\", "/");

                assetPath = assetPath.Substring(root.Length + 1, assetPath.Length - root.Length - 1);

                //包名为前缀//
                importer.assetBundleName = AssetBundleNameTools.ConvertToAssetBundleName(assetPath);

                if (isLog && !string.IsNullOrEmpty(importer.assetBundleName))
                    Debug.Log(string.Format("资源：{0} 封至包：{1}", importer.assetPath, importer.assetBundleName));
            }
        }
    }
}
