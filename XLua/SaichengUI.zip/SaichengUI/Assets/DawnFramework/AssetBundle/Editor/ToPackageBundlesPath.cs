﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.IO;
using System.Xml;

namespace DawnLib.Framework.AssetBundleMaker
{
    public class ToPackageBundlesPath : EditorWindow
    {
        public static List<string> GetPackagePaths()
        {
            if (m_targetPaths == null)
            {
                m_targetPaths = new List<string>();
                InitWithXML(m_targetPaths);
            }

            return m_targetPaths;
        }
        static List<string> m_targetPaths = null;
        public void InitWindow()
        {
            if (m_targetPaths == null)
                m_targetPaths = new List<string>();
            else
                m_targetPaths.Clear();

            InitWithXML(m_targetPaths);
        }
        void OnGUI()
        {
            GUILayout.Space(10);
            EditorGUILayout.PrefixLabel("Paths：");
            GUILayout.Space(10);

            for (int i = 0; i < GetPackagePaths().Count; i++)
            {
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button(m_targetPaths[i], GUILayout.Height(30)))
                {
                    string _newPath = EditorUtility.SaveFolderPanel("受管理路径", Application.dataPath, "");
                    if (!string.IsNullOrEmpty(_newPath))
                        m_targetPaths[i] = _newPath;
                }
                if (GUILayout.Button("移除路径", GUILayout.Height(30)))
                {
                    m_targetPaths[i] = null;
                }
                if (m_targetPaths[i] == null)
                {
                    m_targetPaths.RemoveAt(i);
                    break;
                }
                EditorGUILayout.EndHorizontal();

                GUILayout.Space(5);
            }
            if (GUILayout.Button("添加新路径", GUILayout.Height(30)))
            {
                string _newPath = EditorUtility.SaveFolderPanel("受管理路径", Application.dataPath, "");
                if (!string.IsNullOrEmpty(_newPath))
                    m_targetPaths.Add(_newPath);
            }
            GUILayout.Space(10);

            EditorGUILayout.BeginHorizontal();

            if (GUILayout.Button("预览包名", GUILayout.Height(30)))
            {
                AutoSetAssetsBundleName.Execute(true, true);
                AutoSetAssetsBundleName.Execute(false);

                this.ShowNotification(new GUIContent("看Console窗口"));
            }

            if (GUILayout.Button("完成", GUILayout.Height(30)))
            {
                this.SaveXML();
                this.Close();
            }
            EditorGUILayout.EndHorizontal();
        }
        private void SaveXML()
        {
            if (File.Exists(ABConstValue.PathSet))
                System.IO.File.Delete(ABConstValue.PathSet);

            XmlDocument XmlDoc = new XmlDocument();
            XmlElement xmlRoot = XmlDoc.CreateElement("Path");
            XmlDoc.AppendChild(xmlRoot);

            for (int i = 0; i < m_targetPaths.Count; i++)
            {
                XmlElement xmlElem = XmlDoc.CreateElement("T");
                xmlRoot.AppendChild(xmlElem);

                xmlElem.SetAttribute("P", m_targetPaths[i]);
            }
            XmlDoc.Save(ABConstValue.PathSet);
            XmlDoc = null;

            AssetDatabase.Refresh();
        }
        private static void InitWithXML(List<string> _list)
        {
            if (!File.Exists(ABConstValue.PathSet))
                return;

            XmlDocument XmlDoc = new XmlDocument();
            XmlDoc.Load(ABConstValue.PathSet);
            XmlElement xmlRoot = XmlDoc.DocumentElement;

            foreach (XmlNode node in xmlRoot.ChildNodes)
            {
                if ((node is XmlElement) == false)
                    continue;

                _list.Add((node as XmlElement).GetAttribute("P"));
            }
        }
    }
}