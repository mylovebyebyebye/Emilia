﻿using System.IO;
using System.Xml;
using System.Collections.Generic;
using System.Security.Cryptography;

/************************** 
     * 文件名:CreateMD5List.cs; 
     * 文件描述:创建文件MD5码列表
     * 创建日期:2015/11/23; 
     * Author:董峻铭; 
     ***************************/
namespace DawnLib.Framework.AssetBundleMaker
{
    public class CreateMD5List
    {
        public static void Execute(string _outPath)
        {
            _outPath = _outPath + "/";

            //用于存放MD5数据//
            Dictionary<string, string> DicFileMD5 = new Dictionary<string, string>();
            //生成MD5数据的类//
            MD5CryptoServiceProvider md5Generator = new MD5CryptoServiceProvider();

            foreach (string filePath in Directory.GetFiles(_outPath))
            {
                //无视.meta，xml以及版本文件//
                if (filePath.Contains(".manifest") || filePath.Contains(".meta") || filePath.Contains(ABConstValue.FolderName) || filePath.Contains(".xml"))
                    continue;

                using (FileStream file = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    //根据文件生成MD5//
                    byte[] hash = md5Generator.ComputeHash(file);
                    string strMD5 = System.BitConverter.ToString(hash);

                    string key = filePath.Substring(_outPath.Length, filePath.Length - _outPath.Length);

                    if (DicFileMD5.ContainsKey(key) == false)
                        DicFileMD5.Add(key, strMD5);
                    else
                        UnityEngine.Debug.LogWarning("<Two File has the same name> name = " + filePath);

                    file.Close();
                }

            }
            string savePath = System.IO.Path.Combine(_outPath, ABConstValue.FolderName);

            if (Directory.Exists(savePath) == false)
                Directory.CreateDirectory(savePath);

            // 删除前一版的old数据//
            if (File.Exists(savePath + ABConstValue.MD5FileName_old))
            {
                System.IO.File.Delete(savePath + ABConstValue.MD5FileName_old);
            }

            // 如果之前的版本存在，则将其名字改为VersionMD5-old.xml
            if (File.Exists(savePath + ABConstValue.MD5FileName))
            {
                System.IO.File.Move(savePath + ABConstValue.MD5FileName, savePath + ABConstValue.MD5FileName_old);
            }

            XmlDocument XmlDoc = new XmlDocument();
            XmlElement XmlRoot = XmlDoc.CreateElement("Files");
            XmlDoc.AppendChild(XmlRoot);
            foreach (KeyValuePair<string, string> pair in DicFileMD5)
            {
                XmlElement xmlElem = XmlDoc.CreateElement("File");
                XmlRoot.AppendChild(xmlElem);

                xmlElem.SetAttribute("FileName", pair.Key);
                xmlElem.SetAttribute("MD5", pair.Value);
            }

            // 读取旧版本的MD5
            Dictionary<string, string> dicOldMD5 = ReadMD5File(savePath + ABConstValue.MD5FileName_old);
            // VersionMD5-old中有，而VersionMD5中没有的信息，手动添加到VersionMD5
            foreach (KeyValuePair<string, string> pair in dicOldMD5)
            {
                if (DicFileMD5.ContainsKey(pair.Key) == false)
                    DicFileMD5.Add(pair.Key, pair.Value);
            }

            XmlDoc.Save(savePath + ABConstValue.MD5FileName);
            XmlDoc = null;
        }
        static Dictionary<string, string> ReadMD5File(string fileName)
        {
            Dictionary<string, string> DicMD5 = new Dictionary<string, string>();

            // 如果文件不存在，则直接返回
            if (System.IO.File.Exists(fileName) == false)
                return DicMD5;

            XmlDocument XmlDoc = new XmlDocument();
            XmlDoc.Load(fileName);
            XmlElement XmlRoot = XmlDoc.DocumentElement;

            foreach (XmlNode node in XmlRoot.ChildNodes)
            {
                if ((node is XmlElement) == false)
                    continue;

                string file = (node as XmlElement).GetAttribute("FileName");
                string md5 = (node as XmlElement).GetAttribute("MD5");

                if (DicMD5.ContainsKey(file) == false)
                {
                    DicMD5.Add(file, md5);
                }
            }

            XmlRoot = null;
            XmlDoc = null;

            return DicMD5;
        }
    }
}
