﻿using UnityEngine;
using UnityEditor;
/************************** 
     * 文件名:BuildPlayerHelper.cs; 
     * 文件描述:打包输出
     * 创建日期:2015/10/13; 
     * Author:董峻铭; 
     ***************************/
namespace DawnLib.Framework.AssetBundleMaker
{
    public class BuildPlayerHelper
    {
        public static void Execute(ToPackageWindow _windows)
        {
            string _targetPath = EditorPrefs.GetString("BuildPlayerHelper");

            _targetPath = EditorUtility.SaveFolderPanel("输出目录", _targetPath, "");
            if (string.IsNullOrEmpty(_targetPath))
                return;

            EditorPrefs.SetString("BuildPlayerHelper",_targetPath);

            _targetPath = _targetPath + "/" + Application.productName + ABConstValue.packageSuffix[_windows.TargetIndex()];

            BuildPlayerOptions buildPlayerOptions = new BuildPlayerOptions();
            buildPlayerOptions.scenes = EditorBuildSettingsScene.GetActiveSceneList(EditorBuildSettings.scenes);
            buildPlayerOptions.locationPathName = _targetPath;
            buildPlayerOptions.target = EditorUserBuildSettings.activeBuildTarget;
            buildPlayerOptions.options = BuildOptions.None;

            BuildPipeline.BuildPlayer(buildPlayerOptions);
        }
    }
}