﻿#define USE_LUA
using UnityEngine;
using UnityEditor;

/************************** 
     * 文件名:ToPackageWindow.cs; 
     * 文件描述:配置打包信息
     * 创建日期:2015/10/20; 
     * Author:董峻铭; 
     ***************************/

namespace DawnLib.Framework.AssetBundleMaker
{
    public class ToPackageWindow : EditorWindow
    {
        private BuildTarget[] BuildTargets = { BuildTarget.iOS, BuildTarget.Android, BuildTarget.StandaloneWindows };
        public BuildTarget buildTarget
        {
            get
            {
                return (BuildTarget)EditorPrefs.GetInt("BuildTarget");
            }
            set
            {
                EditorPrefs.SetInt("BuildTarget", (int)value);
            }
        }
        private string m_outPath
        {
            get
            {
                return EditorPrefs.GetString("PublishPath");
            }
            set
            {
                EditorPrefs.SetString("PublishPath", value);
            }
        }
#if USE_LUA
        private bool IsPulishLuaExample
        {
            get
            {
                return PlayerPrefs.GetInt("LuaExample") == 1;
            }
            set
            {
                PlayerPrefs.SetInt("LuaExample", value ? 1 : 0);
            }
        }
#endif
        void OnGUI()
        {
            #region /***参数设置***/
            buildTarget = BuildTargets[EditorGUILayout.Popup("选择平台:", TargetIndex(), ABConstValue.TargetsStr)];
            if (buildTarget != EditorUserBuildSettings.activeBuildTarget)
            {
                if(EditorUserBuildSettings.SwitchActiveBuildTarget(buildTarget) == false)
                {
                    this.ShowNotification(new GUIContent("切换平台失败"));
                    buildTarget = EditorUserBuildSettings.activeBuildTarget;
                }
            }

            GUILayout.Space(10);

            EditorGUILayout.BeginHorizontal();

            EditorGUILayout.PrefixLabel("保存目录：");

            if (GUILayout.Button(m_outPath))
            {
                string _newPath = EditorUtility.SaveFolderPanel("创建文件夹", m_outPath, "");

                if (!string.IsNullOrEmpty(_newPath))
                    m_outPath = _newPath;
            }

            EditorGUILayout.EndHorizontal();

            GUILayout.Space(10);

            EditorGUILayout.BeginHorizontal();

            EditorGUILayout.PrefixLabel("下载根目录");//测试用加载目录//

            if (GUILayout.Button(PlayerPrefs.GetString("AssetUrl")))
            {
                string _newPath = EditorUtility.SaveFolderPanel("下载目录", PlayerPrefs.GetString("AssetUrl"), "");
                if (!string.IsNullOrEmpty(_newPath))
                    PlayerPrefs.SetString("AssetUrl", _newPath);
            }

            EditorGUILayout.EndHorizontal();

            GUILayout.Space(10);
            #endregion
            #region /***Lua相关***/
#if USE_LUA
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Clear lua wrap", GUILayout.Height(30)))
            {
                ToLuaMenu.ClearLuaFiles();
                ToLuaMenu.ClearLuaWraps();
            }
            if (GUILayout.Button("Gen Lua All", GUILayout.Height(30)))
                ToLuaMenu.GenLuaAll();
            EditorGUILayout.EndHorizontal();
            GUILayout.Space(10);

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.PrefixLabel("是否导出Example目录");
            IsPulishLuaExample = EditorGUILayout.Toggle(IsPulishLuaExample);
            EditorGUILayout.EndHorizontal();

            GUILayout.Space(10);

            GUILayout.Label("Step 1:");
            GUILayout.Space(10);

            if (GUILayout.Button("Publish Lua Files", GUILayout.Height(30)))
            {
                if (IsPulishLuaExample)
                    ToLuaMenu.CustomCopyLuaFiles(LuaConst.luaDir/*, LuaConst.toluaDir*/, LuaConst.exampleLuaDir);
                else
                    ToLuaMenu.CustomCopyLuaFiles(LuaConst.luaDir/*, LuaConst.toluaDir*/);
            }
            GUILayout.Space(10);
#endif
            #endregion
            GUILayout.Label("Step 2 :");
            GUILayout.Space(10);
            EditorGUILayout.BeginHorizontal();

            if (GUILayout.Button("Publish Assets Update", GUILayout.Height(30)))
                _PublishUpdateVersion(m_outPath);

            if (GUILayout.Button("Publish New Vision", GUILayout.Height(30)))
                _PublishReleaseVersion(Application.streamingAssetsPath);

            EditorGUILayout.EndHorizontal();

            GUILayout.Label("Step 3 :");
            GUILayout.Space(10);

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Enough", GUILayout.Height(30)))
                this.Close();

            if (GUILayout.Button("Export", GUILayout.Height(30)))
                BuildPlayerHelper.Execute(this);

            EditorGUILayout.EndHorizontal();
        }
        private void _PublishReleaseVersion(string _outPath)
        {
            if (!_outPath.Contains(ABConstValue.TargetsStr[TargetIndex()]))
                _outPath = string.Format("{0}/{1}", _outPath, ABConstValue.TargetsStr[TargetIndex()]);

            if (System.IO.Directory.Exists(_outPath) == false)
                System.IO.Directory.CreateDirectory(_outPath);

            BuildPipeline.BuildAssetBundles(_outPath,
                BuildAssetBundleOptions.ChunkBasedCompression //块加载//
                | BuildAssetBundleOptions.StrictMode //报错即停止//
                | BuildAssetBundleOptions.DisableWriteTypeTree//不包含类型信息//
                , buildTarget);
#if USE_LUA
            if (System.IO.Directory.Exists(Application.dataPath + "/temp") == false)
                Debug.LogWarning("Lua文件没有发布");
            else
                System.IO.Directory.Delete(Application.dataPath + "/temp", true);
#endif
            AssetDatabase.Refresh();

            this.ShowNotification(new GUIContent("发布 完成\n版本:"+Application.version));
        }
        private void _PublishUpdateVersion(string _outPath)
        {
            if (!_outPath.Contains(ABConstValue.TargetsStr[TargetIndex()]))
                _outPath = string.Format("{0}/{1}", _outPath, ABConstValue.TargetsStr[TargetIndex()]);

            if (System.IO.Directory.Exists(_outPath) == false)
                System.IO.Directory.CreateDirectory(_outPath);

            AutoSetAssetsBundleName.Execute(true, false);

            BuildPipeline.BuildAssetBundles(_outPath,
                BuildAssetBundleOptions.ChunkBasedCompression //块加载//
                | BuildAssetBundleOptions.StrictMode //报错即停止//
                | BuildAssetBundleOptions.DisableWriteTypeTree//不包含类型信息//
                , buildTarget);

            CreateMD5List.Execute(_outPath);

            CampareMD5ToGenerateVersionNum.Execute(_outPath);
#if USE_LUA
            if (System.IO.Directory.Exists(Application.dataPath + "/temp") == false)
                Debug.LogWarning("Lua文件没有发布");
            else
                System.IO.Directory.Delete(Application.dataPath + "/temp", true);
#endif
            AutoSetAssetsBundleName.Execute(false, false);

            AssetDatabase.Refresh();

            this.ShowNotification(new GUIContent("发布 完成"));
        }
        //获取平台下标//
        public int TargetIndex()
        {
            for (int i = 0; i < BuildTargets.Length; i++)
            {
                if (buildTarget == BuildTargets[i])
                    return i;
            }
            return 0;
        }
        void OnDestroy()
        {
            PlayerPrefs.Save();
        }
    }
}