﻿using System;
using System.Collections.Generic;
using Utility;
using System.IO;
#if UNITY_5
using UnityEngine;
#else
using log4net;
#endif

namespace Common
{
    public class GameLogHelper
    {
        private static object lockObj = new object();

        private static GameLogHelper instance = null;

        public static GameLogHelper Instance
        {
            get
            {
                lock (lockObj)
                {
                    if (instance == null)
                    {
                        instance = new GameLogHelper();
                    }
                }
                return instance;
            }
        }

        private bool isInit = false;

        private GameLogHelper()
        {
            Init();
        }

#if UNITY_5
#else
       private Dictionary<LogTypeEnum, ILog> dicLogger = new Dictionary<LogTypeEnum, ILog>();
#endif
        public bool Init()
        {
            if (!this.isInit)
            {
#if UNITY_5
#else
                LogHelper.Instance.SetConfig(new FileInfo(Config.GetConfig("log4netConfig")));

                ILog loginfo = log4net.LogManager.GetLogger("loginfo");
                ILog logerror = log4net.LogManager.GetLogger("logerror");
                ILog gamelogin = log4net.LogManager.GetLogger("gameloginfo");
                ILog topupinfo = log4net.LogManager.GetLogger("topupinfo");

                this.dicLogger.Add(LogTypeEnum.LogInfo, loginfo);
                this.dicLogger.Add(LogTypeEnum.LogError, logerror);
                this.dicLogger.Add(LogTypeEnum.GameLogInfo, gamelogin);
                this.dicLogger.Add(LogTypeEnum.TopupInfo, topupinfo);
#endif
                this.isInit = true;
                return true;
            }
            else
            {
                return false;
            }
        }

        public void AddLog(string str)
        {
#if UNITY_5
            Debug.Log(str);
#else
            ILog ilog = null;
            ilog = this.dicLogger[LogTypeEnum.LogInfo];
            LogHelper.Instance.WriteLog(ilog, LogLevelEnum.Info, str);
#endif
        }

        public void AddLog(string str, Exception se)
        {
#if UNITY_5
            Debug.Log(str);
#else
            ILog ilog = null;
            ilog = this.dicLogger[LogTypeEnum.LogError];
            LogHelper.Instance.WriteLog(ilog, str, se);
#endif
        }

        public void AddLog(LogTypeEnum TypeEnum, LogLevelEnum LevelEnum, string str)
        {
#if UNITY_5
            switch (TypeEnum)
            {
                case LogTypeEnum.LogError:
                    Debug.LogError(str);
                    break;
                case LogTypeEnum.TopupInfo:
                    Debug.LogWarning(str);
                    break;
                case LogTypeEnum.GameLogInfo:
                case LogTypeEnum.LogInfo:
                    Debug.Log(str);
                    break;
            }
#else
            ILog ilog = null;
            if (this.dicLogger.ContainsKey(TypeEnum))
            {
                ilog = this.dicLogger[TypeEnum];
            }
            else
            {
                ilog = this.dicLogger[LogTypeEnum.LogInfo];
            }
            LogHelper.Instance.WriteLog(ilog, LevelEnum, str);
#endif
        }
    }
}