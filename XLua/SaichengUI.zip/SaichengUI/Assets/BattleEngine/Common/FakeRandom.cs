﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common
{
    public class FakeRandom
    {
        int g_seed = 0;

        public FakeRandom()
        { }

        public void ClearSeed()
        {
            this.g_seed = 0;
        }

        public void SetSeed(int seed)
        {
            if (seed == 0)
            {
                this.g_seed = 0x11228866;
            }
            else
            {
                this.g_seed = seed;
            }
        }

        /// <summary>
        /// [min,max]
        /// </summary>
        /// <param name="min"></param>
        /// <param name="max"></param>
        /// <returns></returns>
        public int RandomInt(int min, int max)
        {
            if (this.g_seed == 0)
            {
                this.g_seed = 0x11228866;
            }
            this.g_seed = 214013 * g_seed + 2531011;
            int rnd = min + (this.g_seed ^ this.g_seed >> 15) % (max - min + 1);
            return rnd;
        }
    }
}
