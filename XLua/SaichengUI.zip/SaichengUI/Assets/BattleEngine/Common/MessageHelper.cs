﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common
{
    public enum MessageType
    {
        Info = 1,
        PlaybyPlay = 2,
    }

    public class MessageBody
    {
        public MessageType Type{get;set;}

        public string Msg{get;set;}

        public object Body { get; set; }

        public MessageBody(string msg)
            :this(MessageType.Info, msg, null)
        {
        }

        public MessageBody(MessageType type, string msg, object obj)
        {
            this.Type = type;
            this.Msg = msg;
            this.Body = obj;
        }
    }

    public class MessageHelper
    {
        public delegate void MessageHandler(MessageBody body);

        public static event MessageHandler MessageEvent;


        public static void SendMessage(MessageBody body)
        {
            if (MessageEvent != null)
            {
                MessageEvent(body);
            }
        }

        public static void SendMessage(string msg)
        {
            MessageBody body = new MessageBody(msg);
            SendMessage(body);
        }

    }
}
