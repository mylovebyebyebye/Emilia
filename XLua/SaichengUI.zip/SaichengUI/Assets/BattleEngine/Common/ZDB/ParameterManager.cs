﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Utility;
using Common;
using Common.ZDB;

namespace Common.ZDB
{
    public class ParameterManager
    {
        //private Dictionary<int, int> dicParam = new Dictionary<int, int>();

        private List<int> lstParam = new List<int>();


        private static ParameterManager instance = null;
        public static ParameterManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ParameterManager();
                }
                return instance;
            }
        }

        public bool Init()
        {
            try
            {
                ZDBTable paramTable = ZDataManager.Instance.getTable("parameter");

                for (int i = 0; i < paramTable.getRowCount(); i++)
                {
                    ZDB_Row_Data rowData = paramTable.getDataByRow(i);
                    int id = rowData.getCol(0).getValueInt();
                    int value = rowData.getCol(1).getValueInt();
                    if (id != i + 1)
                    {
                        throw new Exception("ParameterManager init error, id is discontinuity");
                        //return false;
                    }
                    lstParam.Add(value);
                }

                foreach (ParameterEnum item in Enum.GetValues(typeof(ParameterEnum)))
                {
                    int key = (int)item;
                    if (this.lstParam.Count < key)
                    {
                        throw new Exception(string.Format("ParameterManager init error, id {0} is missing", key));
                        //return false;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("ParameterManager init error ", ex);
            }
            return true;
        }

        public bool Reload()
        {
#if UNITY_5
            string szFileFullPath = "zdb/parameter";
            ZDBTable paramTable = ZDataManager.Instance.LoadTableByAbsPath(szFileFullPath);
            if (paramTable != null)
            {
                this.lstParam.Clear();
                this.Init();
            }
            else
                GameLogHelper.Instance.AddLog("ParameterManager Reload error");
#else
             try
            {
                string szPath = Config.GetConfig("zdbPath");
                string szFileFullPath = szPath + "parameter.zdb";
                ZDBTable paramTable = ZDataManager.Instance.LoadTableByAbsPath(szFileFullPath);
                this.lstParam.Clear();
                this.Init();
            }
            catch (Exception ex)
            {
                GameLogHelper.Instance.AddLog("ParameterManager Reload error", ex);
                return false;
            }
#endif
            return true;
        }

        public int GetValue(ParameterEnum param)
        {
            int key = (int)param;
            return this.lstParam[key - 1];
        }

        public double GetValueD(ParameterEnum param)
        {
            return this.GetValue(param) * 1.0;
        }
    }
}
