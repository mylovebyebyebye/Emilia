﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common.ZDB
{
    public enum ZDBTableName
    {
        parameter,
        player,
        stamina,
        speed_accelerate,
        speed_normal,
        speed_change,
        speed_up_distance,
        reb1,
        reb2,
        block_angle,
        block_distance,
        tactic_offensive,
        tactic_defensive,
        pickroll_type,
        pickroll_move,
        court_zone,
        playbook,
        stamina_cost,
        steal,
        steal_behave_type,
        steal_ball_speed_type,
        steals_ball_speed,
        floorball,
        floorball_speed,
        floorball_behave,
        floorball_type,
        fastbreak,
        defencetype,
        defencehelp,
        foul,
        live_text,
        team_rating,
        team_rating_inside,
        team_rating_outside,
        team_rating_rebound,
        shot,
        shot_before,
        shot_behave,
        shot_base,
        shot_block,
        shot_percentage,
        shot_fakepara,
        shot_index,
        shot__percentage_layup,
        shot__percentage_dunk,
        shot__percentage_insideshot,
        shot__percentage_jumpshot2,
        shot__percentage_jumpshot3,
        shot__contest_insideshot,
        shot__contest_layup,
        shot__contest_jumpshot2,
        shot__contest_jumpshot3,
        shot__contest_driving,
        shot__contest_insideshot_expectation,
        shot__contest_jumpshot2_expectation,
        shot__contest_jumpshot3_expectation,
        shot__range_insideshot,
        shot__range_driving,
        shot__range_jumpshot2,
        shot__range_jumpshot3,
        shot__range_insideshot_expectation,
        shot__range_jumpshot2_expectation,
        shot__range_jumpshot3_expectation,
        shot__reduction_shotcontest,
        shot__reduction_shotcontest_2p,
        shot__reduction_shotcontest_3p,
        shot__expectation_insideshot,
        shot__expectation_driving,
        shot__expectation_jumpshot2,
        shot__expectation_jumpshot3,
        playerlibrary,
        teamlogo,
        teamname,
        serverdict,
        schedule,
        autobots,
        substitution,
        substitution_type,
        substitution_type_condition,
        substitution_base_time,
        substitution_condition,
        generate_player_initial,
        country,
        countries__chinese_player_first_names,
        countries__chinese_player_last_names,
        league,
        league_matchtime,
        league_type,
        player_constant,
        player_attribute_caculate_order,
        player_attribute_comparation,
        cup_type,
        league_schedule,
        league_schedule_12,
        filter_keys_name,
#if UNITY_5 //客户端标识//
        ball_move,
#endif
    }

    public enum parameterFields
    {
        Id = 0,
        Value = 1,
        Unit = 2,
        Introduction = 3,
    }

    public enum playerFields
    {
        Id = 0,
        Name = 1,
        ShownNames = 2,
        Story = 3,
        PreferredZone = 4,
        Number = 5,
        StrongHand = 6,
        Speed = 7,
    }

    public enum staminaFields
    {
        Id,
        Speed0,
        Speed1,
        Speed2,
        Speed3,
        Speed4,
        Speed5,
        Speed6,
        Speed7,
        Speed8,
        Speed9,
        Speed10,
    }

    public enum speed_accelerateFields
    {
        Id,
        CurrentStamina,
        Speed0,
        Speed1,
        Speed2,
        Speed3,
        Speed4,
        Speed5,
        Speed6,
        Speed7,
        Speed8,
        Speed9,
        Speed10,
    }

    public enum speed_normalFields
    {
        Id,
        CurrentStamina,
        Speed0,
        Speed1,
        Speed2,
        Speed3,
        Speed4,
        Speed5,
        Speed6,
        Speed7,
        Speed8,
        Speed9,
        Speed10,
    }

    public enum reb1Fields
    {
        Id = 0,
        Number = 1,
    }

    public enum reb2Fields
    {
        Id = 0,
    }

    public enum block_angleFields
    {
        Id = 0,
        Angle = 1,
        Chance = 2,
    }

    public enum block_distanceFields
    {
        Id,
        Distance,
        Chance,
    }

    public enum tactic_offensiveFields
    {
        Id                          = 0,
        Name                        = 1,
        InsideIsolation             = 2,
        OutsideIsolation            = 3,
        Offball                     = 4,
        Pace                        = 5,
        FastBreak                   = 6,
        PickRoll                    = 7,
        PickRollType                = 8,
        FastBreak2                  = 9,
        AreaTestP1                  = 10,
        DistancePDivisor            = 11,
    }

    public enum percentage_layupFields
    {
        Id,
        Percentage,
    }

    public enum contest_layupFields
    {
        Id,
        Percentage,
    }

    public enum contest_jumpshot2Fields
    {
        Id,
        Percentage,
    }

    public enum contest_jumpshot3Fields
    {
        Id,
        Percentage,
    }

    public enum contest_insideshot_expectationFields
    {
        Id,
        Percentage,
    }

    public enum contest_jumpshot2_expectationFields
    {
        Id,
        Percentage,
    }

    public enum contest_jumpshot3_expectationFields
    {
        Id,
        Percentage,
    }

    public enum percentage_dunkFields
    {
        Id = 0,
        Percentage = 1,
    }

    public enum percentage_insideshotFields
    {
        Id,
        Percentage,
    }

    public enum percentage_jumpshot2Fields
    {
        Id,
        Percentage,
    }

    public enum percentage_jumpshot3Fields
    {
        Id,
        Percentage,
    }

    public enum contest_insideshotFields
    {
        Id,
        Percentage,
    }

    public enum range_jumpshot2Fields
    {
        Id,
        Distance1,
        Distance2,
        Percentage,
    }

    public enum range_jumpshot3Fields
    {
        Id,
        Distance1,
        Distance2,
        Percentage,
    }

    public enum range_insideshotFields
    {
        Id,
        Distance1,
        Distance2,
        Percentage,
    }

    public enum reduction_shotcontestFields
    {
        Id,
        Distance1,
        Distance2,
        Percentage,
    }

    public enum reduction_shotcontest_2pFields
    {
        Id,
        Distance1,
        Distance2,
        Percentage,
    }

    public enum reduction_shotcontest_3pFields
    {
        Id,
        Distance1,
        Distance2,
        Percentage,
    }

    public enum shotFields
    {
        Id = 0,
        Name = 1,
        StaminaCost = 2,
        Block = 3,
        BlockType = 4,
        Foul = 5,
        FoulType = 6,
        ShotHitType = 7,
        AfterShotBehaveType = 8,
        ShotBaseType = 9,
    }

    public enum shot_indexFields
    {
        Id = 0,
        SheetName = 1,
        Desc = 2,
    }

    public enum shot_behaveFields
    {
        Id = 0,
        AfterShotBehave = 1,
        BehaveTimeType = 2,
        BehaveTime = 3,
        BehaveSpeedType = 4,
        BehaveSpeed = 5,
        BehaveDirection = 6,
    }

    public enum shot_baseFields
    {
        Id = 0,
        BallSpeedMax = 1,
        BallSpeedMin = 2,
        MissRadius = 3,
        MissNumber = 4,
        EventRange = 5,
    }

    public enum shot_blockFields
    {
        Id = 0,
        BlockFormula = 1,
        BlockValue1 = 2,
        BlockValue2 = 3,
        BlockValue3 = 4,
        BlockAttack = 5,
        BlockDeffence = 6,
        AreaValue = 7,
        AreaDefence = 8,
        BallSpeed = 9,
        DefenceBehave = 10,
        AttackBehave = 11,
    }


    public enum shot_percentageFields
    {
        Id = 0,
        Desc = 1,
        FGPercentageBasic = 2,
        AttributeShooter = 3,
        ShotRangeReduction = 4,
        SRRInitial = 5,
        SRRTerminal = 6,
        SRRLength = 7,
        DefenderRange = 8,
        RangeReflectByDistance = 9,
        DefenderRangeReduction = 10,
        DRRInitial = 11,
        DRRTerminal = 12,
        DRRLength = 13,
        FGPercentageReductionBasic = 14,
        AttributeDefender = 15,
        ConstDefender1 = 16,
        ConstDefender2 = 17,
        ConstDefender3 = 18,
        ConstDefender4 = 19,
        ConstDefender5 = 20,
        DefenceBuffJ = 21,
    }

    public enum expectation_insideshotFields
    {
        Id,
        Percentage,
    }

    public enum expectation_drivingFields
    {
        Id,
        Percentage,
    }

    public enum expectation_jumpshot2Fields
    {
        Id,
        Percentage,
    }

    public enum expectation_jumpshot3Fields
    {
        Id,
        Percentage,
    }

    public enum range_drivingFields
    {
        Id,
        Distance1,
        Distance2,
        Percentage,
    }

    public enum contest_drivingFields
    {
        Id,
        Percentage,
    }

    public enum court_zoneFields
    {
        Id = 0,
        Name = 1,
        Court = 2,
        ZoneRadius1 = 3,
        ZoneRadius2 = 4,
        ZoneAngle1 = 5,
        ZoneAngle2 = 6,
        NearbyZone = 7,
        CenterRadius = 8,
        CenterAngle = 9,
        CenterX = 10,
        CenterY = 11,
        MinX = 12,
        MaxX = 13,
        MinY = 14,
        MaxY = 15,
    }

    public enum playbookFields
    {
        Id = 0,
        Name = 1,
        PlayType = 2,
        TargetZone1 = 3,
        TargetZone2 = 4,
        TargetZone3 = 5,
        TargetZone4 = 6,
        TargetZone5 = 7,
    }

    public enum stamina_costFields
    {
        Id = 0,
        Name = 1,
        Cost = 2,
        Frequency = 3,
    }

    public enum stealFields
    {
        Id = 0,
        Name = 1,
        StealValue1 = 2,
        StealValue2 = 3,
        StealValue3 = 4,
        StealAttack = 5,
        StealDeffence = 6,
        StealStyleValue1 = 7,
        StealStyleDeffence = 8,
        StealGetBallDeffenceBehave = 9,
        StealGetBallAttackBehave = 10,
        StealPokeBallDeffenceSpeedLevel = 11,
        StealPokeBallAngle = 12,
        StealPokeBallSpeed = 13,
        StealPokeBallDeffenceBehave = 14,
        StealPokeBallAttackBehave = 15,
    }

    public enum steal_behave_typeFields
    {
        Id = 0,
        StealBehave = 1,
        BehaveTime = 2,
        BehaveSpeedType = 3,
        BehaveSpeed = 4,
        BehaveDirection = 5,
    }

    public enum steals_ball_speedFields
    {
        Id = 0,
        InsideChance = 1,
        PassChance = 2,
    }

    public enum steal_ball_speed_typeFields
    {
        Id = 0,
        BallSpeedType = 1,
        SpeedZdbType = 2,
        BallSpeed = 3,
    }

    public enum tactic_defensiveFields
    {
        Id                          = 0,
        Name                        = 1,
        HelpDefenceMax              = 2,
        HelpDefenceProbability      = 3,
        PickRollBallDefenceChange   = 4,
        PickRollPickDefenceChange   = 5,
        Transition                  = 6,
        HelpDefence                 = 7,
        AreaTestP1                  = 8,
        DistancePDivisor            = 9,
    }

    public enum floorball_speedFields
    {
        Id = 0,
        Speed = 1,
        Chance1 = 2,
        Chance2 = 3,
        Chance3 = 4,
    }

    public enum floorball_behaveFields
    {
        Id = 0,
        Behave = 1,
        BehaveTimeType = 2,
        BehaveTime = 3,
        BehaveSpeedType = 4,
        BehaveSpeed = 5,
        BehaveDirection = 6,
        NextBehave = 7,
    }

    public enum floorball_typeFields
    {
        Id = 0,
        Name = 1,
        AttackGetBall = 2,
        DefenceGetBall = 3,
    }

    public enum floorballFields
    {
        Id = 0,
        Name = 1,
        Time = 2,
        Attack = 3,
        Defence = 4,
        GetBall = 5,
    }

    public enum fastbreakFields
    {
        Id = 0,
        PlayType = 1,
        Chance = 2,
        Play1Choice1 = 3,
        Play1Choice2 = 4,
        Play2Choice1 = 5,
        Play2Choice2 = 6,
    }

    public enum speed_changeFields
    {
        Id = 0,
        Desc = 1,
        Accelerate = 2,
        Decelerate = 3,
    }

    public enum foulFields
    {
        Id = 0,
        Name = 1,
        Type = 2,
        Value1 = 3,
        Value2 = 4,
        Attack = 5,
        Attack1 = 6,
        Defence = 7,
        Distance = 8,
    }

    public enum speed_up_distanceFields
    {
        Id,
        Distance,
        Speed0,
        Speed1,
        Speed2,
        Speed3,
        Speed4,
        Speed5,
        Speed6,
        Speed7,
        Speed8,
        Speed9,
        Speed10,
    }

    public enum pickroll_typeFields
    {
        Id,
        Name,
        PG,
        SG,
        SF,
        PF,
        C,
        Value1,
        Value2,
        Value3,
        Value4,
        Value5,
    }

    public enum range_insideshot_expectationFields
    {
        Id,
        Distance1,
        Distance2,
        Percentage,
    }

    public enum range_jumpshot2_expectationFields
    {
        Id,
        Distance1,
        Distance2,
        Percentage,
    }

    public enum range_jumpshot3_expectationFields
    {
        Id,
        Distance1,
        Distance2,
        Percentage,
    }

    public enum pickroll_moveFields
    {
        Id = 0,
        Name = 1,
        Type = 2,
        Value1 = 3,
        Foundation = 4,
        Value2 = 5,
        Probability = 6,
        Value3 = 7,
        Distance = 8,
        Value4 = 9,
        MovePoint = 10,
        Value5 = 11,
        Value6 = 12,
    }


    public enum shot_percentage_common_Fields
    {
        Id = 0,
        Percentage = 1,
    }

    public enum shot_beforeFields
    {
        Id = 0,
        Name = 1,
        ShootTimeP = 2,
        FakeEnable = 3,
        FakeChance = 4,
        Disturbance = 5,
        HelpDisturbance = 6,
        Fouls = 7,
        NoFouls = 8,
    }

    public enum shot_fakeparaFields
    {
        Id = 0,
        DefDIV = 1,
        DistanceBase = 2,
        DistanceIndex = 3,
        DistanceIndexDIV = 4,
        DistanceDIV = 5,
        FoulsCOE = 6,
        FoulsDIV = 7,
        DistanceMin = 8,
    }

    public enum defencetypeFields
    {
        Id = 0,
        ShotName = 1,
        DistanceMin = 2,
        StaminaCostN = 3,
        DefenceFreezeJ = 4,
        StaminaCostJ = 5,
        DefenceTimeJ = 6,
    }

    public enum live_textFields
    {
        Id = 0,
        Name = 1,
        Text = 2,
        Location0 = 3,
        Annotation0 = 4,
        Location1 = 5,
        Annotation1 = 6,
        Location2 = 7,
        Annotation2 = 8,
        Location3 = 9,
        Annotation3 = 10,
    }

    public enum teamlogoFields
    {
        Id = 0,
        ENGName = 1,
        CHNName = 2,
        LogoRoute = 3,
    }

    public enum playerlibraryFields
    {
        Id,
        Cost,
        PlayerId,
        PlayerName,
        PlayerTeam,
        Library,
        Rank,
        Att,
        Def,
        Reb,
        Ctrl,
        Composite,
        InsideScoring,
        OutsideScoring,
        InsideDefense,
        OutsideDefense,
        PlayersPosition1,
        PlayersPosition2,
        Number
    }

    public enum teamnameFields
    {
        Id,
        FirstName,
        SecondName
    }

    public enum serverdictFields
    {
        Id,
        CN
    }

    public enum scheduleFields
    {
        Id = 0,
        Name = 1,
        StartType = 2,
        AI = 3,
        Match = 4,
        AIVsAI = 5,
        Promotion = 6,
        Preliminary = 7,
        Final = 8,
        Time1 = 9,
        Change1 = 10,
        Time2 = 11,
        Change2 = 12,
        Time3 = 13,
        Change3 = 14,
        WinScore = 15,
        LostScore = 16,
    }

    public enum ball_moveFields
    {
        Id,
        Name,
        Probability,
        Distance,
        Scale,
        Value4,
        Value5,
        Value6,
        Start,
        End,
        Time,
        Value7,
        Roll,
        AllTime,
        Max,
        BackCentreSpeed ,
        BackCentreSpeed1,
        FastOrSlow,
        MovePointValue1 ,
        MovePointSpeed,
        MovePointSpeed1,
        Hand  ,
        PlayerMoveRadius  ,
        Point ,
        PlayerMoveSpeed , 
        PlayerMoveTime
    }

    public enum autobotsFields
    {
        Id              = 0,
        TeamName        = 1,
        TeamLogo        = 2,
        Active          = 3,
        Division        = 4,
        PG              = 5,
        SG              = 6,
        SF              = 7,
        PF              = 8,
        C               = 9,
        PGSub           =10,
        SGSub           =11,
        SFSub           =12,
        PFSub           =13,
        CSub            =14,
    }

    public enum defencehelpFields
    {
        Id                      = 0,
        HelpDefenceDivisor      = 1,
        HelpDefenceIndex        = 2,
        HelpDefenceDivisor2     = 3,
        Basenumber1             = 4,
        Basenumber2             = 5,
        Basenumber3             = 6,
        Basenumber4             = 7,
        MaxHelper               = 8,
    }

    public enum team_ratingFields
    {
        Id                      = 0,
        TacticType              = 1,
        TacticNo                = 2,
        RatingType              = 3,
        Position                = 4,
        Skill1                  = 5,
        Weight1                 = 6,
        Skill2                  = 7,
        Weight2                 = 8,
        Skill3                  = 9,
        Weight3                 = 10,
        Skill4                  = 11,
        Weight4                 = 12,
    }

    public enum team_rating_insideFields
    {
        Id                      = 0,
        Margin                  = 1,
        Skill1                  = 2,
        Margin1                 = 3,
        Skill2                  = 4,
        Margin2                 = 5,
    }

    public enum team_rating_outsideFields
    {
        Id                      = 0,
        Margin                  = 1,
        Skill1                  = 2,
        Margin1                 = 3,
        Skill2                  = 4,
        Margin2                 = 5,
    }

    public enum team_rating_reboundFields
    {
        Id                      = 0,
        Margin                  = 1,
        Skill1                  = 2,
        Margin1                 = 3,
        Skill2                  = 4,
        Margin2                 = 5,
    }

    public enum substitution_typeFields
    {
        Id                      = 0,
        Name                    = 1,
        ChangeOther1            = 2,
        Condition1              = 3,
        ChangeOther2            = 4,
        Condition2              = 5,
    }

    public enum substitution_type_conditionFields
    {
        Id                      = 0,
        Name                    = 1,
        Condition1              = 2,
        Symbol1                 = 3,
        Value1                  = 4,
        Condition2              = 5,
        Symbol2                 = 6,
        Value2                  = 7,
    }

    public enum substitutionFields
    {
        Id                      = 0,
        Name                    = 1,
        ChangeType              = 2,
        ChangeCondition         = 3,
        Turn1                   = 4,
        Turn1Condition         = 5,
        Turn2                   = 6,
        Turn2Condition         = 7,
        Turn3                   = 8,
        Turn3Condition         = 9,
        Turn4                   = 10,
        Turn4Condition         = 11,
        Turn5 = 12,
        Turn5Condition = 13,
        ChanceType              = 14,
        Value                   = 15,
    }

    public enum substitution_base_timeFields
    {
        Id                      = 0,
        Name                    = 1,
        Type                    = 2,
        Time                    = 3,
        TotalRegularTime        = 4,
    }

    public enum substitution_conditionFields
    {
        Id                      = 0,
        Name,
        Condition1,
        Symbol1,
        Value1,
        Condition2,
        Symbol2,
        Value2,
    }

    public enum generate_player_initialFields
    {
        Id,
        Weight,
        HeightMS,
        HeightIS,
        PreferredZone,
        SpeedID,
        SpeedMIN,
        SpeedMAX,
        StrengthID,
        StrengthMIN,
        StrengthMAX,
        InsideShotID,
        InsideShotMIN,
        InsideShotMAX,
        JumpShot2MID,
        JumpShot2MIN,
        JumpShot2MAX,
        JumpShot3ID,
        JumpShot3MIN,
        JumpShot3MAX,
        PullupID,
        PullupMIN,
        PullupMAX,
        InsideDefID,
        InsideDefMIN,
        InsideDefMAX,
        OutsideDefID,
        OutsideDefMIN,
        OutsideDefMAX,
        DrivingID,
        DrivingMIN,
        DrivingMAX,
        LayupID,
        LayupMIN,
        LayupMAX,
        HandingID,
        HandingMIN,
        HandingMAX,
        PassingID,
        PassingMIN,
        PassingMAX,
        PassVisonID,
        PassVisonMIN,
        PassVisonMAX,
        ShotContestID,
        ShotContestMIN,
        ShotContestMAX,
        ReboundingID,
        ReboundingMIN,
        ReboundingMAX,
        ShootTimeID,
        ShootTimeMIN,
        ShootTimeMAX,
        ShotIQID,
        ShotIQMIN,
        ShotIQMAX,
        DefenceIQID,
        DefenceIQMIN,
        DefenceIQMAX,
        StaminaID,
        StaminaMIN,
        StaminaMAX,
        BoxOutID,
        BoxOutMIN,
        BoxOutMAX,
        FreeThrowID,
        FreeThrowMIN,
        FreeThrowMAX,
        StealID,
        StealMIN,
        StealMAX,
        BlockID,
        BlockMIN,
        BlockMAX,
        AttackFoulID,
        AttackFoulMIN,
        AttackFoulMAX,
        DefendFoulID,
        DefendFoulMIN,
        DefendFoulMAX,
        DunkID,
        DunkMIN,
        DunkMAX,
        HookID,
        HookMIN,
        HookMAX,
        FadeAwayID,
        FadeAwayMIN,
        FadeAwayMAX,
        BankShotID,
        BankShotMIN,
        BankShotMAX,
        ReactID,
        ReactMIN,
        ReactMAX,
        SpaceOutID,
        SpaceOutMIN,
        SpaceOutMAX,
        HelpDefenceID,
        HelpDefenceMIN,
        HelpDefenceMAX,
        ChargeID,
        ChargeMIN,
        ChargeMAX,
        FastBreakID,
        FastBreakMIN,
        FastBreakMAX,
        OffballID,
        OffballMIN,
        OffballMAX,
        PickRollID,
        PickRollMIN,
        PickRollMAX,
        DrawFoulID,
        DrawFoulMIN,
        DrawFoulMAX,
        ScreenID,
        ScreenMIN,
        ScreenMAX,
        OffensiveReboundID,
        OffensiveReboundMIN,
        OffensiveReboundMAX,
        FakeID,
        FakeMIN,
        FakeMAX,
        TransitionID,
        TransitionMIN,
        TransitionMAX,
        PlayerType
    }

    public enum countryFields
    {
        Id,
        Name,
        ShortName,
        TimeDifference,
        Zone,
        PlayerFirstName,
        PlayerLastName
    }

    public enum chinese_player_first_namesFields
    {
        Id,
        FirstName,
        Frequency1
    }

    public enum chinese_player_last_namesFields
    {
        Id,
        LastName,
        Frequency2
    }
    public enum leagueFields
    {
        Id,
        Name,
        AITotalTeam,
        Player
    }

    public enum league_matchtimeFields
    {
        Id,
        Name,
        StartTime,
        Edit1,
        EndTime,
        Edit2,
        TimeDifference,
        MaintainStart,
        MaintainEnd
    }
    public enum league_typeFields
    {
        Id,
        Name,
        LeagueType,  
        Symbol1,
        Value1,
        TeamCount,
        PlayOffType,  //
        LevelMaxUp, //LevelMaxUp
        UpGradeCondition, //升级条件
        Symbol2,
        Value2,
        DownGradeCondition, //降级条件
        Symbol3,
        Value3,
        PlayerToAI, //沉默号判定
        Symbol4,
        Value4,
        Set //处理方式
    }

    public enum player_constantFields
    {
        Id,
        Desc,
        SkillID,
        Dividend,
        Skill1,
        Weight1,
        Skill2,
        Weight2,
        Skill3,
        Weight3,
        Skill4,
        Weight4,
        Skill5,
        Weight5,
        Skill6,
        Weight6,
        Skill7,
        Weight7,
        Skill8,
        Weight8,
        Skill9,
        Weight9,
        Skill10,
        Weight10,
    }

    public enum player_attribute_comparationFields
    {
        Id,
        Desc,
        SkillID,
        Type,
        Skill1,
        Skill2,
        Skill3,
        Skill4,
        Skill5,
        Skill6,
    }

    public enum player_attribute_caculate_orderFields
    {
        Id,
        Desc,
        Type,
        CacID,
    }
    public enum cup_typeFields
    {
        Id,
        Name,
        OpenCup,
        Symbol,
        Value,
        TeamCount
    }

    public enum league_scheduleFields
    {
        Id,
        Round,
        Team1,
        Team2,
        Team3,
        Team4,
        Team5,
        Team6,
        Team7,
        Team8
    }

    public enum league_schedule_12Fields
    {
        Id,
        Round,
        Team1,
        Team2,
        Team3,
        Team4,
        Team5,
        Team6,
        Team7,
        Team8,
        Team9,
        Team10,
        Team11,
        Team12
    }

    public enum filter_keys_nameFields
    {
        ID,
        Content,

    }
}
