﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common.ZDB
{
    public enum ParameterEnum
    {
        ReactionTime                            = 1,//球员反应时间
        SpeedCoefficient                        = 2,//速度转换系数
        Shot2PExpectParam1                      = 3,//2分投篮预期参数1
        Shot2PExpectParam2                      = 4,//2分投篮预期参数2
        Shot2PExpectParam3                      = 5,//2分投篮预期参数3
        Shot3PExpectParam1                      = 6,//3分投篮预期参数1
        Shot3PExpectParam2                      = 7,//3分投篮预期参数2
        Shot3PExpectParam3                      = 8,//3分投篮预期参数3
        ShotDefCoefficient                      = 9,//防守投篮转换系数
        ShotDefDisParam                         = 10,//防守者距离参数
        CrossOverExpectParam1                   = 11,//突破转换参数1
        CrossOverExpectParam2                   = 12,//突破转换参数2
        InsideDefParam1                         = 13,//内防转换系数1
        InsideDefParam2                         = 14,//内防缩放指数
        CrossOverSuccessParam                   = 15,//突破预期破防系数
        ShotMinExpect                           = 16,//出手预期-最低出手预期
        ShotAddExpect                           = 17,//出手预期-递增参数


        LayupDistance                           = 18,//上篮出手距离
        ShotExpectMid                           = 19,//球员投篮预期-2分球基础中点
        ShotExpectMidExtend                     = 20,//球员投篮预期-2分球中点延长系数
        OOODefMinShotExpect                     = 21,//盯人最低得分预期

        DefDistanceParam1                       = 22,
        DefDistanceParam2                       = 23,
        MaxStamina                              = 24,//最大体力-开场所有人都是这个
        CalcStaminaCycle                        = 25,//计算体力周期
        HanlderExpectParam                      = 26,//持球人参数
        StealParam1                             = 27,//抢断参数1
        StealParam2                             = 28,//抢断参数2
        AttackOut3STime                         = 29,//进攻方出3秒区时间
        DriveToAttackCourtCOE                   = 30,//会执行带球过半场能力下限
        CrossOverMinDis                         = 31,//突破最近的点，距离篮筐小于这个点就不突破了
        InsideShotMin                           = 32,//内线单打人能力下限
        OutsideDrivingMin                       = 33,//外线单打人能力下限
        InsideAtkAskBallMin                     = 34,//内线单打要球点最小距离
        InsideAtkAskBallMax                     = 35,//内线单打要球点最大距离
        InsideScoringParam1                     = 36,//球员内投转换系数
        InsideScoringParam2                     = 37,//球员内投缩放系数
        InsideScoringParam3                     = 38,//球员内防转换系数
        InsideScoringParam4                     = 39,//球员内防缩放系数
        InsideScoringParam5                     = 40,//内投破防系数
        SpaceOutCutOffPoint                     = 41,//内线单打拉开3分临界值
        SpaceOutAngle                           = 42,//外线单打拉开角度
        LayUpDoubleTeam                         = 43,//上篮包夹概率
        InsideShotDoubleTeamCOE                 = 44,//内投包夹概率

        CrossOverDefFoulCOE                     = 47,//突破防守犯规系数
        CrossOverAtkFoulCOE                     = 50,//突破进攻犯规系数
        CrossOverAtkFoulCOE2                    = 51,//突破进攻犯规系数2
        CrossOverInsideAtkCOE                   = 52,//突破导致背打系数
        CrossOverInsideAtkCOE2                  = 53,//突破导致背打系数2
        PullUpBaseCOE                           = 54,//急停跳投基础概率
        PullUpCOE                               = 55,//急停跳投系数
        PullUpTimeAdd                           = 56,//急停跳投时间影响
        PassBallCOE                             = 57,//传球概率
        AssistTime                              = 58,//传球后多久出手算助攻
        OffBallCOE                              = 59,//跑位概率
        CenterAngle                             = 60,//跑位圆心角度数
        Shot3PExpectDenominatorParam1           = 61,
        Shot3PExpectDenominatorParam2           = 62,
        Shot3PExpectDenominatorParam3           = 63,
        Shot3PExpectDenominatorParam4           = 64,
        Shot3PExpectDenominatorParam5           = 65,
        CoverPaoweiParam                        = 66,
        CoverPaoweiMoveTime                     = 67,//跑位被挡以后移动时间
        CoveredPaoweiMoveSpeedLevel             = 68,//跑位被挡以后移动速度
        TeamRatingCOE                           = 69,//球队评级系数
        OneSecondRestoreStamina                 = 70,//在场下每秒恢复的体力
        HitrateStaminaParam                     = 71,//体力影响命中率参数
        TeamRatingStaminaParam                  = 72,//体力影响评级参数

        CrossOverReactionTime                   = 107,//突破反应时间
        PassBallSpeed                           = 117,//传球速度
        ShotBallSpeed                           = 118,//投篮速度
        DefRangeRadius                          = 119,//防守半径

        DefMinDis                               = 120,//防守最近距离
        PassBallDelayCOE                        = 121,//传球出手时间系数

        RunRadius                               = 123,//跑动范围
        RestrictedArea                          = 124,//合理冲撞区半径
        PlayerArea                              = 125,//球员范围，球员圆柱体

        ReboundCOE                              = 128,//冲抢篮板系数
        AfterTakePosMoveDisCOE                  = 129,//挡人推进距离系数
        AfterTakePosMoveSpeedCOE                = 130,//挡人推进速度系数
        MinRebound                              = 131,//抢篮板最小篮板属性
        BoxOutCOE                               = 133,//抢篮板卡位系数
        ReboundPlacement                        = 143,//篮板落点监测范围
        ReboundParam1                           = 144,//篮板预期参数1
        ReboundParam2                           = 145,//篮板预期参数2
        RoleReboundAdditionPG                   = 146,//PG篮板加成
        RoleReboundAdditionSG                   = 147,//SG篮板加成
        RoleReboundAdditionSF                   = 148,//SF篮板加成
        RoleReboundAdditionPF                   = 149,//PF篮板加成
        RoleReboundAdditionC                     = 150,//C篮板加成

        DisShotPoint1                           = 151,//篮板弹射距离1
        DisShotPoint2                           = 152,//篮板弹射距离2
        BallHoopReboundSpeed                    = 153,//篮板球弹框飞行速度

        DontGetReboundPlayerParam               = 155,//没获得篮板的球员移动参数
        BlockShotCOE                            = 156,//投篮盖帽系数
        BasketRadius                            = 159,//篮筐半径

        DefShotDis1                             = 166,//投篮人范围内无对位防守人，补防距离
        StealPro                                = 169,//抢断概率

        ThrowInMaxSeconds                       = 170,//5秒违例时间
        DisToGetThrowIn                         = 173,//发界外球的接球区域

        DefenceFoulCOE                          = 175,//防守犯规系数
        DefShotDis2                             = 177,//投篮人范围内有对位防守人，补防距离
        HookRange                               = 178,//勾手范围
        
        HookMinDis                              = 184,//勾手最小距离
        HookMaxDis                              = 185,//勾手最大距离
        FadeAwayDis                             = 187,//后仰最小距离

        ShotPoint2Start                         = 188,//长篮板起始
        ShotPoint2End                           = 189,//长篮板终止
        ShotPoint2Step                          = 190,//长篮板步长

        DefHandlerLuoWeiDis                     = 201,//持球人在离篮筐多远之外的时候落位盯人

        BallOnTheFloorSpeedCOE                  = 206,//地板球球速参数
        BallOnTheFloorTimeCOE                   = 207,//地板球时间参数
        
        BlockShotBigRangeCOE                    = 208,//盖帽是大帽的系数
        BlockBallFlyTime                        = 209,//盖帽球飞行时间
        ShotContestCOE                          = 210,//投篮干扰系数
        BlockShotReactionTime                   = 211,//盖帽后所有人反应时间
        BlockedReactionTime                     = 212,//被盖人反应时间
        BlockShotStandyPro                      = 213,//盖帽硬直概率
        FreeThrowWaitTime                       = 214,//罚球出手等待时间

        BasketPointCount                        = 216,//投篮未命中砸到的地方
        NotGoalAngle                            = 217,//投篮未命中弹出角度
        ProtectBasketMinX                       = 219,//追击篮筐X方向便宜距离
        FillInParam1                            = 220,//补防参数1
        FillInParam2                            = 221,//补防参数2
        FillInParam3                            = 222,//补防参数3
        FillInParam4                            = 223,//补防参数4
        FillInParam5                            = 224,//补防参数5
        FillInParam6                            = 225,//补防参数6
        FillInParam7                            = 226,//补防参数7
        FillInParam8                            = 227,//补防参数8

        FreeThrowInterval                       = 230,//罚球砸筐弹出来时间
        NotGoalAngleRightMin                    = 231,//投篮未命中弹出角度--右边
        NotGoalAngleRightMax                    = 232,//投篮未命中弹出角度--右边
        InsideAtkTurnRoundParam1                = 233,//转身突破概率1
        InsideAtkHelpDefParam1                  = 234,//背打协防参数1

        InsideAtkTurnRoundParam2                = 236,//转身突破概率2
        InsideAttackDefFoulPro                  = 237,//背打防守犯规概率、
        TurnRoundReactionTime                   = 241,//转身突破反应时间
        InsideAtkHelpDefParam2                  = 242,//背打协防参数2
        InsideAtkHelpDefParam3                  = 243,//背打协防参数3

        FadeAwayFollowActionSpeed               = 248,//后仰跳投跟随动作速度

        FadeAwayReactionTime                    = 251,//后仰跳投防守队员反应时间
        BlockAgainstCOE                         = 253,//被盖系数2
        DefFoulCOE2                             = 255,//防守犯规系数2
        InsideAttackAtkFoulPro                  = 256,//内线进攻犯规概率
        BallOnTheFloorStartTime                 = 257,//地板球初始时间
        InsideAttackDefDis                      = 258,//内线进攻防守距离

        PermissibleError                        = 261,//允许误差
        SlamDunkMaxDis1                         = 262,//扣篮最远距离1
        SlamDunkSpeedParam1                     = 263,//扣篮速度判断1
        SlamDunkMaxDis2                         = 264,//扣篮最远距离2
        SlamDunkSpeedParam2                     = 265,//扣篮速度判断2
        SlamDunkMaxDis3                         = 266,//扣篮最远距离3
        SlanDunkDefRate                         = 268,//扣篮干扰概率
        SlamDunkDefDis1                         = 269,//扣篮阻挡距离参数1
        SlamDunkDefDis2                         = 270,//扣篮阻挡距离参数2
        SlamDunkDefBlockCOE                     = 271,//扣篮去封盖系数
        SlamDunkBlockDis1                       = 272,//扣篮盖帽判断范围1
        SlamDunkMinAbility                      = 273,//扣篮最小值
        SlamDunkBlockDis2                       = 274,//扣篮盖帽判断范围2
        HookShotFoulCOE                         = 275,//勾手被犯规概率
        FadeAwayFoulCOE                         = 276,//后仰跳投犯规概率
        HookShotBlockCOE                        = 277,//勾手被盖系数
        FadeAwayBlockCOE                        = 278,//后仰被盖概率
   
        SlamDunkBaseTime                        = 281,//扣篮基础时间
        SlamDunkFlyTimeCOE                      = 282,//扣篮飞行时间系数
        
        FadeAwayDefCOE                          = 283,//防后仰投篮概率
        FadeAwayDefArea                         = 284,//后仰跳投防守最大距离
        FadeAwayMoveTimeParam1                  = 285,//后仰跳投移动时间
        FadeAwayMoveTimeParam2                  = 286,//后仰跳投移动时间参数
        FadeAwayMoveSpeed                       = 287,//后仰跳投移动速度
        InsideShotBlockCOE                      = 288,//内投盖帽系数
        InsideShotFoulCOE                       = 289,//内投犯规系数
        ToGetBallOnTheFloorParam1               = 290,//去抢地板球参数1
        SlamDunkOnTheBasket                     = 291,//扣篮挂筐概率
        
        ToGetBallOnTheFloorParam2               = 293,//去抢地板球参数2


        MaxStandbyTime                          = 308,//最大待机时间
        InsideAtkFoulCOE2                       = 309,//背打犯规系数2
        ToGetBallOnTheFloorDis                  = 310,//球员到球的距离
        ToGetBallOnTheFloorDelayTime            = 311,//抢地板球反应时间

        FastBreakFirstOneJump3PParam            = 317,//第一快下人3分概率

        FastBreakFirstOneJump3PMin              = 322,//第一快下人3分最低属性

        FadeAwayBehindRadius                    = 332,//后仰跳投身后判断距离
        FadeAwayBehindAngle                     = 333,//后仰跳投身后判断角度
        TurnRoundSlumDunk                       = 334,//转身突破以后扣篮几率
        GetBallOnTheFloorMaxDis                 = 335,//得球最大距离
        InsideAttackDis2                        = 336,//背打推进距离2
        InsideAttackTime2                       = 337,//背打推进时间2
        InsideAttackStandbyTime                 = 338,//背打待机时间
        BallOnTheFloorRollSpeed                 = 339,//地板球进入滚动阶段的速度
        SlumDunkParam1                          = 340,//扣篮概率参数1
        BallOnTheFloorMoveTime                  = 341,//地板球抢断人移动时间
        InsideAttackMinMiS                      = 342,//背打最短时间
        InsideAttackAtkMoveTime                 = 343,//内线进攻持球人移动时间
        InsideAttackDefMoveTime                 = 344,//内线进攻防守人移动时间

        PassBallParam1                          = 353,//传球参数1

        PassBallParam4                          = 356,//传球参数4

        PassBallParam9                          = 360,//传球参数9
        FillInCoolDown                          = 361,//补防判断cd
        LuoweiMinSpeedLevel                     = 362,//落位最低速度等级
        LuoweiMinShotExpect                     = 363,//最低落位得分预期
        LuoweiDefDisAdd                         = 364,//落位防守距离参数
        FillInCOE1                              = 365,//补防概率参数1
        FillInCOE2                              = 366,//补防概率参数2
        FillInCOE3                              = 367,//补防概率参数3
        FillInDisParam1                         = 368,//补防距离参数1
        FillInDisParam2                         = 369,//补防距离参数2
        FillInDisParam3                         = 370,//补防距离参数3

        PassBallParam2                          = 379,//传球参数2
        PassBallParam3                          = 380,//传球参数3

        PassBallParam5                          = 386,//传球参数5
        SlumDunkParam2                          = 387,//扣篮概率参数2
        TurnRoundMoveToBasketTime               = 388,//转身突破以后向篮筐移动时间
        TurnRoundMinDis                         = 390,//转身突破最小距离
        ReboundStepDis                          = 391,//没人抢到的篮板，检测步长

        FastBreakParam1                         = 410,//快下概率参数1
        FastBreakParam2                         = 411,//快下概率参数2
        FastBreakParam3                         = 412,//快下概率参数3
        FastBreakParam4                         = 413,//快下概率参数4
        FastBreakParam5                         = 414,//快下概率参数5
        FillInDisParam4                         = 415,//补防距离参数4
        FillInMaxCount                          = 416,//补防最大人数

        InsideAtkDoubledShotParam1              = 430,//背打包夹投篮参数1

        InsideAtkJieYingParam1                  = 432,//背打接应参数1
        InsideAtkJieYingParam2                  = 433,//背打接应参数2

        InsideAtkJieYingReaction                = 435,//背打接应反应时间

        InsideAtkJieYingAngle                   = 437,//背打跑位夹角
        InsideAtkJieYingMin3P                   = 438,//背打跑位最低3分属性
        InsideAtkDoubledDefFoulParam1           = 439,//背打包夹防守犯规参数1
        InsideAtkDoubledDefFoulParam2           = 440,//背打包夹防守犯规参数2

        InsideAtkHelpDefArea                    = 442,//背打遭遇协防距离判断
        InsideAtkDoubledAtkFoulParam1           = 443,//背打包夹进攻犯规参数1
        InsideAtkDoubledAtkFoulParam2           = 444,//背打包夹进攻犯规参数2
        InsideAtkDoubledShotParam2              = 445,//背打包夹投篮参数2
        InsideAtkDoubledStandbyTime             = 446,//背打遭遇包夹，待机时间
        InsideAtkDoubledMaxDis                  = 447,//背打遭遇包夹最大距离

        PickRollMoveTime                        = 450,//挡拆每次运动时间

        PickRollArea2                           = 452,//挡拆，摆脱点半径

        PickRollArea                            = 454,//挡拆点判断半径
        PickRollJump3PParam                     = 455,//挡拆3分参数
        PickRollJump2PParam                     = 456,//挡拆2分参数
        PickRollJump3PMin                       = 457,//挡拆去投3分最低属性
        PickRollGetRidParam1                    = 458,//挡拆摆脱时间参数1
        PickRollGetRidParam2                    = 459,//挡拆摆脱时间参数2
        PickRollGetRidParam3                    = 460,//挡拆摆脱时间参数3

        PickRollHanlderTargetRadius             = 466,//挡拆持球人移动半径

        CoverMaxNum                             = 474,//无球掩护人数上限
        CoverMinToBasket                        = 475,//掩护触发最近篮筐距离
        CoverHandlerX1                          = 476,//掩护最小X
        CoverHandlerX2                          = 477,//掩护最小Y

        DefAngleOffset1                         = 481,//防守角度偏移1
        DefAngleOffset2                         = 482,//防守角度偏移2
        DefAngleOffset3                         = 483,//防守角度偏移3

        PickRollTime1                           = 485,//挡拆时间1
        PickRollTime2                           = 486,//挡拆时间2

        PickRoll3PRadius                        = 488,//挡拆，掩护人3分跑位半径
        PickRollChangeDefParam4                 = 489,//挡拆换防参数4
        PickRollChangeDefParam5                 = 490,//挡拆掩护人换防参数
        PickRoll2PRadius                        = 491,//挡拆，掩护人2分跑位半径

        DefAngleOffset4                         = 496,//防守角度偏移4

        PickRollChangeDefParam1                 = 507,//挡拆换防参数1
        PickRollChangeDefParam2                 = 508,//挡拆换防参数2
        PickRollChangeDefParam3                 = 509,//挡拆换防参数3

        PassBallParam7                          = 518,//传球参数7
        PassBallParam8                          = 519,//传球参数8
        BallOnTheFloorDis2                      = 520,//地板球判定范围2

        JoinFinalRanking                        = 531, //晋级决赛排名
        MinPlayerCount                          = 545, //最少选择队员数
        MaxPlayerCount                          = 546, //最多选择队员数
        MaxCosts                                = 547, //最多消耗

        PassBallParam6                          = 560,//传球参数6
        
        PassBallParam10                         = 563,//传球参数10
        PassBallParam11                         = 564,//传球参数11

        PassBallMinInterval                     = 582,//同一个人传球最小时间间隔

        DisturbShotParam1                       = 585,//干扰投篮判断1
        DisturbShotParam2                       = 586,//干扰投篮判断2

        Def3SMinDis                             = 588,//防守三秒距离

        FakeActionInterval                      = 591,//投篮假动作待机时间

        RebDefParam1                            = 626,//防守篮板加成系数1
        RebDefParam2                            = 627,//防守篮板加成系数2
        ChallengeCD                             = 629,//挑战CD
        Def3SecondOut                           = 630,//防守3秒出三秒
        Def3SecondOutPro                        = 631,//防守3秒出去的概率
        FriendMatchTeamAICount                  = 632,//友谊赛电脑数量
        RefreshTeamInterval                     = 633,//友谊赛列表刷新CD
        TechnicalThrowInSpeed                   = 634,//违例发球速度
        StealPassPram2                          = 636,//传球抢断参数2
        DefFastBreakDis                         = 637,//防快下距离
        DefFastBreakCOE                         = 638,//防快下概率
        DefFaskBreakMaxCount                    = 639,//最多防快下的人

        RenameNeedDiamond                       = 652,//改名需要用的钻石数
        TeamNameMaxLength                       = 653,//球队名称最大长度

        BeginPlayerNumber                       = 662,//开档球员数量
    }
}
