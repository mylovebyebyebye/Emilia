﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;

#if UNITY_5
using UnityEngine;
#endif

namespace Common.ZDB
{
    enum EUDataType
    {
        TT_NULL = 0,
        TT_BIN = 1,
        TT_STRINGTABLE = 2,
        TT_INT = 3,
        TT_FLOAT = 4,
        TT_INDEX = 5,
        TT_STRING = 6,
        TT_V_INDEX = 7,
        TT_BIGINT = 8,
    }

    class ZDB_Header
    {
        public int id;
        public int nRecords;
        public int nFields;
        public int textSize;
        public int version;
    }

    public class ZDB_Col_Info
    {
        public int m_nType;
        public string m_szName;

    }

    public class ZDB_Cell_Type
    {
        private int m_nType;
        private byte[] m_data;
        private int m_nValue;
        private string m_strValue;
        private bool m_bIsInt;

        public int readCellData(int a_nType, byte[] a_bytes, int a_nOffset)
        {
            m_nType = a_nType;
            this.m_bIsInt = (m_nType == (int)EUDataType.TT_INT) || (m_nType == (int)EUDataType.TT_V_INDEX); 

            int nDataLength = 0;
            if (this.isInt())
            {
                nDataLength = 4;
            }
            else if (this.isFloat())
            {
                nDataLength = 4;
            }
            else if (this.isBigInt())
            {
                nDataLength = 8;
            }
            else if (this.isString())
            {
                nDataLength = 4 + BitConverter.ToInt32(a_bytes, a_nOffset);
            }

            //数据拷贝一份出来
            m_data = new byte[nDataLength];
            for (int i = 0; i < nDataLength; i++)
            {
                m_data[i] = a_bytes[a_nOffset + i];
            }

            if (this.isInt())
            {
                this.LoadValueInt();
            }
            else if (this.isString())
            {
                this.LoadValueString();
            }

            return nDataLength;
        }

        public bool isInt()
        {
            return this.m_bIsInt;
        }
        public bool isFloat()
        {
            return (m_nType == (int)EUDataType.TT_FLOAT);
        }
        public bool isBigInt()
        {
            return (m_nType == (int)EUDataType.TT_BIGINT);
        }
        public bool isString()
        {
            return (m_nType == (int)EUDataType.TT_STRING) || (m_nType == (int)EUDataType.TT_STRINGTABLE);
        }

        private void LoadValueInt()
        {
            this.m_nValue = BitConverter.ToInt32(m_data, 0);
        }

        private void LoadValueString()
        {
            string szTemp = "";
            int nLength = BitConverter.ToInt32(m_data, 0);
            for (int i = 0; i < nLength; i++)
            {
                szTemp += (char)m_data[4 + i];
            }
            this.m_strValue = szTemp;
        }

        ///////////////////////////////////
        public int getValueInt()
        {
            if (!isInt())
            {
                throw new Exception("not_int_value");
            }
            return m_nValue;
        }
        public string getValueString()
        {
            if (!isString())
            {
                throw new Exception("not_string_value");
            }

            
            return this.m_strValue;
        }
        public string GetUTFString()
        {
            if (!isString())
            {
                throw new Exception("not_string_value");
            }
            byte[] newA = m_data.Skip(4).ToArray();
            string szTemp = Encoding.GetEncoding("UTF-8").GetString(newA);
            
            return szTemp;
        }
        public long getValueBigInt()
        {
            if (!isBigInt())
            {
                throw new Exception("not_big_int_value");
            }
            return BitConverter.ToInt64(m_data, 0);
        }
        public float getValueFloat()
        {
            if (!isFloat())
            {
                throw new Exception("not_float_value");
            }
            return BitConverter.ToSingle(m_data, 0);
        }

    }
   
    public class ZDB_Row_Data
    {
        ZDBTable m_owner;
        ZDB_Cell_Type[] m_listCell;

        public ZDB_Row_Data()
        {
        }


        public void setCellNumber(int a_nCount)
        {
            m_listCell = new ZDB_Cell_Type[a_nCount];
            for (int i = 0; i < a_nCount; i++)
            {
                m_listCell[i] = new ZDB_Cell_Type();
            }
        }

        //从原数据里面初始化这一行数据，并且返回读取的总数据量
        public int readFromData(ZDBTable a_reader, byte[] a_bytes, int a_nOffset)
        {
            m_owner = a_reader;

            int nColCount = a_reader.getColCount();
            this.setCellNumber(nColCount);

            int nByteCount = 0;
            int nOffset = a_nOffset;
            for (int i = 0; i < nColCount; i++)
            {
                int nColType = a_reader.getColType(i);

                nByteCount += m_listCell[i].readCellData(nColType, a_bytes, nOffset + nByteCount);
            }
            return nByteCount;
        }

        public ZDB_Cell_Type getCol(int a_nCol)
        {
            return m_listCell[a_nCol];
        }

        public ZDB_Cell_Type getColByName(string a_szColName)
        {
            int nCol = m_owner.getColByName(a_szColName);
            return m_listCell[nCol];
        }

    }

    public class ZDBTable
    {
        private string tableName = string.Empty;

        public string TableName
        {
            get { return tableName; }
            set { tableName = value; }
        }

        //文件头
        private ZDB_Header m_head;
        //列信息--类型和名称
        private ZDB_Col_Info[] m_col_info;
        //行数据
        private ZDB_Row_Data[] m_row_data;

        //唯一索引到行号的映射
        Dictionary<int, int> m_vid2row = new Dictionary<int, int>();
        //列名到列号的映射
        Dictionary<string, int> m_name2col = new Dictionary<string, int>();


        public ZDBTable()
        {
            m_head = new ZDB_Header();
        }

        //获取总行数
        public int getRowCount()
        {
            return m_head.nRecords;
        }
        //获取总列数
        public int getColCount()
        {
            return m_head.nFields;
        }
        //获取列类型
        public int getColType(int a_nCol)
        {
            if (a_nCol >= 0 && a_nCol < getColCount())
            {
                return m_col_info[a_nCol].m_nType;
            }
            else
            {
                return 0;
            }
        }

        //获取列名
        public string getColName(int a_nCol)
        {
            if (a_nCol >= 0 && a_nCol < getColCount())
            {
                return m_col_info[a_nCol].m_szName;
            }
            else
            {
                return "";
            }
        }
        //通过列名获取列号
        public int getColByName(string a_szColName)
        {
            if (m_name2col.ContainsKey(a_szColName))
            {
                return m_name2col[a_szColName];
            }
            else
            {
                throw new Exception(string.Format("zdb tablename: {0} column: {1} is not exists", this.tableName, a_szColName));
            }
        }


        // 获取行数据--通过行号
        public ZDB_Row_Data getDataByRow(int a_nRow)
        {
            return m_row_data[a_nRow];
        }

        // 获取行数据--通过vindex
        public ZDB_Row_Data getDataByID(int a_nID)
        {
           // bool bHas = m_vid2row.ContainsKey(a_nID);
            int index;
            if (m_vid2row.TryGetValue(a_nID, out index))
            {
                return m_row_data[index];
            }
            else
            {
                throw new Exception(string.Format("zdb tablename: {0} id: {1} is not exists",this.tableName, a_nID));
            }
        }
        //查询id是否存在
        public bool hasID(int a_nID)
        {
            bool bHas = m_vid2row.ContainsKey(a_nID);
            return bHas;
        }

        public bool hasColName(string colName)
        {
            if (m_name2col.ContainsKey(colName))
            {
                return true;
            }
            GameLogHelper.Instance.AddLog(string.Format("zdb {0} col {1} not exists", this.tableName, colName));
            return false;
        }


        public IEnumerator loadZDBCoroutine(string a_szFileName)
        {
#if UNITY_5
            TextAsset _text = null;
            if(CGlobal.ResMgr)
            {
                yield return CGlobal.ResMgr._LoadAsset(a_szFileName,null);

                _text = CGlobal.ResMgr.GetResource<TextAsset>(a_szFileName);
            }
            else
            {
                _text = Resources.Load<TextAsset>(a_szFileName);
            }

            yield return _text;
            if (_text == null)
                Debug.LogError("<loadZDBCoroutine> Failed" + a_szFileName);
            else
                this.parse(_text.bytes);

            if (CGlobal.ResMgr)
                CGlobal.ResMgr.UnLoadAsset(_text);
            else
                Resources.UnloadAsset(_text);
#else
            yield return null;
#endif
        }
        //加载zdb，并且初始化
        public bool loadZDB(string a_szFileName)
        {
#if UNITY_5
            TextAsset _text = Resources.Load<TextAsset>(a_szFileName);
            if (_text == null )
            {
                return false;
            }

            byte[] bytes = _text.bytes;

            Resources.UnloadAsset(_text);
#else
            byte[] bytes;

            using (FileStream fs = new FileStream(a_szFileName, FileMode.Open))
            {
                BinaryReader br = new BinaryReader(fs);
                bytes = br.ReadBytes((int)fs.Length);

                br.Close();
                fs.Close();
            }
#endif

            return parse(bytes);
        }
        private bool parse(byte[] bytes)
        {
            //read file header
            int nOffset = 0;

            m_head.id = BitConverter.ToInt32(bytes, nOffset); nOffset += 4;
            m_head.nRecords = BitConverter.ToInt32(bytes, nOffset); nOffset += 4;
            m_head.nFields = BitConverter.ToInt32(bytes, nOffset); nOffset += 4;
            m_head.textSize = BitConverter.ToInt32(bytes, nOffset); nOffset += 4;
            m_head.version = BitConverter.ToInt32(bytes, nOffset); nOffset += 4;

            // read col info
            m_col_info = new ZDB_Col_Info[m_head.nFields];
            for (int nCol = 0; nCol < m_head.nFields; nCol++)
            {
                m_col_info[nCol] = new ZDB_Col_Info();
                ZDB_Col_Info rInfo = m_col_info[nCol];
                rInfo.m_nType = BitConverter.ToInt32(bytes, nOffset); nOffset += 4;
                char c;
                for (int k = 0; k < 64; k++)
                {
                    c = (char)bytes[nOffset++];
                    if (c > 0)
                    {
                        rInfo.m_szName += c;
                    }
                }
            }
            //read row content
            m_row_data = new ZDB_Row_Data[m_head.nRecords];
            for (int nRow = 0; nRow < m_head.nRecords; nRow++)
            {
                m_row_data[nRow] = new ZDB_Row_Data();
                int nByteCount = m_row_data[nRow].readFromData(this, bytes, nOffset);
                nOffset += nByteCount;
            }


            //make index
            // col name to index
            for (int i = 0; i < getColCount(); i++)
            {
                string szColName = getColName(i);
                m_name2col.Add(szColName, i);
            }

            // vindex to row 
            for (int i = 0; i < getRowCount(); i++)
            {
                int nVindex = getDataByRow(i).getCol(0).getValueInt();
                m_vid2row.Add(nVindex, i);
            }
            return true;
        }
    }
}
