﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Utility;
using System.IO;
using System.Reflection;
using Common.ZDB;
using Common;
using System.Collections;
#if UNITY_5
using UnityEngine;
#endif

namespace Common.ZDB
{
    public class ZDataManager
    {
        private static ZDataManager instance = null;
        public static ZDataManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ZDataManager();
                }
                return instance;
            }
        }

        private bool isInit = false;

        private ZDataManager()
        {
            Init();
        }

        Dictionary<string, ZDBTable> m_name2table = new Dictionary<string, ZDBTable>();

        public bool Init()
        {
            if (!isInit)
            {
                bool bOK = true;
                foreach (ZDBTableName zdbName in Enum.GetValues(typeof(ZDBTableName)))
                {
                    string fileName = zdbName.ToString().Replace("__", "/");
                    string realName = fileName;
                    int index = zdbName.ToString().IndexOf("__");
                    if (index >= 0)
                    {
                        realName = zdbName.ToString().Substring(index + 2, zdbName.ToString().Length - index - 2);
                    }

                    bOK = bOK && loadTable(fileName, realName);
                    bOK = bOK && CheckFields(realName);

                    if (!bOK)
                    {
                        throw new Exception(string.Format("zdb:{0} check error ", realName));
                    }
                }

                isInit = bOK;
                return bOK;
            }
            else
            {
                return false;
            }
        }
        public IEnumerator InitCoroutine()
        {
            if (isInit)
                yield break;

            bool bOK = true;
            foreach (ZDBTableName zdbName in Enum.GetValues(typeof(ZDBTableName)))
            {
                string fileName = zdbName.ToString().Replace("__", "/");
                string realName = fileName;
                int index = zdbName.ToString().IndexOf("__");
                if (index >= 0)
                {
                    realName = zdbName.ToString().Substring(index + 2, zdbName.ToString().Length - index - 2);
                }

                yield return loadTableCoroutine(fileName, realName);
                bOK = bOK && CheckFields(realName);

                if (!bOK)
                {
                    throw new Exception(string.Format("zdb:{0} check error ", realName));
                }
            }

            isInit = bOK;

        }
        private bool CheckFields(string zdbName)
        {
            bool bOk = true;
            ZDBTable table = this.getTable(zdbName);
            try
            {
                Type type = Type.GetType(string.Format("Common.ZDB.{0}Fields", zdbName));
                var fields = type.GetFields(BindingFlags.Static | BindingFlags.Public);
                int index = 0;
                foreach (var fi in fields)
                {
                    bOk = bOk && table.hasColName(fi.Name);
                    string colName = table.getColName(index);
                    bOk = bOk && colName.Equals(fi.Name);
                    index++;
                    if (!bOk)
                    {
                        throw new Exception(string.Format("CheckFields : {0} error", zdbName));
                    }
                }
            }
            catch
            {
                throw new Exception(string.Format("CheckFields : {0} error", zdbName));
            }
            return bOk;
        }
        private IEnumerator loadTableCoroutine(string a_szZDB, string realName)
        {
            string szFileFullPath = "zdb/" + a_szZDB;

            ZDBTable table = new ZDBTable();

            yield return table.loadZDBCoroutine(szFileFullPath);

            table.TableName = a_szZDB;
            m_name2table.Add(realName, table);

            yield return null;
        }
        private bool loadTable(string a_szZDB, string realName)
        {
#if UNITY_5
            string szFileFullPath = "zdb/" + a_szZDB; 
            
            ZDBTable table = new ZDBTable();

            if (table.loadZDB(szFileFullPath))
            {
                table.TableName = a_szZDB;
                m_name2table.Add(realName, table);

                return true;
            }
            else
            {
                GameLogHelper.Instance.AddLog(LogTypeEnum.LogError, LogLevelEnum.Error, string.Format("{0} not exists", szFileFullPath));

                return false;
            }
#else
            //相对路径--自行修改
            string szPath = Config.GetConfig("zdbPath");
            string szFileFullPath = szPath + a_szZDB + ".zdb";
            
            if (File.Exists(szFileFullPath))
            {
                ZDBTable table = new ZDBTable();
                table.loadZDB(szFileFullPath);
                table.TableName = a_szZDB;
                m_name2table.Add(realName, table);
                return true;
            }
            else
            {
                GameLogHelper.Instance.AddLog(LogTypeEnum.LogError, LogLevelEnum.Error, string.Format("{0} not exists", szFileFullPath));
                throw new Exception(string.Format("{0} not exists", szFileFullPath));
            }
#endif
        }

        public ZDBTable LoadTableByAbsPath(string strPath)
        {
#if UNITY_5
            ZDBTable table = new ZDBTable();
            if (table.loadZDB(strPath))
            {
                table.TableName = strPath;
                return table;
            }
            else
            {
                return null;
            }
#else
            if (File.Exists(strPath))
            {
                ZDBTable table = new ZDBTable();
                if (table.loadZDB(strPath))
                {
                    FileInfo fi = new FileInfo(strPath);
                    table.TableName = fi.Name;
                    return table;
                }
                else
                {
                    throw new Exception(string.Format("{0} zdb load fail",strPath));
                }
            }
            else
            {
                throw new Exception("file is not exists");
            }
#endif
        }

        public ZDBTable getTable(string a_szZDB)
        {
            ZDBTable table;
            if (m_name2table.TryGetValue(a_szZDB, out table))
            {
                return table;
            }
            else
            {
                throw new Exception("zdb_" + a_szZDB + "_not_found");
            }
        }

        //判断zdb是否被托管
        public bool isExists(string a_szZDB)
        {
            if (m_name2table.ContainsKey(a_szZDB))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public ZDBTable GetPlayerTable()
        {
            return ZDataManager.Instance.getTable("player");
        }

        public ZDBTable GetStaminaTable()
        {
            return ZDataManager.Instance.getTable("stamina");
        }

        public ZDBTable GetSpeedAccelerateTable()
        {
            return ZDataManager.Instance.getTable("speed_accelerate");
        }

        public ZDBTable GetSpeedNormalTable()
        {
            return ZDataManager.Instance.getTable("speed_normal");
        }

        public ZDBTable GetReb1Table()
        {
            return ZDataManager.instance.getTable("reb1");
        }

        public ZDBTable GetReb2Table()
        {
            return ZDataManager.instance.getTable("reb2");
        }

        public ZDBTable GetBlockAngleTable()
        {
            return ZDataManager.instance.getTable("block_angle");
        }

        public ZDBTable GetBlockDistanceTable()
        {
            return ZDataManager.instance.getTable("block_distance");
        }

        public ZDBTable GetTacticOffecnsiveTable()
        {
            return ZDataManager.instance.getTable("tactic_offensive");
        }

        public ZDBTable GetLayUpTable()
        {
            return ZDataManager.instance.getTable("percentage_layup");
        }

        public ZDBTable GetContestLayUpTable()
        {
            return ZDataManager.instance.getTable("contest_layup");
        }

        public ZDBTable GetDunkTable()
        {
            return ZDataManager.instance.getTable("percentage_dunk");
        }

        public ZDBTable GetInsideShotTable()
        {
            return ZDataManager.instance.getTable("percentage_insideshot");
        }

        public ZDBTable GetContestInsideShotTable()
        {
            return ZDataManager.instance.getTable("contest_insideshot");
        }

        public ZDBTable GetShotTable()
        {
            return ZDataManager.instance.getTable("shot");
        }

        public ZDBTable GetShotBehaveTable()
        {
            return ZDataManager.instance.getTable("shot_behave");
        }

        public ZDBTable GetShotBaseTable()
        {
            return ZDataManager.instance.getTable("shot_base");
        }

        public ZDBTable GetShotBlockTable()
        {
            return ZDataManager.instance.getTable("shot_block");
        }

        public ZDBTable GetShotPercentageTable()
        {
            return ZDataManager.instance.getTable("shot_percentage");
        }

        public ZDBTable GetCourtZoneTable()
        {
            return ZDataManager.instance.getTable("court_zone");
        }

        public ZDBTable GetPlayBookTable()
        {
            return ZDataManager.instance.getTable("playbook");
        }

        public ZDBTable GetStaminaCostTable()
        {
            return ZDataManager.instance.getTable("stamina_cost");
        }

        public ZDBTable GetStealTable()
        {
            return ZDataManager.instance.getTable("steal");
        }

        public ZDBTable GetStealBehaveTable()
        {
            return ZDataManager.instance.getTable("steal_behave_type");
        }

        public ZDBTable GetStealSpeedTable()
        {
            return ZDataManager.instance.getTable("steals_ball_speed");
        }

        public ZDBTable GetStealBallSpeedTypeTable()
        {
            return ZDataManager.instance.getTable("steal_ball_speed_type");
        }

        public ZDBTable GetTacticDefensiveTable()
        {
            return ZDataManager.instance.getTable("tactic_defensive");
        }

        public ZDBTable GetFloorBallSpeedTable()
        {
            return ZDataManager.instance.getTable("floorball_speed");
        }

        public ZDBTable GetFloorBallBehaveTable()
        {
            return ZDataManager.instance.getTable("floorball_behave");
        }

        public ZDBTable GetFloorBallTypeTable()
        {
            return ZDataManager.instance.getTable("floorball_type");
        }

        public ZDBTable GetFloorBallTable()
        {
            return ZDataManager.instance.getTable("floorball");
        }

        public ZDBTable GetFastBreakTable()
        {
            return ZDataManager.Instance.getTable("fastbreak");
        }

        public ZDBTable GetSpeedChangeTable()
        {
            return ZDataManager.instance.getTable("speed_change");
        }

        public ZDBTable GetFoulTable()
        {
            return ZDataManager.instance.getTable("foul");
        }

        public ZDBTable GetSpeedUpDistanceTable()
        {
            return ZDataManager.instance.getTable("speed_up_distance");
        }

        public ZDBTable GetPickRollTable()
        {
            return ZDataManager.instance.getTable("pickroll_type");
        }

        public ZDBTable GetPickRollMoveTable()
        {
            return ZDataManager.instance.getTable("pickroll_move");
        }

        public ZDBTable GetShotBeforeTable()
        {
            return ZDataManager.instance.getTable("shot_before");
        }

        public ZDBTable GetShotFakeParamTable()
        {
            return ZDataManager.instance.getTable("shot_fakepara");
        }

        public ZDBTable GetDefenceTypeTable()
        {
            return ZDataManager.instance.getTable("defencetype");
        }

        public ZDBTable GetLiveTextTable()
        {
            return ZDataManager.instance.getTable("live_text");
        }

        public ZDBTable GetParameterTable()
        {
            return ZDataManager.Instance.getTable("parameter");
        }

        public ZDBTable GetPlayerlibraryTable()
        {
            return ZDataManager.Instance.getTable("playerlibrary");
        }
        public ZDBTable GetTeamlogoTable()
        {
            return ZDataManager.Instance.getTable("teamlogo");
        }
        public ZDBTable GetTeamnameTable()
        {
            return ZDataManager.Instance.getTable("teamname");
        }

        public ZDBTable GetServerDicTable()
        {
            return ZDataManager.Instance.getTable("serverdict");
        }

        public ZDBTable GetScheduleTable()
        {
            return ZDataManager.Instance.getTable("schedule");
        }

        public ZDBTable GetShotIndexTable()
        {
            return ZDataManager.Instance.getTable("shot_index");
        }

        public ZDBTable GetAutoBotsTable()
        {
            return ZDataManager.instance.getTable("autobots");
        }

        public ZDBTable GetDefenceHelpTable()
        {
            return ZDataManager.instance.getTable("defencehelp");
        }

        public ZDBTable GetTeamRatingTable()
        {
            return ZDataManager.instance.getTable("team_rating");
        }

        public ZDBTable GetTeamRatingInsideTable()
        {
            return ZDataManager.instance.getTable("team_rating_inside");
        }

        public ZDBTable GetTeamRatingOutsideTable()
        {
            return ZDataManager.instance.getTable("team_rating_outside");
        }

        public ZDBTable GetTeamRatingReboundTable()
        {
            return ZDataManager.instance.getTable("team_rating_rebound");
        }

        public ZDBTable GetSubsTypeTable()
        {
            return ZDataManager.instance.getTable("substitution_type");
        }

        public ZDBTable GetSubsTypeConditionTable()
        {
            return ZDataManager.instance.getTable("substitution_type_condition");
        }

        public ZDBTable GetSubsTable()
        {
            return ZDataManager.instance.getTable("substitution");
        }

        public ZDBTable GetSubsBaseTimeTable()
        {
            return ZDataManager.instance.getTable("substitution_base_time");
        }

        public ZDBTable GetSubsConditionTable()
        {
            return ZDataManager.instance.getTable("substitution_condition");
        }

        public ZDBTable GetGeneratePlayerInitial()
        {
            return ZDataManager.instance.getTable("generate_player_initial");
        }

        public ZDBTable GetCountry()
        {
            return ZDataManager.instance.getTable("country");
        }

        public ZDBTable GetLeague()
        {
            return ZDataManager.instance.getTable("league");
        }

        public ZDBTable GetLeagueMacthTime()
        {
            return ZDataManager.instance.getTable("league_matchtime");
        }

        public ZDBTable GetLeagueType()
        {
            return ZDataManager.instance.getTable("league_type");
        }

        public ZDBTable GetPlayerConstantTable()
        {
            return ZDataManager.instance.getTable("player_constant");
        }

        public ZDBTable GetPlayerAttrCacOrderTable()
        {
            return ZDataManager.instance.getTable("player_attribute_caculate_order");
        }

        public ZDBTable GetPlayerAttrCmpTable()
        {
            return ZDataManager.instance.getTable("player_attribute_comparation");
        }

        public ZDBTable GetCupTypeTable()
        {
            return ZDataManager.instance.getTable("cup_type");
        }

        public ZDBTable GetLeagueScheduleEight()
        {
            return ZDataManager.instance.getTable("league_schedule");
        }

        public ZDBTable GetLeagueScheduleTwelve()
        {
            return ZDataManager.instance.getTable("league_schedule_12");
        }

        public ZDBTable GetFilterKeysNameTable()
        {
            return ZDataManager.instance.getTable("filter_keys_name");
        }
    }
}
