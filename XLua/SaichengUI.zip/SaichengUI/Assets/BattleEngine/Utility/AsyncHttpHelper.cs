﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;

namespace Utility
{
    class AsyncHttpHelper
    {
        #region HttpWebRequest异步GET

        public static void AsyncGetWithWebRequest(string url)
        {
            var request = (HttpWebRequest) WebRequest.Create(new Uri(url));
            request.BeginGetResponse(new AsyncCallback(ReadCallback), request);
        }
 
        private static void ReadCallback(IAsyncResult asynchronousResult)
        {
            var request = (HttpWebRequest) asynchronousResult.AsyncState;
            var response = (HttpWebResponse) request.EndGetResponse(asynchronousResult);
            using (var streamReader = new StreamReader(response.GetResponseStream()))
            {
                var resultString = streamReader.ReadToEnd();
                Console.WriteLine(resultString);
            }
        }
 
        #endregion

        #region HttpWebRequest异步Post

        public static void AsyncPostWithWebRequest(string url,string postData)
        {
            byte[] data = Encoding.UTF8.GetBytes(postData);
            var request = (HttpWebRequest)WebRequest.Create(new Uri(url));
            request.Timeout = 30000;
            request.AllowAutoRedirect = false;
            request.Method = "POST";
            request.ContentType = "text/xml";
            request.ContentLength = data.LongLength;
            Stream writer = null;
            writer = request.GetRequestStream();
            writer.Write(data, 0, data.Length);
            writer.Flush();

            request.BeginGetResponse(new AsyncCallback(ReadCallback), request);
        }

        #endregion
 

    }
}
