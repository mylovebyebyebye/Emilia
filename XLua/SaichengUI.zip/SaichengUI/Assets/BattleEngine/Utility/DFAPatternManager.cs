﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Common.ZDB;

namespace Logic
{
    public class CDFANode
    {
        private Dictionary<char, CDFANode> dicChildren = new Dictionary<char, CDFANode>();

        private bool isTail = false;

        public bool IsTail
        {
            get { return this.isTail; }
        }

        public void SetTail()
        {
            this.isTail = true;
        }

        public char NodeValue { get; set; }


        public bool IsChildNode(char value)
        {
            if (this.dicChildren.ContainsKey(value))
            {
                return true;
            }
            return false;
        }

        public CDFANode GetChildNode(char value)
        {
            if (this.dicChildren.ContainsKey(value))
            {
                return this.dicChildren[value];
            }
            return null;
        }

        public CDFANode AddChildNode(char value, bool isTail = false)
        {
            if (this.dicChildren.ContainsKey(value))
            {
                return this.dicChildren[value];
            }
            CDFANode childNode = new CDFANode();
            childNode.NodeValue = value;
            if (isTail)
            {
                childNode.SetTail();
            }
            this.dicChildren.Add(value, childNode);
            return childNode;
        }
    }


    /// <summary>
    /// 屏蔽字
    /// </summary>
    public class DFAPatternManager
    {
        private static object lockObj = new object();

        private static DFAPatternManager instance = null;

        public static DFAPatternManager Instance
        {
            get
            {
                lock (lockObj)
                {
                    if (instance == null)
                    {
                        instance = new DFAPatternManager();
                    }
                }
                return instance;
            }
        }

        private CDFANode rootNode = new CDFANode();

        private bool isInit = false;
        
        private int invalidId = -1;

        private DFAPatternManager()
        {
 
        }
        public bool Init()
        {
            if (this.isInit)
            {
                return false;
            }
            ZDBTable filterTable = ZDataManager.Instance.GetFilterKeysNameTable();
            for(int i = 0;i < filterTable.getRowCount();i++)
            {
                ZDB_Row_Data rowData = filterTable.getDataByRow(i);
                string filter = rowData.getCol((int)filter_keys_nameFields.Content).GetUTFString();
                int length = filter.Length;
                int index = 0;
                CDFANode curNode = this.rootNode;
                bool isTail = false;
                foreach (char value in filter)
                {
                    if (index == length - 1)
                    {
                        isTail = true;
                    }
                    if (curNode.IsChildNode(value))
                    {
                        curNode = curNode.GetChildNode(value);
                        if (isTail && !curNode.IsTail)
                        {
                            curNode.SetTail();
                        }
                    }
                    else
                    {
                        curNode = curNode.AddChildNode(value, isTail);
                    }
                    index++;
                }
            }
            return true;
        }

        public bool IsContainIllegal(string strToVerify)
        {
            CDFANode curNode = this.rootNode;
            int length = strToVerify.Length;
            int startIndex = invalidId;
            for (int i = 0; i < length; i++)
            {
                char key = strToVerify[i];
                if (curNode.IsChildNode(key))
                {
                    curNode = curNode.GetChildNode(key);
                    if (startIndex == this.invalidId)
                    {
                        startIndex = i;
                    }
                    if (curNode.IsTail)
                    {
                        return true;
                    }
                }
                else
                {
                    if (startIndex == this.invalidId)
                    {
                        continue;
                    }
                    else
                    {
                        curNode = this.rootNode;
                        i = startIndex;
                        startIndex = this.invalidId;
                    }
                }
            }
            return false;
        }
    }
}
