﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Security.Cryptography;
using System.Collections;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Utility
{
    public class BasicMethod
    {
        public static string md5(string password)
        {
            byte[] result = Encoding.UTF8.GetBytes(password);  
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] output = md5.ComputeHash(result);
            return BitConverter.ToString(output).Replace("-", "").ToLower();
        }

        public static string today()
        {
            return DateTime.Now.ToString("yyyy年MM月dd日 dddd");
        }

        public static bool IsGUID(string str)
        {
            Match m = Regex.Match(str, @"^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$", RegexOptions.IgnoreCase);
            if (m.Success)
            {
                return true;
            }
            return false;
        }

        public static string repString(string strTemp)
        {
            if (strTemp == null)
                strTemp = "";
            strTemp = strTemp.Replace(" ", "");
            strTemp = strTemp.Replace("*", "");
            strTemp = strTemp.Replace("?", "");
            strTemp = strTemp.Replace("#", "");
            strTemp = strTemp.Replace("@", "");
            strTemp = strTemp.Replace("^", "");
            strTemp = strTemp.Replace("&", "");
            strTemp = strTemp.Replace("+", "");
            //strTemp = strTemp.Replace("-", "");
            strTemp = strTemp.Replace("(", "");
            strTemp = strTemp.Replace(")", "");
            strTemp = strTemp.Replace("!", "");
            strTemp = strTemp.Replace("`", "");
            strTemp = strTemp.Replace("~", "");
            strTemp = strTemp.Replace("<", "");
            strTemp = strTemp.Replace(">", "");
            strTemp = strTemp.Replace("'", "");
            strTemp = strTemp.Replace("\"", "");
            strTemp = strTemp.Replace("\\", "");
            strTemp = strTemp.Replace("|", "");
            strTemp = strTemp.Replace("=", "");
            strTemp = strTemp.Replace(",", "");
            strTemp = strTemp.Replace(";", "");
            return strTemp;
        }

        public static string GetFormatData(string strSumData)
        {
            Int64 number;
            //不是数字直接返回
            if (!Int64.TryParse(strSumData, out number))
            {
                return strSumData;
            }
            
            string strSecondPart = string.Empty;//.加小数部分
            string strFirstPart = string.Empty;//整数部分3位相隔用逗号隔开后的字符串
            string strZheng = string.Empty;//整数部分
#if !UNITY_5
            ArrayList arrayFirstPart = new ArrayList();
#endif
            double sumData = Convert.ToDouble(strSumData);
            strSumData = sumData.ToString();
            //先判断是否为负数
            bool isnegative = false;
            if (sumData < 0)
            {
                isnegative = true;
            }

            if (strSumData.Contains("."))
            {

                //整数部分用逗号隔开处理
                strZheng = strSumData.Split('.')[0].ToString();
                //负数的话先把负号去掉，增加完千分位后再添加回来
                if (isnegative)
                {
                    strZheng = strZheng.Substring(1);
                }
                strFirstPart = AddThousandPoint(strZheng);
                if (isnegative)
                {
                    strFirstPart = "-" + strFirstPart;
                }
                //第二部分为小数点+小数部分
                strSecondPart = strSumData.Split('.')[1].ToString();

                if (strSecondPart.Length >= 2)
                {
                    strSecondPart = "." + strSecondPart.Substring(0, 2);
                }
                else
                {
                    strSecondPart = "." + strSecondPart.PadRight(2, '0');
                }
            }
            else
            {
                if (isnegative)
                {
                    strSumData = strSumData.Substring(1);
                }
                strFirstPart = AddThousandPoint(strSumData);
                if (isnegative)
                {
                    strFirstPart = "-" + strFirstPart;
                }
                strSecondPart = ".00";
            }
            //最终返回字符串（加上小数点 及 小数点以后的部分）
            return strFirstPart ;
        }


        private static string AddThousandPoint(string strZheng)
        {
            ArrayList lst = new ArrayList();
            string result = string.Empty;
            int i = 1;
            if (strZheng.Length <= 3 * i)//小于等于3不需要加分位符
            {
                result = strZheng;
            }
            else
            {
                while (strZheng.Length > 3 * i)//循环取3位，前加逗号
                {
                    lst.Add("," + strZheng.Substring(strZheng.Length - (3 * i), 3));
                    i++;
                    if (strZheng.Length <= 3 * i)//将最后不需要加逗号的几位添加到arraylist最后
                        lst.Add(strZheng.Substring(0, strZheng.Length - 3 * (i - 1)));
                }
                //数组中的元素拼接组成最终加千分符以后的字符串
                for (int j = lst.Count - 1; j > -1; j--)
                {
                    result += lst[j].ToString();
                }
            }

            return result;
        }

        /// <summary>
        /// 根据日期计算日期周数（以周一为一周的第一天）
        /// </summary>
        /// <param name="date">日期</param>
        /// <returns>日期周数</returns>
        public static int WeekOfYear(DateTime date)
        {

            DayOfWeek dw = (Convert.ToDateTime(string.Format("{0}-1-1 0:0:0", date.Year.ToString()))).DayOfWeek;
            int day = 0;
            switch (dw)
            {
                case DayOfWeek.Monday:
                    {
                        day = -1;
                        break;
                    }
                case DayOfWeek.Tuesday:
                    {
                        day = 0;
                        break;
                    }
                case DayOfWeek.Wednesday:
                    {
                        day = 1;
                        break;
                    }
                case DayOfWeek.Thursday:
                    {
                        day = 2;
                        break;
                    }
                case DayOfWeek.Friday:
                    {
                        day = 3;
                        break;
                    }
                case DayOfWeek.Saturday:
                    {
                        day = 4;
                        break;
                    }
                case DayOfWeek.Sunday:
                    {
                        day = 5;
                        break;
                    }
            }
            int week = (date.DayOfYear + day) / 7 + 1;

            return week;
        }

        /// <summary>
        /// 把日期转成周数   格式"201301"
        /// </summary>
        /// <param name="datetime"></param>
        /// <returns></returns>
        public static int GetWeekAndYear(DateTime datetime)
        {
            string year = datetime.Year.ToString();
            string week = WeekOfYear(datetime).ToString().PadLeft(2, '0');

            return Convert.ToInt32(year + week);
        }

        /// <summary>   
        /// 将.NET的DateTime转换为unix time   
        /// </summary>   
        /// <param name="dateTime">待转换的时间</param>   
        /// <returns>转换后的unix time</returns>   
        public static long FromDateTime(DateTime dateTime)
        {
            return (dateTime.Ticks - BaseTime.Ticks) / 10000000 - 8 * 60 * 60;
        }

        private static DateTime BaseTime = new System.DateTime(1970, 1, 1, 0, 0, 0, 0);

        public static long GetCurrentTimeStamp()
        {
            return FromDateTime(DateTime.Now);
        }

        public static long GetTodayBeginTimestamp(long nowTime, int timeZone = 8)
        {
            long todayBegin = nowTime - ((nowTime + 3600 * timeZone) % 86400);
            return todayBegin;
        }

        /**/
        /// <summary>
        /// DES加密
        /// </summary>
        /// <param name="encryptString"></param>
        /// <returns></returns>
        public static string DesEncrypt(string encryptString, string key)
        {
            byte[] keyBytes = Encoding.UTF8.GetBytes(key.Substring(0, 8));
            byte[] keyIV = keyBytes;
            byte[] inputByteArray = Encoding.UTF8.GetBytes(encryptString);
            DESCryptoServiceProvider provider = new DESCryptoServiceProvider();
            MemoryStream mStream = new MemoryStream();
            CryptoStream cStream = new CryptoStream(mStream, provider.CreateEncryptor(keyBytes, keyIV), CryptoStreamMode.Write);
            cStream.Write(inputByteArray, 0, inputByteArray.Length);
            cStream.FlushFinalBlock();
            return Convert.ToBase64String(mStream.ToArray());
        }

        /**/
        /// <summary>
        /// DES解密
        /// </summary>
        /// <param name="decryptString"></param>
        /// <returns></returns>
        public static string DesDecrypt(string decryptString, string key)
        {
            try
            {
                byte[] keyBytes = Encoding.UTF8.GetBytes(key.Substring(0, 8));
                byte[] keyIV = keyBytes;
                byte[] inputByteArray = Convert.FromBase64String(decryptString);
                DESCryptoServiceProvider provider = new DESCryptoServiceProvider();
                MemoryStream mStream = new MemoryStream();
                CryptoStream cStream = new CryptoStream(mStream, provider.CreateDecryptor(keyBytes, keyIV), CryptoStreamMode.Write);
                cStream.Write(inputByteArray, 0, inputByteArray.Length);
                cStream.FlushFinalBlock();
                return Encoding.UTF8.GetString(mStream.ToArray());
            }
            catch
            { }
            return string.Empty;
        }


        /// <summary>   
        /// 将unixtime转换为.NET的DateTime   
        /// </summary>   
        /// <param name="timeStamp">秒数</param>   
        /// <returns>转换后的时间</returns>   
        public static DateTime FromUnixTime(long timeStamp)
        {
            return new DateTime((timeStamp + 8 * 60 * 60) * 10000000 + BaseTime.Ticks);
        }
        /// <summary>
        /// 今天是自1970年1月1日以来的第几天。当天是第0天
        /// </summary>
        /// <returns></returns>
        public static int GetDaysFrom1970()
        {
            DateTime now = DateTime.Now;
            TimeSpan ts = now - BaseTime;
            return ts.Days;
        }
        /// <summary>
        /// 指定一个时间，获取这个时间是自1970年以来的第几天。当天是第0天
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public static int GetDaysFrom1970(DateTime time)
        {
            DateTime dTime;
            if (time < BaseTime)
            {
                dTime = BaseTime;
            }
            else
            {
                dTime = time;
            }
            TimeSpan ts = dTime - BaseTime;
            return ts.Days;
        }

        public static T Clone<T>(T realObject)
        {
            using (Stream objectStream = new MemoryStream())
            {
                //利用 System.Runtime.Serialization序列化与反序列化完成引用对象的复制  
                IFormatter formatter = new BinaryFormatter();
                formatter.Serialize(objectStream, realObject);
                objectStream.Seek(0, SeekOrigin.Begin);
                return (T)formatter.Deserialize(objectStream);
            }   
        }
        //跟上面的函数重复了
//         public static long GetTodayBeginTimestamp(long nowTime)
//         {
//             long todayBegin = nowTime - ((nowTime + 3600 * 8) % 86400);
//             return todayBegin;
//         }

        public static bool IsPassDay(long timestamp, long nowTime)
        {
            long todayBegin = GetTodayBeginTimestamp(nowTime);
            if (timestamp < todayBegin)
            {
                return true;
            }
            return false;
        }
    }
}
