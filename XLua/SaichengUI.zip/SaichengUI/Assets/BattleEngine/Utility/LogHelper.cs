﻿using System;   
using System.IO;
#if UNITY_5
#else
using System.Data;
using log4net;
#endif




namespace Utility
{
#if UNITY_5
#else
    /**/
    /// <summary>   
    /// LogHelper的摘要说明。   
    /// </summary>   
    public class LogHelper
    {
        private static object lockOjb = new object();
        private static LogHelper instance = null;


        public static LogHelper Instance
        {
            get
            {
                lock (lockOjb)
                {
                    if (instance == null)
                    {
                        instance = new LogHelper();
                    }
                }
                return instance;
            }
        }
        
        private LogHelper()
        {
     
        }
        public void SetConfig()
        {
            log4net.Config.XmlConfigurator.Configure();
        }

        public void SetConfig(FileInfo configFile)
        {
            log4net.Config.XmlConfigurator.Configure(configFile);
        }
        
        public void WriteLog(ILog ilog, string info,Exception se)
        {
            if (ilog.IsErrorEnabled)
            {
                ilog.Error(info, se);
            }
        }
        public void WriteLog(ILog ilog, LogLevelEnum eLevel, string info)
        {     
            switch (eLevel)
            {
                case LogLevelEnum.Debug:
                    {
                        if (ilog.IsDebugEnabled)
                        {
                            ilog.Debug(info);
                        }
                    }
                    break;
                case LogLevelEnum.Info:
                    {
                        if (ilog.IsInfoEnabled)
                        {
                            ilog.Info(info);
                        }
                    }
                    break;
                case LogLevelEnum.Warn:
                    {
                        if (ilog.IsWarnEnabled)
                        {
                            ilog.Warn(info);
                        }
                    }
                    break;
                case LogLevelEnum.Fatal:
                    {
                        if (ilog.IsFatalEnabled)
                        {
                            ilog.Fatal(info);
                        }
                    }
                    break;
                case LogLevelEnum.Error:
                    {
                        if (ilog.IsErrorEnabled)
                        {
                            ilog.Error(info);
                        }
                    }
                    break;
            }
                
        }
    }
#endif
    public enum LogLevelEnum
    {
        Error= 0,
        Debug = 1,
        Info = 2,
        Warn = 3,
        Fatal= 4

    }

    public enum LogTypeEnum
    {
        LogError=0,
        LogInfo = 1,
        GameLogInfo =2,
        TopupInfo = 3

    }
}