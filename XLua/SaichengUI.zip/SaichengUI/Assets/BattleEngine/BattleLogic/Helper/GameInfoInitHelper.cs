﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Common.ZDB;
using Entity.BattleLogic;

namespace BattleLogic
{
    public class GameInfoInitHelper
    {
        public static GameInfo InitGameInfoByRandomSeedRosters(int randomSeed, Roster homeRoster, Roster awayRoster)
        {
            GameInfo gameInfo = new GameInfo(randomSeed);

            Team home = new Team(TeamType.Home);
            home.AttackField = gameInfo.RightField;

            Team away = new Team(TeamType.Away);
            away.AttackField = gameInfo.LeftField;

            home.SetAnotherTeam(away);
            away.SetAnotherTeam(home);

            home.InitPlayers(homeRoster, gameInfo);
            away.InitPlayers(awayRoster, gameInfo);

            gameInfo.HomeTeam = home;
            gameInfo.AwayTeam = away;

            gameInfo.Init();

            return gameInfo;
        }

        public static GameInfo InitGameInfoByRandomSeed(int randomSeed)
        {
#if !UNITY_5
            Roster homeRoster, awayRoster;
            if (File.Exists("./roster.xml"))
            {
                List<Roster> rosters = Utility.XmlHelper.XmlDeserializeFromFile<List<Roster>>("./roster.xml", Encoding.UTF8);
                homeRoster = rosters[0];
                awayRoster = rosters[1];
            }
            else
            {
                homeRoster = new Roster();
                awayRoster = new Roster();
                ZDBTable playerTable = ZDataManager.Instance.GetPlayerTable();
                for (int i = 0; i < 5; i++)
                {
                    ZDB_Row_Data rowData = playerTable.getDataByRow(i);
                    int id = rowData.getCol(0).getValueInt();
                    homeRoster.AllPlayers.Add(id);
                    homeRoster.Starters[i] = id;

                    awayRoster.AllPlayers.Add(id);
                    awayRoster.Starters[i] = id;
                }
            }
            return InitGameInfoByRandomSeedRosters(randomSeed, homeRoster, awayRoster);
#else
            return null;
#endif
        }

    }
}
