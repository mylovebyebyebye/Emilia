﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity.BattleLogic;
using Entity;

namespace BattleLogic
{
    [Serializable]
    public enum TeamType
    {
        Home        = 1,
        Away        = 2,
    }

    /// <summary>
    /// 犯规统计
    /// </summary>
    public class TeamFoul
    {
        //第几节
        private int quarter;
        //总次数
        private int count;
        //不在最后两分钟内的次数
        private int notIn2MinCount;
        //最后两分钟的次数
        private int in2MinCount;

        public TeamFoul(int quarter)
        {
            this.quarter = quarter;
            this.count = 0;
            this.notIn2MinCount = 0;
            this.in2MinCount = 0;
        }

        public int GetTotalCount()
        {
            return this.count;
        }

        public void AddCount(int count, double seconds)
        {
            this.count += count;
            if (seconds > 120)
            {
                this.notIn2MinCount += count;
            }
            else
            {
                this.in2MinCount += count;
            }
        }

        public bool IsBonusFreeThrow()
        {
            bool res = false;
            if (this.quarter <= 4)
            {
                //常规时间
                if (this.count > 4)
                {
                    res = true;
                }
                else if (this.quarter == 4 && this.notIn2MinCount < 4 && this.in2MinCount > 1)
                {
                    //若第四节前10分钟所有球员犯规和<4次，则最后2分钟犯规和>1次,罚球
                    res = true;
                }
            }
            else
            {
                //加时赛
                if (this.count > 3)
                {
                    res = true;
                }
                else if (this.notIn2MinCount < 3 && this.in2MinCount > 1)
                {
                    res = true;
                }
            }
            return res;
        }
    }

    public class TeamPassBallInfo
    {
        private int lastPassBallFrame;

        public int LastPassBallFrame
        {
            get { return lastPassBallFrame; }
        }

        private Player lastPassBallPlayer;
        public Player LastPassBallPlayer
        {
            get { return this.lastPassBallPlayer; }
        }

        public TeamPassBallInfo()
        {
            this.lastPassBallFrame = -1000000;
            this.lastPassBallPlayer = null;
        }

        public void SetInfo(int gameFrame, Player player)
        {
            this.lastPassBallFrame = gameFrame;
            this.lastPassBallPlayer = player;
        }

        public void Clear()
        {
            this.lastPassBallFrame = -1000000;
        }
    }

    public class Team
    {
        public string Name { get; set; }
        public string NameAbb { get; set; }

        public int PlayerCount = 0;

        public List<Player> Players = new List<Player>();

        public List<Player> BenchPlayers = new List<Player>();

        public List<Player> Bench2rdPlayers = new List<Player>();

        public List<Player> FansPlayers = new List<Player>();

        private Dictionary<long, Player> dicPlayers = new Dictionary<long, Player>();

        //每节几个犯规
        private Dictionary<int, TeamFoul> dicFoul = new Dictionary<int, TeamFoul>();

        private TeamPassBallInfo passBallInfo;

        public TeamPassBallInfo PassBallInfo
        {
            get { return passBallInfo; }
        }
        
        private TeamType teamType;

        public TeamType TeamType
        {
            get { return teamType; }
        }

        public int Icon;

        public Field AttackField { get; set; }

        public Position AttackBasket
        {
            get
            {
                return this.AttackField.GetBasketPos();
            }
        }

        public Player MaxScoringPlayer { get; set; }

        public Player AskBallPlayer { get; set; }

        /// <summary>
        /// 控球最高
        /// </summary>
        public Player MaxHanlder{get;set;}

        /// <summary>
        /// 对位情况表
        /// key是防守人角色，value是进攻人角色
        /// </summary>
        private Dictionary<int, int> dicRoleDef = new Dictionary<int, int>();

        public List<TeamRatingEntity> TeamRatingLst = new List<TeamRatingEntity>();

        /// <summary>
        /// 对方
        /// </summary>
        private Team anOtherTeam;

        public void SetAnotherTeam(Team team)
        {
            this.anOtherTeam = team;
        }

        private Roster roster;

        public Roster GetRoster()
        {
            return this.roster;
        }

        /// <summary>
        /// 单打人
        /// </summary>
        private Player singleAttacker;
        /// <summary>
        /// 单打人
        /// </summary>
        public Player SingleAttacker
        {
            get
            {
                return this.singleAttacker;
            }
        }
        /// <summary>
        /// 清除单打人标记
        /// </summary>
        public void ClearSingleAttacker()
        {
            this.singleAttacker = null;
        }
        /// <summary>
        /// 设置单打人
        /// </summary>
        /// <param name="player"></param>
        public void SetSingleAttacker(Player player)
        {
            this.singleAttacker = player;
        }

        public Team(TeamType type)
        {
            this.teamType = type;
            this.Name = this.teamType.ToString();
            this.NameAbb = this.Name.Substring(0, 3);
            this.singleAttacker = null;
            this.passBallInfo = new TeamPassBallInfo();
            this.anOtherTeam = null;
            this.Icon = 1;
        }

        private int CompareOverall(Player p1, Player p2)
        {
            double p1Overall = p1.GetAttribute(PlayerAttribute.Overall);
            double p2Overall = p2.GetAttribute(PlayerAttribute.Overall);
            return p2Overall.CompareTo(p1Overall);
        }

        public void InitPlayers(Roster roster, GameInfo gameInfo)
        {
            this.roster = roster;
            ZDBTable playerTable = ZDataManager.Instance.getTable("player");
            for (int i = 0; i < 5; i++)
            {
                Player player = new Player(gameInfo, this);
                player.InitFromDB(playerTable.getDataByID( (int)roster.Starters[i] ));

                this.AddPlayer(player);
                this.dicPlayers.Add(roster.Starters[i], player);
            }
            //给主力进行排序,确定上场时间
            List<Player> lstOverall = new List<Player>();
            lstOverall.AddRange(this.Players);
            lstOverall.Sort(this.CompareOverall);

            //主力上场时间
            //todo 直接取了团队模式，明星模式的没取
            //ZDBTable subsBaseTimeTable = ZDataManager.Instance.GetSubsBaseTimeTable();
            //for (int i = 0; i < 5; i++)
            //{
            //    int id = 1000 + i + 1;
            //    ZDB_Row_Data rowData = subsBaseTimeTable.getDataByID(id);
            //    lstOverall[i].TotalRegularTime = rowData.getCol((int)substitution_base_timeFields.TotalRegularTime).getValueInt();
            //}

            for (int i = 0; i < 5; i++)
            {
                if (roster.BenchPlayers[i] != 0)
                {
                    if(!this.dicPlayers.ContainsKey(roster.BenchPlayers[i]))
                    {
                        Player player = new Player(gameInfo, this);
                        player.Role = i + 1;
                        player.InitFromDB(playerTable.getDataByID((int)roster.BenchPlayers[i]));
                        this.BenchPlayers.Add(player);
                        this.dicPlayers.Add(roster.BenchPlayers[i], player);
                    }
                }
            }
            for (int i = 0; i < roster.AllPlayers.Count; i++)
            {
                if (roster.AllPlayers[i] != 0)
                {
                    if (!this.dicPlayers.ContainsKey(roster.AllPlayers[i]))
                    {
                        Player player = new Player(gameInfo, this);
                        player.InitFromDB(playerTable.getDataByID((int)roster.AllPlayers[i]));
                        this.Bench2rdPlayers.Add(player);
                        this.dicPlayers.Add(roster.AllPlayers[i], player);
                    }
                }
            }
        }

        /// <summary>
        /// 记录突破debuff的人
        /// </summary>
        private List<Player> lstCrossOverDebuff = new List<Player>();

        public void AddPlayerToCrossOverDebuff(Player player)
        {
            this.lstCrossOverDebuff.Add(player);
        }

        public void ClearCrossOverDebuffPlayer()
        {
            for (int i = 0; i < this.lstCrossOverDebuff.Count; i++)
            {
                this.lstCrossOverDebuff[i].ClearCrossOver();
            }
            this.lstCrossOverDebuff.Clear();
        }

        public void RemovePlayerFromCrossOverDebuff(Player player)
        {
            if (this.lstCrossOverDebuff.Contains(player))
            {
                this.lstCrossOverDebuff.Remove(player);
            }
        }

        /// <summary>
        /// 平均速度
        /// </summary>
        /// <returns></returns>
        public double AverageSpeed()
        {
            int count = 0;
            double sum = 0f;
            for (int i = 0; i < this.PlayerCount; i++)
            {
                sum += this.Players[i].GetAttribute(PlayerAttribute.Speed);
                count++;
            }

            return sum / count;
        }

        public void AddPlayer(Player player)
        {
            this.SetMaxAbilityPlayer(player);
            if (!player.IsFans)
            {
                this.Players.Add(player);
                player.Role = this.Players.Count;
                this.PlayerCount++;
            }
        }

        public void SetMaxAbilityPlayer(Player player)
        {
            //控球
            if (this.MaxHanlder == null)
            {
                this.MaxHanlder = player;
            }
            else if (player.GetAttribute(PlayerAttribute.Handing) > this.MaxHanlder.GetAttribute(PlayerAttribute.Handing))
            {
                this.MaxHanlder = player;
            }
        }

        public Player GetMyPosDefPlayer(Player player, int type = 0)
        {
            List<Player> lst = this.GetAllMyPosDefPlayer(player);
            if (lst.Count != 0)
            {
                return lst[0];
            }
            return null;
        }

        /// <summary>
        /// 获取对方所有防守我的球员
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public List<Player> GetAllMyPosDefPlayer(Player player)
        {
            List<Player> lst = new List<Player>();
            for (int i = 0; i < this.anOtherTeam.PlayerCount; i++)
            {
                Player defPlayer = this.anOtherTeam.Players[i];
                Player p = defPlayer.GetMyPosAttacker();
                if (player.IsSamePlayer(p))
                {
                    lst.Add(defPlayer);
                }
            }

            return lst;
        }

        public Player GetMyPosAtkPlayer(Player player)
        {
            int myRole = player.Role;
            if (this.dicRoleDef.ContainsKey(myRole))
            {
                //说明换防过了
                return this.anOtherTeam.Players[this.dicRoleDef[myRole] - 1]; 
            }
            return this.anOtherTeam.Players[player.Role - 1];
        }

        /// <summary>
        /// 补防以后设置对位的人
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <param name="defPlayer"></param>
        public void SetMyPosAtkPlayer(Player atkPlayer, Player defPlayer)
        {
            if (atkPlayer.Role == defPlayer.Role)
            {
                if (this.dicRoleDef.ContainsKey(defPlayer.Role))
                {
                    this.dicRoleDef.Remove(defPlayer.Role);
                }
                return;
            }
            if (this.dicRoleDef.ContainsKey(defPlayer.Role))
            {
                this.dicRoleDef[defPlayer.Role] = atkPlayer.Role;
            }
            else
            {
                this.dicRoleDef.Add(defPlayer.Role, atkPlayer.Role);
            }
        }

        public void ResetPosDef()
        {
            this.dicRoleDef.Clear();
        }


        /// <summary>
        /// 增加犯规次数
        /// 这里tm有一个隐藏规则
        /// </summary>
        /// <param name="quarter"></param>
        /// <param name="count"></param>
        public void AddFoul(int quarter, int count, double seconds)
        {
            if (this.dicFoul.ContainsKey(quarter))
            {
                this.dicFoul[quarter].AddCount(count, seconds);
            }
            else
            {
                TeamFoul tf = new TeamFoul(quarter);
                tf.AddCount(count, seconds);
                this.dicFoul.Add(quarter, tf);
            }
        }
        /// <summary>
        /// 返回某节犯规次数
        /// </summary>
        /// <param name="quarter"></param>
        /// <returns></returns>
        public bool IsNeedBonusFreeThrow(int quarter)
        {
            if (this.dicFoul.ContainsKey(quarter))
            {
                return this.dicFoul[quarter].IsBonusFreeThrow();
            }
            return false;
        }

        /// <summary>
        /// 返回某节犯规次数
        /// </summary>
        /// <param name="quarter"></param>
        /// <returns></returns>
        public int GetTeamFoul(int quarter)
        {
            if (this.dicFoul.ContainsKey(quarter))
            {
                return this.dicFoul[quarter].GetTotalCount();
            }
            return 0;
        }

        public void SetPassBallInfo(int gameFrame, Player player)
        {
            this.passBallInfo.SetInfo(gameFrame, player);
        }

        public int FreeNum = 0;

        public void Update(GameInfo gameInfo)
        {
            this.FreeNum = 0;
            for(int i = 0;i < this.PlayerCount;i++)
            {
                Player player = this.Players[i];
                player.Update(gameInfo);
                if (player.IsFree)
                {
                    this.FreeNum += 1;
                }
            }
        }

        /// <summary>
        /// 通过playerid获取对应的球员
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Player GetPlayerById(long id)
        {
            return this.dicPlayers[id];
        }

        public void ClearAllPlayerThisQuarterPlayeFrame()
        {
            for (int i = 0; i < 5; i++)
            {
                this.Players[i].ThisQuarterPlayerFrame = 0;
            }
            for (int i = 0; i < this.BenchPlayers.Count; i++)
            {
                this.BenchPlayers[i].ThisQuarterPlayerFrame = 0;
            }
        }

        /// <summary>
        /// 生成一个球迷
        /// </summary>
        /// <param name="gameInfo"></param>
        /// <returns></returns>
        public Player CreateAFans(GameInfo gameInfo)
        {
            int startIndex = 100000;
            ZDBTable playerTable = ZDataManager.Instance.getTable("player");
            Player player = new Player(gameInfo, this);
            player.InitFromDB(playerTable.getDataByID(startIndex + this.FansPlayers.Count + 1));
            player.IsFans = true;

            this.FansPlayers.Add(player);
            this.AddPlayer(player);
            this.dicPlayers.Add(player.Id, player);

            return player;
        }

        /// <summary>
        /// 获取后备
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public bool GetBench2rdPlayer(int role, out Player player)
        {
            player = null;
            if (this.Bench2rdPlayers.Count == 0)
            {
                return false;
            }
            switch (role)
            {
                case (int)PlayerRole.PG:
                    {
                        this.Bench2rdPlayers.Sort(TacSubstitute.CompareAblityPG);
                    }
                    break;
                case (int)PlayerRole.SG:
                    {
                        this.Bench2rdPlayers.Sort(TacSubstitute.CompareAblitySG);
                    }
                    break;
                case (int)PlayerRole.SF:
                    {
                        this.Bench2rdPlayers.Sort(TacSubstitute.CompareAblitySF);
                    }
                    break;
                case (int)PlayerRole.PF:
                    {
                        this.Bench2rdPlayers.Sort(TacSubstitute.CompareAblityPF);
                    }
                    break;
                case (int)PlayerRole.C:
                    {
                        this.Bench2rdPlayers.Sort(TacSubstitute.CompareAblityC);
                    }
                    break;
            }
            player = this.Bench2rdPlayers[0];
            player.Role = role;
            this.Bench2rdPlayers.RemoveAt(0);
            return true;
        }
    }
}
