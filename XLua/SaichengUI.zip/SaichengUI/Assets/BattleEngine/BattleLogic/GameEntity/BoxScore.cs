﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public enum BoxScoreType
    {
        Begin                   = 0,
        FramePlayed             = 1,
        FGM                     = 2,//投篮命中数
        FGA                     = 3,//投篮数
        F3PM                    = 4,//3分中
        F3PA                    = 5,//3分投数
        FTM                     = 6,//罚球进的
        FTA                     = 7,//罚球数
        OREB                    = 8,//进攻篮板
        DREB                    = 9,//防守篮板
        AST                     = 10,//助攻
        TOV                     = 11,//失误
        STL                     = 12,//抢断
        BLK                     = 13,//盖帽
        PF                      = 14,//犯规
        PTS                     = 15,//得分
        Dunks                   = 16,//扣篮数
        Layups                  = 17,//上篮数
        FadeAways               = 18,//后仰投篮
        Hooks                   = 19,//勾手    
        BlockFillIn             = 20,//协防盖帽
        StealInsideAttack       = 21,//背打抢断
        StealPassBall           = 22,//传球
        StealCrossOver          = 23,//过人
        StealInsideAtkDoubled   = 24,//背打包夹
        FoulOnFadeAway          = 25,//后仰犯规
        FoulOnDunk              = 26,//扣篮犯规
        FoulOnShot              = 27,//投篮犯规
        FoulOnCrossOver         = 28,//突破犯规
        AttackFoulOnCrossOver   = 29,//突破进攻犯规
        FoulOnDoubled           = 30,//夹击犯规
        AttackFoulOnDoubled     = 31,//夹击进攻犯规
        FoulOnInsideAttack      = 32,//背打犯规
        AttackFoulOnInsideAttack= 33,//背打进攻犯规
        FoulOnPickRoll          = 34,//挡拆犯规
        AttackFoulOnPickRoll    = 35,//挡拆进攻犯规
        BA                      = 36,//被盖
        Stolen                  = 37,//被断
        InsideShot              = 38,//内线投篮
        JumpShot2               = 39,//2分跳投
        JumpShot3               = 40,//3分跳投
        FoulOnCoverPaowei       = 41,//掩护犯规
        AtkFoulOnCoverPaowei    = 42,//掩护进攻犯规

        CanNotModify = 43,

        Min = 44,//时间
        FG = 45,//总命中率
        F3PG = 46,//三分命中率
        FT = 47,//罚球命中率
        REB = 48,//总篮板

        End,
    }

    [Serializable]
    public class BoxScorePerson
    {
        public TeamType Team;
        public string TeamName;
        public long RoleID;
        public string Name;
        public string Role;

        public List<double> lstScore = new List<double>();

        public BoxScorePerson()
        {
            for (int i = (int)BoxScoreType.Begin; i < (int)BoxScoreType.End; i++)
            {
                this.lstScore.Add(0);
            }
        }

        public void AddBoxScore(BoxScoreType type, int value)
        {
            int iType = (int)type;
            if ((int)BoxScoreType.CanNotModify > iType)
            {
                this.lstScore[iType] += value;
            }
        }

        private double GetBoxScore(BoxScoreType type)
        {
            return this.lstScore[(int)type];
        }

        public string GetBoxScoreByType(BoxScoreType type)
        {
            string value = string.Empty;
            switch (type)
            {
                case BoxScoreType.Min:
                    {
                        value = TimeFrameConverter.GetTimeDesc((int)(TimeFrameConverter.ConvertFrameToSecond((int)this.GetBoxScore(BoxScoreType.FramePlayed))));
                    }
                    break;
                case BoxScoreType.FG:
                    {
                        if (this.GetBoxScore(BoxScoreType.FGA) > 0)
                        {
                            value = ((double)(Math.Round(((this.GetBoxScore(BoxScoreType.FGM) ) / (this.GetBoxScore(BoxScoreType.FGA) )), 3) * 100)).ToString() + "%";
                        }
                    }
                    break;
                case BoxScoreType.F3PG:
                    {
                        if (this.GetBoxScore(BoxScoreType.F3PA) > 0)
                        {
                            value = ((double)(Math.Round((this.GetBoxScore(BoxScoreType.F3PM) / this.GetBoxScore(BoxScoreType.F3PA)), 3) * 100)).ToString() + "%";
                        }
                    }
                    break;
                case BoxScoreType.FT:
                    {
                        if (this.GetBoxScore(BoxScoreType.FTA) > 0)
                        {
                            value = ((double)(Math.Round((this.GetBoxScore(BoxScoreType.FTM) / this.GetBoxScore(BoxScoreType.FTA)), 3) * 100)).ToString() + "%";
                        }
                    }
                    break;
                case BoxScoreType.REB:
                    {
                        value = ((int)this.GetBoxScore(BoxScoreType.OREB) + (int)this.GetBoxScore(BoxScoreType.DREB)).ToString();
                    }
                    break;
                default:
                    {
                        value = ((int)this.GetBoxScore(type)).ToString();
                    }
                    break;
            }
            return value;
        }
    }

    [Serializable]
    public class TeamBoxScore
    {
        public List<BoxScorePerson> lstPerson = new List<BoxScorePerson>();
        private Dictionary<long, BoxScorePerson> dicPerson = new Dictionary<long, BoxScorePerson>();

        private BoxScorePerson teamBox;
        private Team Team;

        public TeamBoxScore(Team team)
        {
            for (int i = 0; i < team.PlayerCount; i++)
            {
                Player player = team.Players[i];

                BoxScorePerson person = new BoxScorePerson();
                person.Team = team.TeamType;
                person.TeamName = team.Name;
                person.Name = player.Name;
                person.RoleID = player.RoleID;
                person.Role = ((PlayerRole)player.Role).ToString();

                this.lstPerson.Add(person);
                this.dicPerson.Add(player.RoleID, person);
            }

            for (int i = 0; i < team.BenchPlayers.Count; i++)
            {
                Player player = team.BenchPlayers[i];

                BoxScorePerson person = new BoxScorePerson();
                person.Team = team.TeamType;
                person.TeamName = team.Name;
                person.Name = player.Name;
                person.RoleID = player.RoleID;
                person.Role = ((PlayerRole)player.Role).ToString();

                this.lstPerson.Add(person);
                this.dicPerson.Add(player.RoleID, person);
            }

            for (int i = 0; i < team.Bench2rdPlayers.Count; i++)
            {
                Player player = team.Bench2rdPlayers[i];

                BoxScorePerson person = new BoxScorePerson();
                person.Team = team.TeamType;
                person.TeamName = team.Name;
                person.Name = player.Name;
                person.RoleID = player.RoleID;
                person.Role = ((PlayerRole)player.Role).ToString();

                this.lstPerson.Add(person);
                this.dicPerson.Add(player.RoleID, person);
            }

            this.Team = team;
            this.teamBox = new BoxScorePerson();
            this.teamBox.Team = team.TeamType;
            this.teamBox.TeamName = teamBox.Name;
        }

        private BoxScorePerson AddPlayer(Player player)
        {
            BoxScorePerson person = new BoxScorePerson();
            person.Team = this.Team.TeamType;
            person.TeamName = this.Team.Name;
            person.Name = player.Name;
            person.RoleID = player.RoleID;
            person.Role = ((PlayerRole)player.Role).ToString();

            this.lstPerson.Add(person);
            this.dicPerson.Add(player.RoleID, person);
            return person;
        }

        public void AddBoxScore(long roleID, BoxScoreType type, int value, bool addTeamBoxScore = true)
        {
            BoxScorePerson person;
            if (!this.dicPerson.TryGetValue(roleID, out person))
            {
                Player player = this.Team.GetPlayerById(roleID % 100000000);
                person = this.AddPlayer(player);
            }

            person.AddBoxScore(type, value);
            if (addTeamBoxScore)
            {
                this.teamBox.AddBoxScore(type, value);
            }
        }

        public string GetPersonalBoxScoreByType(long RoleID, BoxScoreType type)
        {
            return this.dicPerson[RoleID].GetBoxScoreByType(type);
        }

        public string GetTeamBoxScore(BoxScoreType type)
        {
            return this.teamBox.GetBoxScoreByType(type);
        }
    }

    public class BoxScore
    {
        //public Dictionary<TeamType, TeamBoxScore> dicBoxScore = new Dictionary<TeamType, TeamBoxScore>();
        private List<TeamBoxScore> lstBoxScore = new List<TeamBoxScore>();

        public BoxScore()
        {
        }

        public void AddTeam(Team team)
        {
            if (this.lstBoxScore.Count >= 2)
            {
                this.lstBoxScore.Clear();
            }
            TeamBoxScore box = new TeamBoxScore(team);
            this.lstBoxScore.Add(box);
        }

        public void AddBoxScore(TeamType team, long roleID, BoxScoreType type, int value, bool addTeamBoxScore = true)
        {
            this.lstBoxScore[(int)team - 1].AddBoxScore(roleID, type, value, addTeamBoxScore);
        }

        public string GetPersonalBoxScore(TeamType team, long roleID, BoxScoreType type)
        {
            return this.lstBoxScore[(int)team - 1].GetPersonalBoxScoreByType(roleID, type);
        }

        public string GetTeamBoxScore(TeamType team, BoxScoreType type)
        {
            return this.lstBoxScore[(int)team - 1].GetTeamBoxScore(type);
        }

        public TeamBoxScore GetTeamAllBoxScore(TeamType team)
        {
            return this.lstBoxScore[(int)team - 1];
        }

    }
}
