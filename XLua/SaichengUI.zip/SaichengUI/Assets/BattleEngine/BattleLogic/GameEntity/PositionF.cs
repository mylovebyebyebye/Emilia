﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class PositionF
    {
        public double X { get; set; }
        public double Y { get; set; }

        public PositionF(double x, double y)
        {
            this.X = x;
            this.Y = y;
        }
    }
}
