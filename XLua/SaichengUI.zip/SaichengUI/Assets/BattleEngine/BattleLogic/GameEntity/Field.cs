﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public enum FieldType
    {
        Left = 1,
        Right = 2,
    }

    public class ReboundPostion
    {
        public Position Pos { get; set; }

        public bool IsOccupied { get; set; }

        public ReboundPostion()
        {
            this.IsOccupied = false;
            this.Pos = Position.Empty.Clone();
        }

        public ReboundPostion(int x, int y)
            :this()
        {
            this.Pos.X = x;
            this.Pos.Y = y;
        }
    }

    public abstract class Field
    {
        protected abstract void Init();
        public abstract bool IsCorner(Position pos);
        public abstract Position GetRandomReboundPosByAngleRadius(int angle, double Radius);
        /// <summary>
        /// 是否在这半场，不管界内界外
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        public abstract bool IsOnMe(Position pos);
        /// <summary>
        /// 是否出了底线
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        public abstract bool IsOutOfBottomLine(Position pos);
        /// <summary>
        /// 获取离出三秒区最近的点
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        public abstract Position GetOutOf3SAreatNearestPos(Position pos);
        /// <summary>
        /// 是否处于篮板后方
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        public abstract bool IsBehindRebound(Position pos);

        /// <summary>
        /// 弧顶3分线距离
        /// 单位 像素
        /// </summary>
        public readonly int TopOfTheCircle3PDistance = 240;
        public readonly int Corner3PDistance = 224;
        protected readonly int MiddleX = 506;
        protected Position BasketPos;
        protected List<Area> lstPresetArea = new List<Area>();
        //protected Area BallHandlerArea;
        protected List<ReboundPostion> lstReboundPosition = new List<ReboundPostion>();
        protected List<Position> lstMidJumpPosition = new List<Position>();
        protected Position freeThrowPos;
        protected List<Position> lstDefFTPos = new List<Position>();
        protected List<Position> lstAtkFTPos = new List<Position>();
        //违例罚球，非罚球人站位
        protected List<Position> lstDefTechFTPos = new List<Position>();
        protected List<Position> lstAtkTechFTPos = new List<Position>();
        //篮筐与X轴夹角，场内方向
        protected int XAxisAngle;
        /// <summary>
        /// 篮筐与X轴夹角，场内方向
        /// </summary>
        /// <returns></returns>
        public int GetXAxisAngle()
        {
            return this.XAxisAngle;
        }
        
        /// <summary>
        /// 罚球线与边线交点
        /// </summary>
        protected List<Position> lstFTLine = new List<Position>();

        //犯规发球点1
        protected Position foulThrowIn1;
        //犯规发球点1
        protected Position foulThrowIn2;
        //扣篮出手点
        protected Position slumDunkShotPos;

        protected int freeThrowMinAngle;
        /// <summary>
        /// 3秒区
        /// </summary>
        protected Area Area3Second;

        /// <summary>
        /// 出界底线后，边线发球点1
        /// </summary>
        protected Position sideThrowIn1;
        /// <summary>
        /// 出界底线后，边线发球点2
        /// </summary>
        protected Position sideThrowIn2;

        public int FreeThrowMinAngle
        {
            get { return freeThrowMinAngle; }
        }
        protected int freeThrowMaxAngle;

        public int FreeThrowMaxAngle
        {
            get { return freeThrowMaxAngle; }
        }

        protected Position Top = null;
        protected Position Bottom = null;
        protected int RevisedX = 0;
        public Position ThrowInPos = null;
        public Position TopLeft = null;
        public Position BtmRight = null;
        public int PosOrNegX = 1;

        

        public FieldType FieldType;

        protected CourtZoneManager courtZoneManager;

        public CourtZoneManager CourtZoneManager
        {
            get
            {
                return this.courtZoneManager;
            }
        }

        public Field(FieldType fieldType)
        {
            this.FieldType = fieldType;
            this.Init();

            this.courtZoneManager = new CourtZoneManager();
            this.courtZoneManager.Init(this.FieldType, this.BasketPos);
        }

        public Position GetBasketPos()
        {
            return this.BasketPos;
        }

        public bool IsOutOfTopCircleArc(Position pos)
        {
            if (pos.Distance(this.BasketPos) > this.TopOfTheCircle3PDistance)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 是不是3分
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        public bool Is3P(Position pos, double disToBasket)
        {
            //正面三分远，如果距离已经超过这个，必然是三分
            if (disToBasket > this.TopOfTheCircle3PDistance)
            {
                return true;
            }
            //判是不是底角和侧面三分， 这个只要先判x左边是属于侧面3分范围
            //然后再判y坐标跟篮筐y坐标的叉的，绝对值大于预设值
            if (this.IsCorner(pos) && Math.Abs( pos.Y - this.BasketPos.Y ) > this.Corner3PDistance)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 是否在防守落位区域
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public bool IsOnDefPresetArea(Player player)
        {
            return this.courtZoneManager.IsInMyDefPreset(player);
        }

        /// <summary>
        /// 攻方落位
        /// </summary>
        /// <param name="role">角色</param>
        /// <param name="random">随机数</param>
        /// <returns></returns>
        public Position GetAtkPresetPosition(GameInfo gameInfo, Player player, int random, out int courtZone)
        {
            return this.courtZoneManager.GetAtkPresetPosition(gameInfo, player, random,out courtZone );
        }

        public Position GetDefPresetPosition(Player player, int random)
        {
            return this.courtZoneManager.GetDefPresetPosition(player, random);
        }

        public Position GetBallHanlderPreset(Position curPos,int random)
        {
            return this.courtZoneManager.GetBallHandlerPreset(curPos, random);
        }

        public abstract int GetDistanceToBasketX(Position pos);

        public void ClearReboundPos()
        {
            for (int i = 0; i < this.lstReboundPosition.Count; i++)
            {
                this.lstReboundPosition[i].IsOccupied = false;
            }
        }

        /// <summary>
        /// 获取一个抢篮板点，并且占据该位置
        /// 离传入最近的
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        public Position GetReboundPos(Position pos)
        {
            double minDis = Int32.MaxValue;
            Position p1 = Position.Empty;
            ReboundPostion getRp = null;
            for (int i = 0; i < this.lstReboundPosition.Count; i++)
            {
                ReboundPostion rp = this.lstReboundPosition[i];
                if (!rp.IsOccupied)
                {
                    double dis = rp.Pos.Distance(pos);
                    if (dis < minDis)
                    {
                        minDis = dis;
                        getRp = rp;
                    }
                }
            }
            if (getRp != null)
            {
                getRp.IsOccupied = true;
                p1 = getRp.Pos;
            }
            return p1;
        }


        public int GetDistanceToBottomLine(Position pos)
        {
            return (int)Math.Abs(pos.X - this.Top.X);
        }

        /// <summary>
        /// 底线发球点
        /// </summary>
        /// <param name="playerPos"></param>
        /// <returns></returns>
        public Position GetBottomLineThrowInPos(Position playerPos)
        {
            return new Position(this.Top.X + this.RevisedX, playerPos.Y);
        }

        /// <summary>
        /// 2、3、4节开始的发球点
        /// </summary>
        /// <returns></returns>
        public Position GetStartQuarterThrowInPos()
        {
            return new Position(this.ThrowInPos.X + this.RevisedX, this.ThrowInPos.Y);
        }

        public Position GetMidJumpBallPosition(int role)
        {
            return this.lstMidJumpPosition[role].Clone();
        }

        /// <summary>
        /// 界内
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        public bool IsOnMyEffectiveArea(Position pos)
        {
            if (pos.X >= this.TopLeft.X &&
                pos.Y >= this.TopLeft.Y &&
                pos.X <= this.BtmRight.X &&
                pos.Y <= this.BtmRight.Y)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 罚球人位置
        /// </summary>
        /// <returns></returns>
        public Position GetFreeThrowPos()
        {
            return this.freeThrowPos.Clone();
        }

        /// <summary>
        /// 罚球时防守方位置
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public Position GetFreeThrowDefPos(int index)
        {
            if (index >= 0 && index < this.lstDefFTPos.Count)
            {
                return this.lstDefFTPos[index].Clone();
            }
            return Position.Empty.Clone();
        }

        /// <summary>
        /// 罚球时进攻方位置
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public Position GetFreeThrowAtkPos(int index)
        {
            if (index >= 0 && index < this.lstAtkFTPos.Count)
            {
                return this.lstAtkFTPos[index].Clone();
            }
            return Position.Empty.Clone();
        }

        public Position GetTechFreeThrowDefPos(int index)
        {
            if (index >= 0 && index < this.lstDefTechFTPos.Count)
            {
                return this.lstDefTechFTPos[index].Clone();
            }
            return Position.Empty.Clone();
        }

        public Position GetTechFreeThrowAtkPos(int index)
        {
            if (index >= 0 && index < this.lstAtkTechFTPos.Count)
            {
                return this.lstAtkTechFTPos[index].Clone();
            }
            return Position.Empty.Clone();
        }

        /// <summary>
        /// 获取出界以后，发球点位置
        /// </summary>
        /// <param name="outOfBoundPos"></param>
        /// <returns></returns>
        public Position GetSideThrowInPos(Position outOfBoundPos)
        {
            if(this.IsOutOfBottomLine(outOfBoundPos))
            {
                //出了底线，就找一个近的预设点
                double dis1 = outOfBoundPos.Distance(this.sideThrowIn1);
                double dis2 = outOfBoundPos.Distance(this.sideThrowIn2);
                if(dis1 > dis2)
                {
                    return this.sideThrowIn2.Clone();
                }
                return this.sideThrowIn1.Clone();
            }
            else
            {
                //没出底线，看出的是哪条边线
                if(outOfBoundPos.Y < this.Top.Y)
                {
                    return new Position(outOfBoundPos.X, this.Top.Y - Math.Abs(this.RevisedX));
                }
                return new Position(outOfBoundPos.X, this.Bottom.Y + Math.Abs(this.RevisedX));
            }
        }

        /// <summary>
        /// 是否在3秒区内
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        public bool IsIn3Second(Position pos)
        {
            return this.Area3Second.IsOnMeNotContainEdge(pos);
        }

        /// <summary>
        /// 获取罚球线与边线交点，发球位置
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public Position GetFTLineSideInsection(int index)
        {
            if (index < 0 || index > this.lstFTLine.Count - 1)
            {
                return Position.Empty;
            }
            Position p = this.lstFTLine[index];
            if (index == 0)
            {
                return new Position(p.X, p.Y - Math.Abs(this.RevisedX));
            }
            else
            {
                return new Position(p.X, p.Y + Math.Abs(this.RevisedX));
            }
        }

        /// <summary>
        /// 获取犯规发球点
        /// </summary>
        /// <param name="foulPos"></param>
        /// <returns></returns>
        public Position GetFoulThrowInPos(Position foulPos)
        {
            double dis1 = foulPos.Distance(this.foulThrowIn1);
            double dis2 = foulPos.Distance(this.foulThrowIn2);
            if (dis1 <= dis2)
            {
                return new Position(this.foulThrowIn1.X, this.foulThrowIn1.Y - Math.Abs(this.RevisedX));
            }
            return new Position(this.foulThrowIn2.X, this.foulThrowIn2.Y + Math.Abs(this.RevisedX));
        }

        public Position GetSlumDunkShotPos()
        {
            return this.slumDunkShotPos;
        }

        public bool IsOnCourtZone(int czId, Position pos)
        {
            return this.courtZoneManager.IsInCourtZone(czId, pos);
        }

        public List<Position> GetListPosition(PlayBookType playBook, int random)
        {
            return this.courtZoneManager.GetListPosition(playBook, random);
        }
    }

    public class LeftField : Field
    {

        public LeftField(FieldType fieldType)
            : base(fieldType)
        {

        }

        private readonly int CornerX = 175;


        protected override void Init()
        {
            this.BasketPos = new Position(83, 300);
            this.lstPresetArea.Add(new Area(new Position(340, 452), new Position(430, 533)));
            this.lstPresetArea.Add(new Area(new Position(266, 87), new Position(359, 166)));
            this.lstPresetArea.Add(new Area(new Position(37, 52), new Position(121, 132)));
            this.lstPresetArea.Add(new Area(new Position(91, 184), new Position(184, 266)));
            this.lstPresetArea.Add(new Area(new Position(162, 370), new Position(253, 441)));

            this.lstReboundPosition.Add(new ReboundPostion(79, 258));
            this.lstReboundPosition.Add(new ReboundPostion(79, 343));
            this.lstReboundPosition.Add(new ReboundPostion(98, 250));
            this.lstReboundPosition.Add(new ReboundPostion(98, 341));
            this.lstReboundPosition.Add(new ReboundPostion(114, 272));
            this.lstReboundPosition.Add(new ReboundPostion(114, 329));
            this.lstReboundPosition.Add(new ReboundPostion(124, 290));
            this.lstReboundPosition.Add(new ReboundPostion(124, 313));

            this.lstMidJumpPosition.Add(new Position(342, 300));
            this.lstMidJumpPosition.Add(new Position(486, 409));
            this.lstMidJumpPosition.Add(new Position(486, 191));
            this.lstMidJumpPosition.Add(new Position(422, 316));
            this.lstMidJumpPosition.Add(new Position(488, 300));

            this.Top = new Position(27, 47);
            this.Bottom = new Position(27, 556);
            this.ThrowInPos = new Position(27, 255);
            this.TopLeft = new Position(27, 47);
            this.BtmRight = new Position(506, 556);
            this.RevisedX = -15;

            //罚球相关位置
            this.freeThrowPos = new Position(226, 298);

            this.lstDefFTPos.Add(new Position(106, 219));
            this.lstDefFTPos.Add(new Position(107, 383));
            this.lstDefFTPos.Add(new Position(177, 219));
            this.lstDefFTPos.Add(new Position(178, 383));
            this.lstDefFTPos.Add(new Position(310, 180));
            this.lstDefFTPos.Add(new Position(325, 366));

            this.lstAtkFTPos.Add(new Position(144, 219));
            this.lstAtkFTPos.Add(new Position(145, 383));
            this.lstAtkFTPos.Add(new Position(336, 419));
            this.lstAtkFTPos.Add(new Position(365, 206));

            this.lstDefTechFTPos.Add(new Position(392, 300));
            this.lstDefTechFTPos.Add(new Position(371, 193));
            this.lstDefTechFTPos.Add(new Position(371, 398));
            this.lstDefTechFTPos.Add(new Position(312, 104));
            this.lstDefTechFTPos.Add(new Position(312, 495));

            this.lstAtkTechFTPos.Add(new Position(387, 248));
            this.lstAtkTechFTPos.Add(new Position(387, 349));
            this.lstAtkTechFTPos.Add(new Position(344, 146));
            this.lstAtkTechFTPos.Add(new Position(344, 450));

            //罚球未进弹射角度
            this.freeThrowMinAngle = ParameterManager.Instance.GetValue(ParameterEnum.NotGoalAngle) * -1;
            this.freeThrowMaxAngle = ParameterManager.Instance.GetValue(ParameterEnum.NotGoalAngle);

            //出界底线两个边线发球点
            this.sideThrowIn1 = new Position(25,43 + this.RevisedX);
            this.sideThrowIn2 = new Position(25,556 - this.RevisedX );

            //3秒区
            this.Area3Second = new Area(new Position(28, 224), new Position(219, 383));

            //罚球线与边线交点
            this.lstFTLine.Add(new Position(216, 45));
            this.lstFTLine.Add(new Position(216, 552));

            //犯规罚球点
            this.foulThrowIn1 = new Position(315, 47);
            this.foulThrowIn2 = new Position(315, 556);

            //扣篮出手点
            this.slumDunkShotPos = new Position(165, 300);

            //X轴与篮筐夹角场内方向
            this.XAxisAngle = 0;
        }

        public override bool IsCorner(Position pos)
        {
            if (pos.X < this.CornerX)
            {
                return true;
            }
            return false;
        }

        public override Position GetRandomReboundPosByAngleRadius(int angle, double Radius)
        {
            if (angle > 90)
            {
                angle = 180 + angle;
            }
            int x = (int)Math.Abs(Math.Floor(Radius * Math.Cos( Formula.GetRadian(angle) ) ) );
            int y = (int)Math.Floor(Radius * Math.Sin( Formula.GetRadian(angle) ) );

            Position pos = new Position(this.BasketPos.X + x, this.BasketPos.Y - y);
            return pos;
        }

        public override bool IsOnMe(Position pos)
        {
            return pos.X < this.MiddleX;
        }

        public override bool  IsOutOfBottomLine(Position pos)
        {
 	        return pos.X < this.TopLeft.X;
        }

        /// <summary>
        /// 获取出三秒区最近的点
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        public override Position GetOutOf3SAreatNearestPos(Position pos)
        {
            int disToTop = this.Area3Second.GetDisToTop(pos);
            int disToBtm = this.Area3Second.GetDisToBottom(pos);
            int disToRight = this.Area3Second.GetDisToRight(pos);
            int revise = 5;
            if (disToTop < disToBtm)
            {
                if (disToTop < disToRight)
                {
                    return new Position(pos.X, pos.Y - disToTop - revise);
                }
                return new Position(pos.X + disToRight + revise, pos.Y);
            }
            else
            {
                if (disToBtm < disToRight)
                {
                    return new Position(pos.X, pos.Y + disToBtm + revise);
                }
                return new Position(pos.X + disToRight + revise, pos.Y);
            }
        }

        public override int GetDistanceToBasketX(Position pos)
        {
            return pos.X - this.BasketPos.X;
        }

        public override bool IsBehindRebound(Position pos)
        {
            if (pos.X < this.BasketPos.X - 15)
            {
                return true;
            }
            return false;
        }
    }

    public class RightField : Field
    {
        private readonly int CornerX = 838;

        public RightField(FieldType fieldType)
            : base(fieldType)
        {

        }

        protected override void Init()
        {
            this.BasketPos = new Position(926, 300);
            this.lstPresetArea.Add(new Area(new Position(580, 199), new Position(673, 283)));
            this.lstPresetArea.Add(new Area(new Position(652, 436), new Position(745, 514)));
            this.lstPresetArea.Add(new Area(new Position(884, 471), new Position(979, 553)));
            this.lstPresetArea.Add(new Area(new Position(827, 334), new Position(920, 415)));
            this.lstPresetArea.Add(new Area(new Position(757, 165), new Position(851, 246)));

            this.lstReboundPosition.Add(new ReboundPostion(931, 258));
            this.lstReboundPosition.Add(new ReboundPostion(931, 343));
            this.lstReboundPosition.Add(new ReboundPostion(913, 260));
            this.lstReboundPosition.Add(new ReboundPostion(913, 341));
            this.lstReboundPosition.Add(new ReboundPostion(897, 272));
            this.lstReboundPosition.Add(new ReboundPostion(897, 329));
            this.lstReboundPosition.Add(new ReboundPostion(886, 290));
            this.lstReboundPosition.Add(new ReboundPostion(886, 313));

            this.lstMidJumpPosition.Add(new Position(670, 300));
            this.lstMidJumpPosition.Add(new Position(526, 409));
            this.lstMidJumpPosition.Add(new Position(526, 191));
            this.lstMidJumpPosition.Add(new Position(590, 316));
            this.lstMidJumpPosition.Add(new Position(524, 300));


            this.Top = new Position(983, 47);
            this.Bottom = new Position(983, 556);
            this.ThrowInPos = new Position(983, 255);
            this.TopLeft = new Position(506, 47);
            this.BtmRight = new Position(983, 556);
            this.RevisedX = 15;
            this.PosOrNegX = -1;

            //罚球相关位置
            this.freeThrowPos = new Position(783, 298);

            this.lstDefFTPos.Add(new Position(906, 219));
            this.lstDefFTPos.Add(new Position(907, 383));
            this.lstDefFTPos.Add(new Position(835, 219));
            this.lstDefFTPos.Add(new Position(834, 383));
            this.lstDefFTPos.Add(new Position(700, 180));
            this.lstDefFTPos.Add(new Position(672, 366));

            this.lstAtkFTPos.Add(new Position(869, 219));
            this.lstAtkFTPos.Add(new Position(870, 383));
            this.lstAtkFTPos.Add(new Position(653, 419));
            this.lstAtkFTPos.Add(new Position(681, 206));

            this.lstDefTechFTPos.Add(new Position(618, 300));
            this.lstDefTechFTPos.Add(new Position(640, 193));
            this.lstDefTechFTPos.Add(new Position(618, 398));
            this.lstDefTechFTPos.Add(new Position(698, 104));
            this.lstDefTechFTPos.Add(new Position(698, 495));

            this.lstAtkTechFTPos.Add(new Position(623, 248));
            this.lstAtkTechFTPos.Add(new Position(623, 349));
            this.lstAtkTechFTPos.Add(new Position(666, 146));
            this.lstAtkTechFTPos.Add(new Position(666, 450));

            //罚球未进弹射角度
            this.freeThrowMinAngle = ParameterManager.Instance.GetValue(ParameterEnum.NotGoalAngleRightMin);
            this.freeThrowMaxAngle = ParameterManager.Instance.GetValue(ParameterEnum.NotGoalAngleRightMax);

           //出界底线两个边线发球点
            this.sideThrowIn1 = new Position(984,43 - this.RevisedX);
            this.sideThrowIn2 = new Position(984,556 + this.RevisedX);

            this.Area3Second = new Area(new Position(793, 224), new Position(983, 383));

            //罚球线与边线交点
            this.lstFTLine.Add(new Position(792, 45));
            this.lstFTLine.Add(new Position(792, 552));

            //犯规罚球点
            this.foulThrowIn1 = new Position(696, 47);
            this.foulThrowIn2 = new Position(696, 556);

            //扣篮出手点
            this.slumDunkShotPos = new Position(845, 300);

            //篮筐与X轴夹角，场内方向
            this.XAxisAngle = 180;
        }

        public override bool IsCorner(Position pos)
        {
            if (pos.X > this.CornerX)
            {
                return true;
            }
            return false;
        }


        public override Position GetRandomReboundPosByAngleRadius(int angle, double Radius)
        {
            angle = angle + 90;
            int x = (int)Math.Abs(Math.Floor(Radius * Math.Cos( Formula.GetRadian(angle) ) ) );
            int y = (int)Math.Floor(Radius * Math.Sin( Formula.GetRadian(angle) ) );

            Position pos = new Position(this.BasketPos.X - x, this.BasketPos.Y - y);
            return pos;
        }

        public override bool IsOnMe(Position pos)
        {
            return pos.X > this.MiddleX;
        }

        public override bool  IsOutOfBottomLine(Position pos)
        {
 	        return pos.X > this.BtmRight.X;
        }

        /// <summary>
        /// 获取出三秒区最近的点
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        public override Position GetOutOf3SAreatNearestPos(Position pos)
        {
            int disToTop = this.Area3Second.GetDisToTop(pos);
            int disToBtm = this.Area3Second.GetDisToBottom(pos);
            int disToLeft = this.Area3Second.GetDisToLeft(pos);
            int revise = 5;
            if (disToTop < disToBtm)
            {
                if (disToTop < disToLeft)
                {
                    return new Position(pos.X, pos.Y - disToTop - revise);
                }
                return new Position(pos.X - disToLeft - revise, pos.Y);
            }
            else
            {
                if (disToBtm < disToLeft)
                {
                    return new Position(pos.X, pos.Y + disToBtm + revise);
                }
                return new Position(pos.X - disToLeft - revise, pos.Y);
            }
        }

        public override int GetDistanceToBasketX(Position pos)
        {
            return this.BasketPos.X - pos.X;
        }

        public override bool IsBehindRebound(Position pos)
        {
            if (pos.X > this.BasketPos.X + 15)
            {
                return true;
            }
            return false;
        }
    }

    public class Area
    {
        private Position TopLeft;
        private Position BtmRight;
        private int PixelPermissibleError;

        public Area(Position topLeft, Position btmRight)
        {
            this.TopLeft = topLeft;
            this.BtmRight = btmRight;
            this.PixelPermissibleError = (int)(ParameterManager.Instance.GetValueD(ParameterEnum.PermissibleError) / Position.ActualLengthPerPoint);
        }

        public bool IsOnMe(Position pos)
        {
            if (pos.X >= this.TopLeft.X &&
                pos.Y >= this.TopLeft.Y &&
                pos.X <= this.BtmRight.X &&
                pos.Y <= this.BtmRight.Y)
            {
                return true;
            }
            return false;
        }

        public bool IsOnMeNotContainEdge(Position pos)
        {
            if (!Formula.IsDisInPermissByPixel(pos.X, this.TopLeft.X, this.PixelPermissibleError) &&
                !Formula.IsDisInPermissByPixel(pos.Y, this.TopLeft.Y, this.PixelPermissibleError) &&
                !Formula.IsDisInPermissByPixel(this.BtmRight.X, pos.X, this.PixelPermissibleError) &&
                !Formula.IsDisInPermissByPixel(this.BtmRight.Y, pos.Y, this.PixelPermissibleError))
            //if (pos.X > this.TopLeft.X &&
            //   pos.Y > this.TopLeft.Y &&
            //   pos.X < this.BtmRight.X &&
            //   pos.Y < this.BtmRight.Y)
            {
                return true;
            }
            return false;
        }

        public Position GetRandomPos(int random)
        {
            int deltaX = random % (this.BtmRight.X - this.TopLeft.X);
            int deltaY = random % (this.BtmRight.Y - this.TopLeft.Y);
            return new Position(this.TopLeft.X + deltaX, this.TopLeft.Y + deltaY);
        }

        public int GetDisToTop(Position pos)
        {
            return pos.Y - this.TopLeft.Y;
        }

        public int GetDisToBottom(Position pos)
        {
            return this.BtmRight.Y - pos.Y;
        }

        public int GetDisToLeft(Position pos)
        {
            return pos.X - this.TopLeft.X;
        }

        public int GetDisToRight(Position pos)
        {
            return this.BtmRight.X - pos.X;
        }
    }
}
