﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    /// <summary>
    /// 篮球场区域
    /// </summary>
    public class CourtZone
    {
        private int Id{get;set;}
        private int Court { get; set; }
        private int ZoneRadius1 { get; set; }
        private int ZoneRadius2 { get; set; }
        private int ZoneAngle1 { get; set; }
        private int ZoneAngle2 { get; set; }
        public List<int> NearByZoneList { get; set; }
        private int CenterX { get; set; }
        private int CenterY { get; set; }
        private int MinX { get; set; }
        private int MaxX { get; set; }
        private int MinY { get; set; }
        private int MaxY { get; set; }
        private Position CenterPos { get; set; }
        private Position BasketPos { get; set; }

        public CourtZone(Position basket)
        {
            this.BasketPos = basket;
        }

        public void Init(ZDB_Row_Data row_data)
        {
            this.Id = row_data.getCol((int)court_zoneFields.Id).getValueInt();
            this.Court = row_data.getCol((int)court_zoneFields.Court).getValueInt();
            this.ZoneRadius1 = row_data.getCol((int)court_zoneFields.ZoneRadius1).getValueInt();
            this.ZoneRadius2 = row_data.getCol((int)court_zoneFields.ZoneRadius2).getValueInt();
            this.ZoneAngle1 = row_data.getCol((int)court_zoneFields.ZoneAngle1).getValueInt();
            this.ZoneAngle2 = row_data.getCol((int)court_zoneFields.ZoneAngle2).getValueInt();
            this.CenterX = row_data.getCol((int)court_zoneFields.CenterX).getValueInt();
            this.CenterY = row_data.getCol((int)court_zoneFields.CenterY).getValueInt();
            this.MinX = row_data.getCol((int)court_zoneFields.MinX).getValueInt();
            this.MaxX = row_data.getCol((int)court_zoneFields.MaxX).getValueInt();
            this.MinY = row_data.getCol((int)court_zoneFields.MinY).getValueInt();
            this.MaxY = row_data.getCol((int)court_zoneFields.MaxY).getValueInt();
            this.CenterPos = new Position(this.CenterX, this.CenterY);

            string nearby = row_data.getCol((int)court_zoneFields.NearbyZone).getValueString();
            string[] lstNearBy = nearby.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            this.NearByZoneList = new List<int>();
            for (int i = 0; i < lstNearBy.Length; i++)
            {
                this.NearByZoneList.Add(Convert.ToInt32(lstNearBy[i]));
            }
        }

        public double DistanceToThis(Position pos)
        {
            return this.CenterPos.Distance(pos);
        }

        public Position GetRandomPos(int random)
        {
            int radius = this.GetRandomValue(this.ZoneRadius1, this.ZoneRadius2, random);
            int angle = this.GetRandomValue(this.ZoneAngle1, this.ZoneAngle2, random);


            Position p1 = this.BasketPos.GetPosByAngleRadius(angle, radius);
            if (p1.X < this.MinX)
            {
                p1.X = this.MinX;
            }
            else if (p1.X > this.MaxX)
            {
                p1.X = this.MaxX;
            }
            if (p1.Y < this.MinY)
            {
                p1.Y = this.MinY;
            }
            else if (p1.Y > this.MaxY)
            {
                p1.Y = this.MaxY;
            }
            return p1;
        }

        private int GetRandomValue(int min, int max, int random)
        {
            int step = max - min;
            if (step == 0)
            {
                return min;
            }
            int r = random % step;
            return min + r;
        }

        public int GetId()
        {
            return this.Id;
        }

        public bool IsOnMe(Position pos)
        {
            if (pos.X < this.MinX || 
                pos.X > this.MaxX || 
                pos.Y < this.MinY || 
                pos.Y > this.MaxY)
            {
                return false;
            }
            double dis = pos.DistanceActualLength(this.BasketPos);
            //看到篮筐距离，不属于范围直接排除
            if (dis < this.ZoneRadius1 ||
               dis > this.ZoneRadius2)
            {
                return false;
            }
            Vector2D v = new Vector2D(this.BasketPos, pos);
            double angle = v.GetSlopeAngle();
            if(this.Court == 0 && angle > 180)
            {
                //左边的角度是-180~180，3、4象限-360
                angle -= 360;
            }
            if (angle >= this.ZoneAngle1 && angle <= this.ZoneAngle2)
            {
                return true;
            }
            return false;
        }
    }
}
