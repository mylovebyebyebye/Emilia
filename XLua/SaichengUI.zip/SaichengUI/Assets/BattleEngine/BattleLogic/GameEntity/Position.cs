﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class Position 
    {
        /// <summary>
        /// 一个点相当于 2.9474cm
        /// </summary>
        public const double ActualLengthPerPoint = 3.016f;
        public static Position Empty = new Position(int.MinValue, int.MinValue);

        public Position()
        {

        }

        public Position(int x, int y)
        {
            this.X = x;
            this.Y = y;
        }

        public Position Clone()
        {
            Position p = new Position(this.X,this.Y);
            return p;
        }

        public int X;
        public int Y;

        public double Distance(Position another)
        {
            int subX = this.X - another.X;
            int subY = this.Y - another.Y;
            return System.Math.Sqrt(subX * subX + subY * subY);
        }

        public double DistanceActualLength(Position another)
        {
            return System.Math.Sqrt((this.X - another.X) * (this.X - another.X) + (this.Y - another.Y) * (this.Y - another.Y)) * Position.ActualLengthPerPoint;
        }

        public override string ToString()
        {
            return string.Format(" ({0},{1}) ",this.X,this.Y);
        }

        public static bool operator ==(Position a, Position b)
        {
            if (a.X == b.X && a.Y == b.Y)
            {
                return true;
            }
            return false;
        }

        public static bool operator !=(Position a, Position b)
        {
            if (a.X != b.X || a.Y != b.Y)
            {
                return true;
            }
            return false;
        }

        public static double GetPix(double actualLength)
        {
            return (double)(actualLength / ActualLengthPerPoint);
        }

        /// <summary>
        /// 根据角度和距离计算目标位置
        /// 角度为度数
        /// 距离单位cm
        /// </summary>
        /// <param name="angle">角度</param>
        /// <param name="Radius">距离 cm</param>
        /// <returns></returns>
        public Position GetPosByAngleRadius(double angle, int radius)
        {
            double dis = radius / Position.ActualLengthPerPoint;

            int x = (int)Math.Floor(dis * Math.Cos(Formula.GetRadian(angle)));
            int y = (int)Math.Floor(dis * Math.Sin(Formula.GetRadian(angle)));

            Position pos = new Position(this.X + x, this.Y - y);
            return pos;
        } 

        public bool IsInPermissibleError(Position p)
        {
            if (p.DistanceActualLength(this) <= ParameterManager.Instance.GetValue(ParameterEnum.PermissibleError))
            {
                return true;
            }
            return false;
        }
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
}
