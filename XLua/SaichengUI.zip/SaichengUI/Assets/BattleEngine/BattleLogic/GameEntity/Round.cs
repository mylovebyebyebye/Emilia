﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class Round
    {
        private const int OneRoundTime = 24;

        public bool IsPause = true;

        private int finishFrame;

        public int FinishFrame
        {
            get { return finishFrame; }
        }

        public int StartFrame;
        
        //重置
        public void Reset(int gameFrame)
        {
            this.StartFrame = gameFrame;
            this.finishFrame = TimeFrameConverter.GetFrame(OneRoundTime) - 1;
            this.IsPause = true;
        }

        public void SetPause()
        {
            this.IsPause = true;
        }

        public void SetResume()
        {
            this.IsPause = false;
        }

        public bool IsShotClockViolation()
        {
            if ( !this.IsPause && this.finishFrame == 0)
            {
                return true;
            }
            return false;
        }

        public void AddFrame()
        {
            if (!this.IsPause && this.finishFrame > 0)
            {
                this.finishFrame--;
            }
        }

        public void ResetTo14S()
        {
            int fourteenFrame = TimeFrameConverter.GetFrame(14.0f);
            if (this.finishFrame < fourteenFrame)
            {
                this.finishFrame = fourteenFrame;
                this.IsPause = true;
            }
        }
    }
}
