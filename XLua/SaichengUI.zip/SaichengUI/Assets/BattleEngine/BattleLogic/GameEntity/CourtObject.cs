﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public abstract class CourtObject
    {
        public Position Pos;

        protected GameTask curTask = null;

        public GameTask GetCurTask()
        {
            return this.curTask;
        }

        //public GameTask CurTask
        //{
        //    get { return this.curTask; }
        //}

        private List<GameTask> nextTaskList = new List<GameTask>();

        public List<GameTask> NextTask
        {
            get
            {
                return this.nextTaskList;
            }
        }

        private GameTask lastChoice = null;

        public GameTask LastChoice
        {
            get
            {
                return this.lastChoice;
            }
        }

        private GameTask lastDoTask = null;

        public GameTask LastDoTask
        {
            get
            {
                return this.lastDoTask;
            }
        }

        public void ClearLastChoice()
        {
            this.lastChoice = null;
        }

        protected abstract bool VirtualUpdade(GameInfo gameinfo);
        protected virtual void AfterSetCurTask()
        { }

        public bool Update(GameInfo gameInfo)
        {
            bool res = false;
            //延迟行动
            if (this.curTask.DelayStart > 0)
            {
                this.curTask.DelayStart--;
                res = true;
            }
            else if (this.curTask.FinishFrame <= 0)
            {
                res = true;
            }
            else
            {
                this.curTask.ProcessFrame++;
                this.VirtualUpdade(gameInfo);
                this.curTask.FinishFrame--;

                if (this.curTask.FinishFrame == 0)
                {
                    this.lastDoTask = this.curTask.CloneTask();
                    //结束以后转变任务
                    if (this.curTask.NextTask != TaskType.Unkown)
                    {
                        this.curTask.TaskType = this.curTask.NextTask;
                    }
                    else if (this.NextTask.Count != 0)
                    {
                        //不可打断任务完成后，下一任务自动生效
                        this.SetCurTask( this.NextTask[0], false );
                        this.NextTask.RemoveAt(0);
                    }
                }
            }
            this.VirtualAfterUpdate(gameInfo);
            return res;
        }

        private void SetCurTask(GameTask gt, bool clearNextTasks = true)
        {
            if (this.curTask != null)
            {
                this.lastChoice = this.curTask.CloneTask();
                this.lastDoTask = this.curTask.CloneTask();
                //添加了不可打断的任务
                if (this.curTask.TaskType > TaskType.TaskCanNotInterupt &&
                    this.curTask.FinishFrame > 0)
                {
                    this.NextTask.Clear();
                    this.NextTask.Add(gt);
                }
                else
                {
                    this.curTask = gt;
                    if (clearNextTasks)
                    {
                        this.NextTask.Clear();
                    }
                }
                this.AfterSetCurTask();
            }
            else
            {
                this.curTask = gt;
                if (clearNextTasks)
                {
                    this.NextTask.Clear();
                }
            }
        }


        public virtual bool IsFreeMethod()
        {
            GameTask cTask = this.curTask;
            if (cTask == null || (cTask.FinishFrame <= 0 && cTask.DelayStart <= 0))
            {
                return true;
            }
            return false;
        }

        public void SetFree()
        {
            this.SetCurrentTask(null);
        }

        protected virtual void VirtualAfterUpdate(GameInfo gameinfo)
        {
 
        }

        public void ClearTask()
        {
            this.lastDoTask = this.curTask.CloneTask();

            this.GetCurTask().Clear();
            this.NextTask.Clear();
        }

        public bool IsInTask(TaskType taskType)
        {
            if (this.curTask != null && this.curTask.TaskType == taskType)
            {
                return true;
            }
            return false;
        }

        public void SetCurrentTask(GameTask gt)
        {
            this.SetCurTask(gt);
        }
    }
}
