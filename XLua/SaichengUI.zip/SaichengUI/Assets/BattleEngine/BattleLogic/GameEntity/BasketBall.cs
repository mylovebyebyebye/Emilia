﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class BasketBall : CourtObject
    {
        private BallBehavior ballBehavior;

        private Player owner;

        public Player Owner
        {
            get { return owner; }
        }

        public void SetOwner(Player owner)
        {
            this.owner = owner;
        }
        public void ClearOwner()
        {
            this.owner = null;
            if (this.IsInTask( TaskType.BallOnThePlayer))
            {
                this.ClearTask();
            }
        }
        //public Player Owner
        //{
        //    get { return owner; }
        //    set 
        //    {
        //        this.owner = value;
        //        if (this.owner != null)
        //        {
        //            this.owner.IsCanCrossOver = true;
        //            this.OwnTeam = this.owner.OwnerTeam;
        //        }
        //    }
        //}

        public Team OwnTeam;

        /// <summary>
        /// 设置所属球队
        /// 返回是否发生球权变更
        /// </summary>
        /// <param name="team">所属球队</param>
        /// <returns>返回是否发生球权变更</returns>
        public bool SetOwnTeam(Team team)
        {
            bool isChange = false;
            if (team != null )
            {
                if (team != this.OwnTeam)
                {
                    isChange = true; 
                }
            }
            this.OwnTeam = team;
            return isChange;
        }

        //public Team OwnTeam
        //{
        //    get { return ownTeam; }
        //    set
        //    {
        //        ownTeam = value; 
        //    }
        //}

        public BasketBall()
        {
            this.Pos = new Position(0, 0);
            this.owner = null;
            this.OwnTeam = null;
        }

        public BasketBall(GameInfo gameInfo)
            :base()
        {
            this.ballBehavior = new BallBehavior(gameInfo, this);
        }

        //public override bool  Update(GameInfo gameInfo)
        //{
        //    bool res = base.Update(gameInfo);
        //    if (this.CurTask != null && this.GetCurTask().TaskType == TaskType.MoveTo && this.GetCurTask().FinishFrame <= 0)
        //    {
        //        this.GetCurTask().TaskType = TaskType.Static;
        //    }
        //    return res;
        //}



        protected override bool VirtualUpdade(GameInfo gameinfo)
        {
            this.ballBehavior.TickUpdate();
            return true;
        }
    }
}
