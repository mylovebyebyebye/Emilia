﻿using Entity.DBEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;

namespace BattleLogic
{
    public class CommonGameTask
    {
        public static GameTask GetDelayChangeDefTarget(Player defPlayer, Player targetPlayer)
        {
            GameTask gt = new GameTask(string.Empty);
            gt.TaskType = TaskType.PlayerChangeDefTarget;
            gt.TargetPlayer = targetPlayer;
            gt.DelayStart = TimeFrameConverter.GetFrame(defPlayer.GetAttribute(PlayerAttribute.React) / 1000);

            return gt;
        }
    }
}
