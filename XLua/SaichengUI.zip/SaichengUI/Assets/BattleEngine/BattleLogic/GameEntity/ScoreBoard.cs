﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    [Serializable]
    public class TeamScore
    {
        //private Dictionary<int, int> dicScoreEveryQuarter = new Dictionary<int, int>();

        public List<int> lstScoreEveryQuarter = new List<int>();

        private int totalPoint = 0;

        public int TotalPoint
        {
            get { return totalPoint; }
        }

        public void AddScore(int quarter, int point)
        {
            if (this.lstScoreEveryQuarter.Count < quarter)
            {
                this.lstScoreEveryQuarter.Add(point);
            }
            else
            {
                this.lstScoreEveryQuarter[quarter - 1] += point;
            }

            this.totalPoint += point;
        }

        public int GetQuarterPoint(int quarter)
        {
            if (this.lstScoreEveryQuarter.Count >= quarter)
            {
                return this.lstScoreEveryQuarter[quarter - 1];
            }

            return 0;
        }
    }

    /// <summary>
    /// 记分板
    /// </summary>
    public class ScoreBoard
    {
        private Dictionary<TeamType, TeamScore> dicScore = new Dictionary<TeamType, TeamScore>();

        public ScoreBoard()
        {
            this.dicScore.Add(TeamType.Home, new TeamScore());
            this.dicScore.Add(TeamType.Away, new TeamScore());
        }

        public void AddScore(TeamType team, int quarter ,int point)
        {
            TeamScore ts = this.dicScore[team];
            ts.AddScore(quarter, point);
        }

        public int GetQuarterPoint(TeamType team, int quarter)
        {
            TeamScore ts = this.dicScore[team];
            return ts.GetQuarterPoint(quarter);
        }

        public int GetTotalPoint(TeamType team)
        {
            TeamScore ts = this.dicScore[team];
            return ts.TotalPoint;
        }

        public TeamScore GetTeamScore(TeamType team)
        {
            TeamScore ts = this.dicScore[team];
            return ts;
        }
    }
}
