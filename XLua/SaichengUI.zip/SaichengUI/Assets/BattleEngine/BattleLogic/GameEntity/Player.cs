﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;
using Entity.DBEntity;


namespace BattleLogic
{
    /// <summary>
    /// 进攻人的参数
    /// </summary>
    public class OOODefenceParam
    {
        public bool IsNeedDef3P { get; set; }
        public int Def3PDistance { get; set; }

        public bool IsNeedDef2P { get; set; }
        public int Def2PDistance { get; set; }

        public int Def3SecondLineDistance { get; set; }



        public OOODefenceParam()
        {
            this.IsNeedDef3P = false;
            this.IsNeedDef2P = false;
        }
    }

    public class DistanceInfo
    {
        /// <summary>
        /// 计算时间
        /// </summary>
        public int CalcFrame;

        /// <summary>
        /// 像素距离
        /// </summary>
        public double DisInPix;


        /// <summary>
        /// CM距离
        /// </summary>
        public double DisInCM;
    }

    public enum PlayerRole
    {
        DNP = 0,
        PG = 1,
        SG = 2,
        SF = 3,
        PF = 4,
        C = 5,
    }


    public class Player : CourtObject
    {

        public static readonly double MaxDefRelationTime = 0.2f;

        public bool IsFans = false;

        private long roleId = 0;

        public long RoleID
        {
            get
            {
                return this.roleId;
            }
        }

        public string Name { get; set; }
        public string ShownName { get; private set; }
        public string Number { get; private set; }
        public int StrongHnad { get; private set; }


        private double maxSpeedInPix;

        public double MaxSpeedInPix
        {
            get
            {
                return this.maxSpeedInPix;
            }
        }

        private double[] szAttribute = new double[(int)PlayerAttribute.End];
        /// <summary>
        /// 由于评级会直接修改属性
        /// 这里存着原始属性
        /// </summary>
        private Dictionary<int, double> dicAttributeSoucre = new Dictionary<int, double>();


        public double ScoringExpect;
        public double ShotScoringExpect;
        public double CrossOverExpect;
        public double InsideScoringExpect;

        public double OffballPro;

        /// <summary>
        /// 干扰投篮CD
        /// 这个值小于当前gameframe，才能对投篮造成影响
        /// </summary>
        public int DefShotCD = -1;

        /// <summary>
        /// 对投篮命中率影响有加成的时间
        /// </summary>
        public int DefShotPercentFrame = -1;

        /// <summary>
        /// 传球概率
        /// </summary>
        public double PassBallPro { get; set; }


        private ZDB_Row_Data stamina_Row_Data;

        /// <summary>
        /// 当前体力
        /// </summary>
        public double CurStamina;

        public double DefendFoul { get; set; }
        public int Foul { get; set; }

        
        public int Id { get; set; }

        private bool isCanCrossOver;
        public bool IsCanCrossOver 
        {
            get
            {
                return this.isCanCrossOver;
            }
            set
            {
                if (value)
                {
                    this.OwnerTeam.RemovePlayerFromCrossOverDebuff(this);
                }
                else
                {
                    this.OwnerTeam.AddPlayerToCrossOverDebuff(this);
                }
                this.isCanCrossOver = value;
            }
        }

        public void ClearCrossOver()
        {
            this.isCanCrossOver = true;
        }

        public TeamType TeamType;

        public Team OwnerTeam;

        private int lastCalc3SecondFrame = 0;

        private int calc3SecondStep = TimeFrameConverter.FramesOneSecond / 10;

        /// <summary>
        /// 进攻三秒
        /// </summary>
        public int AtkIn3SecondFrame;


        /// <summary>
        /// 防守三秒
        /// </summary>
        public int Def3SecondFrame;

        private double Def3SecondMinDis;

        /// <summary>
        /// 当前盯防距离的计算回合
        /// </summary>
        public int CalcDefDisRound { get; set; }
        /// <summary>
        /// 一个盯防距离的随机值
        /// </summary>
        public int DefDis { get; set; }

        /// <summary>
        /// 场上位置
        /// 1 PG 2SG 3SF 4PF 5C
        /// </summary>
        public int Role;

        private PaoWeiParam paoweiParam = new PaoWeiParam();

        public PaoWeiParam PaoweiParam
        {
            get { return paoweiParam; }
        }

        private PlayerBehavior playerBehavior;

        private OOODefenceParam defParam;
        /// <summary>
        /// 这个是别人防你的时候会怎么选择站位
        /// </summary>
        public OOODefenceParam DefParam
        {
            get { return defParam; }
        }

        private List<int> preferZoneList = new List<int>();

        public List<int> PreferZoneList
        {
            get { return preferZoneList; }

        }

        public int LastPassBallFrame;

        /// <summary>
        /// 各种投篮方式基础命中率
        /// </summary>
        private List<double> baseHitRateList = new List<double>();

        /// <summary>
        /// 各种基础防守值
        /// </summary>
        private List<double> baseContestList = new List<double>();


        public int MaxStamina = 0;

        /// <summary>
        /// 本节比赛打了多久
        /// </summary>
        public int ThisQuarterPlayerFrame = 0;
        /// <summary>
        /// 这场比赛该上多久
        /// </summary>
        //public int TotalRegularTime = int.MaxValue;

        public Player()
        {
            this.IsFans = false;
            this.playerBehavior = null;
            this.defParam = new OOODefenceParam();

            this.lstNotOut3S = new List<TaskType>();
            this.lstNotOut3S.Add(TaskType.PlayerToPassBall);
            this.lstNotOut3S.Add(TaskType.PlayerToGetPassBallNormal);

            this.LastPassBallFrame = 0;

            this.Def3SecondMinDis = ParameterManager.Instance.GetValue(ParameterEnum.Def3SMinDis);
            this.MaxStamina = ParameterManager.Instance.GetValue(ParameterEnum.MaxStamina);
        }

        public Player(Team team)
            :this()
        {
            this.Pos = new Position(0, 0);
            this.OwnerTeam = team;
            this.IsCanCrossOver = true;
            this.TeamType = team.TeamType;
        }

        public Player(GameInfo gameInfo, Team team)
            :this(team)
        {
            this.playerBehavior = new PlayerBehavior(gameInfo, this);
        }

        public void InitFromDB(ZDB_Row_Data data)
        {
            this.Id = data.getCol((int)playerFields.Id).getValueInt();
            this.Name = data.getCol((int)playerFields.Name).GetUTFString();
            this.ShownName = data.getCol((int)playerFields.ShownNames).GetUTFString();
            this.Number = data.getCol((int)playerFields.Number).getValueInt().ToString();
            this.StrongHnad = data.getCol((int)playerFields.StrongHand).getValueInt();

            this.InitAttribute(data);

            this.roleId = (int)this.OwnerTeam.TeamType * 100000000 + this.Id;

            this.Reload();
        }

        public void InitFromDB(DBPlayer player)
        {
            this.Id = (int)player._id;
            this.Name = player.Name;
            this.ShownName = player.Name;
            this.Number = player.Number.ToString();
            this.StrongHnad = player.MainHand;
            this.Reload();
        }

        public void Reload()
        {
            this.InitAtkParam();
            this.InitDefParam();
        }

        private void InitAttribute(ZDB_Row_Data data)
        {
            szAttribute[(int)PlayerAttribute.Speed] = 1.0f * data.getCol((int)playerFields.Speed).getValueInt() * ParameterManager.Instance.GetValue(ParameterEnum.SpeedCoefficient);
            this.maxSpeedInPix = (double)(this.GetAttribute(PlayerAttribute.Speed) / Position.ActualLengthPerPoint);

            for (int i = (int)PlayerAttribute.Strength; i < (int)PlayerAttribute.End; i++)
            {
                szAttribute[i] = data.getColByName(((PlayerAttribute)i).ToString()).getValueInt() * 1.0f;
            }

            this.CurStamina = ParameterManager.Instance.GetValue(ParameterEnum.MaxStamina) * 1.0f;
            double passBallCOE = ParameterManager.Instance.GetValue(ParameterEnum.PassBallCOE) * 1.0f;
            this.PassBallPro = (double)(1 - Math.Pow((passBallCOE / 10000), this.GetAttribute(PlayerAttribute.PassVison))) * 10000;

            string preferZone = data.getCol((int)playerFields.PreferredZone).getValueString();
            string[] array = preferZone.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < array.Length; i++)
            {
                this.preferZoneList.Add(Convert.ToInt32(array[i]));
            }
        }
                
        private void InitAttribute(DBPlayer player)
        {
            szAttribute = player.szAttribute;

            szAttribute[(int)PlayerAttribute.Speed] = 1.0f * player.szAttribute[(int)PlayerAttribute.Speed] * ParameterManager.Instance.GetValue(ParameterEnum.SpeedCoefficient);
            this.maxSpeedInPix = (double)(this.GetAttribute(PlayerAttribute.Speed) / Position.ActualLengthPerPoint);

            //属性计算

            this.CurStamina = ParameterManager.Instance.GetValue(ParameterEnum.MaxStamina) * 1.0f;
            double passBallCOE = ParameterManager.Instance.GetValue(ParameterEnum.PassBallCOE) * 1.0f;
            this.PassBallPro = (double)(1 - Math.Pow((passBallCOE / 10000), this.GetAttribute(PlayerAttribute.PassVison))) * 10000;

            string preferZone = player.PreferredZone;
            string[] array = preferZone.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < array.Length; i++)
            {
                this.preferZoneList.Add(Convert.ToInt32(array[i]));
            }
        }

        public double GetAttribute(PlayerAttribute attibute)
        {
            return szAttribute[(int)attibute];
        }

        public double GetAttrByIndex(int index)
        {
            if (index <= (int)PlayerAttribute.Begin || index >= (int)PlayerAttribute.End)
            {
                return 0;
            }
            return this.GetAttribute((PlayerAttribute)index);
        }

        private void InitAtkParam()
        {
            double param59 = ParameterManager.Instance.GetValueD(ParameterEnum.OffBallCOE);
            this.OffballPro = Convert.ToSingle(1 - Math.Pow(param59 / 10000, this.GetAttribute(PlayerAttribute.Offball)));

            this.stamina_Row_Data = ZDataManager.Instance.GetStaminaTable().getDataByID((int)this.GetAttribute(PlayerAttribute.Stamina));

            //初始化基础命中率数据
            this.baseHitRateList.Clear();
            ZDBTable shotPercentageTable = ZDataManager.Instance.GetShotPercentageTable();
            int rowCount = shotPercentageTable.getRowCount();
            for (int i = 0; i < rowCount; i++)
            {
                ZDB_Row_Data rowData = shotPercentageTable.getDataByRow(i);
                int tableIndex = rowData.getCol((int)shot_percentageFields.FGPercentageBasic).getValueInt();
                if (tableIndex > 0)
                {
                    ZDBTable shotTable = ShotTableManager.Instance.GetShotTableByIndex(tableIndex);
                    int attrIndex = rowData.getCol((int)shot_percentageFields.AttributeShooter).getValueInt();
                    int attr = (int)this.GetAttrByIndex(attrIndex);
                    if (shotTable != null)
                    {
                        int value = shotTable.getDataByID(attr).getCol((int)shot_percentage_common_Fields.Percentage).getValueInt();
                        this.baseHitRateList.Add(value * 1.0 / 1000000);
                    }
                }
                else
                {
                    this.baseHitRateList.Add(0.0);
                }
            }
        }

        private void InitDefParam()
        {
            //初始化基础投篮防守值
            this.baseContestList.Clear();
            ZDBTable shotPercentageTable = ZDataManager.Instance.GetShotPercentageTable();
            int rowCount = shotPercentageTable.getRowCount();
            for (int i = 0; i < rowCount; i++)
            {
                ZDB_Row_Data rowData = shotPercentageTable.getDataByRow(i);
                int tableIndex = rowData.getCol((int)shot_percentageFields.FGPercentageReductionBasic).getValueInt();
                if (tableIndex > 0)
                {
                    ZDBTable contestTable = ShotTableManager.Instance.GetShotTableByIndex(tableIndex);
                    int attrIndex = rowData.getCol((int)shot_percentageFields.AttributeDefender).getValueInt();

                    int attr = (int)this.GetAttrByIndex(attrIndex);
                    if (contestTable != null)
                    {
                        int value = contestTable.getDataByID(attr).getCol((int)shot_percentage_common_Fields.Percentage).getValueInt();
                        this.baseContestList.Add(value * 1.0 / 1000000);
                    }
                }
                else
                {
                    this.baseContestList.Add(1.0);
                }

            }

            int shot3PDis = this.Calc3PAttackParam();
            if (shot3PDis >= 724)
            {
                this.defParam.IsNeedDef3P = true;
                this.defParam.Def3PDistance = shot3PDis;
            }

            int shot2PDis = this.Calc2PAttackParam();
            if (shot2PDis >= 424)
            {
                this.defParam.IsNeedDef2P = true;
                this.defParam.Def2PDistance = shot2PDis;
            }

            this.defParam.Def3SecondLineDistance = 324;    
        }

        public int Calc3PAttackParam()
        {
            int x = this.Pos.X;
            int y = this.Pos.Y;
            TacNewShot tac = new TacNewShot(null, string.Empty);

            double param21 = ParameterManager.Instance.GetValue(ParameterEnum.OOODefMinShotExpect) * 1.0f;
            double minExpect = param21 / 100;
            int dis = 1024;
            int value = 0;
            while (dis >= 724)
            {
                this.Pos = this.OwnerTeam.AttackBasket.GetPosByAngleRadius(90, dis);
                double shot3PExpect = tac.GetExpectJumpShot3IgnoreDef(this);
                if (shot3PExpect >= minExpect)
                {
                    value = dis;
                    break;
                }
                dis -= 10;
            }
            this.Pos.X = x;
            this.Pos.Y = y;
            return value;
        }

        /// <summary>
        /// 计算什么时候开始防2分
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public int Calc2PAttackParam()
        {
            TacNewShot tac = new TacNewShot(null, string.Empty);

            double param21 = ParameterManager.Instance.GetValue(ParameterEnum.OOODefMinShotExpect) * 1.0f;
            double minExpect = param21 / 100;
            int dis = 724;
            int value = 0;
            while (dis >= 424)
            {
                double shot2PExpect = tac.GetExperctJumpShot2IgnoreDef(this);
                if (shot2PExpect >= minExpect)
                {
                    value = dis;
                    break;
                }
                dis -= 10;
            }
            return value;
        }

        public bool IsInMyDefArea(double distance)
        {
            if (distance < ParameterManager.Instance.GetValue(ParameterEnum.DefRangeRadius))
            {
                return true;
            }

            return false;
        }

        public Player Clone()
        {
            Player player = new Player();
            for (int i = 0; i < this.NextTask.Count; i++)
            {
                player.NextTask.Add(this.NextTask[i].Clone());
            }
            player.Pos = this.Pos.Clone();
            for (int i = 0; i < (int)PlayerAttribute.End; i++)
            {
                player.szAttribute[i] = this.szAttribute[i];
            }
            return player;
        }

        private int FramePlayed = 0;

        protected override bool VirtualUpdade(GameInfo gameinfo)
        {
            this.playerBehavior.TickUpdate();

            return true;
        }

        /// <summary>
        /// 进攻方任务选择
        /// </summary>
        public void ChoiceDefTask()
        {
            this.playerBehavior.TickDefChoice();
        }

        /// <summary>
        /// 防守方任务选择
        /// </summary>
        public void ChoiceAtkTask()
        {
            this.playerBehavior.TickAtkChoice();
        }

        public void ChoiceTask()
        {
            this.playerBehavior.TickChoice();
        }

        private List<TaskType> lstNotOut3S;

        
        public bool IsNeedOut3S()
        {
            double out3STime = ParameterManager.Instance.GetValue(ParameterEnum.AttackOut3STime) * 1.0f / 1000;
            //在3秒区待的时间过长
            if (this.AtkIn3SecondFrame >= TimeFrameConverter.GetFrame(out3STime) && 
                !this.lstNotOut3S.Contains(this.GetCurTask().TaskType) && 
                !this.lstNotOut3S.Contains(this.GetCurTask().NextTask))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 计算得分预期
        /// </summary>
        /// <param name="defTeam"></param>
        /// <returns></returns>
        public double CalcScoringExpect(GameInfo gameInfo)
        {
            //有事在做就不需要算
            if ( this.IsFree )
            {
                this.ForceCalcScoringExpect(gameInfo);
            }
            return this.ScoringExpect;
        }

        public static int ForceCalcScoringExpectCount = 0;
        private int LastCalcFrame = 0;
        public void ForceCalcScoringExpect(GameInfo gameInfo, bool needFramePassed = true)
        {
            //为了减少计算次数
            if (!needFramePassed || gameInfo.IsFramePassed(this.LastCalcFrame, 1))
            {
                this.LastCalcFrame = gameInfo.GameFrame;
                Player.ForceCalcScoringExpectCount++;
                double crossOverExpect = gameInfo.TacShot.GetExpectCrossOver(this);
                double shotExpect = gameInfo.TacShot.GetExpectJumpShot(this);
                double insideExpect = gameInfo.TacShot.GetExpectInsideShot(this);
                double scoringExpect = gameInfo.TacShot.GetMaxExpect(crossOverExpect, shotExpect, insideExpect);
                this.ScoringExpect = scoringExpect;
                this.CrossOverExpect = crossOverExpect;
                this.InsideScoringExpect = insideExpect;
                this.ShotScoringExpect = shotExpect;
            }
        }

        public void CalcStamina()
        {
            //根据查表来算这次要加多少体力
            int speedLevel = 0;
            if (this.curTask != null)
            {
                speedLevel = this.GetCurTask().SpeedLevel;
            }
            if (stamina_Row_Data != null)
            {
                int add = stamina_Row_Data.getCol(speedLevel + 1).getValueInt();
                this.CurStamina += add;
                if (this.CurStamina > this.MaxStamina)
                {
                    this.CurStamina = this.MaxStamina;
                }
                else if (this.CurStamina < 0)
                {
                    this.CurStamina = 0;
                }
            }
        }

        /// <summary>
        /// 在场下恢复体力
        /// </summary>
        public void RestoreStaminaOnBench(double time, int oneSecondRestore)
        {
            int add = (int)(time * oneSecondRestore);
            this.CurStamina += add;
            if (this.CurStamina > this.MaxStamina)
            {
                this.CurStamina = this.MaxStamina;
            }
            else if (this.CurStamina < 0)
            {
                this.CurStamina = 0;
            }
        }

        /// <summary>
        /// 获取当前体力的等级
        /// 1到10
        /// </summary>
        /// <returns></returns>
        public int GetStaminaLevel()
        {
            int staminaLevel = (int)Math.Floor(this.CurStamina * 1.0f / ParameterManager.Instance.GetValue(ParameterEnum.MaxStamina) * 10) + 1;
            if (staminaLevel > 10)
            {
                staminaLevel = 10;
            }
            else if (staminaLevel < 1)
            {
                staminaLevel = 1;
            }
            return staminaLevel;
        }

        /// <summary>
        /// 获取速度 单位 cm/s
        /// </summary>
        /// <param name="speedLevel"></param>
        /// <returns></returns>
        public double GetSpeedByLevel(int speedLevel)
        {
            if (speedLevel < 0)
            {
                speedLevel = 0;
            }
            if (speedLevel > 10)
            {
                speedLevel = 10;
            }
            return this.GetAttribute(PlayerAttribute.Speed) * speedLevel / 10;
        }

        /// <summary>
        /// 获取速度 单位 像素/s
        /// </summary>
        /// <param name="speedLevel"></param>
        /// <returns></returns>
        public double GetSpeedInPixelByLevel(int speedLevel)
        {
            if (speedLevel < 0)
            {
                speedLevel = 0;
            }
            if (speedLevel > 10)
            {
                speedLevel = 10;
            }
            return this.MaxSpeedInPix * speedLevel / 10;
        }

        /// <summary>
        /// 根据实际速度算速度等级
        /// </summary>
        /// <param name="speedInPixel"></param>
        /// <returns></returns>
        public int GetSpeedLevelByRealSpeed(double speedInPixel)
        {
            int speedLevel = (int)Math.Floor(speedInPixel / this.maxSpeedInPix * 10);
            if (speedLevel < 0)
            {
                speedLevel = 0;
            }
            if (speedLevel > 10)
            {
                speedLevel = 10;
            }
            return speedLevel;
        }

        public bool IsFree = false;


        protected override void VirtualAfterUpdate(GameInfo gameinfo)
        {
            if(!gameinfo.IsPause)
            {
                this.Calc3S(gameinfo);
                this.UpdateFramePlayed(gameinfo);
            }
            GameTask cTask = this.curTask;
            if (cTask == null || (cTask.FinishFrame <= 0 && cTask.DelayStart <= 0))
            {
                this.IsFree = true;
            }
            else
            {
                this.IsFree = false;
            }
        }

        private void Calc3S(GameInfo gameinfo)
        {
            if (gameinfo.IsFramePassed(this.lastCalc3SecondFrame, this.calc3SecondStep))
            {
                this.lastCalc3SecondFrame = gameinfo.GameFrame;
                //增加3秒计时等等
                //是进攻方球员，且当前有持球人或者球在传球过程中
                Team attackTeam = gameinfo.AttackTeam;
                if (attackTeam != null &&
                    attackTeam == this.OwnerTeam)
                {
                    //进攻3秒计时
                    this.CalcAtk3S(gameinfo ,attackTeam);
                }
                else
                {
                    //防守3秒
                    this.CalcDef3S(gameinfo, attackTeam);
                }
            }
        }

        private void CalcAtk3S(GameInfo gameinfo,Team attackTeam)
        {
            //进攻3秒计时
            Field attackField = attackTeam.AttackField;
            BasketBall ball = gameinfo.Ball;
            if (ball.Owner != null &&
                !ball.IsInTask(TaskType.BallPassBall))
            {
                if (attackField.IsIn3Second(this.Pos))
                {
                    this.AtkIn3SecondFrame += this.calc3SecondStep;
                }
            }
            if (this.AtkIn3SecondFrame > 0 && !attackField.IsIn3Second(this.Pos))
            {
                this.ClearAttack3S();
            }
        }

        private void CalcDef3S(GameInfo gameinfo, Team attackTeam)
        {
            //防守三秒
            Field attackField = attackTeam.AttackField;
            BasketBall ball = gameinfo.Ball;
            if (ball.Owner != null &&
                !ball.IsInTask(TaskType.BallPassBall))
            {
                Player atkPlayer = this.GetMyPosAttacker();
                double dis = gameinfo.DisManager.GetDistanceInCMToOtherTeamPlayer(gameinfo.Frame, atkPlayer, this);
                //double dis = atkPlayer.Pos.DistanceActualLength(this.Pos);
                //int minDis = ParameterManager.Instance.GetValue(ParameterEnum.Def3SMinDis);
                if (dis < this.Def3SecondMinDis || !attackField.IsIn3Second(this.Pos))
                {
                    if (this.Def3SecondFrame > 0)
                    {
                        //对位的人在附近或者不在3秒区内
                        this.ClearDef3S();
                    }
                }
                else
                {
                    this.Def3SecondFrame += this.calc3SecondStep;
                }
            }
            else
            {
                //没有持球人，且不处于传球状态
                this.ClearDef3S();
            }
        }

        public void UpdateFramePlayed(GameInfo gameInfo)
        {
            if (gameInfo.QuarterFrame > 0)
            {
                this.FramePlayed++;
                if (this.FramePlayed >= TimeFrameConverter.FramesOneSecond)
                {
                    this.ThisQuarterPlayerFrame += this.FramePlayed;
                    gameInfo.GetBoxScore().AddBoxScore(this.OwnerTeam.TeamType, this.RoleID, BoxScoreType.FramePlayed, TimeFrameConverter.FramesOneSecond);
                    this.FramePlayed = 0;
                }
            }
        }


        public void ClearAttack3S()
        {
            this.AtkIn3SecondFrame = 0;
        }

        public void ClearDef3S()
        {
            this.Def3SecondFrame = 0;
        }

        /// <summary>
        /// 我的对位进攻人
        /// 其实就是我防谁
        /// </summary>
        /// <returns></returns>
        public Player GetMyPosAttacker()
        {
            return this.OwnerTeam.GetMyPosAtkPlayer(this);
        }

        /// <summary>
        /// 补防、换防用
        /// </summary>
        /// <param name="atkPlayer"></param>
        public void SetMyPosAttacker(Player atkPlayer)
        {
            this.ClearTask();
            this.OwnerTeam.SetMyPosAtkPlayer(atkPlayer, this);
        }

        /// <summary>
        /// 我的对位防守人
        /// 谁防我，可能有多个，根据不同模式取
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public Player GetMyPosDefPlayer(int type = 0)
        {
            if (type == 0)
            {
                return this.OwnerTeam.GetMyPosDefPlayer(this, type);
            }
            return null;
        }

        public List<Player> GetAllMyPosDefPlayers()
        {
            return this.OwnerTeam.GetAllMyPosDefPlayer(this);
        }

        /// <summary>
        /// 是否同一个人
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>   
        public bool IsSamePlayer(Player player)
        {
            if (player == null)
            {
                return false;
            }
            if (player.RoleID.Equals(this.RoleID))
            {
                return true;
            }
            return false;
        }

        protected override void AfterSetCurTask()
        {
            if (this.IsFree)
            {
                //有可能别的任务有安排
                if (this.GetCurTask().FinishFrame > 0 || this.GetCurTask().DelayStart > 0)
                {
                    this.IsFree = false;
                }
            }
        }

        /// <summary>
        /// 根据索引值获取某种投篮方式基础命中率
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public double GetBaseHitRate(int index)
        {
            if (index <= 0 || index > this.baseHitRateList.Count)
            {
                return 0f;
            }
            return this.baseHitRateList[index - 1];
        }

        /// <summary>
        /// 根据索引值获取某种投篮方式基础干扰值
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public double GetBaseContest(int index)
        {
            if (index <= 0 || index > this.baseContestList.Count)
            {
                return 0f;
            }
            return this.baseContestList[index - 1];
        }


        /// <summary>
        /// 球队评级变化会导致球员属性变化
        /// </summary>
        /// <param name="attrIndex"></param>
        /// <param name="addValue"></param>
        public void AddAttrByIndex(int attrIndex, int addValue)
        {
            double souceValue = 0;
            //要把原始属性存下来
            if (!this.dicAttributeSoucre.ContainsKey(attrIndex))
            {
                souceValue = this.GetAttrByIndex(attrIndex);
                this.dicAttributeSoucre[attrIndex] = souceValue;
            }
            else
            {
                souceValue = this.dicAttributeSoucre[attrIndex];
            }
            double value = souceValue + addValue;
            if (value < 1.0)
            {
                value = 1.0;
            }
            szAttribute[attrIndex] = value;
        }

    }
}
