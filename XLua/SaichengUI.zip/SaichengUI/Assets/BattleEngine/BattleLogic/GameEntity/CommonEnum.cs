﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public enum EStaminaCost
    {
        JumpBall                = 1,//跳球
        InsideAttack            = 2,//背打
        CrossOver               = 3,//突破判断
        Block                   = 4,//盖帽
        PassBall                = 5,//传球
        Rebound                 = 6,//篮板
        TakePosition            = 7,//抢位
    }

    public enum ShotType
    {
        InsideShot              = 1,//内线投篮
        HookShot                = 2,//勾手
        FadeAway                = 3,//后仰跳投
        SlumDunk                = 4,//扣篮
        JumpShot2P              = 5,//2分投篮
        JumpShot3P              = 6,//3分投篮
        LayUp                   = 7,//上篮
    }

    /// <summary>
    /// 抢断来源
    /// </summary>
    public enum EStealSource
    {
        InsideAttack            = 1,//背打
        PassBall                = 2,//传球
        CrossOver               = 3,//过人
        InsideAtkDoubled        = 4,//背打包夹
    }

    /// <summary>
    /// 进攻战术类型
    /// </summary>
    public enum ETacticOff
    {
        BaseOff                 = 1,//基本进攻战术
    }

    /// <summary>
    /// 防守战术类型
    /// </summary>
    public enum ETacticDef
    {
        BaseDef                 = 1,//基本防守战术
    }

    /// <summary>
    /// 任务来源
    /// </summary>
    public enum ETaskSource
    {
        Unkown                  = 0,//未知
        InsideAttack            = 1,//背打
    }

    public enum EBallOnTheFloorSourceType
    {
        Steal                   = 1,//抢断地板球
        Block                   = 2,//盖帽地板球
        Rebound                 = 3,//篮板地板球
        PassBall                = 4,//地板球
    }

    public enum EBallOnTheFloorType
    {
        Bounce                  = 1,//弹
        Roll                    = 2,//滚
    }

    public enum EFoulType
    {
        InsideShotDefFoul               = 1,//内线投篮
        HookDefFoul                     = 2,//勾手    
        FadeAwaryShotDefFoul            = 3,//后仰跳投出手的犯规
        SlumDunkShotDefFoul             = 4,//扣篮出手时候的犯规
        JumpShot2PDefFoul               = 5,//两分跳投
        JumpShot3PDefFoul               = 6,//三分跳投
        LayUpDefFoul                    = 7,//上篮
        InsideAttackDefFoul             = 8,//背打
        PickAndRollDefFoul              = 9,//挡拆
        CrossOverDefFoul                = 10,//突破
        BoxOutDefFoul                   = 11,//抢位
        SlumDunkDefFoul                 = 12,//扣篮过程中的犯规
        FadeAwayDefFoul                 = 13,//后仰过程中的犯规
        DoubledDefFoul                  = 14,//夹击
        CoverPaowei                     = 15,//掩护跑位

        InsideAttackAtkFoul             = 201,//背打进攻犯规
        PickAndRollAtkFoul              = 202,//挡拆进攻犯规
        CrossOverAtkFoul                = 203,//突破进攻犯规
        BoxOutAtkFoul                   = 204,//抢位进攻犯规
        DoubledAtkFoul                  = 205,//夹击进攻犯规
        CoverPaoweiAtkFoul              = 206,//掩护跑位进攻犯规
    }

    public enum EExpectionType
    {
        InsideShot                  = 11,
        CrossOver                   = 12,
        JumpShot2                   = 13,
        JumpShot3                   = 14,
    }

    public enum EPickRollMoveType
    {
        CoverToJump3P               = 1,
        CoverToJump2P               = 2,
        OtherAtkToJump3P            = 3,
        OtherAktToJump2P            = 4,
        CoverToInside               = 5,
    }

    public enum EFreeThrowType
    {
        Normal                      = 1,//普通罚球（罚球不中会抢板）
        Technical                   = 2,//技术犯规罚球（罚球不中不抢板）
    }

    public enum EFillInType
    {
        Default                     = 1,//默认
        CrossOver                   = 2,//突破
        ProtectBasket               = 3,//追击
        PickRoll                    = 4,//挡拆
        Cover                       = 5,//掩护
    }

    public enum EPlayeByPlayType
    {
        SlumDunkNormal                          = 1000,//普通扣篮
        BallShotAndOne                          = 1009,//球进加罚
        FoulOnShot                              = 1021,//打手犯规
        FoulOnAtk                               = 1022,//进攻犯规
        QuarterStart                            = 1023,//第 N 节开始了
        FreeThrowIn                             = 1024,//罚球命中
        FreeThrowNotIn                          = 1025,//罚球未命中
        GetPassBall                             = 1026,//拿到球（传球）
        JumpBallOverTime                        = 1027,//加时赛跳球
        QuarterEnd                              = 1028,//一节结束
        ThrowInVio                              = 1029,//发球违例
        ShotTimeVio                             = 1030,//24秒违例
        Shot                                    = 1031,//投篮出手
        FakeActionJump                          = 1032,//被假动作晃起
        HitRate                                 = 1033,//命中率
        GetPassBall2                            = 1034,//传球（没有传球人）
        PassBall                                = 2001,//传球
        GameOver                                = 20003,//比赛结束了
        FoulNormal                              = 3101,//普通犯规
        GetRebound                              = 4001,//篮板
        DefRebound                              = 4002,//后场篮板
        OffRebound                              = 4003,//进攻篮板
        Steal                                   = 5001,//抢断
        StealTouchBall                          = 5101,//捅到了球
        Block                                   = 6101,//封盖 
        OutOfBoundBySomeBody                    = 7002,//球出界了
        OutOfBound                              = 7003,//球出界了
        StartGameJump                           = 10001,//开始比赛的跳球
        GetBallOnTheFloor                       = 11001,//地板球抢到球
        FakeAction                              = 12001,//假动作
        Def3S                                   = 13002,//防守3秒
        Atk3S                                   = 13004,//进攻3秒
        ShotNotIn                               = 20001,//球没进
        ShotIn                                  = 39001,//球进了
        ShotInByAst                             = 40001,//球进有助攻
        JumpWin                                 = 42001,//跳球结果
        Substitution                            = 50000,//换人
    }

    public enum ETeamRatingType
    {
        Start                       = 0,
        OutsideScoring              = 1,
        InsideScoring               = 2,
        TacFinish                   = 3,
        OutsideDefence              = 4,
        InsideDefence               = 5,
        Rebound                     = 6,
        End                         ,
    }

    public enum EGameStatus
    {
        GarbageTime                 = 1,//垃圾时间
        CrutchTime                  = 2,//关键时间
        NormalTime                  = 3,//常规时间
    }

    public enum EBallShotThrowInReason
    {
        FreeThrow                   = 1,
        BallShot                    = 2,
        ThrowInVio                  = 3,
        ShotClockVio                = 4,
    }

    public enum EJumpBallType
    {
        GameStart                   = 1,
        OverTimeStart               = 2,
    }
}
