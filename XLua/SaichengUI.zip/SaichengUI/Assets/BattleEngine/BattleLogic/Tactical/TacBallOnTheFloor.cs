﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class TacBallOnTheFloor : TacBase
    {
        public TacBallOnTheFloor(GameInfo gameInfo, string source)
            : base(gameInfo, source)
        {
 
        }


        /// <summary>
        /// 计算球的轨迹
        /// </summary>
        /// <param name="startPos"></param>
        /// <param name="angle"></param>
        /// <param name="speed"></param>
        /// <param name="lastOwner"></param>
        /// <param name="touchBallPlayer"></param>
        private void SetBallTask(EBallOnTheFloorSourceType sourceType, Position startPos, int angle, int speed, Player lastOwner, Player touchBallPlayer)
        {
            double param206 = ParameterManager.Instance.GetValueD(ParameterEnum.BallOnTheFloorSpeedCOE);
            double param207 = ParameterManager.Instance.GetValueD(ParameterEnum.BallOnTheFloorTimeCOE);
            double param257 = ParameterManager.Instance.GetValueD(ParameterEnum.BallOnTheFloorStartTime);
            double param339 = ParameterManager.Instance.GetValueD(ParameterEnum.BallOnTheFloorRollSpeed);
            int count = 0;
            this.gameInfo.Ball.ClearTask();
            Position lastPos = startPos;
            while (true)
            {
                double nextSpeed = speed * Math.Pow((1 - param206 / 100), count);
                double time = param257 / 1000 * Math.Pow((1 - param207 / 100), count);

                double dis = time * nextSpeed;
                Position target = lastPos.GetPosByAngleRadius(angle, (int)dis);

                //安排球的弹
                GameTask gt = this.GetBallTask(sourceType, lastPos, target, EBallOnTheFloorType.Bounce, nextSpeed, lastOwner, touchBallPlayer);
                if (count == 0)
                {
                    this.gameInfo.Ball.SetCurrentTask(gt);
                }
                else
                {
                    this.gameInfo.Ball.NextTask.Add(gt);
                }
                if (this.gameInfo.IsInBounds(target))
                {
                    if (nextSpeed < param339)
                    {
                        //这时候进入滚的状态
                        double rollSpeed = speed * Math.Pow((1 - param206 / 100), count + 1);
                        //直接滚50米，不管在哪都可以出去出去
                        Position p1 = target.GetPosByAngleRadius(angle, 5000);
                        this.gameInfo.Ball.NextTask.Add(this.GetBallTask(sourceType, target, p1, EBallOnTheFloorType.Roll, rollSpeed, lastOwner, touchBallPlayer));
                        
                        break;
                    }
                }
                else
                {
                    //界外，结束
                    break;
                }
                lastPos = target.Clone();
                count++;
            }
        }

        /// <summary>
        /// 获取球的任务
        /// </summary>
        /// <param name="startPos"></param>
        /// <param name="targetPos"></param>
        /// <param name="type"></param>
        /// <param name="speed"></param>
        /// <returns></returns>
        private GameTask GetBallTask(EBallOnTheFloorSourceType sourceType, Position startPos, Position targetPos, EBallOnTheFloorType type, double speed, Player lastOnwer, Player touchBallPlayer)
        {
            GameTask gt = new GameTask(this.name);
            if (type == EBallOnTheFloorType.Bounce)
            {
                gt.TaskType = TaskType.BallOnTheFloorBounce;
            }
            else
            {
                gt.TaskType = TaskType.BallOnTheFloorRoll;
            }
            gt.Param1 = (int)sourceType;
            gt.StartPos = startPos;
            gt.TargetPos = targetPos;
            gt.FinishFrame = gt.CalcTimeBySpeed((double)speed);
            gt.TargetPlayer = touchBallPlayer;
            gt.SecondPlayer = lastOnwer;

            return gt;
        }

        /// <summary>
        /// 抢地板球任务
        /// </summary>
        /// <param name="delayStart"></param>
        /// <returns></returns>
        private GameTask GetToGetBallOnTheFloorTask(int delayStart = 0 )
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerToGetBallOnTheFloor;
            gt.DelayStart = delayStart;
            return gt;
        }

        /// <summary>
        /// 是否出界
        /// </summary>
        /// <returns></returns>
        public bool IsOutOfBound()
        {
            if (!this.gameInfo.IsInBounds(this.gameInfo.Ball.Pos))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 出界
        /// </summary>
        public void OutOfBound(EBallOnTheFloorSourceType source, Player sourcePlayer = null)
        {
            if (sourcePlayer == null)
            {
                sourcePlayer = this.gameInfo.Ball.GetCurTask().TargetPlayer;
            }

            PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.OutOfBoundBySomeBody, sourcePlayer.Id);
            this.gameInfo.AddGameInfo(pc);


            if (source == EBallOnTheFloorSourceType.PassBall)
            {
                this.gameInfo.AddPersoanlBoxScore(sourcePlayer, BoxScoreType.TOV, 1);
            }

            Field atkField = this.gameInfo.AttackTeam.AttackField;
            Field defField = this.gameInfo.DefTeam.AttackField;

            //清事件
            this.gameInfo.ClearEvent();

            //所有人待机
            this.gameInfo.SetAllPlayerTask(TaskType.PlayerStandby, int.MaxValue, this.name);

            Position posToThrowIn = Position.Empty;
            if (atkField.IsOnMe(this.gameInfo.Ball.Pos))
            {
                //前场球
                posToThrowIn = atkField.GetSideThrowInPos(this.gameInfo.Ball.Pos);
            }
            else
            {
                //后场球
                posToThrowIn = defField.GetSideThrowInPos(this.gameInfo.Ball.Pos);
            }
            //是否交换球权
            Team atkTeam = this.gameInfo.AttackTeam;
            Team defTeam = this.gameInfo.DefTeam;
            if (sourcePlayer.OwnerTeam == atkTeam)
            {
                this.gameInfo.ClearBallOwner();
                this.gameInfo.SetBallOwnTeam(defTeam);

                //24秒计时
                this.gameInfo.Pause();
                this.gameInfo.StartNewRound();
            }

            //界外球事件
            GameEvent ge = new GameEvent(GameEventType.OutOfBoundToThrowIn);
            ge.Pos = posToThrowIn;
            this.gameInfo.AddGameEvent(ge);
        }

        private void SetOtherPlayerTask(Player touchBallPlayer, Position firstPos)
        {
            double disMax = ParameterManager.Instance.GetValueD(ParameterEnum.ToGetBallOnTheFloorDis);
            double param290 = ParameterManager.Instance.GetValueD(ParameterEnum.ToGetBallOnTheFloorParam1);
            double param293 = ParameterManager.Instance.GetValueD(ParameterEnum.ToGetBallOnTheFloorParam2);
            int random = this.gameInfo.RandomNext();
            int delayFrame = TimeFrameConverter.GetFrame(ParameterManager.Instance.GetValueD(ParameterEnum.ToGetBallOnTheFloorDelayTime) / 1000);
            //2016.11.18修改 增加判断 所有弹地点，都可能触发
            List<Position> lst = new List<Position>();
            lst.Add(this.gameInfo.Ball.Pos);
            lst.Add(firstPos);
            for (int i = 0; i < this.gameInfo.Ball.NextTask.Count; i++)
            {
                GameTask gt = this.gameInfo.Ball.NextTask[i];
                if (gt.TaskType == TaskType.BallOnTheFloorBounce)
                {
                    lst.Add(gt.TargetPos);
                }
            }
            //其他人
            for (int i = 0; i < GameInfo.TeamCount; i++)
            {
                Team team = this.gameInfo.Teams[i];
                for (int j = 0; j < team.PlayerCount; j++)
                {
                    Player player = team.Players[j];
                    //最后触球人单独安排
                    if (!player.IsSamePlayer(touchBallPlayer))
                    {
                        bool isNeedCalc = false;
                        double dis = 0.0;
                        for (int k = 0; k < lst.Count; k++)
                        {
                            Position pos = lst[k];
                            dis = player.Pos.DistanceActualLength(pos);
                            if (dis <= disMax)
                            {
                                isNeedCalc = true;
                                break;
                            }
                        }
                        if (isNeedCalc)
                        {
                            //概率
                            double pro = player.GetAttribute(PlayerAttribute.Steal) * param293 / (dis + param290);
                            pro = pro * 10000;
                            if (pro > random)
                            {
                                player.SetCurrentTask(this.GetToGetBallOnTheFloorTask(delayFrame));
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 是否得球
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public bool IsGetBall(Player player)
        {
            double dis = player.Pos.DistanceActualLength(this.gameInfo.Ball.Pos);
            double maxDis = ParameterManager.Instance.GetValueD(ParameterEnum.GetBallOnTheFloorMaxDis);
            if (dis <= maxDis)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 得球
        /// </summary>
        /// <param name="player"></param>
        public void GetBall(Player player)
        {
            EBallOnTheFloorSourceType sourceType = (EBallOnTheFloorSourceType)this.gameInfo.Ball.GetCurTask().Param1;

            //直播
            PlayByPlayContent pc;
            if (sourceType == EBallOnTheFloorSourceType.Steal)
            {
                pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.GetBallOnTheFloor, player.Id);
            }
            else
            {
                pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.GetRebound, player.Id);
            }
            this.gameInfo.AddGameInfo(pc);

            //清事件，大家重新选择
            this.gameInfo.ClearAllPlayerTask(TaskType.PlayerFastBreak);

            //重置24秒、加技术统计
            ZDBTable floorBallTypeTable = ZDataManager.Instance.GetFloorBallTypeTable();
            ZDB_Row_Data typeRow = floorBallTypeTable.getDataByID(this.gameInfo.Ball.GetCurTask().Param1);

            int floorBallId = 0;
            if (player.OwnerTeam != this.gameInfo.Ball.OwnTeam)
            {
                //原防守方得球
                floorBallId = typeRow.getCol((int)floorball_typeFields.DefenceGetBall).getValueInt();
            }
            else
            {
                //原进攻方得球
                floorBallId = typeRow.getCol((int)floorball_typeFields.AttackGetBall).getValueInt();
            }
            ZDBTable floorBallTable = ZDataManager.Instance.GetFloorBallTable();
            ZDB_Row_Data rowData = floorBallTable.getDataByID(floorBallId);

            int isReset24s = rowData.getCol((int)floorballFields.Time).getValueInt();
            if (isReset24s == 1)
            {
                //重置24秒
                this.gameInfo.StartNewRound();
                this.gameInfo.CurRound.SetResume();
            }

            if (this.gameInfo.IsPause)
            {
                this.gameInfo.Resume();
            }

            //原进攻人技术统计
            Player oldAtkPlayer = this.gameInfo.Ball.GetCurTask().SecondPlayer;
            int oldAtkBoxScore = rowData.getCol((int)floorballFields.Attack).getValueInt();
            if (oldAtkBoxScore > 0 && 
                Enum.IsDefined(typeof(BoxScoreType),oldAtkBoxScore) && 
                oldAtkPlayer != null)
            {
                this.gameInfo.AddPersoanlBoxScore(oldAtkPlayer, (BoxScoreType)oldAtkBoxScore, 1);
            }
            
            //原防守人技术统计
            int oldDefBoxScore = rowData.getCol((int)floorballFields.Defence).getValueInt();
            Player oldDefPlayer = this.gameInfo.Ball.GetCurTask().TargetPlayer;//原防守人
            if (oldDefBoxScore > 0 &&
                Enum.IsDefined(typeof(BoxScoreType), oldDefBoxScore) &&
                oldDefPlayer != null)
            {
                this.gameInfo.AddPersoanlBoxScore(oldDefPlayer, (BoxScoreType)oldDefBoxScore, 1);
            }

            //得球人技术统计
            int getBallBoxScore = rowData.getCol((int)floorballFields.GetBall).getValueInt();
            if (getBallBoxScore > 0 &&
                Enum.IsDefined(typeof(BoxScoreType), getBallBoxScore))
            {
                this.gameInfo.AddPersoanlBoxScore(player, (BoxScoreType)getBallBoxScore, 1);
            }

            //安排球
            this.gameInfo.SetBallOwner(player);
            this.gameInfo.Ball.ClearTask();
            this.gameInfo.Ball.Pos = player.Pos;
            this.gameInfo.Ball.SetCurrentTask(this.GetTaskBallOnThePlayer(player));
        }

        private GameTask GetTaskBallOnThePlayer(Player player)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.BallOnThePlayer;
            gt.StartPos = player.Pos;
            gt.TargetPos = player.Pos;
            gt.TargetPlayer = player;
            gt.FinishFrame = int.MaxValue;

            return gt;
        }

        /// <summary>
        /// 随机地板球速度
        /// </summary>
        /// <param name="speedType"></param>
        /// <returns></returns>
        public int GetSpeed(int speedType)
        {
            ZDBTable floorBallSpeed = ZDataManager.Instance.GetFloorBallSpeedTable();
            int random = this.gameInfo.RandomNext();
            int total = 0;
            int speed = 0;
            for (int i = 0; i < floorBallSpeed.getRowCount(); i++)
            {
                ZDB_Row_Data rowData = floorBallSpeed.getDataByRow(i);
                int chance = rowData.getCol(speedType - 1).getValueInt();
                total += chance;
                if (total >= random)
                {
                    speed = rowData.getCol((int)floorball_speedFields.Speed).getValueInt();
                    break;
                }
            }
            return speed;
        }

        /// <summary>
        /// 进入地板球
        /// </summary>
        /// <param name="type">源头：盖帽、篮板、抢断等</param>
        /// <param name="lastOwner">最后持球人</param>
        /// <param name="lastOwnerBehave">最后持球人延续动作</param>
        /// <param name="touchBallPlayer">触球人</param>
        /// <param name="touchballBehave">触球人延续动作</param>
        /// <param name="start">起点 用来确认方向</param>
        /// <param name="angle">角度 用来确认方向</param>
        /// <param name="speed">球速 cm/s</param>
        public void StartBallOnTheFloor(EBallOnTheFloorSourceType type, Player lastOwner , int lastOwnerBehave, Player touchBallPlayer, int touchballBehave, Position start, int angle, int speed)
        {
            //球没有所属人
            this.gameInfo.ClearBallOwner();

            //球的轨迹
            this.SetBallTask(type, start, angle, speed, lastOwner, touchBallPlayer);
            Position firstPos = this.gameInfo.Ball.GetCurTask().TargetPos;

            //安排球员进入抢地板球
            this.gameInfo.ClearAllPlayerTask(TaskType.PlayerFastBreak);

            //原持球人动作
            if (lastOwnerBehave != 0)
            {
                this.SetPlayerGetBallBehave(lastOwnerBehave, lastOwner, touchBallPlayer);
            }

            //最后触球人动作
            if (touchBallPlayer != null)
            {
                if (touchballBehave != 0)
                {
                    this.SetPlayerGetBallBehave(touchballBehave, touchBallPlayer, lastOwner);
                    touchBallPlayer.NextTask.Add( this.GetToGetBallOnTheFloorTask() );
                }
                else
                {
                    touchBallPlayer.SetCurrentTask(this.GetToGetBallOnTheFloorTask());
                }
            }

            //其他人也判一下
            this.SetOtherPlayerTask( touchBallPlayer, firstPos );
        }

        /// <summary>
        /// 直接得球目标点
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <param name="defPlayer"></param>
        /// <returns></returns>
        private Position GetBallTargetPos(Player atkPlayer)
        {
            double angle = 0;
            int random = this.gameInfo.RandomNext(1, 2);
            Position basketPos = atkPlayer.OwnerTeam.AttackBasket;
            if (basketPos == atkPlayer.Pos)
            {
                //跟篮筐重合
                if (random == 1)
                {
                    angle += 90;
                }
                else
                {
                    angle -= 90;
                }
            }
            else
            {
                Vector2D v = new Vector2D(atkPlayer.OwnerTeam.AttackBasket, atkPlayer.Pos);
                angle = v.GetSlopeAngle();
                if (random == 1)
                {
                    angle += 90;
                }
                else
                {
                    angle -= 90;
                }
            }
            int radius = ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea);

            Position p1 = atkPlayer.Pos.GetPosByAngleRadius((int)angle, radius);
            return p1;
        }

        /// <summary>
        /// 跟随动作
        /// </summary>
        /// <param name="behaveId"></param>
        /// <param name="player"></param>
        /// <param name="anOtherPlayer"></param>
        private void SetPlayerGetBallBehave(int behaveId, Player player, Player anOtherPlayer)
        {
            ZDBTable behaveTable = ZDataManager.Instance.GetFloorBallBehaveTable();
            ZDB_Row_Data rowData = behaveTable.getDataByID(behaveId);

            GameTask gt = this.GetBehaveTask(rowData, player.Pos, player, anOtherPlayer);
            player.SetCurrentTask(gt);

            int nextBehave = rowData.getCol((int)floorball_behaveFields.NextBehave).getValueInt();
            if (nextBehave != 0)
            {
                ZDB_Row_Data nextRowData = behaveTable.getDataByID(nextBehave);
                player.NextTask.Add(this.GetBehaveTask(nextRowData, gt.TargetPos, player, anOtherPlayer));
            }
        }

        private GameTask GetBehaveTask(ZDB_Row_Data rowData, Position startPos, Player player, Player anOtherPlayer)
        {
            int behaveType = rowData.getCol((int)floorball_behaveFields.Behave).getValueInt();
            double behaveTime = rowData.getCol((int)floorball_behaveFields.BehaveTime).getValueInt() * 1.0f / 1000;

            GameTask gt = new GameTask(this.name);
            if (behaveType == 1)
            {
                int speedLevel = 0;
                gt.TaskType = TaskType.PlayerForceMoveTo;
                gt.StartPos = startPos;
                Position p1 = this.GetMoveTargetPos(rowData, player, anOtherPlayer, ref speedLevel);
                gt.TargetPos = p1;
                gt.SpeedLevel = speedLevel;
                gt.FinishFrame = gt.CalcFrameByTime(behaveTime);
            }
            else
            {
                gt.TaskType = TaskType.PlayerForceStandBy;
                gt.StartPos = startPos;
                gt.TargetPos = startPos;
                gt.FinishFrame = TimeFrameConverter.GetFrame(behaveTime);

            }
            return gt;
        }

        /// <summary>
        /// 获取移动的目标点
        /// 同时返回速度等级
        /// </summary>
        /// <param name="rowData"></param>
        /// <param name="player"></param>
        /// <param name="atkPlayer"></param>
        /// <param name="speedLevel"></param>
        /// <returns></returns>
        private Position GetMoveTargetPos(ZDB_Row_Data rowData, Player player, Player anOtherPlayer, ref int speedLevel)
        {
            Position p1 = Position.Empty;

            Position basketPos = this.gameInfo.AttackTeam.AttackBasket;

            int behaveTime = rowData.getCol((int)floorball_behaveFields.BehaveTime).getValueInt();
            //0:读表；1.普通移动；2.加速移动
            int speedType = rowData.getCol((int)floorball_behaveFields.BehaveSpeedType).getValueInt();
            int speed = rowData.getCol((int)floorball_behaveFields.BehaveSpeed).getValueInt();
            //1.远离篮筐；2.靠近篮筐；3.目标点
            int direction = rowData.getCol((int)floorball_behaveFields.BehaveDirection).getValueInt();

            double realSpeed = 0;
            if (speedType == 0)
            {
                realSpeed = speed;
                speedLevel = player.GetSpeedLevelByRealSpeed(Position.GetPix(realSpeed));
            }
            else if (speedType == 1)
            {
                speedLevel = SpeedManager.Instance.GetSpeedNormal(player, this.gameInfo.RandomSpeed());
                realSpeed = player.GetSpeedByLevel(speedLevel);
            }
            else
            {
                speedLevel = SpeedManager.Instance.GetSpeedAccelerate(player, this.gameInfo.RandomSpeed());
                realSpeed = player.GetSpeedByLevel(speedLevel);
            }
            double dis = realSpeed * behaveTime * 1.0f / 1000;
            if (direction == 3)
            {
                //3.目标点
                p1 = this.GetBallTargetPos(anOtherPlayer);
            }
            else if (direction == 1)
            {
                //1.远离篮筐
                p1 = Formula.ClosestIntersection(player.Pos, Position.GetPix(dis), basketPos, player.Pos, true);
            }
            else
            {
                //接近篮筐
                p1 = Formula.ClosestIntersection(player.Pos, Position.GetPix(dis), basketPos, player.Pos);
            }
            if (p1 == Position.Empty)
            {
                p1 = player.Pos;
            }
            return p1;
        }    
    }
}
