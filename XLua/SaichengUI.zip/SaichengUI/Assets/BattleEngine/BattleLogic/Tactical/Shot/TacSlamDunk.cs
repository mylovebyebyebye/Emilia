﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class TacSlamDunk : TacBase
    {
        public TacSlamDunk(GameInfo gameInfo,string source) 
            :base(gameInfo, source)
        {
        }

        /// <summary>
        /// 是否扣篮
        /// 如果扣篮，也会同时返回防守队员
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <param name="lstDefPlayers"></param>
        /// <returns></returns>
        public bool IsSlamDunk(Player atkPlayer )
        {
            double minSlamDunk = ParameterManager.Instance.GetValue(ParameterEnum.SlamDunkMinAbility) * 1.0f;
            if (atkPlayer.GetAttribute(PlayerAttribute.Dunk) < minSlamDunk)
            {
                //小于最低值，不会扣篮
                return false;
            }

            double speedParam1 = ParameterManager.Instance.GetValue(ParameterEnum.SlamDunkSpeedParam1) * 1.0f;
            double speedParam2 = ParameterManager.Instance.GetValue(ParameterEnum.SlamDunkSpeedParam2) * 1.0f;
            double speed = atkPlayer.GetSpeedByLevel(atkPlayer.GetCurTask().SpeedLevel);
            double maxDis = 0f;
            if (speed >= speedParam1)
            {
                maxDis =  ParameterManager.Instance.GetValue(ParameterEnum.SlamDunkMaxDis1) * 1.0f;
            }
            else if (speed >= speedParam2)
            {
                maxDis = ParameterManager.Instance.GetValue(ParameterEnum.SlamDunkMaxDis2) * 1.0f;
            }
            else
            {
                maxDis = ParameterManager.Instance.GetValue(ParameterEnum.SlamDunkMaxDis3) * 1.0f;
            }
            //扣篮范围
            double slamDunkRange = atkPlayer.GetAttribute(PlayerAttribute.Dunk) / 100 * maxDis;

            double atkPlayerDisToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, atkPlayer.OwnerTeam.AttackField, atkPlayer);
            if (atkPlayerDisToBasket > slamDunkRange)
            {
                return false;
            }

            double param340 = ParameterManager.Instance.GetValue(ParameterEnum.SlumDunkParam1);
            double param387 = ParameterManager.Instance.GetValue(ParameterEnum.SlumDunkParam2);
            double param268 = ParameterManager.Instance.GetValue(ParameterEnum.SlanDunkDefRate);

            List<Player> lst = this.GetSlamDunkDefPlayers(atkPlayer);
            double slamDunkPro = atkPlayer.GetAttribute(PlayerAttribute.Dunk) * param340 / (atkPlayerDisToBasket + param387) -
                                lst.Count * param268 / 100;
            slamDunkPro = slamDunkPro * 10000;

            if (slamDunkPro > this.gameInfo.RandomNext())
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// 获取可能防守扣篮的人
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <returns></returns>
        private List<Player> GetSlamDunkDefPlayers(Player atkPlayer)
        {
            List<Player> lst = new List<Player>();
            Position basket = atkPlayer.OwnerTeam.AttackBasket;
            //double atkPlayerDisToBasket = atkPlayer.Pos.DistanceActualLength(basket);
            double atkPlayerDisToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, atkPlayer.OwnerTeam.AttackField, atkPlayer);
            double minDisToBasket = ParameterManager.Instance.GetValue(ParameterEnum.SlamDunkDefDis2) * 1.0f;
            double minDisToAtkerLine = ParameterManager.Instance.GetValue(ParameterEnum.SlamDunkDefDis1) * 1.0f;
            Vector2D v = new Vector2D(atkPlayer.Pos, basket);
            Field atkField = atkPlayer.OwnerTeam.AttackField;
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player defPlayer = this.gameInfo.DefTeam.Players[i];
                //防守球员距离篮筐距离大于一个值，且到篮筐的距离小于进攻人
                //double disToBasket = defPlayer.Pos.DistanceActualLength(basket);
                double disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, atkField, defPlayer);
                if (disToBasket > minDisToBasket && disToBasket < atkPlayerDisToBasket)
                {
                    //到进攻人与篮筐连线的距离，小于一个值
                    double dis = v.DistancePointToVector2D(defPlayer.Pos) * Position.ActualLengthPerPoint;
                    if (dis < minDisToAtkerLine)
                    {
                        lst.Add(defPlayer);
                    }
                }
            }
            return lst;
        }

        public void StartSlamDunk(Player atkPlayer)
        {
            //起跳清三秒
            this.gameInfo.Clear3SecondData();

            Position basket = this.gameInfo.AttackTeam.AttackBasket;

            double playerArea = ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea) * 1.0f;
            //扣篮终点
            Position p1 = Formula.ClosestIntersection(basket, Position.GetPix(playerArea), atkPlayer.Pos, basket);
 
            //扣篮人行为,记录扣篮起始点
            this.SetGameTask(atkPlayer, atkPlayer.Pos);

            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player defPlayer = this.gameInfo.DefTeam.Players[i];
                //防守人是否去封盖
                if (this.IsToBlock(atkPlayer, defPlayer))
                {
                    //去封盖就进入防守扣篮流程
                    //记录扣篮终点
                    this.SetGameTask(defPlayer, p1);
                }
            }

            this.gameInfo.AddPersoanlBoxScore(atkPlayer, BoxScoreType.Dunks, 1);

            PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.SlumDunkNormal, atkPlayer.Id);
            this.gameInfo.AddGameInfo(pc);
        }

        private void SetGameTask(Player player, Position target)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerBeginSlamDunk;
            gt.DelayStart = 0;
            gt.FinishFrame = 1;
            gt.RecordPos = target;

            player.SetCurrentTask(gt);
        }

        private bool IsToBlock(Player atkPlayer, Player defPlayer)
        {

            double dis1 = ParameterManager.Instance.GetValue(ParameterEnum.SlamDunkBlockDis1) * 1.0f;
            double dis2 = ParameterManager.Instance.GetValue(ParameterEnum.SlamDunkBlockDis2) * 1.0f;

            double disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, atkPlayer.OwnerTeam.AttackField, defPlayer);

            double disToAtker = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, atkPlayer, defPlayer);
            if ( disToBasket < dis2 ||
                 disToAtker  < dis1  ) 
            {
                //离篮筐近，或者离扣篮人近
                int quarter = this.gameInfo.Quarter;
                if(quarter > 4)
                {
                    quarter = 4;
                }
                double toBlockCOE = ParameterManager.Instance.GetValue(ParameterEnum.SlamDunkDefBlockCOE) * 1.0f;
                double toBlockRate = 0;
                if (defPlayer.Foul < quarter + 1)
                {
                    toBlockRate = Convert.ToSingle( defPlayer.GetAttribute(PlayerAttribute.Block) / (disToAtker + toBlockCOE) );
                }
                else if (defPlayer.Foul == quarter + 1)
                {
                    toBlockRate = Convert.ToSingle(defPlayer.GetAttribute(PlayerAttribute.Block) / (disToAtker + toBlockCOE) - defPlayer.Foul * 1.0f / 10);
                }
                else
                {
                    toBlockRate = Convert.ToSingle(defPlayer.GetAttribute(PlayerAttribute.Block) / (disToAtker + toBlockCOE) - defPlayer.Foul * 1.0f / 5);
                }
                toBlockRate = toBlockRate * 10000;
                if (toBlockRate > this.gameInfo.RandomNext())
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 是否命中
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <returns></returns>
        public bool IsGoal(Player atkPlayer)
        {
            ZDBTable dunkTable = ZDataManager.Instance.GetDunkTable();
            double goalRate = dunkTable.getDataByID((int)atkPlayer.GetAttribute(PlayerAttribute.Dunk)).getCol((int)percentage_dunkFields.Percentage).getValueInt() * 1.0f / 100;
            if (goalRate >= this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }

        public void SetMoveAfterDunk(Player atkPlayer)
        {
            double rateOnTheBasket = ParameterManager.Instance.GetValue(ParameterEnum.SlamDunkOnTheBasket) * 1.0f / 100 * 10000;
            if (rateOnTheBasket >= this.gameInfo.RandomNext())
            {
                //挂筐
                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.PlayerForceStandBy;
                gt.FinishFrame = TimeFrameConverter.GetFrame(0.3f);

                atkPlayer.Pos = atkPlayer.OwnerTeam.AttackBasket;
                atkPlayer.SetCurrentTask(gt);
            }
            else
            {
                //飞行
            }
        }
    }
}
