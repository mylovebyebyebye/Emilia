﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class TacToShot : TacBase
    {
        private ZDBTable shotBeforeTable;
        private ZDBTable shotFakeParamTable;
        private ZDBTable defenceTypeTable;
        private TacStandby tacStandby;

        public TacToShot(GameInfo gameInfo, string source)
            :base(gameInfo,source)
        {
            this.shotBeforeTable = ZDataManager.Instance.GetShotBeforeTable();
            this.shotFakeParamTable = ZDataManager.Instance.GetShotFakeParamTable();
            this.defenceTypeTable = ZDataManager.Instance.GetDefenceTypeTable();
            this.tacStandby = new TacStandby(this.gameInfo, this.name);
        }

        /// <summary>
        /// 这种投篮方式是否需要判假动作
        /// </summary>
        /// <param name="shotType"></param>
        /// <returns></returns>
        public bool IsNeedFakeAction(ShotType shotType)
        {
            ZDB_Row_Data rowData = this.shotBeforeTable.getDataByID((int)shotType);
            int isFakeEnable = rowData.getCol((int)shot_beforeFields.FakeEnable).getValueInt();
            if (isFakeEnable == 1)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 是否做假动作
        /// </summary>
        /// <param name="shotType"></param>
        /// <param name="player"></param>
        /// <returns></returns>
        public bool IsDoFakeAction(ShotType shotType, Player player)
        {
            ZDB_Row_Data rowData = this.shotBeforeTable.getDataByID((int)shotType);
            int chance = rowData.getCol((int)shot_beforeFields.FakeChance).getValueInt();
            double pro = player.GetAttribute(PlayerAttribute.Fake) / chance * 10000;
            if (pro > this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 做假动作，确认防守队员的反应
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <param name="defPlayer"></param>
        public void DoFakeAction(ShotType shotType, Player atkPlayer, Player defPlayer)
        {
            ZDB_Row_Data shotBeforeRow = this.shotBeforeTable.getDataByID((int)shotType);
            if (this.IsToDisturbShot(shotBeforeRow, atkPlayer, defPlayer))
            {
                //执行干扰投篮
                //是否看破假动作
                if (this.IsSeeThroughFakeAction(atkPlayer, defPlayer))
                {
                    this.DisturbShotNormal(shotBeforeRow, atkPlayer, defPlayer);
                }
                else
                {
                    //被晃了，随机
                    this.DisturbShot(shotBeforeRow, atkPlayer, defPlayer);
                }
            }
        }
        
        /// <summary>
        /// 进行干扰投篮
        /// </summary>
        /// <param name="shotType"></param>
        /// <param name="atkPlayer"></param>
        /// <param name="defPlayer"></param>
        public void DisturnShotByShotType(ShotType shotType, Player atkPlayer, Player defPlayer)
        {
            ZDB_Row_Data shotBeforeRow = this.shotBeforeTable.getDataByID((int)shotType);
            this.DisturbShot(shotBeforeRow, atkPlayer, defPlayer);
        }

        /// <summary>
        /// 进行干扰投篮
        /// </summary>
        /// <param name="shotBeforeRow"></param>
        /// <param name="shooter"></param>
        /// <param name="defPlayer"></param>
        private void DisturbShot(ZDB_Row_Data shotBeforeRow, Player shooter, Player defPlayer)
        {
            double param585 = ParameterManager.Instance.GetValueD(ParameterEnum.DisturbShotParam1);
            double param586 = ParameterManager.Instance.GetValueD(ParameterEnum.DisturbShotParam2);
            double defAttr = shotBeforeRow.getCol((int)shot_beforeFields.Disturbance).getValueInt();
            double pro = (param585 - defAttr) / param586 * 10000;
            if (pro > this.gameInfo.RandomNext())
            {
                //普通干扰
                this.DisturbShotNormal(shotBeforeRow, shooter, defPlayer);
            }
            else
            {
                //跳起干扰
                this.DisturbShotJump(shotBeforeRow, shooter, defPlayer);
            }
        }

        /// <summary>
        /// 进行普通干扰投篮
        /// 仅仅是向投篮者移动，时间为出手时间-去移动时间
        /// </summary>
        /// <param name="shooter"></param>
        /// <param name="defPlayer"></param>
        private void DisturbShotNormal(ZDB_Row_Data shotBeforeRow, Player shooter, Player defPlayer)
        {
            ZDB_Row_Data rowData = this.defenceTypeTable.getDataByID(shotBeforeRow.getCol((int)shot_beforeFields.Id).getValueInt());
            int disMin = rowData.getCol((int)defencetypeFields.DistanceMin).getValueInt();
            int staminaCost = rowData.getCol((int)defencetypeFields.StaminaCostN).getValueInt();

            int shootTime = shotBeforeRow.getCol((int)shot_beforeFields.ShootTimeP).getValueInt();
            if (shootTime > 0)
            {
                double maxSeconds = shootTime * shooter.GetAttribute(PlayerAttribute.ShootTime) / 1000000;
                int shootTimeFrame = TimeFrameConverter.GetFrame(maxSeconds);
                int moveFrame = 0;
                //double dis = shooter.Pos.DistanceActualLength(defPlayer.Pos);
                double dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, shooter, defPlayer);
                bool isMove = false;
                Position target = null;
                if (dis > disMin)
                {
                    //需要移动
                    GameTask gt = new GameTask(this.name);
                    gt.TaskType = TaskType.PlayerMoveTo;
                    gt.StartPos = defPlayer.Pos;
                    target = Formula.ClosestIntersection(shooter.Pos, Position.GetPix( disMin ), defPlayer.Pos, shooter.Pos);
                    //看扑到位置的时间跟出手者的出手时间差
                    if (target != Position.Empty)
                    {
                        gt.TargetPos = target;
                        int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(defPlayer, this.gameInfo.RandomSpeed());

                        double seconds = (double)gt.StartPos.DistanceActualLength(gt.TargetPos) / defPlayer.GetSpeedByLevel(speedLevel);
                        if (maxSeconds < seconds)
                        {
                            seconds = maxSeconds;
                        }
                        //2017.1.12 增加反应时间
                        gt.DelayStart = TimeFrameConverter.GetFrame(defPlayer.GetAttribute(PlayerAttribute.React) / 1000);
                        gt.FinishFrame = gt.CalcRealTargetByTimeSpeed(seconds, defPlayer.GetSpeedInPixelByLevel(speedLevel));
                        gt.SpeedLevel = speedLevel;
                        moveFrame = gt.FinishFrame;
                        isMove = true;
                    }
                    defPlayer.SetCurrentTask(gt);
                }
                {
                    //待机
                    if (moveFrame < shootTimeFrame)
                    {
                        GameTask gtStandby = this.tacStandby.GetMoveInSituByFrameTask(defPlayer, shootTimeFrame - moveFrame);
                        if (isMove && target != Position.Empty)
                        {
                            gtStandby.StartPos = target.Clone();
                            gtStandby.TargetPos = target.Clone();
                        }
                        if (moveFrame > 0)
                        {
                            defPlayer.NextTask.Add(gtStandby);
                        }
                        else
                        {
                            defPlayer.SetCurrentTask(gtStandby);
                        }
                    }
                }
            }
            //扣体力
            defPlayer.CurStamina += staminaCost;
        }

        /// <summary>
        /// 跳起干扰投篮
        /// </summary>
        /// <param name="shooter"></param>
        /// <param name="defPlayer"></param>
        private void DisturbShotJump(ZDB_Row_Data shotBeforeRow, Player shooter, Player defPlayer)
        {
            ZDB_Row_Data rowData = this.defenceTypeTable.getDataByID(shotBeforeRow.getCol((int)shot_beforeFields.Id).getValueInt());
            double freezeJ = rowData.getCol((int)defencetypeFields.DefenceFreezeJ).getValueInt() * 1.0f / 1000;
            int staminaCost = rowData.getCol((int)defencetypeFields.StaminaCostJ).getValueInt();
            double defenceTimeJ = rowData.getCol((int)defencetypeFields.DefenceTimeJ).getValueInt() * 1.0f /1000;

            //强制待机freezeJ
            int freezeFrame = TimeFrameConverter.GetFrame(freezeJ);
            
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerJumpDefShot;
            gt.Param1 = (int)freezeJ;
            gt.Param2 = (int)defenceTimeJ;
            gt.Param3 = staminaCost;
            gt.TargetPlayer = shooter;
            //2017.1.12 增加反应时间
            gt.DelayStart = TimeFrameConverter.GetFrame(defPlayer.GetAttribute(PlayerAttribute.React) / 1000);
            gt.FinishFrame = 1;

            defPlayer.SetCurrentTask(gt);

        }

        /// <summary>
        /// 是否干扰投篮
        /// </summary>
        /// <param name="shotBeforeRow"></param>
        /// <param name="atkPlayer"></param>
        /// <param name="defPlayer"></param>
        /// <returns></returns>
        private bool IsToDisturbShot(ZDB_Row_Data shotBeforeRow, Player atkPlayer, Player defPlayer)
        {
            double defAttr = 0.0f;
            //根据是否是自己的防守对象，取的属性值不一样
            if (atkPlayer.IsSamePlayer(defPlayer.GetMyPosAttacker()))
            {
                defAttr = defPlayer.GetAttrByIndex(shotBeforeRow.getCol((int)shot_beforeFields.Disturbance).getValueInt());
            }
            else
            {
                defAttr = defPlayer.GetAttrByIndex(shotBeforeRow.getCol((int)shot_beforeFields.HelpDisturbance).getValueInt());
            }

            bool isInFoulTrouble = this.gameInfo.IsInFoulTrouble(defPlayer);
            //根据是否在犯规麻烦，取不同的参数列
            int foumulaId = isInFoulTrouble ? shotBeforeRow.getCol((int)shot_beforeFields.Fouls).getValueInt() : shotBeforeRow.getCol((int)shot_beforeFields.NoFouls).getValueInt();
            //取运算参数
            ZDB_Row_Data rowData = this.shotFakeParamTable.getDataByID(foumulaId);
            double defDiv = rowData.getCol((int)shot_fakeparaFields.DefDIV).getValueInt() * 1.0f;
            double disBase = rowData.getCol((int)shot_fakeparaFields.DistanceBase).getValueInt() * 1.0f;
            double disIndex = rowData.getCol((int)shot_fakeparaFields.DistanceIndex).getValueInt() * 1.0f;
            double disIndexDiv = rowData.getCol((int)shot_fakeparaFields.DistanceIndexDIV).getValueInt() * 1.0f;
            double disDiv = rowData.getCol((int)shot_fakeparaFields.DistanceDIV).getValueInt() * 1.0f;
            double foulCOE = rowData.getCol((int)shot_fakeparaFields.FoulsCOE).getValueInt() * 1.0f;
            double foulDiv = rowData.getCol((int)shot_fakeparaFields.FoulsDIV).getValueInt() * 1.0f;
            double disMin = rowData.getCol((int)shot_fakeparaFields.DistanceMin).getValueInt() * 1.0f;
            //double dis = defPlayer.Pos.DistanceActualLength(atkPlayer.Pos);
            double dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, defPlayer, atkPlayer);
            if (dis < disMin)
            {
                dis = disMin;
            }
            double pro = defAttr / defDiv + Math.Pow(disBase, (disIndex - dis) / disIndexDiv) / disDiv * foulCOE / foulDiv ;
            pro = pro * 10000;
            if (pro > this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 是否看破假动作
        /// </summary>
        /// <param name="shootr"></param>
        /// <param name="defPlayer"></param>
        /// <returns></returns>
        private bool IsSeeThroughFakeAction(Player shooter, Player defPlayer)
        {
            double defIQ = defPlayer.GetAttribute(PlayerAttribute.DefenceIQ);
            double atkFake = shooter.GetAttribute(PlayerAttribute.Fake);
            int randomMax = (int)(defIQ + atkFake);
            int random = this.gameInfo.RandomNext(0, randomMax);
            if (random - (defIQ - atkFake) < defIQ)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 出手，加入了出手时间
        /// </summary>
        /// <param name="shotType"></param>
        /// <param name="shooter"></param>
        public void Shot(ShotType shotType, Player shooter)
        {
            ZDB_Row_Data rowData = this.shotBeforeTable.getDataByID((int)shotType);
            int delayStart = 0;
            int shootTime =  rowData.getCol((int)shot_beforeFields.ShootTimeP).getValueInt();
            if (shootTime > 0)
            {
                delayStart = TimeFrameConverter.GetFrame(shootTime * shooter.GetAttribute(PlayerAttribute.ShootTime) / 1000000);
            }
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerShot;
            gt.Param1 = (int)shotType;
            gt.DelayStart = delayStart;
            gt.FinishFrame = 1;

            shooter.SetCurrentTask(gt);
        }

        public GameTask GetToShotTask(ShotType shotType)
        {
            GameTask gt = new GameTask(this.name);
            gt.Param1 = (int)shotType;
            gt.TaskType = TaskType.PlayerToShot;
            return gt;
        }

        public void DoToShot(ShotType shotType, Player player)
        {
            GameTask gt = this.GetToShotTask(shotType);

            player.SetCurrentTask(gt);
        }
    }
}
