﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class TacNewShot : TacBase
    {
        private TacFastBreak tacFastBreak;
        private TacFoul tacFoul;
        ZDBTable shotPercentageTable;
        private double StaminaToHitRateParam;

        public TacNewShot(GameInfo gameInfo, string source)
            :base(gameInfo,source)
        {
            this.tacFastBreak = new TacFastBreak(this.gameInfo, this.name);
            this.tacFoul = new TacFoul(this.gameInfo, this.name);

            this.shotPercentageTable = ZDataManager.Instance.GetShotPercentageTable();
            this.StaminaToHitRateParam = ParameterManager.Instance.GetValue(ParameterEnum.HitrateStaminaParam) * 1.0 / 100000000; 
        }

        public void Shot(Player shooter, ShotType shotType)
        {
            int points = 2;
            if (shotType == ShotType.JumpShot3P)
            {
                points = 3;
            }

            ZDBTable shotTable = ZDataManager.Instance.GetShotTable();
            ZDB_Row_Data shotData = shotTable.getDataByID((int)shotType);

            ZDBTable baseTable = ZDataManager.Instance.GetShotBaseTable();
            ZDB_Row_Data baseData = baseTable.getDataByID(shotData.getCol((int)shotFields.ShotBaseType).getValueInt());

            //直播
            //扣篮有起跳动作这里不播了
            if (shotType != ShotType.SlumDunk)
            {
                this.AddGameInfo(shooter, shotData);
            }
            //扣体力
            this.CostStamina(shooter, shotData);
            //所有人3秒清零
            this.gameInfo.Clear3SecondData();
            //跟随动作(强制不可打断)
            this.AddFollowAction(shooter, shotData);

            //获取可能发生事件的防守人
            List<Player> lstEffectDefPlayer = this.GetEventDefPlayer(shooter, baseData);

            Player blocker = null;
            //是否被盖
            int isBlock = shotData.getCol((int)shotFields.Block).getValueInt();
            int blockType = shotData.getCol((int)shotFields.BlockType).getValueInt();
            if (isBlock == 1 && this.IsBlock(blockType, shooter, lstEffectDefPlayer, ref blocker))
            {
                //isBlock等于1才需要走判断盖帽流程
                //不管进没进，球都不属于这个人了
                this.gameInfo.ClearBallOwner();
                //盖帽
                GameEvent ge = new GameEvent(GameEventType.BlockShot);
                ge.Param1 = points;
                ge.Param2 = (int)shotType;
                ge.Param3 = blockType;
                ge.Param4 = shooter;
                ge.Param5 = blocker;
                this.gameInfo.AddGameEvent(ge);
            }
            else
            {
                //判进没进  
                bool isGoal = this.IsGoal((int)shotType, shooter);

                bool isAssist = false;
                //进了判有没有助攻
                if (isGoal)
                {
                    isAssist = this.IsAssist(shooter.OwnerTeam);
                }

                //没盖帽就出手，看有没有被打手
                Player fouler = null;
                int isFoul = shotData.getCol((int)shotFields.Foul).getValueInt();
                int foulType = shotData.getCol((int)shotFields.FoulType).getValueInt();
                if (isFoul == 1 && this.IsShootFoul(foulType, shooter, lstEffectDefPlayer, ref fouler))
                {
                    this.gameInfo.AddPersoanlBoxScore(fouler, BoxScoreType.FoulOnShot, 1);

                    //球还是要飞
                    this.SetShotBallTask((int)shotType, shooter, baseData, points, isGoal, isAssist, shooter.OwnerTeam.PassBallInfo.LastPassBallPlayer);
                    this.gameInfo.Ball.GetCurTask().Param3 = 1;//设置犯规标识

                    //改为犯规事件
                    GameEvent ge = new GameEvent(GameEventType.Foul);
                    ge.Param1 = (int)FoulType.ShotFoul;
                    ge.Param2 = isGoal ? 1 : points;
                    ge.Param4 = shooter;
                    ge.Param5 = fouler;

                    this.gameInfo.AddGameEvent(ge);
                }
                else
                {
                    //这里是成功出手
                    //安排球的任务
                    this.SetShotBallTask((int)shotType, shooter, baseData, points, isGoal, isAssist, shooter.OwnerTeam.PassBallInfo.LastPassBallPlayer);

                    if (shotType == ShotType.SlumDunk)
                    {
                        //给球加个出手起始点
                        this.gameInfo.Ball.GetCurTask().StartPos = shooter.OwnerTeam.AttackField.GetSlumDunkShotPos();
                    }

                    this.gameInfo.ClearEvent();

                    //安排人的任务
                    //从C开始排到PG
                    this.gameInfo.AttackTeam.AttackField.ClearReboundPos();

                    this.gameInfo.SetAllPlayerTask(TaskType.PlayerToGetRebound, 0, this.name,0);

                    //防守方可能要去快下
                    this.tacFastBreak.CalcFastBreak(this.gameInfo.DefTeam, TaskType.PlayerToGetRebound);
                }
            }
            //出手以后清传球信息
            shooter.OwnerTeam.PassBallInfo.Clear();
        }

        private void AddGameInfo(Player shooter, ZDB_Row_Data shotData)
        {
            PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.Shot, shooter.Id, shotData.getCol((int)shotFields.Id).getValueInt());
            this.gameInfo.AddGameInfo(pc);
        }

        private void CostStamina(Player shooter, ZDB_Row_Data shotData)
        {
            shooter.CurStamina += shotData.getCol((int)shotFields.StaminaCost).getValueInt();
        }

        /// <summary>
        /// 跟随动作
        /// 如果没有就会接篮板流程
        /// </summary>
        /// <param name="shooter"></param>
        /// <param name="shotData"></param>
        private void AddFollowAction(Player shooter, ZDB_Row_Data shotData)
        {
            int followAction = shotData.getCol((int)shotFields.AfterShotBehaveType).getValueInt();
            if (followAction > 0)
            {
                ZDB_Row_Data behaveData = ZDataManager.Instance.GetShotBehaveTable().getDataByID(followAction);
                if (behaveData == null)
                {
                    throw new Exception(string.Format("Error shotType:{1} shotBehaveType :{0}", followAction, shotData.getCol(0).getValueInt()));
                }
                int behaveType = behaveData.getCol((int)shot_behaveFields.AfterShotBehave).getValueInt();
                if (behaveType == 1)
                {
                    //强制移动
                    shooter.SetCurrentTask(this.GetForceMoveTask(shooter, behaveData));
                }
                else if (behaveType == 2)
                {
                    //强制待机
                    shooter.SetCurrentTask(this.GetForceStandByTask(shooter, behaveData));
                }
            }
        }

        private GameTask GetForceStandByTask(Player shooter, ZDB_Row_Data behaveData)
        {
            double standbyTime = behaveData.getCol((int)shot_behaveFields.BehaveTime).getValueInt() * 1.0f / 1000;
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerForceStandBy;
            gt.FinishFrame = TimeFrameConverter.GetFrame(standbyTime);
            return gt;
        }

        private GameTask GetForceMoveTask(Player shooter, ZDB_Row_Data behaveData)
        {
            Position basketPos = this.gameInfo.AttackTeam.AttackBasket;
            Position targetPos = basketPos;
            if (basketPos == shooter.Pos)
            {
                //投篮人跟篮筐重合了，就随机一下
                int random = this.gameInfo.RandomNext(1, 12);
                targetPos = basketPos.GetPosByAngleRadius(random * 30, 5);
            }

            double speed = behaveData.getCol((int)shot_behaveFields.BehaveSpeed).getValueInt();
            double moveTime = behaveData.getCol((int)shot_behaveFields.BehaveTime).getValueInt() * 1.0f / 1000;
            double dis = speed * moveTime;
            int direction = behaveData.getCol((int)shot_behaveFields.BehaveDirection).getValueInt();
            Position p1;
            if (direction == 1)
            {
                //远离篮筐
                p1 = Formula.ClosestIntersection(shooter.Pos, Position.GetPix(dis), targetPos, shooter.Pos, true);
            }
            else
            {
                //靠近篮筐
                p1 = Formula.ClosestIntersection(shooter.Pos, Position.GetPix(dis), targetPos, shooter.Pos);
            }

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerForceMoveTo;
            gt.StartPos = shooter.Pos;
            gt.TargetPos = p1;
            gt.FinishFrame = gt.CalcRealTargetByTimeSpeed(moveTime, Position.GetPix(speed));
            return gt;
        }

        /// <summary>
        /// 获取计算盖帽、犯规的防守队员
        /// </summary>
        /// <param name="shooter"></param>
        /// <param name="baseData"></param>
        /// <returns></returns>
        private List<Player> GetEventDefPlayer(Player shooter, ZDB_Row_Data baseData)
        {
            int effeDis = baseData.getCol((int)shot_baseFields.EventRange).getValueInt();
            return this.GetDefPlayerDisInRange(shooter, effeDis);
        }

        /// <summary>
        /// 是否盖帽
        /// </summary>
        /// <param name="blockType"></param>
        /// <param name="shooter"></param>
        /// <param name="defPlayers"></param>
        /// <param name="blocker"></param>
        /// <returns></returns>
        protected virtual bool IsBlock(int blockType,Player shooter, List<Player> defPlayers,ref  Player blocker)
        {
            ZDBTable shotBlockTable = ZDataManager.Instance.GetShotBlockTable();
            if (!shotBlockTable.hasID(blockType))
            {
                return false;
            }
            ZDB_Row_Data dataRow = shotBlockTable.getDataByID(blockType);

            int blockValue1 = dataRow.getCol((int)shot_blockFields.BlockValue1).getValueInt();
            int blockValue2 = dataRow.getCol((int)shot_blockFields.BlockValue2).getValueInt();
            int blockValue3 = dataRow.getCol((int)shot_blockFields.BlockValue3).getValueInt();
            int blockAttack = dataRow.getCol((int)shot_blockFields.BlockAttack).getValueInt();
            int blockDefence = dataRow.getCol((int)shot_blockFields.BlockDeffence).getValueInt();


            double blockAtkAttr = shooter.GetAttrByIndex(blockAttack);

            int random = this.gameInfo.RandomNext();
            for (int i = 0; i < defPlayers.Count; i++)
            {
                Player defPlayer = defPlayers[i];
                double blockDefAttr = defPlayer.GetAttrByIndex(blockDefence);

                //目前只有这一个公式
                double blockPro = blockDefAttr * blockValue1 / Math.Pow((blockAtkAttr + blockValue2), blockValue3 * 1.0f / 10) / 100 * 10000;
                if (blockPro >= random)
                {
                    blocker = defPlayer;
                    break;
                }
            }
            if (blocker != null)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 是否命中
        /// </summary>
        /// <param name="hitRateType"></param>
        /// <param name="shooter"></param>
        /// <returns></returns>
        private bool IsGoal(int hitRateType, Player shooter)
        {
            double hitRate = this.GetHitRate(hitRateType, shooter, true, true);
            if (hitRate * 10000 >= this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 获取命中表的行
        /// </summary>
        /// <param name="hitRateType"></param>
        /// <returns></returns>
        public ZDB_Row_Data GetShotPercentage(int hitRateType)
        {
            ZDB_Row_Data rowData = this.shotPercentageTable.getDataByID(hitRateType);
            return rowData;
        }

        /// <summary>
        /// 命中率
        /// </summary>
        /// <param name="hitRateType"></param>
        /// <param name="shooter"></param>
        /// <param name="isHaveDefPlayers"></param>
        /// <param name="isAddGameInfo"></param>
        /// <returns></returns>
        private double GetHitRate(int hitRateType, Player shooter, bool isAddGameInfo = false, bool isAddStaminaPercentage = false)
        {
            ZDB_Row_Data rowData = this.GetShotPercentage(hitRateType);

            //%_FieldGoal=%_Shooter( 出手球员命中率基础值)×SRR( 命中率随出手距离递减值)×%_Defender(防守球员影响命中率值)
            double baseRate = this.GetBaseHitRate(shooter, rowData);//出手球员命中率基础值
            double srr = this.GetShotRangeReduce(shooter, rowData);//命中率随出手距离递减值
            double defRate = 1.0f;//防守球员影响命中率值
            List<Player> defPlayers = this.GetHitRateDefPlayer(shooter, rowData);
            if (defPlayers.Count != 0)
            {
                defRate = this.GetDefenderValue(shooter, defPlayers, rowData);
            }
            double hitRate = baseRate * srr * defRate;
            //2016.12.30，增加体力影响命中率
            if (isAddStaminaPercentage)
            {
                double staminaAdd = shooter.CurStamina * this.StaminaToHitRateParam;
                if (staminaAdd > 1.0)
                {
                    staminaAdd = 1.0;
                }
                hitRate = hitRate * staminaAdd;
            }

            if (isAddGameInfo)
            {
                PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.HitRate, (int)(Math.Round(hitRate, 2) * 10000));

                this.gameInfo.AddGameInfo(pc);
            }
            return hitRate;
        }

        /// <summary>
        /// 无视防守情况下的命中率
        /// </summary>
        /// <param name="hitRateType"></param>
        /// <param name="shooter"></param>
        /// <param name="isAddGameInfo"></param>
        /// <returns></returns>
        private double GetHitRateIgnoreDef(int hitRateType, Player shooter)
        {
            ZDB_Row_Data rowData = this.GetShotPercentage(hitRateType);

            //%_FieldGoal=%_Shooter( 出手球员命中率基础值)×SRR( 命中率随出手距离递减值)×%_Defender(防守球员影响命中率值)
            double baseRate = this.GetBaseHitRate(shooter, rowData);//出手球员命中率基础值
            double srr = this.GetShotRangeReduce(shooter, rowData);//命中率随出手距离递减值
            double defRate = 1.0f;//防守球员影响命中率值
            double hitRate = baseRate * srr * defRate;
            return hitRate;
        }

        /// <summary>
        /// 获取影响命中率的防守队员列表
        /// </summary>
        /// <param name="shooter"></param>
        /// <returns></returns>
        private List<Player> GetHitRateDefPlayer(Player shooter, ZDB_Row_Data shotPercentage)
        {
            int range = this.GetDefPlayerRange(shooter, shotPercentage);

            return this.GetDefPlayerDisInRange(shooter, (int)range);
        }

        /// <summary>
        /// 防守球员有效距离
        /// </summary>
        /// <param name="shooter"></param>
        /// <param name="shotPercentage"></param>
        /// <returns></returns>
        public int GetDefPlayerRange(Player shooter, ZDB_Row_Data shotPercentage)
        {
            double range = shotPercentage.getCol((int)shot_percentageFields.DefenderRange).getValueInt() * 1.0 / 100;
            int isMultiplyToBasketDis = shotPercentage.getCol((int)shot_percentageFields.RangeReflectByDistance).getValueInt();
            if (isMultiplyToBasketDis == 1)
            {
                //乘以进攻球员到篮筐距离
                //double disToBasket = shooter.Pos.DistanceActualLength(shooter.OwnerTeam.AttackBasket);
                double disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, shooter.OwnerTeam.AttackField, shooter);
                range = range * disToBasket;
            }
            return (int)range;
        }

        private List<Player> GetDefPlayerDisInRange(Player atkPlayer, int range)
        {
            List<Player> lst = new List<Player>();
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player def = this.gameInfo.DefTeam.Players[i];
                //在防守cd的人，不用计算
                if (def.DefShotCD > this.gameInfo.Frame)
                {
                    continue;
                }

                //double dis = def.Pos.DistanceActualLength(atkPlayer.Pos);
                double dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, def, atkPlayer);
                if (dis <= range)
                {
                    lst.Add(def);
                }
            }
            return lst;
        }

        /// <summary>
        /// 出手球员命中率基础值
        /// </summary>
        /// <param name="shooter"></param>
        /// <param name="shotPercentage"></param>
        /// <returns></returns>
        private double GetBaseHitRate(Player shooter, ZDB_Row_Data shotPercentage)
        {
            int baseHitRate = shotPercentage.getCol((int)shot_percentageFields.FGPercentageBasic).getValueInt();
            if (baseHitRate == 0)
            {
                return 0;
            }
            return shooter.GetBaseHitRate(shotPercentage.getCol((int)shot_percentageFields.Id).getValueInt());
        }

        /// <summary>
        /// 命中率随出手距离递减值
        /// </summary>
        /// <param name="shooter"></param>
        /// <param name="shotPercentage"></param>
        /// <returns></returns>
        private double GetShotRangeReduce(Player shooter, ZDB_Row_Data shotPercentage)
        {
            int shotRangeReduceIndex = shotPercentage.getCol((int)shot_percentageFields.ShotRangeReduction).getValueInt();
            if (shotRangeReduceIndex == -1)
            {
                return 1.0;
            }
            int start = shotPercentage.getCol((int)shot_percentageFields.SRRInitial).getValueInt();
            int end =  shotPercentage.getCol((int)shot_percentageFields.SRRTerminal).getValueInt();
            int step =  shotPercentage.getCol((int)shot_percentageFields.SRRLength).getValueInt();
            //double 
            double disToBasket = 0;
            if (this.gameInfo != null)
            {
                disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, shooter.OwnerTeam.AttackField, shooter);
            }
            else
            {
                disToBasket = shooter.Pos.DistanceActualLength(shooter.OwnerTeam.AttackBasket);
            }
            if (disToBasket > end)
            {
                disToBasket = end;
            }
            else if (disToBasket < start)
            {
                disToBasket = start;
            }
            int index = (int)Math.Floor((disToBasket - start) / step) + 1;

            ZDBTable srrTable = this.GetTableByIndex(shotRangeReduceIndex);
            ZDB_Row_Data rowData = srrTable.getDataByID(index);
            double srr = rowData.getCol((int)range_jumpshot2Fields.Percentage).getValueInt() * 1.0f / 1000000;//同构表结构
            return srr;
        }

        /// <summary>
        /// 防守影响值
        /// </summary>
        /// <param name="shooter"></param>
        /// <param name="defPlayers"></param>
        /// <param name="shotPercentage"></param>
        /// <returns></returns>
        private double GetDefenderValue(Player shooter, List<Player> defPlayers, ZDB_Row_Data shotPercentage)
        {
            List<double> defValue = new List<double>();
            for (int i = 0; i < defPlayers.Count; i++)
            {
                Player defPlayer = defPlayers[i];
                //先分别计算 %_(D_n )×〖DRR〗_n
                double defBase = this.GetBaseDef(defPlayer, shotPercentage);
                double drr = this.GetDefReduceRange(shooter, defPlayer, shotPercentage);
                double def = 1 - (1 - defBase) * drr;
                defValue.Add(def);
            }
            double value = 1d;
            //升序排列
            if (defValue.Count > 1)
            {
                defValue.Sort();
            }
            for (int i = 0; i < defValue.Count; i++)
            {
                //%_Defender=∏_(n=1)^5▒(%_(D_n )×〖DRR〗_n )^(C_n ) 
                double c = shotPercentage.getCol( (int)shot_percentageFields.ConstDefender1 + i).getValueInt() * 1.0f / 1000000;
                value = value * Math.Pow(defValue[i], c);
            }
            return (double)value;
        }

        /// <summary>
        /// 基础防守值
        /// </summary>
        /// <param name="defPlayer"></param>
        /// <param name="shotPercentage"></param>
        /// <returns></returns>
        private double GetBaseDef(Player defPlayer, ZDB_Row_Data shotPercentage)
        {
            int defBasicIndex = shotPercentage.getCol((int)shot_percentageFields.FGPercentageReductionBasic).getValueInt();
            if (defBasicIndex == 0)
            {
                return 0;
            }
            double baseDef = defPlayer.GetBaseContest(shotPercentage.getCol((int)shot_percentageFields.Id).getValueInt());
            if (defPlayer.DefShotPercentFrame >= this.gameInfo.Frame)
            {
                double baseDefBuf = shotPercentage.getCol((int)shot_percentageFields.DefenceBuffJ).getValueInt() * 1.0f / 10000;
                baseDef = baseDef * baseDefBuf;
            }
            return baseDef;
        }

        /// <summary>
        /// 防守距离衰减值
        /// </summary>
        /// <param name="shooter"></param>
        /// <param name="defPlayer"></param>
        /// <param name="shotPercentage"></param>
        /// <returns></returns>
        private double GetDefReduceRange(Player shooter, Player defPlayer, ZDB_Row_Data shotPercentage)
        {
            int defRangeReduceIndex = shotPercentage.getCol((int)shot_percentageFields.DefenderRangeReduction).getValueInt();
            if (defRangeReduceIndex == -1)
            {
                return 1.0f;
            }
            int start = shotPercentage.getCol((int)shot_percentageFields.DRRInitial).getValueInt();
            int end = shotPercentage.getCol((int)shot_percentageFields.DRRTerminal).getValueInt();
            int step = shotPercentage.getCol((int)shot_percentageFields.DRRLength).getValueInt();
            double dis = 0;
            if (this.gameInfo != null)
            {
                dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, shooter, defPlayer);
            }
            else
            {
                dis = shooter.Pos.DistanceActualLength(defPlayer.Pos);
            }
            if (dis > end)
            {
                dis = end;
            }
            int index = (int)Math.Floor((dis - start) / step) + 1;

            ZDBTable drrTable = this.GetTableByIndex(defRangeReduceIndex);
            ZDB_Row_Data rowData = drrTable.getDataByID(index);
            double drr = rowData.getCol((int)reduction_shotcontestFields.Percentage).getValueInt() * 1.0f / 1000000;//表结构相同
            return drr;
        }

        /// <summary>
        /// 是否打手
        /// </summary>
        /// <param name="foulType"></param>
        /// <param name="shooter"></param>
        /// <param name="defPlayers"></param>
        /// <param name="fouler"></param>
        /// <returns></returns>
        private bool IsShootFoul(int foulType, Player shooter, List<Player> defPlayers, ref Player fouler)
        {
            if(!Enum.IsDefined(typeof(EFoulType), foulType))
            {
                return false;
            }
            EFoulType type = (EFoulType)foulType;
            for (int i = 0; i < defPlayers.Count; i++)
            {
                Player defPlayer = defPlayers[i];
                if (this.tacFoul.IsFoul(type, shooter, defPlayer))
                {
                    fouler = defPlayer;
                    break;
                }
            }
            if (fouler != null)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 投篮出手成功，球的事件
        /// </summary>
        /// <param name="shooter"></param>
        protected void SetShotBallTask(int shotType,Player shooter, ZDB_Row_Data baseData, int points, bool isGoal, bool isAssist = false, Player assPlayer = null)
        {
            int maxSpeed = baseData.getCol((int)shot_baseFields.BallSpeedMax).getValueInt();
            int minSpeed = baseData.getCol((int)shot_baseFields.BallSpeedMin).getValueInt();
            int speed = this.gameInfo.RandomNext(minSpeed, maxSpeed);

            Position target = this.gameInfo.AttackTeam.AttackBasket;
            if (!isGoal)
            {
                //未命中，随机一个落点
                int radius = baseData.getCol((int)shot_baseFields.MissRadius).getValueInt();
                int missNumber = baseData.getCol((int)shot_baseFields.MissNumber).getValueInt();
                int step = 360 / missNumber;
                int random = this.gameInfo.RandomNext(1, missNumber);
                target = target.GetPosByAngleRadius(random * step, radius);
            }

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.BallShot;
            gt.StartPos = this.gameInfo.Ball.Pos;
            gt.TargetPos = target;
            gt.TargetPlayer = shooter;
            gt.Param2 = points;
            gt.Param1 = isAssist ? 1 : 0;//是否有助攻
            gt.Param4 = shotType;
            gt.SecondPlayer = assPlayer;
            gt.Success = isGoal;
            gt.FinishFrame = gt.CalcTimeBySpeed(speed);

            //不管进没进，球都不属于这个人了
            this.gameInfo.ClearBallOwner();

            this.gameInfo.Ball.SetCurrentTask(gt);
        }

        /// <summary>
        /// 判断是否有助攻
        /// </summary>
        /// <returns></returns>
        private bool IsAssist(Team attackTeam)
        {
            double param58 = ParameterManager.Instance.GetValue(ParameterEnum.AssistTime) * 1.0f / 1000;
            int frame = TimeFrameConverter.GetFrame(param58);
            if (frame + attackTeam.PassBallInfo.LastPassBallFrame >= this.gameInfo.GameFrame)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 内线得分期望
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public double GetExpectInsideShot(Player player)
        {
            return this.GetHitRate((int)EExpectionType.InsideShot, player);
        }

        /// <summary>
        /// 突破得分期望
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public double GetExpectCrossOver(Player player)
        {
            return this.GetHitRate((int)EExpectionType.CrossOver, player);
        }

        /// <summary>
        /// 2分得分期望
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public double GetExpectJumpShot2(Player player, bool isHaveDefPlayers = true)
        {
            return this.GetHitRate((int)EExpectionType.JumpShot2, player);
        }

        /// <summary>
        /// 无防守情况下2分得分期望
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public double GetExperctJumpShot2IgnoreDef(Player player)
        {
            return this.GetHitRateIgnoreDef((int)EExpectionType.JumpShot2, player);
        }

        /// <summary>
        /// 3分得分期望
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public double GetExpectJumpShot3(Player player)
        {
            return this.GetHitRate((int)EExpectionType.JumpShot3, player);
        }

        /// <summary>
        /// 3分得分期望，无视防守
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public double GetExpectJumpShot3IgnoreDef(Player player)
        {
            return this.GetHitRateIgnoreDef((int)EExpectionType.JumpShot3, player);
        }

        /// <summary>
        /// 投篮得分期望
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public double GetExpectJumpShot(Player player)
        {
            double shotExpect = 0f;
            double disToBasket = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, player.OwnerTeam.AttackField, player);
            if (player.OwnerTeam.AttackField.Is3P(player.Pos, disToBasket))
            {
                shotExpect = this.GetExpectJumpShot3(player);
            }
            else
            {
                shotExpect = this.GetExpectJumpShot2(player);
            }
            return shotExpect;
        }

        /// <summary>
        /// 得分期望
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public double GetExpect(Player player)
        {
            double crossOverExpect = this.GetExpectCrossOver(player);
            double shotExpect = this.GetExpectJumpShot(player);
            double insideExpect = this.GetExpectInsideShot(player);
            return this.GetMaxExpect(crossOverExpect, shotExpect, insideExpect);
        }

        /// <summary>
        /// 获取最大值
        /// </summary>
        /// <param name="crossOverExpect"></param>
        /// <param name="shotExpect"></param>
        /// <param name="insideExpect"></param>
        /// <returns></returns>
        public double GetMaxExpect(double crossOverExpect, double shotExpect, double insideExpect)
        {
            if (crossOverExpect > shotExpect)
            {
                return crossOverExpect > insideExpect ? crossOverExpect : insideExpect;
            }
            else
            {
                return shotExpect > insideExpect ? shotExpect : insideExpect;
            }
        }

        private ZDBTable GetTableByIndex(int tableIndex)
        {
            return ShotTableManager.Instance.GetShotTableByIndex(tableIndex);
        }
    }
}
