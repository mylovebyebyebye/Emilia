﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class TacLayup : TacBase
    {
        public TacLayup(GameInfo gameInfo, string source)
            :base(gameInfo ,source)
        {
  
        }

        public void Do(Player shooter)
        {
            //double disAtk = shooter.Pos.DistanceActualLength(shooter.OwnerTeam.AttackBasket);
            double disAtk = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, shooter.OwnerTeam.AttackField, shooter);
            if (disAtk <= ParameterManager.Instance.GetValue(ParameterEnum.LayupDistance))
            {
                GameEvent ge = new GameEvent(GameEventType.ShotNew);
                ge.Param1 = (int)ShotType.LayUp;
                ge.Param4 = shooter;
                this.gameInfo.AddGameEvent(ge);

                this.gameInfo.AddPersoanlBoxScore(shooter, BoxScoreType.Layups, 1);
            }
            else
            {
                //靠近篮筐再出手
                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.PlayerLayup;
                gt.StartPos = shooter.Pos;
                double moveDis = disAtk - ParameterManager.Instance.GetValue(ParameterEnum.LayupDistance);
                if (moveDis < ParameterManager.Instance.GetValue(ParameterEnum.PermissibleError))
                {
                    moveDis = ParameterManager.Instance.GetValue(ParameterEnum.PermissibleError);
                }

                Position pos = Formula.ClosestIntersection(this.gameInfo.AttackTeam.AttackBasket, Position.GetPix(disAtk - moveDis), shooter.Pos, this.gameInfo.AttackTeam.AttackBasket);
                if (pos != Position.Empty)
                {
                    gt.TargetPos = pos;
                }
                else
                {
                    gt.TargetPos = this.gameInfo.AttackTeam.AttackBasket;
                }

                //速度
                int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(shooter, this.gameInfo.RandomSpeed());
                gt.SpeedLevel = speedLevel;
                gt.FinishFrame = gt.CalcTimeBySpeed(shooter.GetSpeedByLevel(speedLevel));
                shooter.SetCurrentTask(gt);
                this.gameInfo.Ball.GetCurTask().TaskType = TaskType.BallOnThePlayer;
                this.gameInfo.Ball.GetCurTask().FinishFrame = int.MaxValue;
            }
        }
    }
}
