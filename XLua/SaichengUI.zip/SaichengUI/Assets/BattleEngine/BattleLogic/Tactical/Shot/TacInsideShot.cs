﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class TacInsideShot : TacBase
    {
        public TacInsideShot(GameInfo gameInfo, string source)
            : base(gameInfo,source)
        { }

 

        private bool IsBlockInsideShot(Player atkPlayer, Player defPlayer)
        {
            double blockPro = defPlayer.GetAttribute(PlayerAttribute.Block) * ParameterManager.Instance.GetValue(ParameterEnum.BlockShotCOE) * 1.0f /
                             (atkPlayer.GetAttribute(PlayerAttribute.InsideShot) + ParameterManager.Instance.GetValue(ParameterEnum.InsideShotBlockCOE)) / 100;
            blockPro = blockPro * 10000;
            if (blockPro >= this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }



        private bool IsInsideShotFoul(Player atkPlayer, Player defPlayer)
        {
            double foulPro = (defPlayer.DefendFoul + atkPlayer.GetAttribute(PlayerAttribute.InsideShot)) / ParameterManager.Instance.GetValue(ParameterEnum.InsideShotFoulCOE);
            foulPro = foulPro * 10000;
            if (foulPro >= this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }


        /// <summary>
        /// 获取防守队员
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <returns></returns>
        private List<Player> GetDefPlayers(Player atkPlayer)
        {
            List<Player> lst = new List<Player>();
            double maxDis = ParameterManager.Instance.GetValue(ParameterEnum.InsideAttackDefDis) * 1.0f;
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player defPlayer = this.gameInfo.DefTeam.Players[i];
                double disToPlayer = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, atkPlayer, defPlayer);
                if (disToPlayer <= maxDis)
                {
                    //范围内的才是有效防守球员
                    lst.Add(defPlayer);
                }

            }
            return lst;
        }
    }
}
