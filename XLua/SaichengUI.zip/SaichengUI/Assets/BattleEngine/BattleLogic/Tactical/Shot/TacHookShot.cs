﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class TacHookShot : TacBase
    {
        public TacHookShot(GameInfo gameInfo, string source) 
            : base(gameInfo,source)
        {
        }

        public bool IsHook(Player atkPlayer)
        {
            double minDis = ParameterManager.Instance.GetValue(ParameterEnum.HookMinDis) * 1.0f;
            double maxDis = ParameterManager.Instance.GetValue(ParameterEnum.HookMaxDis) * 1.0f;

            double disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, atkPlayer.OwnerTeam.AttackField, atkPlayer);
            //double disToBasket = atkPlayer.Pos.DistanceActualLength(basketPos);
            if (disToBasket >= minDis && disToBasket <= maxDis)
            {
                //在这个距离才可能发生勾手投篮
                double hookPro = atkPlayer.GetAttribute(PlayerAttribute.Hook) / 100 * 10000;
                if (hookPro >= this.gameInfo.RandomNext())
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 获取防守队员
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <returns></returns>
        private List<Player> GetDefPlayers(Player atkPlayer)
        {
            List<Player> lst = new List<Player>();
            double maxDis = ParameterManager.Instance.GetValue(ParameterEnum.InsideAttackDefDis) * 1.0f;

            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player defPlayer = this.gameInfo.DefTeam.Players[i];
                double disToPlayer = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, atkPlayer, defPlayer);
                if (disToPlayer <= maxDis)
                {
                    //范围内的才是有效防守球员
                    lst.Add(defPlayer);
                }
            }
            return lst;
        }

        private bool IsBlockHook(Player atkPlayer, Player defPlayer)
        {
            double blockPro = defPlayer.GetAttribute(PlayerAttribute.Block) * ParameterManager.Instance.GetValue(ParameterEnum.BlockShotCOE) * 1.0f / 
                             ( atkPlayer.GetAttribute(PlayerAttribute.Hook) + ParameterManager.Instance.GetValue(ParameterEnum.HookShotBlockCOE)) / 100;
            blockPro = blockPro * 10000;
            if( blockPro >= this.gameInfo.RandomNext())
            {
                return true; 
            }
            return false;
        }

        private bool IsHookFoul(Player atkPlayer, Player defPlayer)
        {
            double foulPro = (defPlayer.DefendFoul + atkPlayer.GetAttribute(PlayerAttribute.Hook)) / ParameterManager.Instance.GetValue(ParameterEnum.HookShotBlockCOE);
            foulPro = foulPro * 10000;
            if (foulPro >= this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }


    }
}
