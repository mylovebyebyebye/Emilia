﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class TacFadeAwayShot : TacBase
    {

        public TacFadeAwayShot(GameInfo gameInfo, string source)
            : base(gameInfo,source)
        {
        }

        public bool IsFadeAwayShot(Player atkPlayer)
        {
            double minDis = ParameterManager.Instance.GetValue(ParameterEnum.FadeAwayDis) * 1.0f;
            double maxDis = ParameterManager.Instance.GetValue(ParameterEnum.HookMaxDis) * 1.0f;

            double disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, atkPlayer.OwnerTeam.AttackField, atkPlayer);
            //double disToBasket = atkPlayer.Pos.DistanceActualLength(basketPos);
            if (disToBasket >= minDis && disToBasket <= maxDis)
            {
                //在这个距离才可能发生后仰
                double fadeAwayPro = atkPlayer.GetAttribute(PlayerAttribute.FadeAway) / 100 * 10000;
                if (fadeAwayPro >= this.gameInfo.RandomNext())
                {
                    if (!this.IsAnyBodyBehindMe(atkPlayer))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// 判断是否有人在身后一定角度
        /// 如果有人的话，就不能后仰了
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        private bool IsAnyBodyBehindMe(Player shooter)
        {
            double radius = ParameterManager.Instance.GetValue(ParameterEnum.FadeAwayBehindRadius) * 1.0f;
            double angle = ParameterManager.Instance.GetValue(ParameterEnum.FadeAwayBehindAngle) * 1.0f;

            Vector2D vToBasket = new Vector2D(shooter.OwnerTeam.AttackBasket, shooter.Pos);
            double angleToBasket = vToBasket.GetSlopeAngle() + 360;//为了不跨越0
            double minAngle = angleToBasket - angle;
            double maxAngle = angleToBasket + angle;

            for (int i = 0; i < GameInfo.TeamCount; i++)
            {
                Team team = this.gameInfo.Teams[i];
                for (int j = 0; j < team.PlayerCount; j++)
                {
                    Player player = team.Players[j];
                    if (!player.IsSamePlayer(shooter))
                    {
                        double dis = shooter.Pos.DistanceActualLength(player.Pos);
                        if (dis <= radius)
                        {
                            //距离在xx以内再判断角度
                            Vector2D v = new Vector2D(shooter.OwnerTeam.AttackBasket, player.Pos);
                            double a = v.GetSlopeAngle() + 360;
                            if (a >= minAngle && a <= maxAngle)
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }

       
        public void StartFadeAway(Player atkPlayer)
        {
            //起跳清三秒
            atkPlayer.ClearAttack3S();

            //设置任务，记录起始点
            this.SetGameTask(atkPlayer, atkPlayer.Pos);

            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player defPlayer = this.gameInfo.DefTeam.Players[i];
                if (this.IsToBlock(atkPlayer, defPlayer))
                {
                    //去封盖的安排任务
                    this.SetGameTask(defPlayer, atkPlayer.Pos);
                    //增加延迟
                    defPlayer.GetCurTask().DelayStart = TimeFrameConverter.GetFrame(ParameterManager.Instance.GetValue(ParameterEnum.FadeAwayReactionTime) * 1.0f / 1000);
                }
            }
        }


        private void SetGameTask(Player player, Position target)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerBeginFadeAway;
            gt.DelayStart = 0;
            gt.FinishFrame = 1;
            gt.RecordPos = target;

            player.SetCurrentTask(gt);
        }

        private bool IsToBlock(Player atkPlayer, Player defPlayer)
        {   
            //判断是否去扑投篮
            double maxDis = ParameterManager.Instance.GetValue(ParameterEnum.FadeAwayDefArea) * 1.0f;
            //double disToShooter = defPlayer.Pos.DistanceActualLength(atkPlayer.Pos);
            double disToShooter = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, atkPlayer, defPlayer);
            if (disToShooter <= maxDis)
            {
                //离篮筐近，或者离扣篮人近
                int quarter = this.gameInfo.Quarter;
                if (quarter > 4)
                {
                    quarter = 4;
                }
                double toBlockCOE = ParameterManager.Instance.GetValue(ParameterEnum.FadeAwayDefCOE) * 1.0f;
                double toBlockRate = 0;
                if (defPlayer.Foul < quarter + 1)
                {
                    toBlockRate = Convert.ToSingle(defPlayer.GetAttribute(PlayerAttribute.Block) / (disToShooter + toBlockCOE));
                }
                else if (defPlayer.Foul == quarter + 1)
                {
                    toBlockRate = Convert.ToSingle(defPlayer.GetAttribute(PlayerAttribute.Block) / (disToShooter + toBlockCOE) - defPlayer.Foul * 1.0f / 10);
                }
                else
                {
                    toBlockRate = Convert.ToSingle(defPlayer.GetAttribute(PlayerAttribute.Block) / (disToShooter + toBlockCOE) - defPlayer.Foul * 1.0f / 5);
                }
                toBlockRate = toBlockRate * 10000;
                if (toBlockRate > this.gameInfo.RandomNext())
                {
                    return true;
                }
            }
            return false;
        }

    }
}
