﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class TacAttackBasket : TacBase
    {
        public TacAttackBasket(GameInfo gameInfo, string source)
            :base(gameInfo,source)
        {
        }

        public void Do(Player player)
        {
            GameTask gt = this.GetAttackBasketTask(player, player.Pos);
            player.SetCurrentTask(gt);

            GameTask gtBall = new GameTask(this.name);
            gtBall.TaskType = TaskType.BallOnThePlayer;
            gtBall.TargetPlayer = player;
            gtBall.FinishFrame = int.MaxValue;
            gameInfo.Ball.SetCurrentTask(gtBall);
        }

        public GameTask GetAttackBasketTask(Player player, Position startPos)
        {
            GameTask gt = new GameTask(this.name);
            //前场得分预期最高，冲击篮筐
            gt.TaskType = TaskType.PlayerDriveToTheBasket;
            gt.TargetPos = gameInfo.AttackTeam.AttackBasket;
            gt.StartPos = startPos;
            double seconds = ParameterManager.Instance.GetValue(ParameterEnum.CrossOverReactionTime) * 1.0f / 1000;
            //这个时候发突破事件是否成功
            //加入了速度计算
            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(player, this.gameInfo.RandomSpeed());
            gt.FinishFrame = gt.CalcRealTargetByTimeSpeed(seconds, player.GetSpeedInPixelByLevel(speedLevel));
            gt.SpeedLevel = speedLevel;

            return gt;
        }
    }
}
