﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class TacDriveToAtkCourt : TacBase
    {

        public TacDriveToAtkCourt(GameInfo gameInfo, string source):
            base(gameInfo,source)
        {
        }

        public void Do(Player player)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = player.Pos;
            Position pos = Position.Empty;
            pos = gameInfo.AttackTeam.AttackField.GetBallHanlderPreset(player.Pos, gameInfo.RandomNext());
            //if (player.LastChoice != null && 
            //    player.LastChoice.TargetPos != Position.Empty && 
            //    player.LastChoice.TaskType == TaskType.PlayerDriveToAtkCourt)
            //{
            //    pos = player.LastChoice.TargetPos;
            //}
            //else
            //{
            //    pos = gameInfo.AttackTeam.AttackField.GetBallHanlderPreset(player.Pos ,gameInfo.RandomNext());
            //}
            gt.TargetPos = pos;
            int speedLevel = SpeedManager.Instance.GetSpeedNormal(player, this.gameInfo.RandomSpeed());
            gt.SpeedLevel = speedLevel;
            gt.FinishFrame = gt.CalcTimeBySpeed(player.GetSpeedByLevel(speedLevel));
            player.SetCurrentTask(gt);

            //todo 过半场现在没考虑有人来防
            //gt.FinishFrame = gt.CalcRealTargetByTimeSpeed(0.2f, this.player.MaxSpeedInPix);
        }

        public double GetPro(Player player)
        {
            //过半场概率
            double d = player.GetAttribute(PlayerAttribute.Handing) / player.OwnerTeam.MaxHanlder.GetAttribute(PlayerAttribute.Handing) -
                        ParameterManager.Instance.GetValue(ParameterEnum.DriveToAttackCourtCOE) * 1.0f / 100;
            if (d < 0)
            {
                d = 0;
            }
            return d;
        }

        public bool IsNeedDriveToAtkCourt(Player player)
        {
            if (!player.OwnerTeam.AttackField.IsOnMyEffectiveArea(player.Pos))
            {
                double myPro = this.GetPro(player);
                double sumPro = myPro;
                for (int i = 0; i < player.OwnerTeam.PlayerCount; i++)
                {
                    Player other = player.OwnerTeam.Players[i];
                    if (!other.IsSamePlayer(player))
                    {
                        double pro = this.GetPro(other);
                        sumPro += pro;
                    }
                }
                int realPro = (int)(myPro / sumPro * 10000);
                if (realPro > this.gameInfo.RandomNext())
                {
                    return true;
                }
            }
            return false;
        }
    }
}
