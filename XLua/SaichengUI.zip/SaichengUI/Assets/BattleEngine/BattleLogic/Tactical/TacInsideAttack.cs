﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class TacInsideAttack : TacBase
    {
        private TacCostStamina tacCostStamina;
        private TacSteal tacSteal;
        private TacStandby tacStandby;
        private TacFoul tacFoul;
        public TacInsideAttack(GameInfo gameInfo, string source)
            :base(gameInfo, source)
        {
            this.tacCostStamina = new TacCostStamina(this.gameInfo, source);
            this.tacSteal = new TacSteal(this.gameInfo, source);
            this.tacStandby = new TacStandby(this.gameInfo, source);
            this.tacFoul = new TacFoul(this.gameInfo, source);
        }

        public double Do(Player player)
        {
            Player defPlayer = player.GetMyPosDefPlayer();

            //开始背打清掉三秒
            player.ClearAttack3S();

            //计算协防与接应
            this.CalcHelpDefAndJieYing(player, defPlayer);

            //计算背打时间
            double randomTime = 0;
            bool isMoveForward = this.IsMoveForward(player, defPlayer);
            if (isMoveForward)
            {
                //能打动，两人一起往里推
                randomTime = this.MoveForwardTogether(player, defPlayer);
            }
            else
            {
                //打不动，背打人动，防守人不动
                randomTime = this.MoveForwardThenStandby(player, defPlayer);
            }
            //扣体力
            this.tacCostStamina.Cost(EStaminaCost.InsideAttack, player, (int)(randomTime * 1000));
            this.tacCostStamina.Cost(EStaminaCost.InsideAttack, defPlayer, (int)(randomTime * 1000));

            int delayStartFrame = TimeFrameConverter.GetFrame(randomTime) + this.gameInfo.Frame - 1;
            if (this.tacSteal.IsSteal(EStealSource.InsideAttack, player, defPlayer))
            {
                this.gameInfo.AddPersoanlBoxScore(defPlayer, BoxScoreType.StealInsideAttack, 1);

                //抢断
                GameEvent ge = new GameEvent(GameEventType.Steal);
                ge.Param1 = (int)EStealSource.InsideAttack;
                ge.Param4 = player;
                ge.Param5 = defPlayer;
                ge.StartFrame = delayStartFrame;
                this.gameInfo.AddGameEvent(ge);
            }
            else if (this.tacFoul.IsFoul(EFoulType.InsideAttackDefFoul, player, defPlayer))
            {
                this.gameInfo.AddPersoanlBoxScore(defPlayer, BoxScoreType.FoulOnInsideAttack, 1);

                GameEvent ge = new GameEvent(GameEventType.Foul);
                ge.Param1 = (int)FoulType.Normal;
                ge.Param2 = 2;
                ge.Param4 = player;
                ge.Param5 = defPlayer;
                ge.StartFrame = delayStartFrame;

                this.gameInfo.AddGameEvent(ge);
            }
            else if (this.tacFoul.IsFoul(EFoulType.InsideAttackAtkFoul, player, defPlayer))
            {
                this.gameInfo.AddPersoanlBoxScore(player, BoxScoreType.AttackFoulOnInsideAttack, 1);

                GameEvent ge = new GameEvent(GameEventType.Foul);
                ge.Param1 = (int)FoulType.AttackFoul;
                ge.Param2 = 2;
                ge.Param4 = defPlayer;
                ge.Param5 = player;
                ge.StartFrame = delayStartFrame;

                this.gameInfo.AddGameEvent(ge);
            }
            else if (this.IsTurnRound(player, defPlayer))
            {
                //转身突破事件
                GameEvent ge = new GameEvent(GameEventType.TurnRound);
                ge.Param4 = defPlayer;
                ge.Param5 = player;
                ge.StartFrame = delayStartFrame;
                this.gameInfo.AddGameEvent(ge);
            }
            else
            {
                //什么都没发生，就内投了
                GameEvent ge = new GameEvent(GameEventType.InsideShot);
                ge.Param4 = defPlayer;
                ge.Param5 = player;
                ge.StartFrame = delayStartFrame;
                this.gameInfo.AddGameEvent(ge);
            }
            return randomTime;
        }

        /// <summary>
        /// 判断是否能背打动
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <param name="defPlayer"></param>
        /// <returns></returns>
        private bool IsMoveForward(Player atkPlayer, Player defPlayer)
        {
            if (atkPlayer.GetAttribute(PlayerAttribute.Strength) > defPlayer.GetAttribute(PlayerAttribute.Strength))
            {
                return true;
            }
            return false;
        }


        /// <summary>
        /// 没打动的时候
        /// 进攻人先移动一段距离然后待机
        /// 防守人直接待机
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <param name="defPlayer"></param>
        /// <returns></returns>
        private double MoveForwardThenStandby(Player atkPlayer, Player defPlayer)
        {
            double seconds1 = ParameterManager.Instance.GetValue(ParameterEnum.InsideAttackTime2) * 1.0f / 1000;//进攻人挤的时间
            double seconds2 = ParameterManager.Instance.GetValue(ParameterEnum.InsideAttackStandbyTime) * 1.0f / 1000;//进攻人挤完以后待机时间
            double dis = ParameterManager.Instance.GetValue(ParameterEnum.InsideAttackDis2) * 1.0f;//进攻人挤的距离

            //先设置进攻人第一段任务
            Position p1 = Formula.ClosestIntersection(atkPlayer.Pos, Position.GetPix(dis), atkPlayer.OwnerTeam.AttackBasket, atkPlayer.Pos);
            this.SetForwardTask(atkPlayer, atkPlayer.Pos, p1, seconds1);

            //进攻人第二段任务
            GameTask gtStandbyAtk = this.GetStandbyTask(atkPlayer, seconds2, p1);
            atkPlayer.NextTask.Add(gtStandbyAtk);

            //防守人待机
            GameTask gtStandbyDef = this.GetStandbyTask(defPlayer, seconds1 + seconds2, defPlayer.Pos);
            defPlayer.SetCurrentTask(gtStandbyDef);

            return seconds1 + seconds2;
        }

        /// <summary>
        /// 待机
        /// 这里的待机为了不进入单打战术，用的是原地移动
        /// </summary>
        /// <param name="player"></param>
        /// <param name="seconds"></param>
        /// <returns></returns>
        private GameTask GetStandbyTask(Player player,double seconds, Position target)
        {
            GameTask gt = new GameTask(this.name, ETaskSource.InsideAttack);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = target;
            gt.TargetPos = target;
            gt.FinishFrame = gt.CalcFrameByTime(seconds);

            return gt;
        }

        /// <summary>
        /// 能打动，两人一起往里走
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <param name="defPlayer"></param>
        private double MoveForwardTogether(Player atkPlayer, Player defPlayer)
        {
            double maxSeconds = this.GetInsideAtkTime(atkPlayer, defPlayer);
            //背打结束点
            Position target = this.GetTargetPos(atkPlayer, defPlayer);
            atkPlayer.GetCurTask().RecordPos = target;

            int minMiseconds = ParameterManager.Instance.GetValue(ParameterEnum.InsideAttackMinMiS);
            double randomTime = 0;
            if (maxSeconds > 0)
            {
                randomTime = this.gameInfo.RandomNext(minMiseconds, (int)(maxSeconds * 1000)) * 1.0f / 1000;

                //安排进攻和防守人任务
                this.SetForwardTask(atkPlayer, atkPlayer.Pos, target, randomTime);

                this.SetForwardTask(defPlayer, defPlayer.Pos, target, randomTime);
            }
            return randomTime;
        }

        private void SetForwardTask(Player player, Position startPos, Position targetPos, double seconds)
        {
            GameTask gt = new GameTask(this.name, ETaskSource.InsideAttack);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = startPos;
            gt.TargetPos = targetPos;
            gt.FinishFrame = gt.CalcFrameByTime(seconds);

            double speedInpixel = startPos.Distance(targetPos) / seconds;
            gt.SpeedLevel = player.GetSpeedLevelByRealSpeed((double)speedInpixel);

            player.SetCurrentTask(gt);
        }

        private double GetInsideAtkTime(Player atkPlayer, Player defPlayer)
        {
            double time = 0f;
            if (atkPlayer.GetAttribute(PlayerAttribute.Strength) > defPlayer.GetAttribute(PlayerAttribute.Strength))
            {
                time = ParameterManager.Instance.GetValue(ParameterEnum.AfterTakePosMoveDisCOE) * 1.0f /
                         ParameterManager.Instance.GetValue(ParameterEnum.AfterTakePosMoveSpeedCOE);
            }
            return time;
        }

        private Position GetTargetPos(Player atkPlayer, Player defPlayer)
        {
            Position p1 = Position.Empty;
            double maxRadius = (atkPlayer.GetAttribute(PlayerAttribute.Strength) - defPlayer.GetAttribute(PlayerAttribute.Strength)) * ParameterManager.Instance.GetValue(ParameterEnum.AfterTakePosMoveDisCOE);
            if (maxRadius > 0)
            {
                double playerArea = ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea) * 1.0f;
                //double disToBasket = atkPlayer.Pos.DistanceActualLength(atkPlayer.OwnerTeam.AttackBasket);
                double disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, atkPlayer.OwnerTeam.AttackField, atkPlayer);
                if ((maxRadius + playerArea) <= disToBasket)
                {
                    p1 = Formula.ClosestIntersection(atkPlayer.Pos, Position.GetPix(maxRadius), atkPlayer.OwnerTeam.AttackBasket, atkPlayer.Pos);
                }
                else
                {
                    if (disToBasket <= playerArea)
                    {
                        p1 = atkPlayer.Pos;
                    }
                    else
                    {
                        p1 = Formula.ClosestIntersection(atkPlayer.OwnerTeam.AttackBasket, Position.GetPix(playerArea), atkPlayer.Pos, atkPlayer.OwnerTeam.AttackBasket);
                    }
                }
            }
            return p1;
        }


        /// <summary>
        /// 转身突破
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <param name="defPlayer"></param>
        /// <returns></returns>
        private bool IsTurnRound(Player atkPlayer, Player defPlayer)
        {
            double param390 = ParameterManager.Instance.GetValueD(ParameterEnum.TurnRoundMinDis);
            //double disToBasket = atkPlayer.Pos.DistanceActualLength( atkPlayer.OwnerTeam.AttackBasket);
            double disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, atkPlayer.OwnerTeam.AttackField, atkPlayer);
            //距离篮筐小于一定值，无法转身突破
            if (disToBasket < param390)
            {
                return false;
            }

            double param233 = ParameterManager.Instance.GetValue(ParameterEnum.InsideAtkTurnRoundParam1) * 1.0f;
            double param236 = ParameterManager.Instance.GetValue(ParameterEnum.InsideAtkTurnRoundParam2) * 1.0f;
            double pro = Convert.ToSingle(atkPlayer.GetAttribute(PlayerAttribute.Driving) / param233 - param236 / disToBasket);
            pro = pro * 10000;
            if (pro > this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }


        public void StartInsideAttack(Player player)
        {
            player.ClearAttack3S();

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerInsideAttackPrepare;
            gt.FinishFrame = 1;
            gt.DelayStart = 0;

            player.SetCurrentTask(gt);

            Player defPlayer = player.GetMyPosDefPlayer();
            if (defPlayer != null)
            {
                GameTask gt1 = new GameTask(this.name);
                gt1.TaskType = TaskType.PlayerInsideAttackPrepare;
                gt1.FinishFrame = 0;
                gt1.DelayStart = 0;
                defPlayer.SetCurrentTask(gt1);
            }
        }

        private bool IsNeedToHelpDefence(Player atkPlayer, Player curDefPlayer, Player player, double dis)
        {
            if(player.IsSamePlayer(curDefPlayer))
            {
                return false;
            }
            double maxDis = ParameterManager.Instance.GetValueD(ParameterEnum.RunRadius);
            if (dis > maxDis)
            {
                return false;
            }
            ZDBTable tacDefTable = ZDataManager.Instance.GetTacticDefensiveTable();
            ZDB_Row_Data rowData = tacDefTable.getDataByID((int)ETacticDef.BaseDef);
            double tacAdd = rowData.getCol((int)tactic_defensiveFields.HelpDefenceProbability).getValueInt() * 1.0f / 100;


            double param234 = ParameterManager.Instance.GetValueD(ParameterEnum.InsideAtkHelpDefParam1);
            double param242 = ParameterManager.Instance.GetValueD(ParameterEnum.InsideAtkHelpDefParam2);
            double param243 = ParameterManager.Instance.GetValueD(ParameterEnum.InsideAtkHelpDefParam3);

            double pro = player.GetAttribute(PlayerAttribute.HelpDefence) * param234 / (param242 + dis) +
                         atkPlayer.GetAttribute(PlayerAttribute.InsideShot) / param243 + tacAdd;
            pro = pro * 10000;
            if (pro > this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }

        private void CalcHelpDefAndJieYing(Player atkPlayer, Player defPlayer)
        {
            ZDBTable tacDefTable = ZDataManager.Instance.GetTacticDefensiveTable();
            ZDB_Row_Data rowData = tacDefTable.getDataByID((int)ETacticDef.BaseDef);
            int maxCount = rowData.getCol((int)tactic_defensiveFields.HelpDefenceMax).getValueInt();

            int helpDefCount = 0;
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player helpDefPlayer = this.gameInfo.DefTeam.Players[i];
                if (helpDefCount >= maxCount)
                {
                    //到数量了
                    break;
                }
                double dis = this.gameInfo.DisManager.GetDistanceInPixelToOtherTeamPlayer(this.gameInfo.Frame, atkPlayer, helpDefPlayer);
                //double dis = helpDefPlayer.Pos.DistanceActualLength(atkPlayer.Pos);
                if (this.IsNeedToHelpDefence(atkPlayer, defPlayer, helpDefPlayer, dis))
                {
                    //安排协防
                    GameTask gt = new GameTask(this.name, ETaskSource.InsideAttack);
                    gt.TaskType = TaskType.PlayerInsideAttackHelpDefence;
                    gt.TargetPlayer = atkPlayer;
                    helpDefPlayer.SetCurrentTask(gt);

                    helpDefCount++;

                    //被防守人计算是否跑接应
                    Player jieYingPlayer = helpDefPlayer.GetMyPosAttacker();
                    if (this.IsNeedToJieYing(jieYingPlayer, dis))
                    {
                        this.SetJieYing(atkPlayer, jieYingPlayer);
                    }
                }
            }
        }

        private bool IsNeedToJieYing( Player jieYingPlayer, double dis)
        {
            if (jieYingPlayer == null)
            {
                return false;
            }
            double param432 = ParameterManager.Instance.GetValueD(ParameterEnum.InsideAtkJieYingParam1);
            double param433 = ParameterManager.Instance.GetValueD(ParameterEnum.InsideAtkJieYingParam2);

            double pro = jieYingPlayer.GetAttribute(PlayerAttribute.Offball) * param432 / (dis + param433);
            pro = pro * 10000;
            if (pro > this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }

        private void SetJieYing(Player atkPlayer, Player jieYingPlayer)
        {
            double delaySeconds = ParameterManager.Instance.GetValueD(ParameterEnum.InsideAtkJieYingReaction) / 1000;
            Position target = Position.Empty;
            if (this.IsMoveTo3P(atkPlayer, jieYingPlayer))
            {
                int min3p = ParameterManager.Instance.GetValue(ParameterEnum.InsideAtkJieYingMin3P);
                if (min3p < jieYingPlayer.GetAttribute(PlayerAttribute.JumpShot3))
                {
                    //有三分能力就向三分跑
                    target = atkPlayer.OwnerTeam.AttackField.CourtZoneManager.GetNearestCourtZonePos(PlayBookType.InsideAtkJieYing1, jieYingPlayer, this.gameInfo.RandomNext());
                }
            }
            else
            {
                target = atkPlayer.OwnerTeam.AttackField.CourtZoneManager.GetNearestCourtZonePos(PlayBookType.InsideAtkJieYing2, jieYingPlayer, this.gameInfo.RandomNext());
                if (target == jieYingPlayer.Pos)
                {
                    //已经在里面就不用跑了
                    target = Position.Empty;
                }
            }
            if (target == Position.Empty)
            {
                jieYingPlayer.ClearTask();
                this.tacStandby.Do(jieYingPlayer, TimeFrameConverter.GetFrame(delaySeconds));
            }
            else
            {
                this.tacStandby.Do(jieYingPlayer, TimeFrameConverter.GetFrame(delaySeconds));

                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.PlayerMoveTo;
                gt.StartPos = jieYingPlayer.Pos;
                gt.TargetPos = target;

                int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(jieYingPlayer, this.gameInfo.RandomSpeed());
                double speed = jieYingPlayer.GetSpeedByLevel(speedLevel);
                gt.FinishFrame = gt.CalcTimeBySpeed(speed);

                jieYingPlayer.NextTask.Add(gt);
            }
        }

        /// <summary>
        /// 向三分线跑位
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <param name="jieYingPlayer"></param>
        /// <returns></returns>
        private bool IsMoveTo3P(Player atkPlayer, Player jieYingPlayer)
        {
            Position basketPos = atkPlayer.OwnerTeam.AttackBasket;

            //double disAtk = basketPos.Distance(atkPlayer.Pos);
            double disAtk = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, atkPlayer.OwnerTeam.AttackField, atkPlayer);
            //double disJieYing = basketPos.Distance(jieYingPlayer.Pos);
            double disJieYing = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, atkPlayer.OwnerTeam.AttackField, jieYingPlayer);
            if (disAtk > disJieYing)
            {
                return false;
            }

            double angleAtk = 0;
            double angleJieYing = 0;

            if (atkPlayer.Pos != basketPos)
            {
                Vector2D v1 = new Vector2D(basketPos, atkPlayer.Pos);
                angleAtk = v1.GetSlopeAngle();
            }
            else
            {
                return false;
            }
            Vector2D v2 = new Vector2D(basketPos, jieYingPlayer.Pos);
            angleJieYing = v2.GetSlopeAngle();

            double angle = Math.Abs(angleAtk - angleJieYing);
            if (angle < ParameterManager.Instance.GetValue(ParameterEnum.InsideAtkJieYingAngle))
            {
                return true;
            }
            return false;
        }
    }
}
