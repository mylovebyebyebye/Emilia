﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic.Tactical
{
    public class TacJumpball : TacBase
    {
        public TacJumpball(GameInfo gameInfo, string source)
            :base(gameInfo, source)
        {

        }

        public void Do( Team team)
        {
            //position 左中右3个跳球位置，暂不处理
            //从左往右

            int playerCount = team.Players.Count;
            Field defField = this.gameInfo.GetAnotherTeam(team).AttackField;
            for (int i = 0; i < playerCount; i++)
            {
                Player player = team.Players[i];
                player.Pos = defField.GetMidJumpBallPosition(player.Role - 1);
                GameTask task = new GameTask(this.name);
                task.StartPos = player.Pos;
                task.TargetPos = player.Pos;
                task.TaskType = TaskType.PlayerLocation;
                task.DelayStart = 0;
                player.SetCurrentTask(task);
            }
        }
    }
}
