﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class TacAskBall : TacBase
    {
        private int passBallMinInterval;

        public TacAskBall(GameInfo gameInfo, string source)
            : base(gameInfo, source)
        {
            double minSeconds = ParameterManager.Instance.GetValueD(ParameterEnum.PassBallMinInterval) / 1000;

            this.passBallMinInterval = TimeFrameConverter.GetFrame(minSeconds);
        }

        /// <summary>
        /// 是否要球
        /// </summary>
        /// <param name="player"></param>
        /// <param name="handler"></param>
        /// <returns></returns>
        public bool IsAskBall(Player player, Player handler)
        {
            //
            //1.	当前本方有持球人角色
            //2.	无球人得分期望大于【持球人得分期望】
            //3.	无球人得分期望大于【自身期望】
            //4.    持球人达到最小传球时间间隔
            if (handler == null)
            {
                return false;
            }
            if(handler.LastPassBallFrame + this.passBallMinInterval > this.gameInfo.Frame)
            {
                return false;
            }

            double myExpect = this.gameInfo.GetPlayerExpectNormal( player);
            if (player.ScoringExpect > handler.ScoringExpect &&
                player.ScoringExpect > myExpect)
            {
                if (handler.PassBallPro > this.gameInfo.RandomNext())
                {
                    return true;
                }
            }
            return false;
        }

        public void Do(Player player)
        {
            Team attackTeam = this.gameInfo.Ball.OwnTeam;
            //GameTask gt = new GameTask(this.name);
            //gt.TaskType = TaskType.PlayerAskTheBall;
            //gt.FinishFrame = 1;
            //gt.StartPos = player.Pos;
            //gt.TargetPos = player.Pos;
            attackTeam.AskBallPlayer = player;

            //player.SetCurrentTask(gt);
        }
    }
}
