﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class TacRebound : TacBase
    {
        public TacRebound(GameInfo gameInfo,string source) 
            :base(gameInfo, source)
        {
        }

        public GameTask GetReboundTask(Player player)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerRebound;
            gt.StartPos = player.Pos;
            gt.DelayStart = this.gameInfo.Ball.GetCurTask().DelayStart;
            gt.FinishFrame = this.gameInfo.Ball.GetCurTask().FinishFrame;
            double seconds = TimeFrameConverter.ConvertFrameToSecond(gt.FinishFrame);

            //篮筐跟球员连线与合理冲撞区交点
            Field attackField = this.gameInfo.AttackTeam.AttackField;
            Position p1 = attackField.GetReboundPos(player.Pos);
            if (p1 != Position.Empty)
            {
                gt.TargetPos = p1;

                //三分线外加速移动，三分线内普速
                int speedLevel = 10;
                double disToBasket = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, attackField, player);
                if (attackField.Is3P(player.Pos, disToBasket))
                {
                    speedLevel = SpeedManager.Instance.GetSpeedAccelerate(player, this.gameInfo.RandomSpeed());
                }
                else
                {
                    speedLevel = SpeedManager.Instance.GetSpeedNormal(player, this.gameInfo.RandomSpeed());
                }
                double speedInPixel = player.GetSpeedInPixelByLevel(speedLevel);
                gt.FinishFrame = gt.CalcRealTargetBySpeedMaxSeconds(ref speedInPixel, seconds);
                gt.SpeedLevel = player.GetSpeedLevelByRealSpeed(speedInPixel);

            }
            else
            {
                gt.TaskType = TaskType.PlayerStandby;
            }
            return gt;
        }
    }
}
