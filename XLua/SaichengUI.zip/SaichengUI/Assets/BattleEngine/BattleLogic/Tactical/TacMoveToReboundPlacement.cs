﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class TacMoveToReboundPlacement : TacBase
    {
        private TacCostStamina tacCostStamina;
        private TacFastBreak tacFastBreak;
        public TacMoveToReboundPlacement(GameInfo gameInfo , string source) :
            base(gameInfo, source)
        {
            this.tacCostStamina = new TacCostStamina(this.gameInfo, source);
            this.tacFastBreak = new TacFastBreak(this.gameInfo, source);
        }

        public void Do(Player shooter)
        {
            //计算球权归属
            bool isHaveOwner = this.CalcBallOwner();
            if (!isHaveOwner)
            {
                this.gameInfo.Ball.GetCurTask().SecondPlayer = shooter;
                ////进入地板球
                //int speed = ParameterManager.Instance.GetValue(ParameterEnum.BallHoopReboundSpeed);
                //Vector2D v1 = new Vector2D(this.gameInfo.Ball.GetCurTask().StartPos, this.gameInfo.Ball.GetCurTask().TargetPos);
                //int angle = (int)v1.GetSlopeAngle();

                //this.tacBallOnTheFloor.StartBallOnTheFloor(EBallOnTheFloorSourceType.Rebound, shooter, 0, shooter, 0, v1.Start, angle, speed);
                //return;
            }

            //把所有人的任务置空，让他们重新选
            for (int i = 0; i < GameInfo.TeamCount; i++)
            {
                Team team = this.gameInfo.Teams[i];
                for (int j = 0; j < team.PlayerCount; j++)
                {
                    Player player = team.Players[j];
                    if (player.IsInTask( TaskType.PlayerFastBreak))//新添加在下快攻，不进入抢板流程
                    {
                        continue;
                    }
                    player.ClearTask();
                    player.GetCurTask().TaskType = TaskType.PlayerAfterBallHitHoop;
                }
            }
            if (isHaveOwner)
            {
                //拿到球的人直接安排任务
                this.SetGetReboundTask(this.gameInfo.Ball.GetCurTask().TargetPlayer, true);

                //扣得球人体力
                this.tacCostStamina.Cost(EStaminaCost.Rebound, this.gameInfo.Ball.GetCurTask().TargetPlayer);

                //指定这是进攻篮板还是防守篮板
                if (this.gameInfo.AttackTeam == this.gameInfo.Ball.GetCurTask().TargetPlayer.OwnerTeam)
                {
                    //进攻篮板
                    this.gameInfo.Ball.GetCurTask().Param2 = 2;
                }
                else
                {
                    //防守篮板
                    this.gameInfo.Ball.GetCurTask().Param2 = 1;
                }
            }
            else
            {
                //禅道 11797，没人抢就找离落点最近的一些人往那走
                Position target = this.gameInfo.Ball.GetCurTask().TargetPos;
                double seconds = TimeFrameConverter.ConvertFrameToSecond(this.gameInfo.Ball.GetCurTask().FinishFrame);
                List<Player> players = this.GetNearestPlayers(target);
                for (int i = 0; i < players.Count; i++)
                {
                    Player player = players[i];
                    //往落点加速移动
                    this.SetMoveToTargetTast(player, target, seconds);
                }
            }

            //这时没有进攻方
            this.gameInfo.LastAttackTeam = this.gameInfo.Ball.OwnTeam;
            this.gameInfo.ClearBallOwner();

            //增加是否判下快攻标记
            Team lastDefTeam = this.gameInfo.GetAnotherTeam(this.gameInfo.LastAttackTeam);
            this.tacFastBreak.CalcFastBreak(lastDefTeam, TaskType.PlayerAfterBallHitHoop);
        }


        public void SetGetReboundTask(Player player, bool isGetRebound)
        {
            double speed = this.GetSpeed(player, isGetRebound);
            int speedLevel = 10;
            double speedInPixel = 0f;

            speedInPixel = (double)(speed / Position.ActualLengthPerPoint);
            speedLevel = player.GetSpeedLevelByRealSpeed(speedInPixel);

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerAfterBallHitMoveToBall;
            gt.StartPos = player.Pos;
            gt.TargetPos = this.gameInfo.Ball.GetCurTask().TargetPos;
            gt.DelayStart = this.gameInfo.Ball.GetCurTask().DelayStart;
            gt.FinishFrame = gt.CalcTimeBySpeed(speed);
            gt.SpeedLevel = speedLevel;

            player.SetCurrentTask(gt);
        }

        private double GetSpeed(Player player, bool isGetRebound)
        {
            Team attackTeam = this.gameInfo.AttackTeam;
            if (attackTeam == null)
            {
                attackTeam = this.gameInfo.LastAttackTeam;
            }
            double speed = 0f;
            double ballSeconds = TimeFrameConverter.ConvertFrameToSecond(this.gameInfo.Ball.GetCurTask().FinishFrame);
            Position targetPos = this.gameInfo.Ball.GetCurTask().TargetPos;
            double disPlayerToPlacement = player.Pos.DistanceActualLength(targetPos);

            double param = ParameterManager.Instance.GetValue(ParameterEnum.DontGetReboundPlayerParam);
            if (isGetRebound)
            {
                speed = (double)(disPlayerToPlacement / ballSeconds);

            }
            else
            {
                speed = (double)((disPlayerToPlacement * param / 100) / ballSeconds);
            }
            return speed;
        }


        private bool CalcBallOwner()
        {
            //para143=落点范围检测半径
            //检测球落点范围 落点范围检测半径CM 范围内所有球员的信息
            //如果落点范围内没有任意一名球员，进入地板球
            //2016.12.6,检测半径修改
            double ballFlyTime = TimeFrameConverter.ConvertFrameToSecond( this.gameInfo.Ball.GetCurTask().FinishFrame);
            int defRadius = this.GetDefRebRadius((int)ETacticDef.BaseDef, ballFlyTime);
            int atkRadius = this.GetAtkRebRadius((int)ETacticOff.BaseOff, ballFlyTime);

            //计算所有人到落点的距离
            //先算攻方，再算守方
            Position target = this.gameInfo.Ball.GetCurTask().TargetPos.Clone();
            double minDis = double.MaxValue;
            int minDisIndex = int.MaxValue;
            List<int> lstIndex = new List<int>();
            List<double> lstDis = new List<double>();
            //先算攻方
            for (int i = 0; i < this.gameInfo.AttackTeam.PlayerCount; i++)
            {
                Player atkPlayer = this.gameInfo.AttackTeam.Players[i];
                this.CalcDistanceToPlacement(atkPlayer, target, atkRadius, lstDis, lstIndex, ref minDis, ref minDisIndex);
            }
            //再算守方
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player defPlayer = this.gameInfo.DefTeam.Players[i];
                this.CalcDistanceToPlacement(defPlayer, target, defRadius, lstDis, lstIndex, ref minDis, ref minDisIndex);
            }
            Player getReboundPlayer = null;
            if (lstIndex.Count > 0)
            {
                //落点内的人算概率
                List<int> lstProbality = new List<int>();
                int sum = 0;
                for(int i =0;i< lstIndex.Count;i++)
                {
                    int index = lstIndex[i];
                    Player player = this.GetPlayerByIndex(index);
                    int pro = this.CalcGetReboundProbality(player, lstDis[index]);
                    lstProbality.Add(pro);
                    sum += pro;
                }
                int random = this.gameInfo.RandomNext(1, sum);
                int getReboundIndex = ProbabilityCalc.GetPosition(lstProbality, random);
                getReboundPlayer = this.GetPlayerByIndex(lstIndex[getReboundIndex]);
            }
            else
            {
                //范围内没人，走地板球
                return false;
            }
            this.gameInfo.Ball.GetCurTask().TargetPlayer = getReboundPlayer;
            return true;
        }

        private int GetDefRebRadius(int type, double ballFlyTime)
        {
            ZDBTable tacDefTable = ZDataManager.Instance.GetTacticDefensiveTable();
            ZDB_Row_Data rowData = tacDefTable.getDataByID(type);
            int areaTestP1 = rowData.getCol((int)tactic_defensiveFields.AreaTestP1).getValueInt();
            int disDiv = rowData.getCol((int)tactic_defensiveFields.DistancePDivisor).getValueInt();

            int radius = areaTestP1 + (int)(ballFlyTime * disDiv);

            return radius;
        }

        private int GetAtkRebRadius(int type, double ballFlyTime)
        {
            ZDBTable tacOffTable = ZDataManager.Instance.GetTacticOffecnsiveTable();
            ZDB_Row_Data rowData = tacOffTable.getDataByID(type);
            int areaTestP1 = rowData.getCol((int)tactic_offensiveFields.AreaTestP1).getValueInt();
            int disDiv = rowData.getCol((int)tactic_offensiveFields.DistancePDivisor).getValueInt();

            int radius = areaTestP1 + (int)(ballFlyTime * disDiv);
            return radius;
        }

        private void CalcDistanceToPlacement(Player player, Position target, int Radius, List<double> lstDis, List<int> lstIndex, ref double minDis, ref int minDisIndex)
        {
            double dis = this.GetDisToTarget(player, target);
            lstDis.Add(dis);
            if (dis < Radius)
            {
                lstIndex.Add(lstDis.Count - 1);
            }
            if (dis < minDis)
            {
                minDis = dis;
                minDisIndex = lstDis.Count - 1;
            }
        }

        private double GetDisToTarget(Player player, Position target)
        {
            double dis;
            //处于硬直状态的人不参与篮板计算
            if (player.GetCurTask().TaskType > TaskType.TaskCanNotInterupt && player.GetCurTask().FinishFrame > 0)
            {
                dis = double.MaxValue;
            }
            else
            {
                dis = player.Pos.DistanceActualLength(target);
            }
            return dis;
        }

        private int CalcGetReboundProbality(Player player, double dis)
        {
            double param1 = ParameterManager.Instance.GetValue(ParameterEnum.ReboundParam1) * 1.0f;
            double param2 = ParameterManager.Instance.GetValue(ParameterEnum.ReboundParam2) * 1.0f;
            double roleAddition = ParameterManager.Instance.GetValue(ParameterEnum.RoleReboundAdditionPG + player.Role - 1) * 1.0f;
            double pro = 0;
            if (player.OwnerTeam == this.gameInfo.AttackTeam)
            {
                pro = player.GetAttribute(PlayerAttribute.Rebounding) * (roleAddition / 1000) * Math.Pow(param1 / 1000, dis / param2);
            }
            else
            {
                double param3 = ParameterManager.Instance.GetValueD(ParameterEnum.RebDefParam1);
                double param4 = ParameterManager.Instance.GetValueD(ParameterEnum.RebDefParam2);
                //2016.11.7修改，防守方篮板概率有加成
                pro = player.GetAttribute(PlayerAttribute.Rebounding) * (roleAddition / 1000) * Math.Pow(param1 / 1000, dis / param2) * param3 / param4;
            }
            return (int)Math.Floor(pro * 10000);
        }

        private Player GetPlayerByIndex(int index)
        {
            if (index < 5)
            {
                return this.gameInfo.AttackTeam.Players[index];
            }
            return this.gameInfo.DefTeam.Players[index - 5];
        }

        /// <summary>
        /// 离落点最近的一些人
        /// </summary>
        /// <returns></returns>
        private List<Player> GetNearestPlayers(Position target)
        {
            List<Player> players = new List<Player>();
            double minDis = double.MaxValue;
            int minDisIndex = int.MaxValue;
            List<int> lstIndex = new List<int>();
            List<double> lstDis = new List<double>();

            int maxDis = 100 * 100;//100米以内的人，太远不计算了

            int detecDis = ParameterManager.Instance.GetValue(ParameterEnum.ReboundStepDis);

            //先算攻方
            for (int i = 0; i < this.gameInfo.AttackTeam.PlayerCount; i++)
            {
                Player atkPlayer = this.gameInfo.AttackTeam.Players[i];
                this.CalcDistanceToPlacement(atkPlayer, target, maxDis, lstDis, lstIndex, ref minDis, ref minDisIndex);
            }
            //再算守方
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player defPlayer = this.gameInfo.DefTeam.Players[i];
                this.CalcDistanceToPlacement(defPlayer, target, maxDis, lstDis, lstIndex, ref minDis, ref minDisIndex);
            }
            if (lstIndex.Count > 0)
            {
                Player player = this.GetPlayerByIndex(lstIndex[0]);//最近的
                players.Add(player);

                //再看其他人离这个人有多远，在一定范围内也可以
                for (int i = 1; i < lstIndex.Count; i++)
                {
                    if (lstDis[i] - minDis < detecDis)
                    {
                        Player other = this.GetPlayerByIndex(lstIndex[i]);
                        players.Add(other);//比最近的远一点点的也可以
                    }
                }
            }

            return players;
        }

        /// <summary>
        /// 向落点加速移动
        /// </summary>
        /// <param name="player"></param>
        private void SetMoveToTargetTast(Player player, Position target, double seconds)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = player.Pos;
            gt.TargetPos = target;

            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(player, this.gameInfo.RandomSpeed());
            double speedInPixel = player.GetSpeedInPixelByLevel(speedLevel);
            gt.FinishFrame = gt.CalcRealTargetByTimeSpeed(seconds, speedInPixel);

            player.SetCurrentTask(gt);

        }
    }
}
