﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{


    public class TacSteal : TacBase
    {
        private List<int> lstInsideSteal = new List<int>();
        private List<int> lstPassChance = new List<int>();

        public TacSteal(GameInfo gameInfo, string source)
            : base(gameInfo, source)
        {
            this.Init();
        }

        private void Init()
        {
            ZDBTable stealSpeedTalbe = ZDataManager.Instance.GetStealSpeedTable();
            int count = stealSpeedTalbe.getRowCount();
            for(int i =0;i < count;i++)
            {
                ZDB_Row_Data rowData = stealSpeedTalbe.getDataByRow(i);
                lstInsideSteal.Add( rowData.getCol((int)steals_ball_speedFields.InsideChance).getValueInt());
                lstPassChance.Add( rowData.getCol((int)steals_ball_speedFields.PassChance).getValueInt());
            }
        }

        /// <summary>
        /// 是否触发抢断
        /// </summary>
        /// <param name="eSource"></param>
        /// <param name="atkPlayer"></param>
        /// <param name="defPlayer"></param>
        /// <returns></returns>
        public bool IsSteal(EStealSource eSource, Player atkPlayer, Player defPlayer)
        {
            if (defPlayer == null)
            {
                return false;
            }
            ZDBTable stealTable = ZDataManager.Instance.GetStealTable();
            ZDB_Row_Data rowData = stealTable.getDataByID((int)eSource);
            double defAttr = 0f;
            int defAttrIndex = rowData.getCol((int)stealFields.StealDeffence).getValueInt();
            if (defAttrIndex > 0)
            {
                defAttr = defPlayer.GetAttrByIndex(defAttrIndex);
            }
            double atkAttr = 0f;
            int atkAttrIndex = rowData.getCol((int)stealFields.StealAttack).getValueInt();
            if (atkAttrIndex > 0)
            {
                atkAttr = atkPlayer.GetAttrByIndex(atkAttrIndex);
            }
            double param1 = rowData.getCol((int)stealFields.StealValue1).getValueInt() * 1.0f;
            double param2 = rowData.getCol((int)stealFields.StealValue2).getValueInt() * 1.0f;
            double param3 = rowData.getCol((int)stealFields.StealValue3).getValueInt() * 1.0f;
            double defFoulCount = defPlayer.Foul * 1.0f;

            double pro = defAttr * param1 / (atkAttr + param2) / 100 - defFoulCount / param3;
            pro = pro * 10000;
            if (pro > this.gameInfo.RandomNext())
            {
                return true;
            }


            return false;
        }

        /// <summary>
        /// 是否直接得球
        /// </summary>
        /// <param name="eSource"></param>
        /// <param name="atkPlayer"></param>
        /// <param name="defPlayer"></param>
        /// <returns></returns>
        public bool IsGetBall(EStealSource eSource, Player atkPlayer, Player defPlayer)
        {
            ZDBTable stealTable = ZDataManager.Instance.GetStealTable();
            ZDB_Row_Data rowData = stealTable.getDataByID((int)eSource);
            double defAttr = 0f;
            int defAttrIndex = rowData.getCol((int)stealFields.StealStyleDeffence).getValueInt();
            if (defAttrIndex > 0)
            {
                defAttr = defPlayer.GetAttrByIndex(defAttrIndex);
            }
            double param1 = rowData.getCol((int)stealFields.StealStyleValue1).getValueInt() * 1.0f;
            double pro = defAttr / param1;
            pro = pro * 10000;
            if (pro > this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 防守者直接拿到球的过程
        /// </summary>
        /// <param name="eSource"></param>
        /// <param name="atkPlayer"></param>
        /// <param name="defPlayer"></param>
        public void SetGetBallTask(EStealSource eSource, Player atkPlayer, Player defPlayer)
        {
            //所有人当前任务清空
            this.gameInfo.ClearAllPlayerTask();

            ZDBTable stealTable = ZDataManager.Instance.GetStealTable();
            ZDB_Row_Data rowData = stealTable.getDataByID((int)eSource);
            //默认直接拿到
            int getBallFrame = 0;

            int defPlayerBehave = rowData.getCol((int)stealFields.StealGetBallDeffenceBehave).getValueInt();
            if (defPlayerBehave > 0)
            {
                //防守者需要移动一下才能拿球
                getBallFrame = this.SetPlayerGetBallBehave(defPlayerBehave, defPlayer, atkPlayer);
            }

            int atkPlayerBehave = rowData.getCol((int)stealFields.StealGetBallAttackBehave).getValueInt();
            if (atkPlayerBehave > 0)
            {
                //原进攻人动作
                this.SetPlayerGetBallBehave(atkPlayerBehave, atkPlayer, atkPlayer);
            }

            //清空球的所属人
            this.gameInfo.ClearBallOwner();
            //看需不需要等
            if (getBallFrame > 0)
            {
                this.gameInfo.Ball.ClearTask();

                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.BallLocation;
                gt.FinishFrame = getBallFrame - 1;
                gt.StartPos = this.gameInfo.Ball.Pos;
                gt.TargetPos = this.gameInfo.Ball.Pos;
                this.gameInfo.Ball.SetCurrentTask(gt);

                this.gameInfo.Ball.NextTask.Add(this.GetBallOnThePlayerTask(defPlayer));
            }
            else
            {
                this.gameInfo.Ball.SetCurrentTask(this.GetBallOnThePlayerTask(defPlayer));
            }
        }

        /// <summary>
        /// 直接得球目标点
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <param name="defPlayer"></param>
        /// <returns></returns>
        private Position GetBallTargetPos(Player atkPlayer)
        {
            double angle = 0;
            int random = this.gameInfo.RandomNext(1, 2);
            Position basketPos = atkPlayer.OwnerTeam.AttackBasket;
            if (basketPos == atkPlayer.Pos)
            {
                //跟篮筐重合
                if (random == 1)
                {
                    angle += 90;
                }
                else
                {
                    angle -= 90;
                }
            }
            else
            {
                Vector2D v = new Vector2D(atkPlayer.OwnerTeam.AttackBasket, atkPlayer.Pos);
                angle = v.GetSlopeAngle();
                if (random == 1)
                {
                    angle += 90;
                }
                else
                {
                    angle -= 90;
                }
            }
            int radius = ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea);

            Position p1 = atkPlayer.Pos.GetPosByAngleRadius((int)angle, radius);
            return p1;
        }

        private int SetPlayerGetBallBehave(int behaveId, Player player, Player atkPlayer)
        {
            ZDBTable stealBehaveTable = ZDataManager.Instance.GetStealBehaveTable();
            ZDB_Row_Data rowData = stealBehaveTable.getDataByID(behaveId);
            //1.移动，2.待机
            int stealBehave = rowData.getCol((int)steal_behave_typeFields.StealBehave).getValueInt();
            double behaveTime = rowData.getCol((int)steal_behave_typeFields.BehaveTime).getValueInt() * 1.0f / 1000;

            GameTask gt = new GameTask(this.name);
            if (stealBehave == 1)
            {
                int speedLevel = 0;
                gt.TaskType = TaskType.PlayerForceMoveTo;
                gt.StartPos = player.Pos;
                Position p1 = this.GetMoveTargetPos(rowData, player, atkPlayer, ref speedLevel);
                gt.TargetPos = p1;
                gt.SpeedLevel = speedLevel;
                gt.FinishFrame = gt.CalcFrameByTime(behaveTime);
            }
            else
            {
                gt.TaskType = TaskType.PlayerForceStandBy;
                gt.StartPos = player.Pos;
                gt.TargetPos = player.Pos;
                gt.FinishFrame = TimeFrameConverter.GetFrame(behaveTime);

            }
            player.SetCurrentTask(gt);
            return gt.FinishFrame;
        }

        /// <summary>
        /// 获取移动的目标点
        /// 同时返回速度等级
        /// </summary>
        /// <param name="rowData"></param>
        /// <param name="player"></param>
        /// <param name="atkPlayer"></param>
        /// <param name="speedLevel"></param>
        /// <returns></returns>
        private Position GetMoveTargetPos(ZDB_Row_Data rowData, Player player, Player atkPlayer, ref int speedLevel)
        {
            Position p1 = Position.Empty;
            int behaveTime = rowData.getCol((int)steal_behave_typeFields.BehaveTime).getValueInt();
            //0:读表；1.普通移动；2.加速移动
            int speedType = rowData.getCol((int)steal_behave_typeFields.BehaveSpeedType).getValueInt();
            int speed = rowData.getCol((int)steal_behave_typeFields.BehaveSpeed).getValueInt();
            //1.远离篮筐；2.靠近篮筐；3.目标点
            int direction = rowData.getCol((int)steal_behave_typeFields.BehaveDirection).getValueInt();

            double realSpeed = 0;
            if(speedType == 0)
            {
                realSpeed = speed;
                speedLevel = player.GetSpeedLevelByRealSpeed(Position.GetPix(realSpeed));
            }
            else if(speedType == 1)
            {
                speedLevel = SpeedManager.Instance.GetSpeedNormal(player, this.gameInfo.RandomSpeed());
                realSpeed = player.GetSpeedByLevel(speedLevel);
            }
            else
            {
                speedLevel = SpeedManager.Instance.GetSpeedAccelerate(player, this.gameInfo.RandomSpeed());
                realSpeed = player.GetSpeedByLevel(speedLevel);
            }
            double dis = realSpeed * behaveTime / 1000;
            if (direction == 3)
            {
                //3.目标点
                p1 = this.GetBallTargetPos(atkPlayer);
            }
            else if (direction == 1)
            {
                //1.远离篮筐
                p1 = Formula.ClosestIntersection(player.Pos, Position.GetPix(dis), atkPlayer.OwnerTeam.AttackBasket, player.Pos, true);
            }
            else
            {
                //接近篮筐
                p1 = Formula.ClosestIntersection(player.Pos, Position.GetPix(dis), atkPlayer.OwnerTeam.AttackBasket, player.Pos);
            }
            if (p1 == Position.Empty)
            {
                p1 = player.Pos;
            }
            return p1;
        }

        private GameTask GetBallOnThePlayerTask(Player player)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.BallOnThePlayer;
            gt.TargetPlayer = player;
            gt.FinishFrame = int.MaxValue;
            gt.DelayStart = 0;
            return gt;
        }

        /// <summary>
        /// 捅到球计算角度
        /// </summary>
        /// <param name="eSource"></param>
        /// <param name="atkPlayer"></param>
        /// <param name="defPlayer"></param>
        public int GetPokeBallAngle(EStealSource eSource, Player atkPlayer, Player defPlayer)
        {
            ZDBTable stealTable = ZDataManager.Instance.GetStealTable();
            ZDB_Row_Data rowData = stealTable.getDataByID((int)eSource);

            int deltaAngle = BlockManager.Instance.GetIndexRandomBlockAngle(this.gameInfo.RandomNext());
            int speedLevel = rowData.getCol((int)stealFields.StealPokeBallDeffenceSpeedLevel).getValueInt();
            //1:被抢断人正后方
            //2:抢断人斜前方
            //3:抢断人斜前方
            int angleType = rowData.getCol((int)stealFields.StealPokeBallAngle).getValueInt();
            int angle = 0;
            if (angleType == 1)
            {
                angle = this.GetAngleBehindAtkPlayer(atkPlayer);
            }
            else if (angleType == 2)
            {
                //todo 传球抢断
            }
            else if (angleType == 3)
            {
                //double disToBasketDef = defPlayer.Pos.Distance(atkPlayer.OwnerTeam.AttackBasket);
                double disToBasketDef = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, atkPlayer.OwnerTeam.AttackField, defPlayer);
                //double disToBasketAtk = atkPlayer.Pos.Distance(atkPlayer.OwnerTeam.AttackBasket);
                double disToBasketAtk = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, atkPlayer.OwnerTeam.AttackField, atkPlayer);
                //突破抢断
                if ( (defPlayer.GetCurTask().SpeedLevel < speedLevel && disToBasketDef < disToBasketAtk)  || 
                       atkPlayer.Pos == atkPlayer.OwnerTeam.AttackBasket)
                {
                    //速度为0 时的抢断
                    angle = this.GetAngleBehindAtkPlayer(atkPlayer);
                }
                else
                {
                    angle = this.GetAngleAtkDef(atkPlayer, atkPlayer.OwnerTeam.AttackBasket, defPlayer);
                }
            }
            return this.gameInfo.RandomNext(angle - deltaAngle, angle + deltaAngle);
        }

        /// <summary>
        /// 进攻人，防守人夹角
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <param name="atkTarget"></param>
        /// <param name="defPlayer"></param>
        /// <returns></returns>
        private int GetAngleAtkDef(Player atkPlayer, Position atkTarget, Player defPlayer)
        {
            int angle = 0;
            Vector2D v1 = new Vector2D(atkPlayer.Pos, atkTarget);
            double a1 = v1.GetSlopeAngle();

            Vector2D v2 = new Vector2D(defPlayer.GetCurTask().StartPos, defPlayer.GetCurTask().TargetPos);
            double a2 = v2.GetSlopeAngle();

            double a3 = 0;
            if (a1 - a2 < 180)
            {
                a3 = (a1 + a2) / 2;

            }
            else
            {
                a3 = 180 + (a1 + a2) / 2;
            }
            if (a1 < a3)
            {
                angle = this.gameInfo.RandomNext((int)a1, (int)a3);
            }
            else
            {
                angle = this.gameInfo.RandomNext((int)a3, (int)a1);
            }
            return angle;
        }

        /// <summary>
        /// 进攻人身后
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <returns></returns>
        private int GetAngleBehindAtkPlayer(Player atkPlayer)
        {
            int angle = 0;
            if (atkPlayer.Pos == atkPlayer.OwnerTeam.AttackBasket)
            {
                angle = this.GetRandomAngleByBasket(atkPlayer);
            }
            else
            {
                Vector2D v = new Vector2D(atkPlayer.OwnerTeam.AttackBasket, atkPlayer.Pos);
                angle = (int)v.GetSlopeAngle();
            }
            return angle;
        }

        /// <summary>
        /// 已篮筐与X夹角为基础，获取一个随机值
        /// </summary>
        /// <param name="aktPlayer"></param>
        /// <returns></returns>
        private int GetRandomAngleByBasket(Player atkPlayer)
        {
            Field field = atkPlayer.OwnerTeam.AttackField;
            int basketXAxis = field.GetXAxisAngle();
            return this.GetRandomByBaseAngle(basketXAxis, 90);
        }
         
        
        /// <summary>
        /// 根据基础角度和变化角度，随机一个值
        /// </summary>
        /// <param name="baseAngle"></param>
        /// <param name="delta"></param>
        /// <returns></returns>
        private int GetRandomByBaseAngle(int baseAngle, int delta)
        {
            return this.gameInfo.RandomNext(baseAngle - delta, baseAngle + delta);
        }

        /// <summary>
        /// 获取速度
        /// </summary>
        /// <param name="eSource"></param>
        /// <returns></returns>
        public int GetPokeBallSpeed(EStealSource eSource)
        {
            int speed = 0;
            ZDBTable stealTable = ZDataManager.Instance.GetStealTable();
            ZDB_Row_Data rowData = stealTable.getDataByID((int)eSource);

            ZDBTable stealSpeedTypeTable = ZDataManager.Instance.GetStealBallSpeedTypeTable();
            ZDB_Row_Data speedRowData = stealSpeedTypeTable.getDataByID(rowData.getCol((int)stealFields.StealPokeBallSpeed).getValueInt());

            //1:读数值; 2:读表
            int ballSpeedType = speedRowData.getCol((int)steal_ball_speed_typeFields.BallSpeedType).getValueInt();
            int zdbType = speedRowData.getCol((int)steal_ball_speed_typeFields.SpeedZdbType).getValueInt();
            int ballSpeed = speedRowData.getCol((int)steal_ball_speed_typeFields.BallSpeed).getValueInt();
            if (ballSpeedType == 1)
            {
                speed = ballSpeed;
            }
            else
            {
                int index = 0;
                if (zdbType == 2)
                {
                    index = ProbabilityCalc.GetPosition(this.lstInsideSteal, this.gameInfo.RandomNext());
                }
                else
                {
                    index = ProbabilityCalc.GetPosition(this.lstPassChance, this.gameInfo.RandomNext());
                }
                ZDBTable stealSpeedTalbe = ZDataManager.Instance.GetStealSpeedTable();
                ZDB_Row_Data speedRow = stealSpeedTalbe.getDataByRow(index);
                speed = speedRow.getCol(0).getValueInt();
            }
            return speed;
        }
    }
}
