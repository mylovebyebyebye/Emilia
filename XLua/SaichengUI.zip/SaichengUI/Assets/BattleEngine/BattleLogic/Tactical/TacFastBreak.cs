﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class TacFastBreak : TacBase
    {
        public TacFastBreak(GameInfo gameInfo, string source)
            : base(gameInfo, source)
        {

        }

        /// <summary>
        /// 最终干的事
        /// </summary>
        /// <param name="player"></param>
        public void Do(Player player)
        {
            Player firstPlayer = null;
            if (this.IsFirstOne(player,ref firstPlayer))
            {
                this.DoFirstOne(player);
            }
            else
            {
                this.DoOtherPlayer(player, firstPlayer);
            }
            this.DoDefFastBreak(player);
        }

        /// <summary>
        /// 防快下
        /// </summary>
        /// <param name="player"></param>
        private void DoDefFastBreak(Player player)
        {
            int defFastBreakDis = ParameterManager.Instance.GetValue(ParameterEnum.DefFastBreakDis);
            int defFastBreakCount = ParameterManager.Instance.GetValue(ParameterEnum.DefFaskBreakMaxCount);
            double defFaskBreakCOE = ParameterManager.Instance.GetValueD(ParameterEnum.DefFastBreakCOE);

            Team anOtherTeam = this.gameInfo.GetAnotherTeam(player.OwnerTeam);
            int count = this.GetDefFaskBreakCount(anOtherTeam);
            Position target = player.GetCurTask().TargetPos;
            for (int i = 0; i < anOtherTeam.Players.Count; i++)
            {
                if (count >= defFastBreakCount)
                {
                    //已经有足够多人防快下了
                    break;
                }
                Player defFastBreakPlayer = anOtherTeam.Players[i];
                if(defFastBreakPlayer.GetCurTask().TaskType == TaskType.PlayerMoveToDefFastBreak)
                {
                    //已经在防快下了
                    continue;
                }
                double dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, player, defFastBreakPlayer);
                if (dis < defFastBreakDis)
                {
                    double pro = defFastBreakPlayer.GetAttribute(PlayerAttribute.DefenceIQ) / defFaskBreakCOE * 10000;
                    if (pro > this.gameInfo.RandomNext())
                    {
                        int speedLevel = SpeedManager.Instance.GetSpeedAccelerate( defFastBreakPlayer, this.gameInfo.RandomSpeed());
                        double speed = player.GetSpeedByLevel(speedLevel);
                        int delayStart = TimeFrameConverter.GetFrame( player.GetAttribute(PlayerAttribute.React) / 1000);
                        defFastBreakPlayer.SetCurrentTask(this.GetDefFaskBreakTask(speedLevel, speed, defFastBreakPlayer.Pos, target, delayStart));
                        count++;   
                    }

                }
            }
        }

        private int GetDefFaskBreakCount(Team team)
        {
            int count = 0;
            for (int i = 0; i < team.Players.Count; i++)
            {
                Player defFastBreakPlayer = team.Players[i];
                if (defFastBreakPlayer.GetCurTask().TaskType == TaskType.PlayerMoveToDefFastBreak)
                {
                    count++;
                }
            }
            return count;
        }

        private GameTask GetDefFaskBreakTask(int speedLevel, double speed, Position start, Position target, int delayStart)
        {
            GameTask gt = new GameTask(this.name);
            gt.StartPos = start.Clone();
            gt.TargetPos = target.Clone();
            gt.FinishFrame = gt.CalcTimeBySpeed(speed);
            gt.SpeedLevel = speedLevel;
            gt.TaskType = TaskType.PlayerMoveToDefFastBreak;
            gt.DelayStart = delayStart;
            return gt;
        }

        /// <summary>
        /// 是否第一快下人
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        private bool IsFirstOne(Player player, ref Player firstPlayer)
        {
            //看看有没有其他人的任务是快下
            for (int i = 0; i < player.OwnerTeam.PlayerCount; i++)
            {
                Player otherPlayer = player.OwnerTeam.Players[i];
                if (!otherPlayer.IsSamePlayer(player))
                {
                    if (otherPlayer.GetCurTask().TaskType == TaskType.PlayerFastBreak)
                    {
                        firstPlayer = otherPlayer;
                        return false;
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// 有多少人已经在快攻
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        private int GetFastBreakCount(Player player)
        {
            int count = 0;
            //看看有没有其他人的任务是快下
            for (int i = 0; i < player.OwnerTeam.PlayerCount; i++)
            {
                Player otherPlayer = player.OwnerTeam.Players[i];
                if (!otherPlayer.IsSamePlayer(player))
                {
                    if (otherPlayer.GetCurTask().TaskType == TaskType.PlayerFastBreak)
                    {
                        count++;
                    }
                }
            }
            return count;
        }

        /// <summary>
        /// 第一快下人战术
        /// </summary>
        /// <param name="player"></param>
        private void DoFirstOne(Player player)
        {
            int fastbreakId = this.GetFastBreakId( player ) ;
            ZDBTable fastBreakTable = ZDataManager.Instance.GetFastBreakTable();
            ZDB_Row_Data rowData = fastBreakTable.getDataByID(fastbreakId);
            int pbId = 0;
            int isJump3P = 0;
            if (this.IsFirstOneJump3P(player))
            {
                pbId = this.GetRandomPBId(rowData.getCol((int)fastbreakFields.Play1Choice2).getValueString());
                isJump3P = 1;
            }
            else
            {
                pbId = this.GetRandomPBId(rowData.getCol((int)fastbreakFields.Play1Choice1).getValueString());
            }
            Position target = this.GetTarget(player.OwnerTeam.AttackField, pbId);
            GameTask gt = this.GetFastBreakGameTask(player, target);
            gt.Param1 = fastbreakId;
            gt.Param2 = isJump3P;

            player.SetCurrentTask(gt);
        }

        /// <summary>
        /// 不是第一快攻人的选择
        /// </summary>
        /// <param name="player"></param>
        /// <param name="firstPlayer"></param>
        private void DoOtherPlayer(Player player, Player firstPlayer)
        {
            int fastbreakId = firstPlayer.GetCurTask().Param1;
            int isJump3P = firstPlayer.GetCurTask().Param2;
            int pbId = 0;
            ZDBTable fastBreakTable = ZDataManager.Instance.GetFastBreakTable();
            ZDB_Row_Data rowData = fastBreakTable.getDataByID(fastbreakId);

            if (isJump3P == 1)
            {
                pbId = this.GetRandomPBId(rowData.getCol((int)fastbreakFields.Play1Choice2).getValueString());
            }
            else
            {
                pbId = this.GetRandomPBId(rowData.getCol((int)fastbreakFields.Play1Choice1).getValueString());
            }
            Position target = this.GetTarget(player.OwnerTeam.AttackField, pbId);
            GameTask gt = this.GetFastBreakGameTask(player, target);
            gt.Param1 = fastbreakId;
            gt.Param2 = isJump3P;

            player.SetCurrentTask(gt);
        }

        /// <summary>
        /// 是否进行三分跑位
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        private bool IsFirstOneJump3P(Player player)
        {
            double param322 = ParameterManager.Instance.GetValueD(ParameterEnum.FastBreakFirstOneJump3PMin);
            double param317 = ParameterManager.Instance.GetValueD(ParameterEnum.FastBreakFirstOneJump3PParam);

            if (player.GetAttribute(PlayerAttribute.JumpShot3) >= param322)
            {
                //必须达到最低属性
                double pro = player.GetAttribute(PlayerAttribute.JumpShot3) / param317 * 10000;
                if (pro >= this.gameInfo.RandomNext())
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 获取一个目标点
        /// </summary>
        /// <param name="field"></param>
        /// <param name="pbId"></param>
        /// <returns></returns>
        private Position GetTarget(Field field, int pbId)
        {
            Position p1 = field.CourtZoneManager.GetRandomPosition(pbId, this.gameInfo.RandomNext());
            return p1;
        }

        private GameTask GetFastBreakGameTask(Player player, Position target)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerFastBreak;
            gt.StartPos = player.Pos;
            gt.TargetPos = target;
            gt.Param3 = this.gameInfo.GameFrame;

            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(player, this.gameInfo.RandomSpeed());
            double speed = player.GetSpeedByLevel(speedLevel);
            gt.SpeedLevel = speedLevel;
            gt.FinishFrame = gt.CalcTimeBySpeed(speed);

            return gt;
        }

        /// <summary>
        /// 获取fastbreakid
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        private int GetFastBreakId(Player player)
        {
            int tacId = (int)ETacticOff.BaseOff;//todo 真正战术布置

            ZDBTable fastBreakTable = ZDataManager.Instance.GetFastBreakTable();
            List<int> lstId = new List<int>();
            List<int> lstChance = new List<int>();
            for (int i = 0; i < fastBreakTable.getRowCount(); i++)
            {
                ZDB_Row_Data rowData = fastBreakTable.getDataByRow(i);
                int type = rowData.getCol((int)fastbreakFields.PlayType).getValueInt();
                if (type == tacId)
                {
                    int id = rowData.getCol((int)fastbreakFields.Id).getValueInt();
                    int chance = rowData.getCol((int)fastbreakFields.Chance).getValueInt();

                    lstId.Add(id);
                    lstChance.Add(chance);
                }
            }
            int index = ProbabilityCalc.GetPosition(lstChance, this.gameInfo.RandomNext());

            return lstId[index];
        }

        /// <summary>
        /// 离篮筐最近的3个人才需要打标记
        /// </summary>
        /// <param name="team"></param>
        public void CalcFastBreak(Team team, TaskType taskType)
        {
            if(!this.IsNeedCalc(team, taskType))
            {
                return;
            }

            List<double> lstDis1 = new List<double>();
            List<double> lstDis2 = new List<double>();
            for (int i = 0; i < team.PlayerCount; i++)
            {
                Player player = team.Players[i];
                double dis = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, team.AttackField, player);
                lstDis1.Add(dis);
                lstDis2.Add(dis);
            }

            lstDis1.Sort();
            for(int i= 0;i<lstDis2.Count;i++)
            {
                double dis = lstDis2[i];
                if (dis < lstDis2[3])
                {
                    if (team.Players[i].GetCurTask().TaskType == taskType)
                    {
                        team.Players[i].GetCurTask().Param1 = 1;
                    }
                }
            }
        }


        private bool IsNeedCalc(Team team, TaskType taskType)
        {
            ZDBTable tacOffTable = ZDataManager.Instance.GetTacticOffecnsiveTable();
            ZDB_Row_Data rowData = tacOffTable.getDataByID((int)ETacticOff.BaseOff);
            int fastBreak2 = rowData.getCol((int)tactic_offensiveFields.FastBreak2).getValueInt();
            if (fastBreak2 == 0 && taskType == TaskType.PlayerToGetRebound)
            {
                return true;
            }
            if (fastBreak2 == 1 && taskType == TaskType.PlayerAfterBallHitHoop)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// 是否快下，概率计算
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public bool IsNeedFastBreak(Player player)
        {
            double playerFastBreak = player.GetAttribute(PlayerAttribute.FastBreak);
            double param410 = ParameterManager.Instance.GetValueD(ParameterEnum.FastBreakParam1);
            double param411 = ParameterManager.Instance.GetValueD(ParameterEnum.FastBreakParam2);
            double param412 = ParameterManager.Instance.GetValueD(ParameterEnum.FastBreakParam3);
            double param413 = ParameterManager.Instance.GetValueD(ParameterEnum.FastBreakParam4);
            double param414 = ParameterManager.Instance.GetValueD(ParameterEnum.FastBreakParam5);

            int disCOE = 0;
            if (this.IsNearerBasketThanAnotherTeamAll(player))
            {
                disCOE = 1;
            }
            double tacAdd = this.GetTacAdd(player) * 1.0f / 100;
            //之前在下快攻人数
            int fastBreakCount = this.GetFastBreakCount(player);

            double pro = (playerFastBreak / param410 + param411 / param412 * disCOE) * tacAdd / param414 + param413 * fastBreakCount / 100;
            pro = pro * 10000;
            if (pro > this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 是否比对方所有人更接近自己篮筐
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        private bool IsNearerBasketThanAnotherTeamAll(Player player)
        {
            Field attackField = player.OwnerTeam.AttackField;
            //Position basket = player.OwnerTeam.AttackBasket;
            Team anotherTeam = this.gameInfo.GetAnotherTeam(player.OwnerTeam);
            //double disToBasket = basket.Distance(player.Pos);
            double disToBasket = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, attackField, player);
            for (int i = 0; i < anotherTeam.PlayerCount; i++)
            {
                Player otherPlayer = anotherTeam.Players[i];
                double dis = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, attackField, otherPlayer);
                if (dis < disToBasket)
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// 战术对快攻加成
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        private int GetTacAdd(Player player)
        {
            ZDBTable tacticOffTable = ZDataManager.Instance.GetTacticOffecnsiveTable();
            ZDB_Row_Data rowData = tacticOffTable.getDataByID((int)ETacticOff.BaseOff);

            int fastBreakAdd = rowData.getCol((int)tactic_offensiveFields.FastBreak).getValueInt();

            return fastBreakAdd;
        }

        /// <summary>
        /// 获取一个pbid
        /// </summary>
        /// <param name="pb"></param>
        /// <returns></returns>
        private int GetRandomPBId(string pb)
        {
            int random = this.gameInfo.RandomNext();
            string[] array = pb.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            int index = random % array.Length;

            return Convert.ToInt32(array[index]);
        }
    }
}
