﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class TacPassBall : TacBase
    {
        public TacPassBall(GameInfo gameInfo, string source)
            : base(gameInfo, source)
        {

        }

        public void GetPassBall(Player getBallPlayer, Player passBallPlayer)
        {
            //出界判断
            if (this.gameInfo.IsInBounds(getBallPlayer.Pos))
            {
                this.gameInfo.ResumeCurRound();

                //传球结束
                GameTask gtBall = new GameTask(this.name);
                gtBall.TaskType = TaskType.BallOnThePlayer;
                gtBall.TargetPlayer = getBallPlayer;
                gtBall.FinishFrame = int.MaxValue;
                this.gameInfo.Ball.SetCurrentTask(gtBall);

                this.gameInfo.SetBallOwner(getBallPlayer);

                getBallPlayer.ClearTask();
                //真正强制重算得分预期
                getBallPlayer.ForceCalcScoringExpect(this.gameInfo, false);

                //PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.GetPassBall2, getBallPlayer.Id);
                //this.gameInfo.AddGameInfo(pc);
            }
            else
            {
                PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.OutOfBoundBySomeBody, passBallPlayer.Id);
                this.gameInfo.AddGameInfo(pc);

                this.gameInfo.AddPersoanlBoxScore(passBallPlayer, BoxScoreType.TOV, 1);

                Field atkField = this.gameInfo.AttackTeam.AttackField;
                Field defField = this.gameInfo.DefTeam.AttackField;
                //边线球
                Position posToThrowIn = Position.Empty;
                if (atkField.IsOnMe(this.gameInfo.Ball.Pos))
                {
                    //前场球
                    posToThrowIn = atkField.GetSideThrowInPos(this.gameInfo.Ball.Pos);
                }
                else
                {
                    //后场球
                    posToThrowIn = defField.GetSideThrowInPos(this.gameInfo.Ball.Pos);
                }
                //一定交换球权

                Team defTeam = this.gameInfo.DefTeam;

                this.gameInfo.ClearBallOwner();
                this.gameInfo.SetBallOwnTeam(defTeam);

                //24秒计时
                this.gameInfo.Pause();
                this.gameInfo.StartNewRound();

                this.gameInfo.ClearAllPlayerTask();
                this.gameInfo.Ball.ClearTask();

                //界外球事件
                GameEvent ge = new GameEvent(GameEventType.OutOfBoundToThrowIn);
                ge.Pos = posToThrowIn;
                this.gameInfo.AddGameEvent(ge);
            }
        }

        /// <summary>
        /// 是否拿到球
        /// </summary>
        /// <param name="getBallPlayer"></param>
        /// <param name="passBallPlayer"></param>
        /// <returns></returns>
        public bool IsGetBall(Player getBallPlayer, Player passBallPlayer)
        {
            if (this.gameInfo.Ball.Owner != null)
            {
                //球没传出来，肯定不能接到球
                return false;
            }

            double minDis = ParameterManager.Instance.GetValueD(ParameterEnum.PassBallParam9);
            double dis = getBallPlayer.Pos.DistanceActualLength(this.gameInfo.Ball.Pos);
            if (dis < minDis)
            {
                return true;
            }
            return false;
        }

    }
}
