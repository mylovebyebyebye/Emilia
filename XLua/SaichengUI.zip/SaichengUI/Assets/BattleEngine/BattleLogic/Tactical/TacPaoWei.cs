﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class PaoWeiParam
    {
        private List<PaoWeiSegmentParam> lst;

        private int index = -1;

        public PaoWeiParam()
        {
            this.lst = new List<PaoWeiSegmentParam>();
        }

        public int GetCount()
        {
            return this.lst.Count;
        }

        public PaoWeiSegmentParam GetSegementByIndex(int index)
        {
            if (index >= 0 && index < lst.Count)
            {
                return this.lst[index];
            }
            return null;
        }

        public void AddPaoWeiSegmentParam(PaoWeiSegmentParam param)
        {
            this.lst.Add(param);
        }

        public void Start()
        {
            this.index = 0;
        }

        public void Next()
        {
            if (this.index < this.lst.Count)
            {
                this.index++;
            }
        }

        public void Clear()
        {
            this.index = -1;
            this.lst.Clear();
        }

        /// <summary>
        /// 当前位置是否到达该段
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        public bool IsReachTarget(Position pos)
        {
            if (this.lst.Count < 1)
            {
                return false;
            }
            Position target = this.lst[this.index].EndPostion;
            double dis = pos.DistanceActualLength(target);
            if (dis < 30)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 是否全部结束
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        public bool IsAllClear(Position pos)
        {
            if (this.lst.Count < 1)
            {
                return false;
            }
            Position target = this.lst[this.lst.Count - 1].EndPostion;
            double dis = pos.DistanceActualLength(target);
            if (dis < 30)
            {
                return true;
            }
            return false;
        }

        public PaoWeiSegmentParam GetCurParam()
        {
            if (this.index == -1)
            {
                return null;
            }
            return this.lst[this.index];
        }
    }

    /// <summary>
    /// 跑位每一段参数
    /// </summary>
    public class PaoWeiSegmentParam
    {
        private Position circle;

        public Position Circle
        {
            get { return circle; }
            set { circle = value; }
        }

        private double radius;
        /// <summary>
        /// 单位厘米
        /// </summary>
        public double Radius
        {
            get { return radius; }
            set { radius = value; }
        }

        private Position endPostion;

        public Position EndPostion
        {
            get { return endPostion; }
            set { endPostion = value; }
        }

        /// <summary>
        /// 是否是顺时针
        /// 不是的话就是逆时针
        /// </summary>
        public bool IsClockWise { get; set; }

        /// <summary>
        /// 圆心角
        /// </summary>
        public double CenterAngle;
    }

    public class TacPaoWei : TacBase
    {
        private TacStandby tacTacStandby;
        public TacPaoWei(GameInfo gameInfo, string source)
            : base(gameInfo, source)
        {
            this.tacTacStandby = new TacStandby(this.gameInfo, this.name);
        }

        public bool IsNeedPaoWei(Player player)
        {
            if (this.gameInfo.DefTeam == player.OwnerTeam)
            {
                //防守方不跑位
                return false;
            }
            if(player.IsSamePlayer(this.gameInfo.Ball.Owner ))
            {
                //持球人不跑位
                return false;
            }
            Field atkField = this.gameInfo.AttackTeam.AttackField;
            //在前场
            if (atkField.IsOnMyEffectiveArea(player.Pos))
            {
                //待机
                if (player.IsInTask( TaskType.PlayerStandby) && 
                    player.GetCurTask().FinishFrame > 0)
                {
                    //计算概率
                    if (player.OffballPro * 10000 > this.gameInfo.RandomNext())
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public void Do(Player player)
        {
            List<Position> lstPos;
            //判断是3分还是2分
            if (this.IsMidDis(player))
            {
                lstPos = this.GetPaoWeiPath(player, PlayBookType.Paowei2P1);
            }
            else
            {
                lstPos = this.GetPaoWeiPath(player, PlayBookType.Paowei3P1);
            }
            if(lstPos.Count <= 2)
            {
                throw new Exception("TacPaoWei 错误的配置");
            }
            player.PaoweiParam.Clear();

            //得到了一系列点，开始分段 
            int count = lstPos.Count - 2;
            for (int i = 0; i < count; i++)
            {
                this.CreateSegment(lstPos, i, player.PaoweiParam);
            }

            //计算完成开始第一段跑位
            if (player.PaoweiParam.GetCount() > 0)
            {
                player.PaoweiParam.Start();
                this.DoThisSegmentNext(player);
            }

            //跑位会触发掩护
            Player handler = this.gameInfo.Ball.Owner;
            for (int i = 0; i < player.OwnerTeam.PlayerCount; i++)
            {
                Player otherPlayer = player.OwnerTeam.Players[i];
                if (!otherPlayer.IsSamePlayer(player) &&
                    !otherPlayer.IsSamePlayer(handler) &&
                    otherPlayer.GetCurTask().TaskType == TaskType.PlayerStandby)
                {
                    //其他非持球人,且在待机 才进行判断
                    if (this.IsNeedCover(player, otherPlayer))
                    {
                        this.DoCoverPaowei(player, otherPlayer);
                    }
                }
            }

            //2017.1.12 跑位会给防守自己的人加一个反应时间buf
            List<Player> myPosDefPlayers = player.GetAllMyPosDefPlayers();
            for (int i = 0; i < myPosDefPlayers.Count; i++)
            {
                Player defPlayer = myPosDefPlayers[i];
                double standbyTime = defPlayer.GetAttribute(PlayerAttribute.React) / 1000;
                this.tacTacStandby.DoMoveInSituBySeconds(defPlayer, standbyTime);
            }
        }

        public void DoNextSegment(Player player)
        {
            PaoWeiParam param = player.PaoweiParam;
            param.Next();
            this.DoThisSegmentNext(player);
        }

        /// <summary>
        /// 跑下一段
        /// </summary>
        /// <param name="player"></param>
        public void DoThisSegmentNext(Player player)
        {
            //todo 一堆临时参数
            PaoWeiSegmentParam param = player.PaoweiParam.GetCurParam();
            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(player, this.gameInfo.RandomSpeed()) ;
            double speedInPixel = player.GetSpeedInPixelByLevel(speedLevel);
            double time = 0.1f;
            double moveDis = speedInPixel * time;

            double disToTarget = player.Pos.Distance(param.EndPostion);
            Position target;
            if (disToTarget <= moveDis)
            {
                //直接跑到
                target = param.EndPostion;
            }
            else
            {
                //等腰三角形一半为底边，半径为斜边， 求转动角度
                double angle = Formula.GetAngle( Math.Asin((moveDis / 2) / param.Radius) ) * 2;
                Vector2D v = new Vector2D(param.Circle, player.Pos);
                double vSlope = v.GetSlopeAngle();
                if (param.IsClockWise)  
                {
                    angle = vSlope - angle;
                }
                else
                {
                    angle = vSlope + angle;
                }
                target = param.Circle.GetPosByAngleRadius(angle, (int)(param.Radius * Position.ActualLengthPerPoint));
            }

            //安排继续跑位
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerPositioning;
            gt.StartPos = player.Pos;
            gt.TargetPos = target;
            gt.SpeedLevel = speedLevel;
            gt.FinishFrame = gt.CalcRealTargetTryMyBest(speedInPixel, time);
            gt.DelayStart = 0;
            player.SetCurrentTask(gt);
        }

        /// <summary>
        /// 该段完成
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public bool IsReachTarget(Player player)
        {
            PaoWeiParam param = player.PaoweiParam;
            if (param.IsReachTarget(player.Pos))
            {
                return true;
            }
            return false;
        }

        public bool IsAllClear(Player player)
        {
            PaoWeiParam param = player.PaoweiParam;
            if (param.IsAllClear(player.Pos))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 是否中距离跑位
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        private bool IsMidDis(Player player)
        {
            ZDBTable tacOffTable = ZDataManager.Instance.GetTacticOffecnsiveTable();
            //todo 现在都取第一号战术
            ZDB_Row_Data rowData = tacOffTable.getDataByID((int)ETacticOff.BaseOff);
            double offball = rowData.getCol((int)tactic_offensiveFields.Offball).getValueInt();

            double jumpshot2 = player.GetAttribute(PlayerAttribute.JumpShot2);
            double jumpshot3 = player.GetAttribute(PlayerAttribute.JumpShot3);
            double pro = jumpshot2 / (jumpshot2 + offball / 100 * jumpshot3);
            if (pro * 10000 >= this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 跑位路径
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        private List<Position> GetPaoWeiPath(Player player, PlayBookType playBook)
        {
            List<Position> lst = new List<Position>();
            lst.Add(player.Pos);
            lst.AddRange( player.OwnerTeam.AttackField.GetListPosition(playBook, this.gameInfo.RandomNext()) );
            return lst;
        }

        /// <summary>
        /// 分段计算跑位的参数
        /// </summary>
        /// <param name="lstPos">所有点</param>
        /// <param name="index">当前计算到哪个点开始了</param>
        /// <param name="param">保存结果的地方</param>
        private void CreateSegment(List<Position> lstPos, int index, PaoWeiParam param)
        {
            if (lstPos.Count < index + 3)
            {
                return;
            }
            //起点A，终点C，途经点B
            Vector2D vAC = new Vector2D(lstPos[index], lstPos[index + 2]);
            Vector2D vAB = new Vector2D(lstPos[index], lstPos[index + 1]);
            Vector2D vBC = new Vector2D(lstPos[index + 1], lstPos[index + 2]);

            if (vAB.Start == vAB.End)
            {
                return;
            }
                    
            double angleSlopeAB = vAB.GetSlopeAngle();
            if (angleSlopeAB > 180.0)
            {
                angleSlopeAB -= 180.0;
            }
            double angleSlopeBC = vBC.GetSlopeAngle();
            if(angleSlopeBC > 180.0)
            {
                angleSlopeBC -= 180.0;
            }
            double angleABC = Math.Abs(angleSlopeAB - angleSlopeBC);
            double centerAngle = 180.0 - angleABC;

            bool isOnMyLeft = false;
            if (vAC.IsOnMyLeft(vAB))
            {
                isOnMyLeft = true;
            }
            if (index == 0)
            {
                PaoWeiSegmentParam param1 = this.GetSegmentParam(vAB,centerAngle / 2, isOnMyLeft);
                param.AddPaoWeiSegmentParam(param1);
            }
            //第二段，都得算
            {
                PaoWeiSegmentParam param2 = this.GetSegmentParam(vBC,centerAngle / 2, isOnMyLeft);
                param.AddPaoWeiSegmentParam(param2);
            }
        }

        /// <summary>
        /// 分别计算每一段
        /// </summary>
        /// <param name="v1"></param>
        /// <param name="isOnMyLeft"></param>
        /// <returns></returns>
        private PaoWeiSegmentParam GetSegmentParam(Vector2D v1, double centerAngle, bool isOnMyLeft)
        {
            double length = v1.GetLength();
            //根据圆心角和边长，计算半径
            double radius1 = (length / 2) / Math.Sin(Formula.GetRadian(centerAngle));

            Position circle = Formula.GetCircleByTwoPointsAndRadius(v1.Start, v1.End, radius1, isOnMyLeft);

            PaoWeiSegmentParam param1 = new PaoWeiSegmentParam();
            param1.Circle = circle;
            param1.Radius = (double)radius1;
            param1.EndPostion = v1.End.Clone();
            param1.IsClockWise = isOnMyLeft;
            param1.CenterAngle = centerAngle * 2;

            return param1;
        }

        /// <summary>
        /// 是否去掩护跑位的人
        /// </summary>
        /// <param name="paoweiPlayer"></param>
        /// <param name="player"></param>
        /// <returns></returns>
        public bool IsNeedCover(Player paoweiPlayer, Player player)
        {
            double screen = player.GetAttribute(PlayerAttribute.Screen);
            double param66 = ParameterManager.Instance.GetValueD(ParameterEnum.CoverPaoweiParam);

            double pro = 1 - Math.Pow(param66 / 10000, screen);
            pro = pro * 10000;
            if (pro > this.gameInfo.RandomNext())
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// 跑位掩护
        /// </summary>
        /// <param name="paoweiPlayer"></param>
        /// <param name="player"></param>
        public void DoCoverPaowei(Player paoweiPlayer, Player player)
        {
            Position p1 = this.GetCoverPaoweiPos(paoweiPlayer, player);
            if (p1 == Position.Empty)
            {
                return;
            }
            //转成跑位掩护人
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerCoverPaowei;
            gt.RecordPos = p1;
            gt.TargetPlayer = paoweiPlayer;

            player.SetCurrentTask(gt);
        }

        /// <summary>
        /// 获取掩护点
        /// </summary>
        /// <param name="paoweiPlayer"></param>
        /// <param name="player"></param>
        /// <returns></returns>
        private Position GetCoverPaoweiPos(Player paoweiPlayer, Player player)
        {
            Position p1 = Position.Empty;
            PaoWeiParam paoweiParam = paoweiPlayer.PaoweiParam;
            int count = paoweiParam.GetCount();
            for(int i = count - 1; i > 0; i--)
            {
                //倒序算
                PaoWeiSegmentParam segment = paoweiParam.GetSegementByIndex(i);
                double disToPaowei = segment.EndPostion.Distance(paoweiPlayer.Pos);
                double disToCover = segment.EndPostion.Distance(player.Pos);
                if (disToCover < disToPaowei)
                {
                    //计算随机点,注意这里是用终点算的， 顺时针和逆时针是相反的
                    Vector2D v = new Vector2D(segment.Circle, segment.EndPostion);
                    double angle = v.GetSlopeAngle();
                    double random = this.gameInfo.RandomNext(0, (int)(segment.CenterAngle));
                    if(segment.IsClockWise)
                    {
                        angle += random;
                    }
                    else
                    {
                        angle -= random;
                    }
                    p1 = segment.Circle.GetPosByAngleRadius(angle, (int)(segment.Radius * Position.ActualLengthPerPoint));
                    break;
                }
            }
            return p1;
        }
        
    }
}
