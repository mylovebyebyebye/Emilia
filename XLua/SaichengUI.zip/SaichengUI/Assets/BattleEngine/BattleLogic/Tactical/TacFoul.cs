﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class TacFoul : TacBase
    {
        public TacFoul(GameInfo gameInfo, string source)
            : base(gameInfo, source)
        {
 
        }

        /// <summary>
        /// 通用犯规公式
        /// </summary>
        /// <param name="foulType"></param>
        /// <param name="atkPlayer"></param>
        /// <param name="defPlayer"></param>
        /// <returns></returns>
        public bool IsFoul(EFoulType foulType, Player atkPlayer, Player defPlayer)
        {
            ZDBTable foulTable = ZDataManager.Instance.GetFoulTable();
            int id = (int)foulType;

            if (!foulTable.hasID(id))
            {
                return false;
            }

            //double disToBasket = atkPlayer.Pos.DistanceActualLength(atkPlayer.OwnerTeam.AttackBasket);
            double disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, atkPlayer.OwnerTeam.AttackField, atkPlayer);
            
            ZDB_Row_Data rowData = foulTable.getDataByID(id);
            int minDis = rowData.getCol((int)foulFields.Distance).getValueInt();
            int value1 = rowData.getCol((int)foulFields.Value1).getValueInt();
            int value2 = rowData.getCol((int)foulFields.Value2).getValueInt();
            int atkAttrIndex = rowData.getCol((int)foulFields.Attack).getValueInt();
            int atkAttrIndex1 = rowData.getCol((int)foulFields.Attack1).getValueInt();
            int defAttrIndex = rowData.getCol((int)foulFields.Defence).getValueInt();
            int type = rowData.getCol((int)foulFields.Type).getValueInt();

            if (disToBasket < minDis)
            {
                return false;
            }

            double atkAttr = atkPlayer.GetAttrByIndex(atkAttrIndex);
            double atkAttr1 = atkPlayer.GetAttrByIndex(atkAttrIndex1);
            double defAttr = defPlayer.GetAttrByIndex(defAttrIndex);
            double pro = 0.0;
            if (type == 1)
            {
                pro = this.GetType1Pro(value1, value2, atkAttr, atkAttr1, defAttr);
            }
            else
            {
                pro = this.GetType2Pro(value1, value2, atkAttr, defAttr);
            }

            if (pro > this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }

        private double GetType1Pro(int value1, int value2, double atkAttr, double atkAttr1, double defAttr)
        {
            double pro = (atkAttr + atkAttr1) / value1 + defAttr / value2;

            return pro * 10000;
        }

        private double GetType2Pro(int value1, int value2, double atkAttr, double defAttr)
        {
            double pro = (atkAttr + defAttr) / (value1 + value2);
            return pro * 10000;
        }
    }
}
