﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    /// <summary>
    /// 补防
    /// </summary>
    public class TacFillIn : TacBase
    {

        public TacFillIn(GameInfo gameInfo, string source)
            : base(gameInfo, source)
        {
 
        }

        /// <summary>
        /// 补防
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <param name="oldDefPlayer"></param>
        public void Do(EFillInType eFillInType, Player atkPlayer)
        {
            double param201 = ParameterManager.Instance.GetValueD(ParameterEnum.DefHandlerLuoWeiDis);
            //double disToBasket = atkPlayer.Pos.DistanceActualLength(atkPlayer.OwnerTeam.AttackBasket);
            double disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, atkPlayer.OwnerTeam.AttackField, atkPlayer);
            if (disToBasket > param201)
            {
                //距离过远不触发补防
                return;
            }

            Position target = this.GetFillInTargetPos(atkPlayer);
            double tAtkPlayer = this.GetAtkToTargetTime(atkPlayer, target);

            int count = 0;
            //补防判断，应该是当前防守人不是该进攻人的人
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player defPlayer = this.gameInfo.DefTeam.Players[i];
                Player myPosAtkPlayer = defPlayer.GetMyPosAttacker();
                if ( !atkPlayer.IsSamePlayer(myPosAtkPlayer))
                {
                    //进入这里需要进行补防判断
                    if (this.IsToFillIn(eFillInType, defPlayer, atkPlayer, target, tAtkPlayer, count))
                    {
                        //还要判最后时刻和犯规麻烦等，才真正决定去
                        if (this.IsTheEndOfGame() || !this.gameInfo.IsInFoulTrouble(defPlayer))
                        {
                            //这里就是真的去补防了
                            defPlayer.SetCurrentTask(CommonGameTask.GetDelayChangeDefTarget(defPlayer, atkPlayer));
                            count++;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 是否是比赛最后时刻,且分差小于一定值
        /// </summary>
        /// <returns></returns>
        private bool IsTheEndOfGame()
        {
            int endOfGameTime = ParameterManager.Instance.GetValue(ParameterEnum.FillInParam6);
            int scoreGapMax = ParameterManager.Instance.GetValue(ParameterEnum.FillInParam7);
            //时间是最后
            if (this.gameInfo.Quarter >= 4 && this.gameInfo.QuarterTime <= endOfGameTime)
            {
                //分差
                int scoreGap = this.gameInfo.GetTotalPoint(TeamType.Home) - this.gameInfo.GetTotalPoint(TeamType.Away);
                scoreGap = Math.Abs(scoreGap);
                if (scoreGap <= scoreGapMax)
                {
                    return true;
                }
            }

            return false;
        }

        public static int count = 0;
        /// <summary>
        /// 是否补防
        /// </summary>
        /// <param name="player"></param>
        /// <param name="atkPlayer"></param>
        /// <returns></returns>
        private bool IsToFillIn(EFillInType eFillInType, Player defPlayer, Player atkPlayer, Position target, double tAtkPlayer, int count)
        {
            ZDBTable defenceHelpTable = ZDataManager.Instance.GetDefenceHelpTable();
            ZDB_Row_Data rowData = defenceHelpTable.getDataByID((int)eFillInType);

            int maxCount = rowData.getCol((int)defencehelpFields.MaxHelper).getValueInt();
            if (count >= maxCount)
            {
                //人数上限，直接不算了
                return false;
            }

            bool isCanFillIn = this.IsCanFillIn(defPlayer, target, tAtkPlayer);
            if (isCanFillIn)
            {
                int param365 = rowData.getCol((int)defencehelpFields.HelpDefenceDivisor).getValueInt() ;
                int param366 = rowData.getCol((int)defencehelpFields.HelpDefenceIndex).getValueInt();
                int param367 = rowData.getCol((int)defencehelpFields.HelpDefenceDivisor2).getValueInt();
                //能补防到,计算概率
                //double dis = defPlayer.Pos.DistanceActualLength(atkPlayer.Pos);
                double dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, atkPlayer, defPlayer);
                int disParam = this.GetFillInDisParam(rowData, dis);
                double pro = defPlayer.GetAttribute(PlayerAttribute.HelpDefence) / param365 - Math.Pow(disParam, param366) / param367;
                pro = pro * 10000;
                if (pro > this.gameInfo.RandomNext())
                {
                    TacFillIn.count++;
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 距离参数
        /// </summary>
        /// <param name="dis"></param>
        /// <returns></returns>
        private int GetFillInDisParam(ZDB_Row_Data rowData, double dis)
        {
            int value = 0;
            if (dis <= 200)
            {
                value = rowData.getCol((int)defencehelpFields.Basenumber1).getValueInt();
            }
            else if (dis <= 400)
            {
                value = rowData.getCol((int)defencehelpFields.Basenumber2).getValueInt();
            }
            else if (dis <= 600)
            {
                value = rowData.getCol((int)defencehelpFields.Basenumber3).getValueInt();
            }
            else
            {
                value = rowData.getCol((int)defencehelpFields.Basenumber4).getValueInt();
            }
            return value;
        }

        /// <summary>
        /// 补防计算点
        /// </summary>
        /// <param name="player"></param>
        /// <param name="atkPlayer"></param>
        /// <returns></returns>
        private Position GetFillInTargetPos(Player atkPlayer)
        {
            Position target = Position.Empty;
            Position basketPos = atkPlayer.OwnerTeam.AttackBasket;
            double RadiusRestrictedArea = ParameterManager.Instance.GetValue(ParameterEnum.RestrictedArea);
            //篮筐到持球人连线与合理冲撞区交点
            target = Formula.ClosestIntersection(basketPos, Position.GetPix(RadiusRestrictedArea), atkPlayer.Pos, basketPos);

            return target;
        }

        /// <summary>
        /// 是否能补防到
        /// </summary>
        /// <param name="player"></param>
        /// <param name="atkPlayer"></param>
        /// <returns></returns>
        private bool IsCanFillIn(Player player, Position target, double tAktPlayer)
        {
            double tDefPlayer = this.GetDefToTargetTime(player, target);
            double param220 = ParameterManager.Instance.GetValueD(ParameterEnum.FillInParam1);
            double param221 = ParameterManager.Instance.GetValueD(ParameterEnum.FillInParam2);
            double param222 = ParameterManager.Instance.GetValueD(ParameterEnum.FillInParam3);
            double param223 = ParameterManager.Instance.GetValueD(ParameterEnum.FillInParam4);
            double param224 = ParameterManager.Instance.GetValueD(ParameterEnum.FillInParam5);
            double param227 = ParameterManager.Instance.GetValueD(ParameterEnum.FillInParam8);

            double devPlayer = Math.Pow(1 / player.GetAttribute(PlayerAttribute.HelpDefence), param220 / param221 * param222);
            double dev100 = Math.Pow(1.0f / 100, param220 / param221 * param222) * param223 / param224;
            int devMax = (int)(devPlayer - dev100);
            int devRandom = this.gameInfo.RandomNext(1, devMax + 1);
            double value;
            if (devRandom % 2 == 0)
            {
                value = tAktPlayer - (tDefPlayer + devRandom * (tDefPlayer / param227));
            }
            else
            {
                value = tAktPlayer - (tDefPlayer - devRandom * (tDefPlayer / param227));
            }
            if (value > 0)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 进攻人到目标点时间
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <param name="target"></param>
        /// <returns></returns>
        private double GetAtkToTargetTime(Player atkPlayer, Position target)
        {
            double disAtkToTarget = target.DistanceActualLength(atkPlayer.Pos);

            double vAttack = atkPlayer.GetSpeedByLevel(SpeedManager.Instance.GetSpeedAccelerate(atkPlayer, this.gameInfo.RandomSpeed()));

            return Convert.ToSingle(disAtkToTarget / vAttack);
        }

        /// <summary>
        /// 防守球员到目标点时间
        /// </summary>
        /// <param name="defPlayer"></param>
        /// <param name="target"></param>
        /// <returns></returns>
        private double GetDefToTargetTime(Player defPlayer, Position target)
        {
            double disToTarget = target.DistanceActualLength(defPlayer.Pos);
            double vDef = defPlayer.GetSpeedByLevel(SpeedManager.Instance.GetSpeedAccelerate(defPlayer, this.gameInfo.RandomSpeed()));

            double param1 = ParameterManager.Instance.GetValueD(ParameterEnum.ReactionTime) / 10;

            double seconds = disToTarget / vDef + param1 / 10;

            return (double)seconds;
        }

        /// <summary>
        /// 重新选择防守对象
        /// </summary>
        /// <param name="atkPlayer"></param>
        public void ChooseDefAgain(Player atkPlayer)
        {
            List<Player> lst = atkPlayer.GetAllMyPosDefPlayers();
            if (lst.Count < 2)
            {
                return;
            }
            int maxIndex = -1;//这个人不需要换
            int max = int.MinValue;
            int index =0;
            for (int i = 0; i < lst.Count; i++)
            {
                Player defPlayer = lst[i];
                int random = 0;
                //看谁换防，进行roll点
                if (defPlayer.Role != atkPlayer.Role)
                {
                    random = this.gameInfo.RandomNext();
                }
                else
                {
                    random = int.MaxValue;
                }
                if (random > max)
                {
                    max = random;
                    maxIndex = index;
                }
                index++;
            }
            for (int i = 0; i < lst.Count; i++)
            {
                if (i != maxIndex)
                {
                    this.ChangeDef(lst[i]);
                }
            }
        }

        /// <summary>
        /// 更换防守对象
        /// </summary>
        /// <param name="defPlayer"></param>
        private void ChangeDef(Player defPlayer)
        {
            //在进攻队里找离我最近无人防守球员
            double disMin = double.MaxValue;
            Player myTarget = null;
            for (int i = 0; i < this.gameInfo.AttackTeam.PlayerCount; i++)
            {
                Player atkPlayer = this.gameInfo.AttackTeam.Players[i];
                List<Player> lst = atkPlayer.GetAllMyPosDefPlayers();
                if (lst.Count == 0)
                {
                    //double dis = atkPlayer.Pos.Distance(defPlayer.Pos);
                    double dis = this.gameInfo.DisManager.GetDistanceInPixelToOtherTeamPlayer(this.gameInfo.Frame, atkPlayer, defPlayer);
                    if (dis < disMin)
                    {
                        disMin = dis;
                        myTarget = atkPlayer;
                    }
                }
            }
            if (myTarget != null)
            {
                defPlayer.SetCurrentTask(CommonGameTask.GetDelayChangeDefTarget(defPlayer, myTarget));
            }
        }
    }
}
