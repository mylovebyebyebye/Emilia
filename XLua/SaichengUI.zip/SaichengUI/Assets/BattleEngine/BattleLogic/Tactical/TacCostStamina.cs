﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class TacCostStamina : TacBase
    {
        public TacCostStamina(GameInfo gameInfo, string source)
            : base(gameInfo, source)
        { }

        public void Cost(EStaminaCost costType, Player player, int mSeconds = 0)
        {
            ZDBTable staminaCostTable = ZDataManager.Instance.GetStaminaCostTable();
            ZDB_Row_Data rowData = staminaCostTable.getDataByID((int)costType);

            int cost = rowData.getCol((int)stamina_costFields.Cost).getValueInt();
            if (mSeconds == 0)
            {
                player.CurStamina += cost;
            }
            else
            {
                player.CurStamina += (int)(cost * mSeconds * 1.0f / rowData.getCol((int)stamina_costFields.Frequency).getValueInt());
            }
        }
    }
}
