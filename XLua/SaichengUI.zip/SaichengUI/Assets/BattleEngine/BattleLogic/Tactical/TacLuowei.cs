﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class TacLuowei : TacBase
    {
        public TacLuowei(GameInfo gameInfo, string source)
            : base(gameInfo, source)
        { }

        public int Do(Player atkPlayer, Field atkField = null)
        {
            Team attackTeam = gameInfo.Ball.OwnTeam;
            if (atkField == null)
            {
                atkField = attackTeam.AttackField;
            }
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveToArea;
            gt.StartPos = atkPlayer.Pos;

            Position pos = Position.Empty.Clone();
            int courtZone = 0;
            if (atkPlayer.LastChoice != null && atkPlayer.LastChoice.TaskType == TaskType.PlayerMoveToArea)
            {
                pos = atkPlayer.LastChoice.TargetPos;
                courtZone = atkPlayer.LastChoice.Param1;
            }
            else
            {
                pos = atkField.GetAtkPresetPosition(this.gameInfo, atkPlayer, gameInfo.RandomNext(), out courtZone);
            }
            gt.TargetPos = pos;
            gt.Param1 = courtZone;
            int speedLevel = SpeedManager.Instance.GetSpeedNormal(atkPlayer, this.gameInfo.RandomSpeed());
            gt.SpeedLevel = speedLevel;
            gt.FinishFrame = gt.CalcTimeBySpeed(atkPlayer.GetSpeedByLevel(speedLevel));
            //SpeedManager.Instance.SetMoveTask(this.gameInfo, atkPlayer, gt);
            atkPlayer.SetCurrentTask(gt);


            //遍历其他人，如果正在我的落位区域里执行待机，让他去干别的
            for (int i = 0; i < atkPlayer.OwnerTeam.PlayerCount; i++)
            {
                Player otherPlayer = atkPlayer.OwnerTeam.Players[i];
                if (!otherPlayer.IsSamePlayer(atkPlayer) && !otherPlayer.IsSamePlayer(this.gameInfo.Ball.Owner))
                {
                    if (otherPlayer.IsInTask(TaskType.PlayerStandby))
                    {
                        if (atkField.IsOnCourtZone(courtZone, otherPlayer.Pos))
                        {
                            //让这个人重新选择
                            this.Do(otherPlayer);
                        }
                    }
                }
            }
            return courtZone;
        }
    }
}
