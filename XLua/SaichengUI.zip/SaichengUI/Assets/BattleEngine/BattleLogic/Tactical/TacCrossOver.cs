﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class TacCrossOver : TacBase
    {
        private TacInsideAttack tacInsideAttack;
        private TacCostStamina tacCostStamina;
        private TacSteal tacSteal;
        private TacFillIn tacFillIn;
        private TacFoul tacFoul;

        public TacCrossOver(GameInfo gameInfo, string source)
            :base(gameInfo, source)
        {
            this.tacInsideAttack = new TacInsideAttack(this.gameInfo, this.name);
            this.tacCostStamina = new TacCostStamina(this.gameInfo, source);
            this.tacSteal = new TacSteal(this.gameInfo, this.name);
            this.tacFillIn = new TacFillIn(this.gameInfo, this.name);
            this.tacFoul = new TacFoul(this.gameInfo, this.name);
        }

        public void Do(Player atkPlayer, Player defPlayer )
        {
            //扣体力
            this.tacCostStamina.Cost(EStaminaCost.CrossOver, atkPlayer);

            //1.进攻犯规
            //2.防守犯规 
            //3.抢断
            //4.背打 
            //5.地板漆 几率0 
            //6.过人
            //7.突破失败
            if (this.tacFoul.IsFoul(EFoulType.CrossOverAtkFoul, atkPlayer, defPlayer))
            {
                this.gameInfo.AddPersoanlBoxScore(atkPlayer, BoxScoreType.AttackFoulOnCrossOver, 1);

                GameEvent ge = new GameEvent(GameEventType.Foul);
                ge.Param1 = (int)FoulType.AttackFoul;
                ge.Param2 = 2;
                ge.Param4 = defPlayer;
                ge.Param5 = atkPlayer;
                this.gameInfo.AddGameEvent(ge);
            }
            else if (this.tacFoul.IsFoul(EFoulType.CrossOverDefFoul, atkPlayer, defPlayer))
            {
                this.gameInfo.AddPersoanlBoxScore(defPlayer, BoxScoreType.FoulOnCrossOver, 1);

                GameEvent ge = new GameEvent(GameEventType.Foul);
                ge.Param1 = (int)FoulType.Normal;
                ge.Param2 = 2;
                ge.Param4 = atkPlayer;
                ge.Param5 = defPlayer;

                this.gameInfo.AddGameEvent(ge);
            }
            else if (this.tacSteal.IsSteal(EStealSource.CrossOver, atkPlayer, defPlayer))
            {
                this.gameInfo.AddPersoanlBoxScore(defPlayer, BoxScoreType.StealCrossOver, 1);

                GameEvent ge = new GameEvent(GameEventType.Steal);
                ge.Param1 = (int)EStealSource.CrossOver;
                ge.Param4 = atkPlayer;
                ge.Param5 = defPlayer;
                this.gameInfo.AddGameEvent(ge);
            }
            else if (this.IsInsideAttack(atkPlayer, defPlayer))
            {
                this.tacInsideAttack.StartInsideAttack(atkPlayer);
            }
            else if (this.IsCrossOverSuccess(atkPlayer, defPlayer))
            {
                //触发补防
                this.tacFillIn.Do(EFillInType.CrossOver, atkPlayer);

                //突破成功，转身突破
                GameEvent ge = new GameEvent(GameEventType.TurnRound);
                ge.Param4 = defPlayer;
                ge.Param5 = atkPlayer;
                this.gameInfo.AddGameEvent(ge);
            }
            else
            {
                //突破失败 debuf
                atkPlayer.IsCanCrossOver = false;
            }
        }

        private bool IsCrossOverSuccess(Player atkPlayer, Player defPlayer)
        {
            double param11 = ParameterManager.Instance.GetValue(ParameterEnum.CrossOverExpectParam1) * 1.0f;
            double param12 = ParameterManager.Instance.GetValue(ParameterEnum.CrossOverExpectParam2) * 1.0f;
            double param13 = ParameterManager.Instance.GetValue(ParameterEnum.InsideDefParam1) * 1.0f;
            double param14 = ParameterManager.Instance.GetValue(ParameterEnum.InsideDefParam2) * 1.0f;
            double param15 = ParameterManager.Instance.GetValue(ParameterEnum.CrossOverSuccessParam) * 1.0f;

            double pro = (Math.Pow(atkPlayer.GetAttribute(PlayerAttribute.Driving) / param11, param12 / 100) -
                         Math.Pow(defPlayer.GetAttribute(PlayerAttribute.OutsideDef) / param13, param14 / 100) *
                         Math.Pow(param15 / 1000, atkPlayer.GetAttribute(PlayerAttribute.Driving))) * 10000;
            int random = this.gameInfo.RandomNext();
            if (pro > random)
            {
                return true;
            }

            return false;
        }


        private bool IsInsideAttack(Player atkPlayer, Player defPlayer)
        {
            //double disToBasket = atkPlayer.Pos.DistanceActualLength(atkPlayer.OwnerTeam.AttackBasket);
            double disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, atkPlayer.OwnerTeam.AttackField, atkPlayer);
            double minDis = ParameterManager.Instance.GetValue(ParameterEnum.InsideAtkAskBallMin) * 1.0f;
            double maxDis = ParameterManager.Instance.GetValue(ParameterEnum.InsideAtkAskBallMax) * 1.0f;
            if (disToBasket > minDis && disToBasket < maxDis)
            {
                double param52 = ParameterManager.Instance.GetValue(ParameterEnum.CrossOverInsideAtkCOE) * 1.0f;
                double param53 = ParameterManager.Instance.GetValue(ParameterEnum.CrossOverInsideAtkCOE2) * 1.0f;
                double pro = atkPlayer.GetAttribute(PlayerAttribute.InsideShot) / (defPlayer.GetAttribute(PlayerAttribute.InsideDef) + param53) * param52;
                if (pro >= this.gameInfo.RandomNext())
                {
                    return true;
                }
            }
            return false;
        }

        public void DoLayUp(Player atkPlayer, double disAtk)
        {
            GameEvent gameEvent = new GameEvent(GameEventType.Layup);
            gameEvent.Param4 = atkPlayer;
            gameInfo.AddGameEvent(gameEvent);
        }

    }
}
