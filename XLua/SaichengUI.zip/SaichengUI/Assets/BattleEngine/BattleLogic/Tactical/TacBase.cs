﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class TacBase
    {
        protected string name;
        protected GameInfo gameInfo;

        public TacBase(GameInfo gameInfo,string source)
        {
            this.gameInfo = gameInfo;
            this.name = source;
        }
    }
}
