﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class TacMoveOut3SArea : TacBase
    {
        private int OutDefFrame = 0;
        private double OutDefMoveTime = 0.2;
        public TacMoveOut3SArea(GameInfo gameInfo, string source)
            :base(gameInfo, source)
        {
            this.OutDefFrame = TimeFrameConverter.GetFrame( ParameterManager.Instance.GetValueD(ParameterEnum.Def3SecondOut) / 1000 );
        }

        public void Do(Player player)
        {
            GameTask gt = new GameTask(this.name);

            gt.TaskType = TaskType.PlayerMoveTo;
            //目标位置，出3秒区最近的点
            gt.TargetPos = gameInfo.AttackTeam.AttackField.GetOutOf3SAreatNearestPos(player.Pos);
            gt.StartPos = player.Pos;

            int speedLevel = SpeedManager.Instance.GetSpeedNormal(player, this.gameInfo.RandomSpeed());
            gt.FinishFrame = gt.CalcTimeBySpeed(player.GetSpeedByLevel(speedLevel));
            gt.SpeedLevel = speedLevel;
            gt.NextTask = player.GetCurTask().NextTask;
            gt.RecordPos = player.GetCurTask().RecordPos;
            gt.DelayStart = 0;
            player.SetCurrentTask(gt);
        }

        /// <summary>
        /// 是否执行出防守三秒
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public bool IsNeedOutDef3S(Player player)
        {
            if (player.Def3SecondFrame >= this.OutDefFrame)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 防守球员出防守3秒
        /// </summary>
        /// <param name="defPlayer"></param>
        /// <param name="atkPlayer"></param>
        public void DefPlayerDo(Player defPlayer, Player atkPlayer)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;


            int speedLevel = SpeedManager.Instance.GetSpeedNormal(defPlayer, this.gameInfo.RandomSpeed());
            double speed = defPlayer.GetSpeedInPixelByLevel(speedLevel);

            //获取移动目标点，向进攻球员移动0.2秒
            gt.StartPos = defPlayer.Pos.Clone();
            gt.TargetPos = atkPlayer.Pos.Clone();
            gt.FinishFrame = gt.CalcRealTargetTryMyBest(speed, this.OutDefMoveTime);
            gt.DelayStart = 0;
            defPlayer.SetCurrentTask(gt);
        }
    }
}
