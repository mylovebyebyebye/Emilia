﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class TacPickRoll : TacBase
    {
        private TacStandby tacStandBy;
        private TacFoul tacFoul;
        private TacAttackBasket tacAttackBasket;
        public TacPickRoll(GameInfo gameInfo, string source)
            : base(gameInfo, source)
        {
            this.tacStandBy = new TacStandby(this.gameInfo, this.name);
            this.tacFoul = new TacFoul(this.gameInfo, this.name);
            this.tacAttackBasket = new TacAttackBasket(this.gameInfo, this.name);
        }

        /// <summary>
        /// 挡拆
        /// </summary>
        /// <param name="handler">持球人</param>
        /// <param name="coverPlayer">掩护人</param>
        /// <param name="defHandler">持球人防守人</param>
        /// <param name="defCoverPlayer">掩护人防守人</param>
        public void Do(Player handler, Player coverPlayer, Player defHandler, Player defCoverPlayer)
        {
            int maxSpaceOutFrame = this.GetSpaceOutMaxFrame(handler);

            //持球人行动
            Position handlerTarget = this.GetPickRollHanlderTarget(coverPlayer, defHandler);
            this.HanlderPickRoll(handler, handlerTarget, maxSpaceOutFrame);

            //持球人防守人行动
            bool isDefHandlerNeedChangeDef = this.IsDefHandlerNeedChangeDef(defHandler, coverPlayer);
            Position getRidPos = this.GetPickRollDefHandlerGetRidPos(coverPlayer, handlerTarget);
            double getRidTime = this.GetRidOfTime(defHandler, coverPlayer);
            this.DefHandlerPickRoll(defHandler, coverPlayer, getRidPos, getRidTime, isDefHandlerNeedChangeDef, maxSpaceOutFrame);

            //掩护人行动
            this.CoverPlayerPickRoll(coverPlayer, defHandler, handler, handlerTarget, getRidTime, isDefHandlerNeedChangeDef, maxSpaceOutFrame);

            //掩护人防守人行动
            if (defCoverPlayer != null)
            {
                this.DefCoverPlayerPickRoll(defCoverPlayer, handler, isDefHandlerNeedChangeDef, maxSpaceOutFrame);
            }

            //增加了无球进攻人的移动
            for (int i = 0; i < handler.OwnerTeam.PlayerCount; i++)
            {
                Player otherAtker = handler.OwnerTeam.Players[i];
                if (!otherAtker.IsSamePlayer(handler) &&
                    !otherAtker.IsSamePlayer(coverPlayer))
                {
                    this.OtherAkterPickRoll(otherAtker, handler, handlerTarget);
                }
            }      
        }

        /// <summary>
        /// 获取现在处于拉开状态的球员中，要完成拉开需要的最长帧数
        /// </summary>
        /// <param name="handler"></param>
        /// <returns></returns>
        private int GetSpaceOutMaxFrame(Player handler)
        {
            int maxFrame = 0;
            for (int i = 0; i < handler.OwnerTeam.PlayerCount; i++)
            {
                Player otherPlayer = handler.OwnerTeam.Players[i];
                if (!handler.IsSamePlayer(otherPlayer))
                {
                    if (otherPlayer.GetCurTask().TaskType == TaskType.PlayerMoveToSpaceOut)
                    {
                        if (otherPlayer.GetCurTask().FinishFrame > maxFrame)
                        {
                            maxFrame = otherPlayer.GetCurTask().FinishFrame;
                        }
                    }
                }
            }
            return maxFrame;
        }

        /// <summary>
        /// 计算持球人目标点
        /// </summary>
        /// <param name="handler"></param>
        /// <param name="cover"></param>
        /// <param name="defHandler"></param>
        /// <returns></returns>
        private Position GetPickRollHanlderTarget(Player cover, Player defHandler)
        {
            //【目标点】，垂直于掩护人篮筐的直线，和以掩护人为圆心，半径466号参数的圆的交点
            //选择离持球人防守人远的交点
            int radius = ParameterManager.Instance.GetValue(ParameterEnum.PickRollHanlderTargetRadius);

            Vector2D v = new Vector2D(cover.Pos, cover.OwnerTeam.AttackBasket);
            double angle = v.GetSlopeAngle();
            double angle1 = angle + 90;
            double angle2 = angle - 90;

            Position p1 = cover.Pos.GetPosByAngleRadius(angle1, radius);
            Position p2 = cover.Pos.GetPosByAngleRadius(angle2, radius);

            double dis1 = p1.Distance(defHandler.Pos);
            double dis2 = p2.Distance(defHandler.Pos);

            if (dis1 > dis2)
            {
                return p1;
            }
            return p2;
        }

        /// <summary>
        /// 根据掩护人和持球人目标点
        /// 计算持球人防守人摆脱点位置
        /// </summary>
        /// <param name="cover"></param>
        /// <param name="handlerTarget"></param>
        /// <returns></returns>
        private Position GetPickRollDefHandlerGetRidPos(Player cover, Position handlerTarget)
        {
            int radius = ParameterManager.Instance.GetValue(ParameterEnum.PickRollArea2);

            //【摆脱点】，垂直于掩护人与持球人目标点直线，和以掩护人为圆心，半径452号参数的圆的交点
            Vector2D v = new Vector2D(cover.Pos, handlerTarget);
            double angle = v.GetSlopeAngle();
            double angleTarget = angle;
            int random = this.gameInfo.RandomNext(1, 2);
            if (random == 1)
            {
                angleTarget += 90;
            }
            else
            {
                angleTarget -= 90; 
            }

            Position p1 = cover.Pos.GetPosByAngleRadius(angleTarget, radius);

            return p1;
        }

        /// <summary>
        /// 持球人运动 
        /// </summary>
        /// <param name="maxSpaceOutFrame"></param>
        private void HanlderPickRoll(Player handler,Position handlerTarget, int maxSpaceOutFrame)
        {
            if (maxSpaceOutFrame > 0)
            {
                //等待拉开结束
                this.tacStandBy.DoMoveInSituByFrame(handler, maxSpaceOutFrame);
            }
            //向目标点移动
            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(handler, this.gameInfo.RandomSpeed());

            double speed = handler.GetSpeedByLevel(speedLevel);

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveToFinishPickRoll;
            gt.StartPos = handler.Pos;
            gt.TargetPos = handlerTarget;
            gt.SpeedLevel = speedLevel;
            gt.FinishFrame = gt.CalcTimeBySpeed(speed);

            if (maxSpaceOutFrame > 0)
            {
                handler.NextTask.Add(gt);
            }
            else
            {
                handler.SetCurrentTask(gt);
            }

            GameTask gtAttackBasket = this.tacAttackBasket.GetAttackBasketTask(handler, handlerTarget);
            handler.NextTask.Add(gtAttackBasket);
        }

        /// <summary>
        /// 持球人防守人是否换防
        /// </summary>
        /// <param name="defHandler"></param>
        /// <param name="coverPlayer"></param>
        /// <returns></returns>
        private bool IsDefHandlerNeedChangeDef(Player defHandler, Player coverPlayer)
        {
            double coverPickRollAttr = coverPlayer.GetAttribute(PlayerAttribute.PickRoll);
            double param507 = ParameterManager.Instance.GetValueD(ParameterEnum.PickRollChangeDefParam1);
            double speed = defHandler.GetAttribute(PlayerAttribute.Speed) / ParameterManager.Instance.GetValue(ParameterEnum.SpeedCoefficient);
            double param508 = ParameterManager.Instance.GetValueD(ParameterEnum.PickRollChangeDefParam2);
            double param509 = ParameterManager.Instance.GetValueD(ParameterEnum.PickRollChangeDefParam3);
            double param489 = ParameterManager.Instance.GetValueD(ParameterEnum.PickRollChangeDefParam4);

            ZDBTable tacDefTable = ZDataManager.Instance.GetTacticDefensiveTable();
            ZDB_Row_Data rowData = tacDefTable.getDataByID((int)ETacticDef.BaseDef);
            double tacChange = rowData.getCol((int)tactic_defensiveFields.PickRollBallDefenceChange).getValueInt() * 1.0f;

            double pro = (coverPickRollAttr + param507) / (speed + param508) / param509 + tacChange / param489;
            pro = pro * 10000;
            if (pro > this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }

        private double GetRidOfTime(Player defHandler, Player coverPlayer)
        {
            double param458 = ParameterManager.Instance.GetValueD(ParameterEnum.PickRollGetRidParam1);
            double param459 = ParameterManager.Instance.GetValueD(ParameterEnum.PickRollGetRidParam2);
            double param460 = ParameterManager.Instance.GetValueD(ParameterEnum.PickRollGetRidParam3);
            double param2 = ParameterManager.Instance.GetValueD(ParameterEnum.SpeedCoefficient);

            double seconds = (coverPlayer.GetAttribute(PlayerAttribute.PickRoll) + param458) / (defHandler.GetAttribute(PlayerAttribute.Speed) / param2 + param459) * param460 / 1000;
            return (double)seconds;
        }

        /// <summary>
        /// 持球人防守人行动
        /// </summary>
        /// <param name="defHandler">持球人防守人</param>
        /// <param name="coverPlayer">掩护人</param>
        /// <param name="getRidTarget">摆脱点</param>
        /// <param name="isDefHandlerNeedChangeDef">是否换防</param>
        /// <param name="maxSpaceOutFrame">拉开时间</param>
        private void DefHandlerPickRoll(Player defHandler, Player coverPlayer, Position getRidTarget,double seconds, bool isDefHandlerNeedChangeDef, int maxSpaceOutFrame)
        {
            if (maxSpaceOutFrame > 0)
            {
                //等待拉开结束
                this.tacStandBy.DoMoveInSituByFrame(defHandler, maxSpaceOutFrame);
            }
            GameTask gtNext = null;
            double reactionSeconds = defHandler.GetAttribute(PlayerAttribute.React) / 1000;
            if (isDefHandlerNeedChangeDef)
            {
                //转换防守对象
                //待机反应时间
                defHandler.SetMyPosAttacker(coverPlayer);
                gtNext = this.tacStandBy.GetMoveInSituBySecondsTask(defHandler, reactionSeconds);
            }
            else
            {
                //延迟移动到摆脱点
                //计算过去的时间
                gtNext = new GameTask(this.name);
                gtNext.TaskType = TaskType.PlayerMoveTo;
                gtNext.StartPos = defHandler.Pos;
                gtNext.TargetPos = getRidTarget;
                gtNext.FinishFrame = gtNext.CalcFrameByTime(seconds);
                gtNext.DelayStart = TimeFrameConverter.GetFrame(reactionSeconds);

                double speed = gtNext.TargetPos.Distance(gtNext.StartPos) / seconds;
                gtNext.SpeedLevel = defHandler.GetSpeedLevelByRealSpeed( Position.GetPix(speed));
            }

            if (maxSpaceOutFrame > 0)
            {
                defHandler.NextTask.Add(gtNext);
            }
            else
            {
                defHandler.SetCurrentTask(gtNext);
            }
        }

        /// <summary>
        /// 掩护人行动
        /// </summary>
        /// <param name="coverPlayer">掩护人</param>
        /// <param name="defHandler">持球人防守人</param>
        /// <param name="getRidSeconds">持球人防守人摆脱时间</param>
        /// <param name="isDefHandlerNeedChangeDef">是否换防</param>
        /// <param name="maxSpaceOutFrame">拉开人帧数</param>
        private void CoverPlayerPickRoll(Player coverPlayer, Player defHandler, Player handler, Position handlerTarget,double getRidSeconds, bool isDefHandlerNeedChangeDef, int maxSpaceOutFrame)
        {
            if (maxSpaceOutFrame > 0)
            {
                //等待拉开结束
                this.tacStandBy.DoMoveInSituByFrame(coverPlayer, maxSpaceOutFrame);
            }
            if (isDefHandlerNeedChangeDef)
            {
                //换防了，重新选择事件
                coverPlayer.ClearTask();
                return;
            }
            double reactionMis = defHandler.GetAttribute(PlayerAttribute.React);
            double getRidMis = getRidSeconds * 1000;
            double randomSeconds = this.gameInfo.RandomNext((int)reactionMis, (int)getRidMis) * 1.0f / 1000;
            bool isFoul = false;
            //进攻犯规
            if (this.tacFoul.IsFoul(EFoulType.PickAndRollAtkFoul, coverPlayer, defHandler))
            {
                this.gameInfo.AddPersoanlBoxScore(coverPlayer, BoxScoreType.AttackFoulOnPickRoll, 1);

                //延迟触发
                GameEvent ge = new GameEvent(GameEventType.Foul);
                ge.Param1 = (int)FoulType.AttackFoul;
                ge.Param2 = 2;
                ge.Param4 = defHandler;
                ge.Param5 = coverPlayer;
                ge.StartFrame = this.gameInfo.Frame + maxSpaceOutFrame + TimeFrameConverter.GetFrame(randomSeconds);
                this.gameInfo.AddGameEvent(ge);

                isFoul = true;
            }
            else if (this.tacFoul.IsFoul(EFoulType.PickAndRollDefFoul, coverPlayer, defHandler))
            {
                this.gameInfo.AddPersoanlBoxScore(defHandler, BoxScoreType.FoulOnPickRoll, 1);

                //延迟触发
                GameEvent ge = new GameEvent(GameEventType.Foul);
                ge.Param1 = (int)FoulType.Normal;
                ge.Param2 = 2;
                ge.Param4 = coverPlayer;
                ge.Param5 = defHandler;
                ge.StartFrame = this.gameInfo.Frame + maxSpaceOutFrame + TimeFrameConverter.GetFrame(randomSeconds);
                this.gameInfo.AddGameEvent(ge);

                isFoul = true;
            }
            if (isFoul)
            {
                //直接待机就行了
                if (maxSpaceOutFrame > 0)
                {
                    GameTask gt = this.tacStandBy.GetMoveInSituBySecondsTask(coverPlayer, randomSeconds);
                    coverPlayer.NextTask.Add(gt);
                }
                else
                {
                    this.tacStandBy.DoMoveInSituBySeconds(coverPlayer, randomSeconds);
                }
            }
            else
            {
                //待机
                double standByTime = defHandler.GetAttribute(PlayerAttribute.React) / 1000 + getRidSeconds;
                if (maxSpaceOutFrame > 0)
                {
                    GameTask gt = this.tacStandBy.GetMoveInSituBySecondsTask(coverPlayer, standByTime);
                    coverPlayer.NextTask.Add(gt);
                }
                else
                {
                    this.tacStandBy.DoMoveInSituBySeconds(coverPlayer, standByTime);
                }
                Position p1 = Position.Empty;
                //跑位
                if (this.IsToMove(handler, coverPlayer, EPickRollMoveType.CoverToJump3P))
                {
                    p1 = this.GetMovePos(coverPlayer, handler, handlerTarget, EPickRollMoveType.CoverToJump3P);
                }
                else if (this.IsToMove(handler, coverPlayer, EPickRollMoveType.CoverToJump2P))
                {
                    p1 = this.GetMovePos(coverPlayer, handler, handlerTarget, EPickRollMoveType.CoverToJump2P);
                }
                else
                {
                    p1 = this.GetMovePos(coverPlayer, handler, handlerTarget, EPickRollMoveType.CoverToInside);
                }
                if (p1 != Position.Empty)
                {
                    //向目标点移动
                    int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(coverPlayer, this.gameInfo.RandomSpeed());

                    double speed = coverPlayer.GetSpeedByLevel(speedLevel);

                    GameTask gt = new GameTask(this.name);
                    gt.TaskType = TaskType.PlayerMoveTo;
                    gt.StartPos = coverPlayer.Pos;
                    gt.TargetPos = p1;
                    gt.SpeedLevel = speedLevel;
                    gt.FinishFrame = gt.CalcTimeBySpeed(speed);

                    coverPlayer.NextTask.Add(gt);
                }
            }
        }

        /// <summary>
        /// 是否进行某个类型的移动
        /// </summary>
        /// <param name="player"></param>
        /// <param name="moveType"></param>
        /// <returns></returns>
        private bool IsToMove(Player handler, Player player, EPickRollMoveType moveType)
        {
            ZDBTable moveTable = ZDataManager.Instance.GetPickRollMoveTable();
            ZDB_Row_Data rowData = moveTable.getDataByID((int)moveType);

            //是否需要判断与持球人的距离
            int needCalcDis = rowData.getCol((int)pickroll_moveFields.Distance).getValueInt();
            if (needCalcDis == 1)
            {
                int value4 = rowData.getCol((int)pickroll_moveFields.Value4).getValueInt();
                double dis = this.gameInfo.DisManager.GetDistanceInCMToSameTeamPlayer(this.gameInfo.Frame, player, handler);
                //double dis = handler.Pos.DistanceActualLength(player.Pos);
                if (dis > value4)
                {
                    //距离太远，不用动
                    return false;
                }
            }

            int foundation = rowData.getCol((int)pickroll_moveFields.Foundation).getValueInt();
            if (foundation > 0)
            {
                //需要计算某个属性是否大于某个值
                double attFoundation = player.GetAttrByIndex(foundation);
                int value1 = rowData.getCol((int)pickroll_moveFields.Value1).getValueInt();
                if (attFoundation < value1)
                {
                    return false;
                }
            }

            int attrType = rowData.getCol((int)pickroll_moveFields.Probability).getValueInt();
            if (attrType > 0)
            {
                //需要进行一个公式计算
                double attrValue2 = player.GetAttrByIndex(attrType);
                int value2 = rowData.getCol((int)pickroll_moveFields.Value2).getValueInt();
                double pro = attrValue2 / value2 * 10000;
                if (pro < this.gameInfo.RandomNext())
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 获取跑位移动位置
        /// </summary>
        /// <param name="player"></param>
        /// <param name="moveType"></param>
        /// <returns></returns>
        private Position GetMovePos(Player player,Player handler, Position handlerTarget,EPickRollMoveType moveType)
        {
            Position p1 = Position.Empty;

            ZDBTable moveTable = ZDataManager.Instance.GetPickRollMoveTable();
            ZDB_Row_Data rowData = moveTable.getDataByID((int)moveType);

            int type = rowData.getCol((int)pickroll_moveFields.Type).getValueInt();
            if (type == 1)
            {
                //根据表计算
                int movePoint = rowData.getCol((int)pickroll_moveFields.MovePoint).getValueInt();
                double radius = rowData.getCol((int)pickroll_moveFields.Value5).getValueInt() * 1.0f;
                if(movePoint == 1)
                {
                    //2分
                    p1 = this.GetTorMidShotPos(player, handler, handlerTarget, radius);
                }
                else if(movePoint == 2)
                {
                    //3分
                    p1 = this.GetToJump3PPos(player, handler, handlerTarget, radius);
                }
            }
            else if (type == 2)
            {
                //用playebook
                int playbookId = rowData.getCol((int)pickroll_moveFields.Value1).getValueInt();
                p1 = player.OwnerTeam.AttackField.CourtZoneManager.GetNearestCourtZonePosByBookId(playbookId, player, this.gameInfo.RandomNext());
            }
            return p1;
        }


        /// <summary>
        /// 3分跑位目标点
        /// </summary>
        /// <param name="coverPlayer"></param>
        /// <param name="handler"></param>
        /// <returns></returns>
        private Position GetToJump3PPos(Player player, Player handler, Position handlerTarget, double radius)
        {
            Position p1 = Position.Empty;
            double radiusInPixel = Position.GetPix(radius);

            Position pos1, pos2;
            int count = Formula.FindCircleCircleIntersections(player.Pos, radiusInPixel, player.OwnerTeam.AttackBasket, player.OwnerTeam.AttackField.TopOfTheCircle3PDistance, out pos1, out pos2);
            if (count == 1)
            {
                p1 = pos1;
            }
            if (count == 2)
            {
                double dis1 = handlerTarget.Distance(pos1);
                double dis2 = handlerTarget.Distance(pos2);
                if (dis1 > dis2)
                {
                    p1 = pos1;
                }
                else
                {
                    p1 = pos2;
                }
            }
            return p1;
        }

        /// <summary>
        /// 中距离跳投目标点
        /// </summary>
        /// <param name="coverPlayer"></param>
        /// <param name="handler"></param>
        /// <returns></returns>
        private Position GetTorMidShotPos(Player player, Player handler, Position handlerTarget, double radius)
        {
            //掩护人到篮筐的直线，与，以篮筐为圆心，半径491号参数的圆交点
            //以该交点为圆心，半径491号参数的圆，与，垂直掩护人到篮筐直线的交点
            Position p1 = Position.Empty;
            double radiusInPixel = Position.GetPix(radius);
            Position basket = handler.OwnerTeam.AttackBasket;
            Position p2 = Formula.ClosestIntersection(basket, radiusInPixel, player.Pos, basket);
            if (p2 != Position.Empty)
            {
                Vector2D v = new Vector2D(player.Pos, basket);
                double angle = v.GetSlopeAngle();
                double angle1 = angle + 90;
                double angle2 = angle - 90;

                Position p3 = p2.GetPosByAngleRadius(angle1, (int)radius);
                Position p4 = p2.GetPosByAngleRadius(angle2, (int)radius);

                double dis1 = handlerTarget.Distance(p3);
                double dis2 = handlerTarget.Distance(p4);
                if (dis1 > dis2)
                {
                    p1 = p3;
                }
                else
                {
                    p1 = p4;
                }
            }
            return p1;
        }

        /// <summary>
        /// 掩护人防守人行动
        /// </summary>
        /// <param name="defCoverPlayer"></param>
        /// <param name="handler"></param>
        /// <param name="isDefHandlerNeedChangeDef"></param>
        private void DefCoverPlayerPickRoll(Player defCoverPlayer, Player handler, bool isDefHandlerNeedChangeDef, int maxSpaceOutFrame)
        {
            if (isDefHandlerNeedChangeDef)
            {
                //持球人换防了，我必定换
                defCoverPlayer.SetMyPosAttacker(handler);
            }
            else
            {
                //如果持球人防守人没换防， 掩护人防守人有可能换， 变成两人都去扑持球人
                double param490 = ParameterManager.Instance.GetValueD(ParameterEnum.PickRollChangeDefParam5);
                double defIQ = defCoverPlayer.GetAttribute(PlayerAttribute.DefenceIQ);
                double pro = defIQ / param490 * 10000;

                if (pro > this.gameInfo.RandomNext())
                {
                    //我也换防
                    defCoverPlayer.SetMyPosAttacker(handler);
                }
            }
            double reactionSeconds = defCoverPlayer.GetAttribute(PlayerAttribute.React) / 1000;
            if (maxSpaceOutFrame > 0)
            {
                //等待拉开结束
                this.tacStandBy.DoMoveInSituByFrame(defCoverPlayer, maxSpaceOutFrame);
                GameTask gt = this.tacStandBy.GetMoveInSituBySecondsTask(defCoverPlayer, reactionSeconds);
                defCoverPlayer.NextTask.Add(gt);
            }
            else
            {
                this.tacStandBy.DoMoveInSituBySeconds(defCoverPlayer, reactionSeconds);
            }
        }

        /// <summary>
        /// 其他进攻人
        /// </summary>
        /// <param name="handler"></param>
        /// <param name="handlerTarget"></param>
        private void OtherAkterPickRoll(Player otherAtker, Player handler, Position handlerTarget)
        {
            Position p1 = Position.Empty;
            //跑位
            if (this.IsToMove(handler, otherAtker, EPickRollMoveType.OtherAtkToJump3P))
            {
                p1 = this.GetMovePos(otherAtker, handler, handlerTarget, EPickRollMoveType.OtherAtkToJump3P);
            }
            else if (this.IsToMove(handler, otherAtker, EPickRollMoveType.OtherAktToJump2P))
            {
                p1 = this.GetMovePos(otherAtker, handler, handlerTarget, EPickRollMoveType.OtherAktToJump2P);
            }
            else
            {
                return;
            }

            if (p1 != Position.Empty)
            {
                //向目标点移动
                int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(otherAtker, this.gameInfo.RandomSpeed());

                double speed = otherAtker.GetSpeedByLevel(speedLevel);

                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.PlayerMoveTo;
                gt.StartPos = otherAtker.Pos;
                gt.TargetPos = p1;
                gt.SpeedLevel = speedLevel;
                gt.FinishFrame = gt.CalcTimeBySpeed(speed);

                otherAtker.SetCurrentTask(gt);
            }
        }
    }
}
