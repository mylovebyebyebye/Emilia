﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic.Tactical
{
    public class TacBallMoveToPlayer : TacBase
    {
        public TacBallMoveToPlayer(GameInfo gameInfo, string source):
            base(gameInfo, source)
        {
        }

        public void Do(Player player, double seconds)
        {
            int finishFrame = TimeFrameConverter.GetFrame(seconds);
            GameTask task = new GameTask(this.name);
            task.TaskType = TaskType.PlayerStandby;
            task.FinishFrame = finishFrame;
            for (int i = 0; i < GameInfo.TeamCount; i++)
            {
                Team team = this.gameInfo.Teams[i];
                for (int j = 0; j < team.PlayerCount; j++)
                {
                    Player p = team.Players[j];
                    if (!p.IsSamePlayer(player))
                    {
                        p.SetCurrentTask(task);
                    }
                }
            }

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerToGetPassBall;
            gt.TargetPos = player.Pos;
            gt.FinishFrame = finishFrame;
            player.SetCurrentTask(gt);

            GameTask ballTask = new GameTask(this.name);
            ballTask.TaskType = TaskType.BallPassBall;
            ballTask.TargetPlayer = player;
            ballTask.TargetPos = player.Pos;
            ballTask.StartPos = this.gameInfo.Ball.Pos;
            ballTask.DelayStart = 1;
            ballTask.Success = true;
            ballTask.FinishFrame = ballTask.CalcFrameByTime(seconds);

            this.gameInfo.Ball.SetCurrentTask(ballTask);
        }
    }
}
