﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class TacThrowIn : TacBase
    {
        public TacThrowIn(GameInfo gameInfo, string source):
            base(gameInfo, source)
        {
        }

        /// <summary>
        /// 是否在安全接球区域
        /// </summary>
        /// <param name="player"></param>
        /// <param name="ballPos"></param>
        /// <returns></returns>
        public bool IsInSafeArea(Player player, Position ballPos)
        {
            //在接球区域内 或者 在接球安全区域内
            //在接球区域内
            Position throwInPos = ballPos;
            double Radius = ParameterManager.Instance.GetValue(ParameterEnum.DisToGetThrowIn);
            double disToThrowIn = throwInPos.DistanceActualLength(player.Pos);
            if (disToThrowIn <= Radius)
            {
                return true;
            }
            //接球安全区域内没有防守球员
            double safeGetBallRadius = Formula.GetSafeGetBallRadius(player, throwInPos);
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player def = this.gameInfo.DefTeam.Players[i];
                double dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, player, def);
                //double dis = def.Pos.DistanceActualLength(player.Pos);
                if (Formula.IsDisInPermissibleError(dis, safeGetBallRadius))
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 获取移动要球位置
        /// </summary>
        /// <param name="player"></param>
        /// <param name="ballPos"></param>
        /// <returns></returns>
        public Position GetAskBallPos(Player player, Position ballPos)
        {
            double Radius = ParameterManager.Instance.GetValue(ParameterEnum.DisToGetThrowIn);

            Position p1 = Formula.ClosestIntersection(ballPos, Position.GetPix(Radius), player.Pos, ballPos);
            return p1;
        }

    }
}
