﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    /// <summary>
    /// 背打被包夹了
    /// </summary>
    public class TacInsideAtkDoubled : TacBase
    {
        private TacSteal tacSteal;
        private TacFoul tacFoul;
        public TacInsideAtkDoubled(GameInfo gameInfo, string source)
            : base(gameInfo, source)
        {
            this.tacSteal = new TacSteal(this.gameInfo, this.name);
            this.tacFoul = new TacFoul(this.gameInfo, this.name);
        }

        /// <summary>
        /// 是否发生任何事件
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <returns></returns>
        public bool IsAnyEventsHappened(Player atkPlayer)
        {
            List<Player> lstPlayer = this.GetEffectiveDefPlayers(atkPlayer);

            for (int i = 0; i < lstPlayer.Count; i++)
            {
                Player defPlayer = lstPlayer[i];
                bool happened = false;
                if (this.tacFoul.IsFoul(EFoulType.DoubledAtkFoul, atkPlayer, defPlayer))
                {
                    this.gameInfo.AddPersoanlBoxScore(atkPlayer, BoxScoreType.AttackFoulOnDoubled, 1);

                    GameEvent ge = new GameEvent(GameEventType.Foul);
                    ge.Param1 = (int)FoulType.AttackFoul;
                    ge.Param2 = 2;
                    ge.Param4 = defPlayer;
                    ge.Param5 = atkPlayer;
                    this.gameInfo.AddGameEvent(ge);

                    happened = true;
                }
                else if (this.tacFoul.IsFoul(EFoulType.DoubledDefFoul, atkPlayer, defPlayer))
                {
                    this.gameInfo.AddPersoanlBoxScore(defPlayer, BoxScoreType.FoulOnDoubled, 1);

                    GameEvent ge = new GameEvent(GameEventType.Foul);
                    ge.Param1 = (int)FoulType.Normal;
                    ge.Param2 = 2;
                    ge.Param4 = atkPlayer;
                    ge.Param5 = defPlayer;

                    this.gameInfo.AddGameEvent(ge);

                    happened = true;
                }
                else if (this.tacSteal.IsSteal(EStealSource.InsideAtkDoubled, atkPlayer, defPlayer))
                {
                    this.gameInfo.AddPersoanlBoxScore(defPlayer, BoxScoreType.StealInsideAtkDoubled, 1);

                    //抢断
                    GameEvent ge = new GameEvent(GameEventType.Steal);
                    ge.Param1 = (int)EStealSource.InsideAttack;
                    ge.Param4 = atkPlayer;
                    ge.Param5 = defPlayer;
                    this.gameInfo.AddGameEvent(ge);

                    happened = true;
                }
                else if (this.IsInsideShot(atkPlayer, defPlayer))
                {
                    GameEvent ge = new GameEvent(GameEventType.InsideShot);
                    ge.Param4 = defPlayer;
                    ge.Param5 = atkPlayer;
                    this.gameInfo.AddGameEvent(ge);

                    happened = true;
                }
                if (happened)
                {
                    return true;
                }
            }

            return false;
        }

        private List<Player> GetEffectiveDefPlayers(Player atkPlayer)
        {
            List<Player> lst = new List<Player>();
            double maxDis = ParameterManager.Instance.GetValueD(ParameterEnum.InsideAtkDoubledMaxDis);
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player defPlayer = this.gameInfo.DefTeam.Players[i];
                double dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, atkPlayer, defPlayer);
                //double dis = defPlayer.Pos.DistanceActualLength(atkPlayer.Pos);
                if (Formula.IsDisInPermissibleError(dis, maxDis))
                {
                    lst.Add(defPlayer);
                }
            }
            return lst;
        }


        private bool IsInsideShot(Player atkPlayer, Player defPlayer)
        {
            double param445 = ParameterManager.Instance.GetValueD(ParameterEnum.InsideAtkDoubledShotParam2);
            double param430 = ParameterManager.Instance.GetValueD(ParameterEnum.InsideAtkDoubledShotParam1);

            double pro = (param445 - atkPlayer.GetAttribute(PlayerAttribute.ShotIQ) - defPlayer.GetAttribute(PlayerAttribute.Block)) / param430;
            pro = pro * 10000;
            if (pro > this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }
    }
}
