﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity.BattleLogic;
using Entity;

namespace BattleLogic
{
    public class SubstitutePlayer
    {
        public Player Player;
        public int Type;

        public SubstitutePlayer(Player player, int type)
        {
            this.Player = player;
            this.Type = type;
        }
    }


    public class TacSubstitute : TacBase
    {
        private ZDBTable subsTypeTable;
        private ZDBTable subsTypeConditionTable;
        private ZDBTable subsTable;
        private ZDBTable subsCondtionTable;

        /// <summary>
        /// 按常规时间、关键时刻、垃圾时间分类
        /// </summary>
        private List<List<ZDB_Row_Data>> lstSubstitution;

        public TacSubstitute(GameInfo gameInfo, string source)
            : base(gameInfo, source)
        {
            this.subsTypeTable = ZDataManager.Instance.GetSubsTypeTable();
            this.subsTypeConditionTable = ZDataManager.Instance.GetSubsTypeConditionTable();
            this.subsTable = ZDataManager.Instance.GetSubsTable();
            this.subsCondtionTable = ZDataManager.Instance.GetSubsConditionTable();

            this.lstSubstitution = new List<List<ZDB_Row_Data>>();

            this.Init();
        }

        private void Init()
        {
            //把换人条件分组，减少之后的遍历次数
            for(int i = 0; i < this.subsTypeTable.getRowCount();i++)
            {
                this.lstSubstitution.Add(new List<ZDB_Row_Data>());
            }
            int rowCount = this.subsTable.getRowCount();
            for (int i = 0; i < rowCount; i++)
            {
                ZDB_Row_Data rowData = this.subsTable.getDataByRow(i);
                int changeType = rowData.getCol((int)substitutionFields.ChangeType).getValueInt();
                this.lstSubstitution[changeType - 1].Add(rowData);
            }
        }


        public void Do(Player playerCanNotSubstitution = null)
        {
            this.ChangeGameStatus();

            bool isSubs = this.DoTeam(this.gameInfo.HomeTeam, playerCanNotSubstitution);
            isSubs =  this.DoTeam(this.gameInfo.AwayTeam, playerCanNotSubstitution) | isSubs;
            if (isSubs)
            {
                this.gameInfo.TeamRaingMgr.CalcTeamRaingAndAddPlayerAttr(this.gameInfo);
            }
        }

        /// <summary>
        /// 看要不要切状态
        /// </summary>
        private void ChangeGameStatus()
        {
            int curStatus = (int)this.gameInfo.GameStatus;
            ZDB_Row_Data rowData = this.subsTypeTable.getDataByID(curStatus);
            for (int i = 0; i < 2; i++)
            {
                //只有2种转换情况
                int changeToStatus = rowData.getCol((int)substitution_typeFields.ChangeOther1 + i * 2).getValueInt();
                int condition = rowData.getCol((int)substitution_typeFields.ChangeOther1 + i*2 + 1).getValueInt();
                if (changeToStatus > 0)
                {
                    ZDB_Row_Data changeCondition = this.subsTypeConditionTable.getDataByID(condition);
                    bool needChange = true;
                    for (int j = 0; j < 2; j++)
                    {
                        int typeCondition = changeCondition.getCol((int)substitution_type_conditionFields.Condition1 + j * 3).getValueInt();
                        if (typeCondition > 0)
                        {
                            int typeSymbol = changeCondition.getCol((int)substitution_type_conditionFields.Symbol1 + j * 3).getValueInt();
                            int typeValue = changeCondition.getCol((int)substitution_type_conditionFields.Value1 + j * 3).getValueInt();
                            int curValue = 0;
                            switch (typeCondition)
                            {
                                case 1:
                                    {
                                        //比赛进行了多久
                                        curValue = (int)TimeFrameConverter.ConvertFrameToSecond(this.gameInfo.GameFrame);
                                    }
                                    break;
                                case 2:
                                    {
                                        //第四节之后，当节剩余时间
                                        if (this.gameInfo.Quarter >= 4)
                                        {
                                            curValue = (int)this.gameInfo.QuarterTime;
                                        }
                                        else
                                        {
                                            curValue = int.MaxValue;
                                        }
                                    }
                                    break;
                                case 3:
                                    {
                                        //分差
                                        curValue = Math.Abs(this.gameInfo.GetTotalPoint(TeamType.Home) - this.gameInfo.GetTotalPoint(TeamType.Away));
                                    }
                                    break;
                                default:
                                    break;
                            }
                            switch (typeSymbol)
                            {
                                case 1:
                                    {
                                        if (curValue >= typeValue)
                                        {
                                            needChange = needChange & true;
                                        }
                                        else
                                        {
                                            needChange = false;
                                        }
                                    }
                                    break;
                                case 2:
                                    {
                                        if (curValue < typeValue)
                                        {
                                            needChange = needChange & true;
                                        }
                                        else
                                        {
                                            needChange = false;
                                        }
                                    }
                                    break;
                            }
                            if (!needChange)
                            {
                                break;
                            }
                        }
                    }
                    if (needChange)
                    {
                        this.gameInfo.GameStatus = (EGameStatus)changeToStatus;
                        if (this.gameInfo.GameStatus == EGameStatus.CrutchTime)
                        {
                            //进入关键时刻，刷新一下两边队伍的最强阵容
                            this.RefreshMaxAbilityPlayers(this.gameInfo.HomeTeam);
                            this.RefreshMaxAbilityPlayers(this.gameInfo.AwayTeam);
                        }
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// 计算最强阵容
        /// </summary>
        /// <param name="team"></param>
        private void RefreshMaxAbilityPlayers(Team team)
        {
            Roster roster = team.GetRoster();
            roster.ClearMaxAbilityPlayers();

            List<Player> lstAllPlayer = new List<Player>();
            lstAllPlayer.AddRange(team.Players);
            lstAllPlayer.AddRange(team.BenchPlayers);


            if (lstAllPlayer.Count < 5)
            {
                return;
            }

            lstAllPlayer.Sort(TacSubstitute.CompareAblityPG);
            roster.MaxAbilityPlayers[0] = lstAllPlayer[0].Id;
            lstAllPlayer.RemoveAt(0);

            lstAllPlayer.Sort(TacSubstitute.CompareAblitySG);
            roster.MaxAbilityPlayers[1] = lstAllPlayer[0].Id;
            lstAllPlayer.RemoveAt(0);

            lstAllPlayer.Sort(TacSubstitute.CompareAblitySF);
            roster.MaxAbilityPlayers[2] = lstAllPlayer[0].Id;
            lstAllPlayer.RemoveAt(0);

            lstAllPlayer.Sort(TacSubstitute.CompareAblityPF);
            roster.MaxAbilityPlayers[3] = lstAllPlayer[0].Id;
            lstAllPlayer.RemoveAt(0);

            lstAllPlayer.Sort(TacSubstitute.CompareAblityC);
            roster.MaxAbilityPlayers[4] = lstAllPlayer[0].Id;
            lstAllPlayer.RemoveAt(0);
        }

        /// <summary>
        /// 每个队开始看自己要不要换
        /// </summary>
        /// <param name="team"></param>
        private bool DoTeam(Team team, Player playerCanNotSubstitution)
        {
            List<ZDB_Row_Data> lstCondition = this.lstSubstitution[(int)this.gameInfo.GameStatus - 1];
            List<SubstitutePlayer> needSubstutionPlayers = this.GetNeedSubstutionPlayers(team, playerCanNotSubstitution, lstCondition);

            bool isSubs = this.DoTeamByNeedSubstitutionPlayers(team, playerCanNotSubstitution, needSubstutionPlayers);

            if (isSubs)
            {
                //2016.12.30修改，跑两遍换人流程
                needSubstutionPlayers = this.GetNeedSubstutionPlayers(team, playerCanNotSubstitution, lstCondition);
                if ( needSubstutionPlayers.Count > 0 )
                {
                    this.DoTeamByNeedSubstitutionPlayers(team, playerCanNotSubstitution, needSubstutionPlayers);
                }
            }
            

            return isSubs;
        }

        /// <summary>
        /// 换人的具体过程
        /// </summary>
        /// <param name="team"></param>
        /// <param name="playerCanNotSubstitution"></param>
        /// <param name="needSubstutionPlayers"></param>
        /// <returns></returns>
        private bool DoTeamByNeedSubstitutionPlayers(Team team, Player playerCanNotSubstitution, List<SubstitutePlayer> needSubstutionPlayers)
        {
            if (needSubstutionPlayers.Count == 0)
            {
                return false;
            }
            List<Player> benchPlayers = team.BenchPlayers;

            bool isSubs = false;
            Roster roster = team.GetRoster();
            for (int i = 0; i < 5; i++)
            {
                //从最优先的条件开始遍历所有人
                List<SubstitutePlayer> lstChangePlayer = new List<SubstitutePlayer>();
                for (int j = 0; j < needSubstutionPlayers.Count; j++)
                {
                    Player player = needSubstutionPlayers[j].Player;
                    Player enterPlayer;
                    int type = needSubstutionPlayers[j].Type;
                    ZDB_Row_Data rowData = this.subsTable.getDataByID(type);

                    int enterId = rowData.getCol((int)substitutionFields.Turn1 + i * 2).getValueInt();
                    int enterCondition = rowData.getCol((int)substitutionFields.Turn1Condition + i * 2).getValueInt();
                    bool isChange = this.GetEnterPlayer(enterId, enterCondition, team, roster, benchPlayers, player, out enterPlayer);
                    if (isChange)
                    {
                        //换人
                        this.DoSubstitution(team, player, enterPlayer);

                        lstChangePlayer.Add(needSubstutionPlayers[j]);
                        isSubs = true;
                        //没人可换了
                        //if (benchPlayers.Count == 0)
                        //{
                        //    break;
                        //}
                    }
                }
                for (int j = 0; j < lstChangePlayer.Count; j++)
                {
                    //从待换下名单里移除
                    needSubstutionPlayers.Remove(lstChangePlayer[j]);
                }
                if (needSubstutionPlayers.Count == 0 )
                {
                    //判断还有人没换 或 有没有替补
                    break;
                }
            }
            return isSubs;     
        }

        /// <summary>
        /// 根据下场的人，选择上场的人
        /// </summary>
        /// <returns></returns>
        private bool GetEnterPlayer(int enterId, int enterCondition,Team team,Roster roster,List<Player> benchPlayers,  Player offSitePlayer, out Player enterPlayer)
        {
            enterPlayer = null;
            bool isGetPlayer = false;
            int roleIndex = offSitePlayer.Role - 1;
            switch (enterId)
            {
                case 1:
                    {
                        //玩家设置的主力
                        Player starter = team.GetPlayerById(roster.Starters[roleIndex]);
                        if (benchPlayers.Contains(starter))
                        {
                            enterPlayer = starter;
                            isGetPlayer = true;
                        }
                    }
                    break;
                case 2:
                    {
                        //玩家设置的替补1
                        long id = roster.BenchPlayers[roleIndex];
                        if (id > 0)
                        {
                            Player subsPlayer = team.GetPlayerById(id);
                            if (benchPlayers.Contains(subsPlayer))
                            {
                                enterPlayer = subsPlayer;
                                isGetPlayer = true;
                            }
                        }
                    }
                    break;
                case 3:
                    {
                        if (benchPlayers.Count > 0)
                        {
                            switch (offSitePlayer.Role)
                            {
                                case (int)PlayerRole.PG:
                                    {
                                        benchPlayers.Sort(TacSubstitute.CompareAblityPG);
                                    }
                                    break;
                                case (int)PlayerRole.SG:
                                    {
                                        benchPlayers.Sort(TacSubstitute.CompareAblitySG);
                                    }
                                    break;
                                case (int)PlayerRole.SF:
                                    {
                                        benchPlayers.Sort(TacSubstitute.CompareAblitySF);
                                    }
                                    break;
                                case (int)PlayerRole.PF:
                                    {
                                        benchPlayers.Sort(TacSubstitute.CompareAblityPF);
                                    }
                                    break;
                                case (int)PlayerRole.C:
                                    {
                                        benchPlayers.Sort(TacSubstitute.CompareAblityC);
                                    }
                                    break;
                            }
                            //该位置场下现在最厉害的
                            enterPlayer = benchPlayers[0];
                            isGetPlayer = true;
                        }
                    }
                    break;
#region 被取消掉的换人方式
                                    //case 5:
                //    {
                //        //玩家设置的替补2
                //        long id = roster.BenchPlayers2nd[roleIndex];
                //        if (id > 0)
                //        {
                //            Player subsPlayer = team.GetPlayerById(id);
                //            if (benchPlayers.Contains(subsPlayer))
                //            {
                //                enterPlayer = subsPlayer;
                //                isGetPlayer = true;
                //            }
                //        }
                //    }
                //    break;
#endregion
                case 4:
                    {
                        //最强阵容
                        long id = roster.MaxAbilityPlayers[roleIndex];
                        if (id > 0)
                        {
                            Player subsPlayer = team.GetPlayerById(id);
                            if (benchPlayers.Contains(subsPlayer))
                            {
                                enterPlayer = subsPlayer;
                                isGetPlayer = true;
                            }
                        }
                    }
                    break;
                case 6:
                    {
                        //球迷
                        enterPlayer = team.CreateAFans(this.gameInfo);
                        isGetPlayer = true;
                    }
                    break;
                case 7:
                    {
                        //后备大名单
                        bool isGet2nrBench = team.GetBench2rdPlayer(offSitePlayer.Role, out enterPlayer);
                        if (isGet2nrBench)
                        {
                            isGetPlayer = true;
                        }
                    }
                    break;
                    
            }
            if (isGetPlayer)
            {
                //是否满足换上条件
                enterPlayer.Role = offSitePlayer.Role;
                isGetPlayer = this.IsNeedChange(enterPlayer, team, enterCondition);
            }
            return isGetPlayer;
        }

        /// <summary>
        /// 获取需要被换下的人列表
        /// </summary>
        /// <param name="team"></param>
        /// <param name="playerCanNotSubstitution"></param>
        /// <param name="lstCondition"></param>
        /// <returns></returns>
        private List<SubstitutePlayer> GetNeedSubstutionPlayers(Team team, Player playerCanNotSubstitution, List<ZDB_Row_Data> lstCondition)
        {
            List<SubstitutePlayer> needSubstutionPlayers = new List<SubstitutePlayer>();
            for (int i = 0; i < team.PlayerCount; i++)
            {
                //每个人都要遍历所有条件
                //看是否需要换人
                for (int j = 0; j < lstCondition.Count; j++)
                {
                    Player player = team.Players[i];
                    ZDB_Row_Data rowData = lstCondition[j];
                    if (playerCanNotSubstitution == null || !player.IsSamePlayer(playerCanNotSubstitution))
                    {
                        int changeCondition = rowData.getCol((int)substitutionFields.ChangeCondition).getValueInt();
                        if (this.IsNeedChange(player, team, changeCondition))
                        {
                            //符合换人条件，还要进行随机
                            int chanceType = rowData.getCol((int)substitutionFields.ChanceType).getValueInt();
                            int value5 = rowData.getCol((int)substitutionFields.Value).getValueInt();
                            //todo 没加SubstitutionIntensity
                            double pro = value5 * 1.0 / 100 * 10000;
                            if (pro >= this.gameInfo.RandomNext())
                            {
                                SubstitutePlayer subPlayer = new SubstitutePlayer(player, rowData.getCol(0).getValueInt());
                                needSubstutionPlayers.Add(subPlayer);
                                break;
                            }
                        }
                    }
                }
            }
            return needSubstutionPlayers;
        }

        /// <summary>
        /// 换人的一些操作
        /// </summary>
        /// <param name="team"></param>
        /// <param name="offSitePlayer"></param>
        /// <param name="enterPlayer"></param>
        private void DoSubstitution(Team team, Player offSitePlayer, Player enterPlayer)
        {
            enterPlayer.Pos.X = offSitePlayer.Pos.X;
            enterPlayer.Pos.Y = offSitePlayer.Pos.Y;

            enterPlayer.Role = offSitePlayer.Role;
            if (team.BenchPlayers.Contains(enterPlayer))
            {
                team.BenchPlayers.Remove(enterPlayer);
            }
            //判换下的人是否已经满犯
            if (offSitePlayer.Foul < 6)
            {
                team.BenchPlayers.Add(offSitePlayer);
            }
            //下场的人当前speedlevel设为0，用来恢复体力
            if (offSitePlayer.GetCurTask() != null)
            {
                offSitePlayer.GetCurTask().SpeedLevel = 0;
            }

            team.Players[enterPlayer.Role - 1] = enterPlayer;

            PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.Substitution, (int)team.TeamType, enterPlayer.Id, offSitePlayer.Id);
            this.gameInfo.AddGameInfo(pc);
        }

        /// <summary>
        /// 这里是是否换人真正的判断
        /// </summary>
        /// <param name="player"></param>
        /// <param name="team"></param>
        /// <param name="rowData"></param>
        /// <returns></returns>
        private bool IsNeedChange(Player player, Team team, int changeCondition)
        {
            bool needChange = true;
            if(changeCondition > 0)
            {
                ZDB_Row_Data rowCondition = this.subsCondtionTable.getDataByID(changeCondition);
                //每个condition又是由两个子条件组成
                for (int j = 0; j < 2; j++)
                {
                    int index = (int)substitution_conditionFields.Condition1 + 3 * j;
                    int condition = rowCondition.getCol(index).getValueInt();
                    if (condition > 0)
                    {
                        int symbol = rowCondition.getCol(index + 1).getValueInt();
                        int value = rowCondition.getCol(index + 2).getValueInt();
                        needChange = needChange & this.IsNeedChangeCondition(team, player, condition, symbol, value);
                        if (!needChange)
                        {
                            break;
                        }
                    }
                }
            }
            
            return needChange;
        }

        /// <summary>
        /// 根据不同条件判断是否需要下场
        /// </summary>
        /// <param name="team"></param>
        /// <param name="player"></param>
        /// <param name="condition"></param>
        /// <param name="symbol"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        private bool IsNeedChangeCondition(Team team, Player player, int condition, int symbol, int value)
        {
            bool needChange = false;
            int curValue = 0;
            switch (condition)
            {
                case 1:
                    {
                        curValue = player.Foul - this.gameInfo.Quarter;
                    }
                    break;
                case 2:
                    {
                        curValue = (int)(player.CurStamina / player.MaxStamina * 100);
                    }
                    break;
                case 3:
                    {
                        if (team.GetRoster().Starters.Contains(player.Id))
                        {
                            curValue = 1;
                        }
                        else
                        {
                            curValue = 0;
                        }
                    }
                    break;
                case 4:
                    {
                        if (team.GetRoster().MaxAbilityPlayers.Contains(player.Id))
                        {
                            curValue = 1;
                        }
                        else
                        {
                            curValue = 0;
                        }
                    }
                    break;
                //case 5:
                //    {
                //        double thisQuarterPlayed = TimeFrameConverter.ConvertFrameToSecond(player.ThisQuarterPlayerFrame);
                //        double thisGamePlayered = TimeFrameConverter.ConvertFrameToSecond(Convert.ToInt32(this.gameInfo.GetPersonalBoxScore(team.TeamType, player.RoleID, BoxScoreType.FramePlayed)));
                //        curValue = Convert.ToInt32(thisQuarterPlayed - (player.TotalRegularTime - thisGamePlayered) / (5 - this.gameInfo.Quarter));
                //    }
                //    break;
                case 6:
                    {
                        int FGA = Convert.ToInt32(this.gameInfo.GetPersonalBoxScore(team.TeamType, player.RoleID, BoxScoreType.FGA));
                        curValue = (int)(FGA * 1.0 / this.gameInfo.Quarter);
                    }
                    break;
                case 7:
                    {
                        int FGA = Convert.ToInt32(this.gameInfo.GetPersonalBoxScore(team.TeamType, player.RoleID, BoxScoreType.FGA));
                        int FGM = Convert.ToInt32(this.gameInfo.GetPersonalBoxScore(team.TeamType, player.RoleID, BoxScoreType.FGM));
                        curValue = (int)(FGM * 1.0 / FGA * 100);
                    }
                    break;
                case 8:
                    {
                        curValue = player.Foul;
                    }
                    break;
                //case 9:
                //    {
                //        //判这个位置的首发球员
                //        Roster roster = team.GetRoster();
                //        Player starter = team.GetPlayerById(roster.Starters[player.Role - 1]);
                //        double starterThisGamePlayered = TimeFrameConverter.ConvertFrameToSecond(Convert.ToInt32(this.gameInfo.GetPersonalBoxScore(team.TeamType, starter.RoleID, BoxScoreType.FramePlayed)));
                //        double thisGamePlayered = TimeFrameConverter.ConvertFrameToSecond(Convert.ToInt32(this.gameInfo.GetPersonalBoxScore(team.TeamType, player.RoleID, BoxScoreType.FramePlayed)));
                //        curValue = Convert.ToInt32(2880 - starter.TotalRegularTime - (this.gameInfo.GameTotalTime - starterThisGamePlayered) * 1.0 / (5 - this.gameInfo.Quarter) - thisGamePlayered);
                //    }
                //    break;
                case 10:
                    {
                        //判这个位置的
                        Roster roster = team.GetRoster();
                        Player starter = team.GetPlayerById(roster.Starters[player.Role - 1]);
                        curValue = (int)(starter.CurStamina / starter.MaxStamina * 100);

                    }
                    break;
                case 11:
                    {
                        //当前位置主力是否在场
                        Roster roster = team.GetRoster();
                        Player starter = team.GetPlayerById(roster.Starters[player.Role - 1]);
                        if (team.Players.Contains(starter))
                        {
                            curValue = 1;
                        }
                        else
                        {
                            curValue = 0;
                        }
                    }   
                    break;
            }
            switch (symbol)
            {
                case 1:
                    {
                        if (curValue >= value)
                        {
                            needChange =  true;
                        }
                    }
                    break;
                case 2:
                    {
                        if (curValue < value)
                        {
                            needChange = true;
                        }
                    }
                    break;
            }
            return needChange;
        }

        public static int CompareAblityC(Player p1, Player p2)
        {
            double p1AbilityC = p1.GetAttribute(PlayerAttribute.AbilityC);
            double p2AbilityC = p2.GetAttribute(PlayerAttribute.AbilityC);
            return p2AbilityC.CompareTo(p1AbilityC);
        }

        public static int CompareAblityPF(Player p1, Player p2)
        {
            double p1AbilityPF = p1.GetAttribute(PlayerAttribute.AbilityPF);
            double p2AbilityPF = p2.GetAttribute(PlayerAttribute.AbilityPF);
            return p2AbilityPF.CompareTo(p1AbilityPF);
        }

        public static int CompareAblitySF(Player p1, Player p2)
        {
            double p1AbilitySF = p1.GetAttribute(PlayerAttribute.AbilitySF);
            double p2AbilitySF = p2.GetAttribute(PlayerAttribute.AbilitySF);
            return p2AbilitySF.CompareTo(p1AbilitySF);
        }

        public static int CompareAblitySG(Player p1, Player p2)
        {
            double p1AbilitySG = p1.GetAttribute(PlayerAttribute.AbilitySG);
            double p2AbilitySG = p2.GetAttribute(PlayerAttribute.AbilitySG);
            return p2AbilitySG.CompareTo(p1AbilitySG);
        }

        public static int CompareAblityPG(Player p1, Player p2)
        {
            double p1AbilityPG = p1.GetAttribute(PlayerAttribute.AbilityPG);
            double p2AbilityPG = p2.GetAttribute(PlayerAttribute.AbilityPG);
            return p2AbilityPG.CompareTo(p1AbilityPG);
        }
    }
}
