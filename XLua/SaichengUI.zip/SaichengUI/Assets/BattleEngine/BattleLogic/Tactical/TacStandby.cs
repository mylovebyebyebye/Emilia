﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class TacStandby : TacBase
    {
        public TacStandby(GameInfo gameInfo, string source)
            :base(gameInfo, source)
        {
        }

        public void Do(Player player, int frame)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            gt.FinishFrame = frame;

            player.SetCurrentTask(gt);
        }

        public void Do(Player player, double seconds)
        {
            this.Do(player, TimeFrameConverter.GetFrame(seconds));
        }

        public void DoMoveInSituBySeconds(Player player, double seconds)
        {
            GameTask gt = this.GetMoveInSituBySecondsTask(player, seconds);

            player.SetCurrentTask(gt);
        }

        public void DoMoveInSituByFrame(Player player, int frame)
        {
            GameTask gt = this.GetMoveInSituByFrameTask(player, frame);

            player.SetCurrentTask(gt);
        }

        public GameTask GetMoveInSituBySecondsTask(Player player, double seconds)
        {
            int frame = TimeFrameConverter.GetFrame(seconds);
            GameTask gt = this.GetMoveInSituByFrameTask(player, frame);
            return gt;
        }

        public GameTask GetMoveInSituByFrameTask(Player player, int frame)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = player.Pos;
            gt.TargetPos = player.Pos;
            gt.FinishFrame = frame;

            return gt;
        }

        public void DoForceStandby(Player player, double seconds)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerForceStandBy;
            gt.StartPos = player.Pos;
            gt.FinishFrame = TimeFrameConverter.GetFrame( seconds);

            player.SetCurrentTask(gt);
        }

        public int GetMaxStandbyFrame()
        {
            double maxTime = ParameterManager.Instance.GetValue(ParameterEnum.MaxStandbyTime) * 1.0f / 1000;
            int frame = this.gameInfo.Ball.GetCurTask().FinishFrame;
            if (frame > TimeFrameConverter.GetFrame(maxTime))
            {
                frame = TimeFrameConverter.GetFrame(maxTime);
            }
            return frame;
        }
    }
}
