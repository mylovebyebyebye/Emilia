﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class LayupEvent : BaseGameEventSequenceNode
    {
        TacLayup tac;

        public LayupEvent(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.tac = new TacLayup(this.gameInfo, this.name);
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            this.tac.Do((Player)this.gameInfo.CurEvent.Param4);
            return BehaviourTreeStatus.Success;
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.Layup;
        }
    }
}
