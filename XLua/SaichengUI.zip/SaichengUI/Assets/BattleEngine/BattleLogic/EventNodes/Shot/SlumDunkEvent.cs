﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class SlumDunkEvent : BaseGameEventSequenceNode
    {
        TacSlamDunk tac;

        public SlumDunkEvent(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.tac = new TacSlamDunk(this.gameInfo, this.name);
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            this.gameInfo.ClearEvent();

            this.tac.StartSlamDunk((Player)this.gameInfo.CurEvent.Param4);
            return BehaviourTreeStatus.Success;
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.SlumDunk;
        }
    }
}
