﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class BallHitHoopEvent : BaseGameEventSequenceNode
    {
        TacMoveToReboundPlacement tac;
        public BallHitHoopEvent(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.tac = new TacMoveToReboundPlacement(this.gameInfo, this.name);
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.BallHitHoop;
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            //清3秒
            this.gameInfo.Clear3SecondData();

            Player shooter = this.gameInfo.CurEvent.Param4 as Player;

            //先算球的线路
            this.SetBallLineByHitHoop();

            this.tac.Do(shooter);

            //打筐，重置24秒
            this.gameInfo.StartNewRound();

            return BehaviourTreeStatus.Success;
        }

        private void SetBallLineByHitHoop()
        {
            int angle = this.gameInfo.RandomNext(0, 180);

            Position shotPoint = this.gameInfo.Ball.GetCurTask().StartPos;
            Position basketPos = this.gameInfo.AttackTeam.AttackBasket;
            //先判是长篮板还是短篮板
            double disShotPointToBasket = shotPoint.DistanceActualLength(basketPos);
            int random = this.gameInfo.RandomNext(1, 1000000);
            int disRandom = 0;
            if (disShotPointToBasket <= ParameterManager.Instance.GetValue(ParameterEnum.DisShotPoint1))
            {
                //短篮板
                int rowIndex = ReboundMananger.Instance.GetIndexRandomReb1(random);

                disRandom = ZDataManager.Instance.GetReb1Table().getDataByRow(rowIndex).getCol((int)reb1Fields.Id).getValueInt();
            }
            else
            { 
                //长篮板
                //要根据出手距离算在哪一列
                //先判是不是最后一列
                int colIndex = 0;
                int shotPoint2Start = ParameterManager.Instance.GetValue(ParameterEnum.ShotPoint2Start);
                int shotPoint2End = ParameterManager.Instance.GetValue(ParameterEnum.ShotPoint2End);
                int step = ParameterManager.Instance.GetValue(ParameterEnum.ShotPoint2Step);
                if (disShotPointToBasket >= shotPoint2End)
                {
                    colIndex = (shotPoint2End - shotPoint2Start) / step;
                }
                else
                {
                    colIndex = (int)(disShotPointToBasket - shotPoint2Start) / step;
 
                }
                colIndex += 1;

                int rowIndex = ReboundMananger.Instance.GetIndexRandomReb2(colIndex, random);

                disRandom = ZDataManager.Instance.GetReb2Table().getDataByRow(rowIndex).getCol((int)reb2Fields.Id).getValueInt();
            }
            //转成像素
            disRandom = (int)Position.GetPix(disRandom);

            Position pos = this.gameInfo.AttackTeam.AttackField.GetRandomReboundPosByAngleRadius(angle, disRandom);
            int speed = ParameterManager.Instance.GetValue(ParameterEnum.BallHoopReboundSpeed);

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.BallRebound;
            gt.StartPos = this.gameInfo.Ball.Pos;
            gt.TargetPos = pos;
            gt.FinishFrame = gt.CalcTimeBySpeed(speed);

            this.gameInfo.Ball.SetCurrentTask(gt);
        }

        
    }
}
