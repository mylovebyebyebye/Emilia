﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using BattleLogic.Tactical;
using Common;
using Entity;

namespace BattleLogic
{
    public class JumpBallEvent : BaseGameEventSequenceNode
    {
        private TacBallMoveToPlayer tac;
        private TacCostStamina tacCostStamina;
        private TacSubstitute tacSubs;
        private List<int> lstPrbGetBall = new List<int>();

        public JumpBallEvent(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.lstPrbGetBall.Add(4000);
            this.lstPrbGetBall.Add(4000);
            this.lstPrbGetBall.Add(1000);
            this.lstPrbGetBall.Add(1000);

            this.tac = new TacBallMoveToPlayer(this.gameInfo, this.name);
            this.tacCostStamina = new TacCostStamina(this.gameInfo, this.name);
            this.tacSubs = new TacSubstitute(this.gameInfo, this.name);
        }


        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            this.gameInfo.ClearBallOwner();

            Player player1 = (Player)this.gameInfo.CurEvent.Param4;
            Player player2 = (Player)this.gameInfo.CurEvent.Param5;

            //中圈跳球
            if (this.gameInfo.CurEvent.Param1 == 1)
            {
                if (this.gameInfo.CurEvent.Param2 == (long)EJumpBallType.OverTimeStart)
                {
                    this.tacSubs.Do();
                    player1 = this.gameInfo.HomeTeam.Players[(int)PlayerRole.C - 1];
                    player2 = this.gameInfo.AwayTeam.Players[(int)PlayerRole.C - 1];

                    PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.JumpBallOverTime, this.gameInfo.Quarter - 4, player1.Id, player2.Id);
                    this.gameInfo.AddGameInfo(pc);
                }

                int random = this.gameInfo.RandomNext();

                int value = (int)(player1.GetAttribute(PlayerAttribute.Rebounding) / (player1.GetAttribute(PlayerAttribute.Rebounding) + player2.GetAttribute(PlayerAttribute.Rebounding)) * 10000);

                int randomGetBall = this.gameInfo.RandomNext();
                int iIndex = ProbabilityCalc.GetPosition(this.lstPrbGetBall, randomGetBall);

                if(iIndex == -1)
                {
                    throw new Exception("跳球概率有误");
                }

                Player getBallPlayer;
                if(random <= value)
                {
                    //主队赢
                    getBallPlayer = this.gameInfo.HomeTeam.Players[iIndex];
                    this.gameInfo.StartGameJumpWinTeam = this.gameInfo.HomeTeam;

                    PlayByPlayContent pcWin = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.JumpWin, player1.Id);
                    this.gameInfo.AddGameInfo(pcWin);

                }
                else
                {
                    //客队赢
                    this.gameInfo.StartGameJumpWinTeam = this.gameInfo.AwayTeam;
                    getBallPlayer = this.gameInfo.AwayTeam.Players[iIndex];

                    PlayByPlayContent pcWin = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.JumpWin, player2.Id);
                    this.gameInfo.AddGameInfo(pcWin);
                }
                this.gameInfo.SetBallOwnTeam(getBallPlayer.OwnerTeam);

                this.tac.Do(getBallPlayer, 0.5f);
                //事件处理完毕
                //this.gameInfo.CurEvent = null;
                this.gameInfo.Resume();
            }

            //扣体力
            this.tacCostStamina.Cost(EStaminaCost.JumpBall, player1);
            this.tacCostStamina.Cost(EStaminaCost.JumpBall, player2);

            this.gameInfo.StartNewRound();
            return BehaviourTreeStatus.Success;
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.JumpBall;
        }

    }
}
