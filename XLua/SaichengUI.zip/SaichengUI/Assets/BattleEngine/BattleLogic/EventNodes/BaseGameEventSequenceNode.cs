﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public abstract class BaseGameEventSequenceNode : SequenceNode
    {
        protected GameEventType eventType;

        public BaseGameEventSequenceNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.SetGameEventType();
        }

        protected override void CreateChildNode()
        {
            ConditionNode isMyEvent = new ConditionNode(string.Format("是否{0}", this.name), this.IsMyEvent);
            this.AddChild(isMyEvent);

            ActionNode process = new ActionNode(string.Format("处理{0}事件", this.name), this.ProcessEvent);
            this.AddChild(process);

            ActionNode clearEvent = new ActionNode("事件清除", this.ClearEvent);
            this.AddChild(clearEvent);

        }

        protected virtual bool IsMyEvent(TimeData time)
        {
            if (this.gameInfo.CurEvent != null && this.gameInfo.CurEvent.EventType == this.eventType)
            {
                return true;
            }
            return false;
        }

        protected virtual BehaviourTreeStatus ClearEvent(TimeData time)
        {
            this.gameInfo.ClearSingleAttacker();
            this.gameInfo.ClearCrossOverDeBuff();
            this.gameInfo.CurEvent = null;
            return BehaviourTreeStatus.Success;
        }

        protected abstract BehaviourTreeStatus ProcessEvent(TimeData time);
        protected abstract void SetGameEventType();
    }
}
