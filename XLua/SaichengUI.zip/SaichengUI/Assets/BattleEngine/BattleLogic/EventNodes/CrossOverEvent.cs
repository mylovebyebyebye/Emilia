﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class CrossOverEvent : BaseGameEventSequenceNode
    {
        private TacCrossOver tac;
        private TacSlamDunk tacSlumDunk;
        private TacNewShot tacShot;
        private TacToShot tacToShot;

        public CrossOverEvent(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {

            this.tac = new TacCrossOver(this.gameInfo, this.name);
            this.tacSlumDunk = new TacSlamDunk(this.gameInfo,this.name);
            this.tacShot = new TacNewShot(this.gameInfo, this.name);
            this.tacToShot = new TacToShot(this.gameInfo, this.name);
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            Player atkPlayer = (Player)this.gameInfo.CurEvent.Param4;
            Player defPlayer = (Player)this.gameInfo.CurEvent.Param5;

            //重新计算期望
            atkPlayer.ShotScoringExpect = this.tacShot.GetExpectJumpShot(atkPlayer);
            atkPlayer.CrossOverExpect = this.tacShot.GetExpectCrossOver(atkPlayer);
            atkPlayer.InsideScoringExpect = this.tacShot.GetExpectInsideShot(atkPlayer);

            Field atkField = this.gameInfo.AttackTeam.AttackField;
            double playerArea = ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea) * 1.0f;
            //double disAtk = atkPlayer.Pos.DistanceActualLength(basketPos);
            double disAtk = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, atkField, atkPlayer);
            double disDef = double.MaxValue;
            if (defPlayer != null)
            {
                disDef = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, atkField, defPlayer);
            }
            double dis = double.MaxValue;
            if (defPlayer != null)
            {
                dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, atkPlayer, defPlayer);
                //dis = atkPlayer.Pos.DistanceActualLength(defPlayer.Pos);
            }

            if (this.IsShot(atkPlayer))
            {
                //投篮
                this.JumpShot(atkPlayer);
            }
            else if (this.tacSlumDunk.IsSlamDunk(atkPlayer))
            {
                //扣篮
                GameEvent ge = new GameEvent(GameEventType.SlumDunk);
                ge.Param4 = atkPlayer;
                this.gameInfo.AddGameEvent(ge);
                //this.tacSlumDunk.StartSlamDunk(atkPlayer);
            }
            else if (this.IsLayUp(atkPlayer, disAtk))
            {
                //上篮
                this.tac.DoLayUp(atkPlayer, disAtk);
            }
            else if ( disAtk > disDef && dis <= playerArea )
            {
                //进攻球员远离篮筐，且两人距离小于125参数
                //突破判断
                this.tac.Do(atkPlayer, defPlayer);
            }
            else
            {
                //执行移动任务
                this.SetMoveTask(atkPlayer, defPlayer);
            }

            return BehaviourTreeStatus.Success;        
        }

        private void SetMoveTask(Player atkPlayer, Player defPlayer)
        {
            //进攻任务 移动
            GameTask gtMove = new GameTask(this.name);
            gtMove.TaskType = TaskType.PlayerMoveToCrossOver;
            gtMove.TargetPos = atkPlayer.OwnerTeam.AttackBasket;
            gtMove.StartPos = atkPlayer.Pos;
            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(atkPlayer, this.gameInfo.RandomSpeed());
            double speed = atkPlayer.GetSpeedInPixelByLevel(speedLevel);
            gtMove.FinishFrame = gtMove.CalcRealTargetBySpeedMaxSeconds(ref speed, 0.1f);
            gtMove.SpeedLevel = atkPlayer.GetSpeedLevelByRealSpeed(speed);
            gtMove.TargetPlayer = defPlayer;

            //SpeedManager.Instance.SetMoveTask(this.gameInfo, atkPlayer, gtMove);
            atkPlayer.SetCurrentTask(gtMove);

            //球任务
            this.gameInfo.Ball.GetCurTask().DelayStart = gtMove.DelayStart;
            this.gameInfo.Ball.GetCurTask().FinishFrame = gtMove.FinishFrame;
        }

        /// <summary>
        /// 是否投篮
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        private bool IsShot(Player player)
        {
            double expect = this.gameInfo.GetPlayerExpectHanlder( player);
            if (player.ShotScoringExpect > (player.CrossOverExpect + player.InsideScoringExpect) &&  
                player.ShotScoringExpect > expect)
            {
                double param54 = ParameterManager.Instance.GetValue(ParameterEnum.PullUpBaseCOE) * 1.0f;
                double param55 = ParameterManager.Instance.GetValue(ParameterEnum.PullUpCOE) * 1.0f;
                double param56 = ParameterManager.Instance.GetValue(ParameterEnum.PullUpTimeAdd) * 1.0f;

                double time = param55 - this.gameInfo.CurRoundRemaingTime;
                if (time < 0)
                {
                    time = 0;
                }
                double pro = player.GetAttribute(PlayerAttribute.Pullup) * param54 / 10000 + time * param56 / 100;
                if (pro > 1)
                {
                    pro = 1;
                }
                pro = pro * 10000;
                if (pro > this.gameInfo.RandomNext())
                {
                    return true;
                }
            }
            return false;
        }

        private void JumpShot(Player player)
        {
            ShotType shotType = ShotType.JumpShot2P;
            double disToBasket = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, player.OwnerTeam.AttackField, player);
            if (player.OwnerTeam.AttackField.Is3P(player.Pos, disToBasket))
            {
                shotType = ShotType.JumpShot3P;
            }

            this.tacToShot.DoToShot(shotType, player);

            //GameTask gt = new GameTask(this.name);
            //gt.TaskType = TaskType.PlayerShot;
            //gt.DelayStart = TimeFrameConverter.GetFrame(player.GetAttribute(PlayerAttribute.ShootTime) / 1000);
            //gt.FinishFrame = 1;
            //player.SetCurrentTask(gt);
        }

        private bool IsLayUp(Player player, double disToBasket)
        {
            double maxDis = ParameterManager.Instance.GetValue(ParameterEnum.LayupDistance);
            if (disToBasket <= maxDis)
            {
                return true;
            }
            return false;
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.CrossOver;
        }
    }
}
