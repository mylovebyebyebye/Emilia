﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class AfterTakePosEvent : BaseGameEventSequenceNode
    {
        private TacCostStamina tacCostStamina;
        public AfterTakePosEvent(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacCostStamina = new TacCostStamina(this.gameInfo, this.name);
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            Player player1 = this.gameInfo.CurEvent.Param4 as Player;
            Player player2 = this.gameInfo.CurEvent.Param5 as Player;

            //扣体力
            this.tacCostStamina.Cost(EStaminaCost.TakePosition, player1);
            this.tacCostStamina.Cost(EStaminaCost.TakePosition, player2);

            Player playerStrenthHigh = player1.GetAttribute(PlayerAttribute.Strength) >= player2.GetAttribute(PlayerAttribute.Strength) ? player1 : player2;
            Player playerStrenthLow = player1.GetAttribute(PlayerAttribute.Strength) >= player2.GetAttribute(PlayerAttribute.Strength) ? player2 : player1;

            Field attackField = this.gameInfo.AttackTeam.AttackField;

            //double disToBasket1 = basketPos.DistanceActualLength(playerStrenthHigh.Pos);
            //double disToBasket2 = basketPos.DistanceActualLength(playerStrenthLow.Pos);
            double disToBasket1 = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, attackField, playerStrenthHigh);
            double disToBasket2 = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, attackField, playerStrenthLow);
            if (disToBasket1 < disToBasket2 || (player1.GetAttribute(PlayerAttribute.Strength) - player2.GetAttribute(PlayerAttribute.Strength)) < Formula.MinDifference)
            {
                //进入待机
                this.EnterStandby(player1);
                this.EnterStandby(player2);
            }
            else
            {
                //进入挤,
                //其实就是给两个人一个相同的速度在同一条直线上运动
                this.SetAfterTakeOffMove(playerStrenthHigh, playerStrenthLow, disToBasket1);
            }

            return BehaviourTreeStatus.Success;
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.AfterTakePosition;
        }

        private void EnterStandby(Player player)
        {
            GameTask gt = new GameTask(this.name);
            gt.FinishFrame = this.gameInfo.Ball.GetCurTask().FinishFrame;
            gt.DelayStart = this.gameInfo.Ball.GetCurTask().DelayStart;
            gt.TaskType = TaskType.PlayerTakePosStandby;

            player.SetCurrentTask(gt);
        }

        private void SetAfterTakeOffMove(Player winner, Player loser, double disWinnerToBasket)
        {
            Position basketPos = this.gameInfo.AttackTeam.AttackBasket;

            double speed = Math.Abs(winner.GetAttribute(PlayerAttribute.Strength) - loser.GetAttribute(PlayerAttribute.Strength)) * ParameterManager.Instance.GetValue(ParameterEnum.AfterTakePosMoveSpeedCOE) / 10;
            double speedInPixel = (double)(speed / Position.ActualLengthPerPoint);
            double maxDis = Math.Abs(winner.GetAttribute(PlayerAttribute.Strength) - loser.GetAttribute(PlayerAttribute.Strength)) * ParameterManager.Instance.GetValue(ParameterEnum.AfterTakePosMoveDisCOE) / 10;

            double maxSeconds = TimeFrameConverter.ConvertFrameToSecond(this.gameInfo.Ball.GetCurTask().FinishFrame);

            double RadiusRestrictedArea = ParameterManager.Instance.GetValue(ParameterEnum.RestrictedArea);
            double RadiusPlayerArea = ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea);


            double Radius = 0f;
            if (RadiusPlayerArea > maxDis)
            {
                Radius = (double)maxDis;
            }
            else
            {
                Radius = (double)RadiusPlayerArea;
            }
            Position pWinnerMoveTo = Position.Empty;
            Position pLoserMoveTo = Position.Empty;
            if (disWinnerToBasket > (RadiusRestrictedArea + RadiusPlayerArea))
            {
                pWinnerMoveTo = Formula.ClosestIntersection(winner.Pos, Position.GetPix(Radius), basketPos, winner.Pos);
                pLoserMoveTo = Formula.ClosestIntersection(loser.Pos, Position.GetPix(Radius), basketPos, loser.Pos);
            }
            else if (disWinnerToBasket < (RadiusRestrictedArea - RadiusPlayerArea))
            {
                pWinnerMoveTo = Formula.ClosestIntersection(winner.Pos, Position.GetPix(Radius), basketPos, winner.Pos, true);
                pLoserMoveTo = Formula.ClosestIntersection(loser.Pos, Position.GetPix(Radius), basketPos, loser.Pos, true);
            }
            else
            {
                this.EnterStandby(winner);
                this.EnterStandby(loser);
                return;
            }
            this.AfterTakePosMove(winner, pWinnerMoveTo, speedInPixel, maxSeconds);
            this.AfterTakePosMove(loser, pLoserMoveTo, speedInPixel, maxSeconds);
        }

        private int AfterTakePosMove(Player player, Position target, double speedInPixel, double maxSeconds)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerTakePosMove;
            gt.StartPos = player.Pos;
            gt.TargetPos = target;

            gt.FinishFrame = gt.CalcRealTargetTryMyBest(speedInPixel, maxSeconds);

            player.SetCurrentTask(gt);

            return gt.FinishFrame;
        }
    }
}
