﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class FreeThrowEvent : BaseGameEventSequenceNode
    {
        private TacSubstitute tacSubs;
        public FreeThrowEvent(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.tacSubs = new TacSubstitute(this.gameInfo, this.name);
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.FreeThrow;
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            int type = (int)this.gameInfo.CurEvent.Param3;

            if (type != (int)EFreeThrowType.Technical)
            {
                //24秒重置
                this.gameInfo.StartNewRound();
            }      

            int index = (int)this.gameInfo.CurEvent.Param2;
            Player freeThrower = this.gameInfo.CurEvent.Param4 as Player;
            if (index == 1)
            {
                //换人判断
                this.tacSubs.Do(freeThrower);

                if (type != (int)EFreeThrowType.Technical)
                {
                    //球员落位
                    this.SetPlayerPosition(freeThrower);
                }
                else
                {
                    //违例落位点
                    this.SetTechFreeThrowPlayerPos(freeThrower);
                }
            }
            //球在人手上
            this.SetBallPosition(freeThrower);
            //准备出手，加一个延迟出手事件
            {
                double waitTime = ParameterManager.Instance.GetValue(ParameterEnum.FreeThrowWaitTime) / 1000 * 1.0f;
                GameEvent ge = new GameEvent(GameEventType.FreeThrowShot);
                ge.StartFrame = this.gameInfo.Frame + TimeFrameConverter.GetFrame(waitTime);
                ge.Param4 = freeThrower;
                ge.Param1 = this.gameInfo.CurEvent.Param1;
                ge.Param2 = index;
                ge.Param3 = type;

                this.gameInfo.AddGameEvent(ge);
            }
            return BehaviourTreeStatus.Success;
        }

        private void SetBallPosition(Player freeThrower)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.BallReadyToFreeThrow;
            gt.FinishFrame = int.MaxValue;
            gt.TargetPlayer = freeThrower;

            this.gameInfo.Ball.SetCurrentTask(gt);
        }

        private void SetPlayerPosition(Player freeThrower)
        {
            Field atkField = freeThrower.OwnerTeam.AttackField;
            {
                //罚球人位置
                Position p1 = freeThrower.OwnerTeam.AttackField.GetFreeThrowPos();
                this.SetLocation(freeThrower, p1);
            }
            //防守方位置
            {
                Team defTeam = this.gameInfo.DefTeam;
                //从C到PG
                //第一个球员，放在防守方1或防守方2，等概率
                //第二个球员，剩下的位置
                //第三个球员，防守方3或防守方4，等概率
                int random1 = this.gameInfo.RandomNext(1, 2) - 1;
                int random2 = this.gameInfo.RandomNext(2, 3);
                int random3 = this.gameInfo.RandomNext(4, 5);
                //C
                this.SetLocation(defTeam.Players[(int)PlayerRole.C - 1], atkField.GetFreeThrowDefPos(random1));
                //PF
                this.SetLocation(defTeam.Players[(int)PlayerRole.PF - 1], atkField.GetFreeThrowDefPos(random1 == 0 ? 1 : 0));
                //SF
                this.SetLocation(defTeam.Players[(int)PlayerRole.SF - 1], atkField.GetFreeThrowDefPos(random2));
                //SG
                this.SetLocation(defTeam.Players[(int)PlayerRole.SG - 1], atkField.GetFreeThrowDefPos(random3));
                //PG
                this.SetLocation(defTeam.Players[(int)PlayerRole.PG - 1], atkField.GetFreeThrowDefPos(random3 == 4 ? 5 : 4));
            }
            //进攻方位置
            {
                //第一个球员，放在进攻方1或进攻方2，等概率
                //第二个球员，剩下的位置
                Team atkTeam = this.gameInfo.AttackTeam;
                int count = 0;
                int index = (int)PlayerRole.C - 1;
                int random1 = this.gameInfo.RandomNext(1, 2) - 1;
                int random2 = this.gameInfo.RandomNext(2, 3);
                while (true)
                {
                    Player player = atkTeam.Players[index];
                    if (!player.IsSamePlayer(freeThrower))
                    {
                        count++;
                        if (count == 1)
                        {
                            this.SetLocation(player, atkField.GetFreeThrowAtkPos(random1));
                        }
                        else if (count == 2)
                        {
                            this.SetLocation(player, atkField.GetFreeThrowAtkPos(random1 == 0 ? 1: 0));
                        }
                        else if (count == 3)
                        {
                            this.SetLocation(player, atkField.GetFreeThrowAtkPos(random2));
                        }
                        else
                        {
                            this.SetLocation(player, atkField.GetFreeThrowAtkPos(random2 == 2 ? 3 : 2));
                            break;
                        }
                    }
                    index--;
                }
            }
        }

        private void SetTechFreeThrowPlayerPos(Player freeThrower)
        {
            Field atkField = freeThrower.OwnerTeam.AttackField;
            {
                //罚球人位置
                Position p1 = freeThrower.OwnerTeam.AttackField.GetFreeThrowPos();
                this.SetLocation(freeThrower, p1);
            }
            //防守方位置
            {
                Team defTeam = this.gameInfo.DefTeam;
                for (int i = 0; i < defTeam.Players.Count; i++)
                {
                    Position pos = atkField.GetTechFreeThrowDefPos(i);
                    pos.X += this.gameInfo.RandomNext(-20, 20);
                    pos.Y += this.gameInfo.RandomNext(-20, 20);
                    this.SetLocation(defTeam.Players[i], pos);
                }
            }
            //进攻方位置
            {
                Team atkTeam = this.gameInfo.AttackTeam;
                int index = 0;
                for (int i = 0; i < atkTeam.Players.Count; i++)
                {
                    Player player = atkTeam.Players[i];
                    if (!player.IsSamePlayer(freeThrower))
                    {
                        Position pos = atkField.GetTechFreeThrowAtkPos(index);
                        pos.X += this.gameInfo.RandomNext(-20, 20);
                        pos.Y += this.gameInfo.RandomNext(-20, 20);
                        this.SetLocation(player, pos);
                        index++;
                    }
                }
            }
        }

        private void SetLocation(Player player, Position pos)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerLocation;
            gt.FinishFrame = int.MaxValue;
            gt.StartPos = player.Pos;
            gt.TargetPos = pos;
            gt.DelayStart = 0;

            player.SetCurrentTask(gt);
        }
    }
}
