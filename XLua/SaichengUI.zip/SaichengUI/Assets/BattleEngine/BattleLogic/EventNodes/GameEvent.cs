﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public enum GameEventType
    {
        JumpBall                            = 1,
        //Shot                                = 2,
        CrossOver                           = 3,
        Layup                               = 4,
        AfterTakePosition                   = 5,//抢位后事件
        BallHitHoop                         = 6,//砸到篮筐
        BallShotToThrowIn                   = 7,//进球以后准备去发界外球
        BallShotThrowIn                     = 8,//进球后发界外球事件
        QuarterStartThrowIn                 = 9,//2、3、4节开始的界外球
        BlockShot                           = 10,//投篮盖帽事件
        BlockShotAfter                      = 11,//投篮盖帽后事件
        Foul                                = 12,//犯规
        FreeThrow                           = 13,//准备罚球
        FreeThrowShot                       = 14,//罚球出手
        OutOfBoundToThrowIn                 = 15,//出界准备发界外球
        OutOfBoundThrowIn                   = 16,//出界界外球
        ThrowInIllegal                      = 17,//发球违例
        Steal                               = 18,//抢断
        TurnRound                           = 19,//转身突破
        InsideShot                          = 20,//内线投篮
        FoulToThrowIn                       = 21,//犯规准备发界外球
        FoulThrowIn                         = 22,//犯规界外球
        SlumDunk                            = 23,//扣篮
        //HookShot                            = 24,//勾手投篮
        //FadeAwayShot                        = 25,//后仰出手
        ShotNew                             = 26,//统一出手
    }

    public class GameEvent
    {
        public GameEventType EventType {get; set;}

        public GameEvent(GameEventType type)
        {
            this.EventType = type;
            this.Pos = Position.Empty;
            this.AddIndex = 0;
        }

        public int AddIndex;

        public int Param1 { get; set; }

        public long Param2 { get; set; }

        public long Param3 { get; set; }

        public CourtObject Param4 { get; set; }
        public CourtObject Param5 { get; set; }

        public int StartFrame { get; set; }

        public Position Pos { get; set; }

        public static int CompareStartFrame(GameEvent p1, GameEvent p2)
        {
            if (p1.StartFrame == p2.StartFrame)
            {
                return p1.AddIndex.CompareTo(p2.AddIndex);
            }
            return p1.StartFrame.CompareTo(p2.StartFrame);
        }
    }

}
