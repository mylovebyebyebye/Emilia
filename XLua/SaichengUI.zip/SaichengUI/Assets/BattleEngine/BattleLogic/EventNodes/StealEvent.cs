﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class StealEvent : BaseGameEventSequenceNode
    {
        private TacSteal tacSteal;
        private TacBallOnTheFloor tacBallOnTheFloor;

        public StealEvent(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.tacSteal = new TacSteal(this.gameInfo, this.name);
            this.tacBallOnTheFloor = new TacBallOnTheFloor(this.gameInfo, this.name);
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            EStealSource eSource = (EStealSource)this.gameInfo.CurEvent.Param1;

            Player atkPlayer = this.gameInfo.CurEvent.Param4 as Player;
            Player defPlayer = this.gameInfo.CurEvent.Param5 as Player;

            this.gameInfo.ClearEvent();

            if (this.tacSteal.IsGetBall(eSource, atkPlayer, defPlayer))
            {
                //直接得球
                PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.Steal, defPlayer.Id);
                this.gameInfo.AddGameInfo(pc);

                //重置24秒
                this.gameInfo.StartNewRound();
                this.gameInfo.ResumeCurRound();

                //数据统计
                this.gameInfo.AddPersoanlBoxScore(atkPlayer, BoxScoreType.Stolen, 1);
                this.gameInfo.AddPersoanlBoxScore(defPlayer, BoxScoreType.STL, 1);
                this.gameInfo.AddPersoanlBoxScore(atkPlayer, BoxScoreType.TOV, 1);

                //各方动作
                this.tacSteal.SetGetBallTask(eSource, atkPlayer, defPlayer);
            }
            else
            {
                //捅球
                PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.StealTouchBall, defPlayer.Id);
                this.gameInfo.AddGameInfo(pc);

                ZDBTable stealTable = ZDataManager.Instance.GetStealTable();
                ZDB_Row_Data rowData = stealTable.getDataByID((int)eSource);

                //进入地板球
                //需要计算角度和速度
                int angle = this.tacSteal.GetPokeBallAngle(eSource, atkPlayer, defPlayer);
                int speed = this.tacBallOnTheFloor.GetSpeed(rowData.getCol((int)stealFields.StealPokeBallSpeed).getValueInt());

                //各自后续行为

                int atkBehave = rowData.getCol((int)stealFields.StealPokeBallAttackBehave).getValueInt();
                int defBehave = rowData.getCol((int)stealFields.StealPokeBallDeffenceBehave).getValueInt();

                this.tacBallOnTheFloor.StartBallOnTheFloor(EBallOnTheFloorSourceType.Steal, atkPlayer, atkBehave, defPlayer, defBehave, this.gameInfo.Ball.Pos, angle, speed);
            }

            return BehaviourTreeStatus.Success;
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.Steal;
        }

    }
}
