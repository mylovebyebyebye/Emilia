﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public abstract class BaseGameEventSelectorNode : SelectorNode
    {
        protected GameEventType eventType;

        public BaseGameEventSelectorNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.SetGameEventType();
        }

        protected override void CreateChildNode()
        {
            ConditionNode isMyEvent = new ConditionNode(string.Format("是否{0}", this.name), this.IsMyEvent);
            this.AddChild(isMyEvent);

            ActionNode process = new ActionNode(string.Format("处理{0}事件", this.name), this.ProcessEvent);
            this.AddChild(process);

        }

        protected virtual bool IsMyEvent(TimeData time)
        {
            if (this.gameInfo.CurEvent != null && this.gameInfo.CurEvent.EventType == this.eventType)
            {
                return true;
            }
            return false;
        }

        protected abstract BehaviourTreeStatus ProcessEvent(TimeData time);
        protected abstract void SetGameEventType();
    }
}
