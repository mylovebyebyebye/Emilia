﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using BattleLogic.Tactical;
using Common.ZDB;

namespace BattleLogic
{
    public class StartQuarterThrowIn : BaseGameEventSequenceNode
    {
        private TacJumpball tac;
        private TacSubstitute tacSubs;
        public StartQuarterThrowIn(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.tac = new TacJumpball(this.gameInfo, this.name);
            this.tacSubs = new TacSubstitute(this.gameInfo, this.name);
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            this.gameInfo.Quarter = this.gameInfo.CurEvent.Param1;

            PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.QuarterStart, this.gameInfo.CurEvent.Param1);
            this.gameInfo.AddGameInfo(pc);

            this.gameInfo.StartNewRound();

            //换人
            this.tacSubs.Do();

            //重置防守
            this.gameInfo.ResetPosDef();

            Player playerToThrowIn = null;
            //第2、3节发球方为开场跳球失败的一方，第4节为开场跳球成功的一方
            if (this.gameInfo.Quarter == 4)
            {
                playerToThrowIn = this.gameInfo.StartGameJumpWinTeam.Players[(int)PlayerRole.C - 1];
            }
            else
            {
                playerToThrowIn = this.gameInfo.GetAnotherTeam(this.gameInfo.StartGameJumpWinTeam).Players[(int)PlayerRole.C - 1];
            }

            Player playerToGetBall = playerToThrowIn.OwnerTeam.Players[(int)PlayerRole.PG - 1];

            //设置球的任务
            this.SetBallTask(playerToThrowIn);

            this.tac.Do(this.gameInfo.AttackTeam);
            for (int i = 0; i < this.gameInfo.AttackTeam.PlayerCount; i++)
            {
                Player player = this.gameInfo.AttackTeam.Players[i];
                if (player.GetCurTask().TargetPos != Position.Empty)
                {
                    player.Pos = player.GetCurTask().TargetPos;
                }
            }


            this.tac.Do(this.gameInfo.DefTeam);
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player player = this.gameInfo.DefTeam.Players[i];
                player.ClearLastChoice();
                if (player.GetCurTask().TargetPos != Position.Empty)
                {
                    player.Pos = player.GetCurTask().TargetPos;
                }
            }

            //接球人任务
            this.SetGetBallTask(playerToGetBall);

            //发球人任务
            this.SetThrowInPlayerTask(playerToThrowIn);

            //发球点
            this.gameInfo.Ball.GetCurTask().TargetPos = playerToThrowIn.Pos;

            for (int i = 0; i < GameInfo.TeamCount; i++)
            {
                Team team = this.gameInfo.Teams[i];
                for (int j = 0; j < team.PlayerCount; j++)
                {
                    Player player = team.Players[j];
                    player.GetCurTask().DelayStart = TimeFrameConverter.GetFrame(1.0f);
                }
            }
            
            return BehaviourTreeStatus.Success;
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.QuarterStartThrowIn;
        }

        private void SetGetBallTask(Player player)
        {
            Field defField = this.gameInfo.GetAnotherTeam(player.OwnerTeam).AttackField;

            //随机出现在以发球点为圆心 param173为半径圆内
            Position p1 = Position.Empty;
            while (!defField.IsOnMyEffectiveArea(p1))
            {
                int angel = this.gameInfo.RandomNext(1, 179);
                int Radius = ParameterManager.Instance.GetValue(ParameterEnum.DisToGetThrowIn);
                Position posThrowIn = defField.GetStartQuarterThrowInPos();
                p1 = new Position(posThrowIn.X + (int)(Radius * Math.Sin(Formula.GetRadian(angel))) * defField.PosOrNegX,
                                            posThrowIn.Y + (int)(Radius * Math.Cos(Formula.GetRadian(angel - 90))));
            }

            //只能直接给他定位
            player.Pos = p1;

            GameTask task = new GameTask(this.name);
            task.TargetPos = p1;
            task.TaskType = TaskType.PlayerReadyToBallShotThrowIn;
            task.DelayStart = 0;
            task.FinishFrame = 1;
            player.SetCurrentTask(task);
        }

        public void SetThrowInPlayerTask(Player player)
        {
            Field defField = this.gameInfo.GetAnotherTeam(player.OwnerTeam).AttackField;
            player.Pos = defField.GetStartQuarterThrowInPos();


            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerToThrowIn;
            gt.FinishFrame = TimeFrameConverter.GetFrame(5.0f);

            player.SetCurrentTask(gt);
        }

        public void SetBallTask(Player player)
        {
            this.gameInfo.Ball.Pos = player.Pos;
            this.gameInfo.SetBallOwner(player);
            this.gameInfo.Ball.GetCurTask().TaskType = TaskType.BallOnThePlayer;
            this.gameInfo.Ball.GetCurTask().TargetPlayer = player;
            this.gameInfo.Ball.GetCurTask().FinishFrame = Int32.MaxValue;
        }
    }
}
