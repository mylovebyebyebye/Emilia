﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class BallShotThrowIn : ThrowInBaseEvent
    {
        public BallShotThrowIn(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.BallShotThrowIn;
        }

        protected override TaskType GetPlayerTask()
        {
            return TaskType.PlayerReadyToBallShotThrowIn;
        }
    }
}
