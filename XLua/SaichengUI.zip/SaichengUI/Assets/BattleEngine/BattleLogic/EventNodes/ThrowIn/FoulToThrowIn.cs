﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class FoulToThrowIn : ToThrowInBaseEvent
    {
        private TacSubstitute tacSubs;
        public FoulToThrowIn(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.tacSubs = new TacSubstitute(this.gameInfo, this.name);
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.FoulToThrowIn;
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            this.gameInfo.ClearEvent();

            //所有人3秒清零
            this.gameInfo.Clear3SecondData();

            //换人
            this.tacSubs.Do();

            //篮球隐形
            this.SetBallTask(GameEventType.FoulThrowIn);
            
            //设置发球点
            Position throwInPos = this.GetThrowInPos(this.gameInfo.CurEvent.Param4 as Player);

            this.gameInfo.Ball.GetCurTask().TargetPos = throwInPos;

            //计时暂停
            this.gameInfo.Pause();

            //给防守方分角色
            this.SetDefTeamTask(TaskType.PlayerAfterBallShot);

            //计算发球人，给进攻方分角色
            Player playerToThrowIn = null;
            double minDis = double.MaxValue;

            for (int i = 0; i < this.gameInfo.AttackTeam.PlayerCount; i++)
            {
                Player player = this.gameInfo.AttackTeam.Players[i];
                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.PlayerAfterBallShot;
                gt.DelayStart = 0;
                gt.FinishFrame = 0;
                player.SetCurrentTask(gt);
                if (player.Role != (int)PlayerRole.PG)
                {
                    double dis = throwInPos.Distance(player.Pos);
                    if (dis < minDis)
                    {
                        minDis = dis;
                        playerToThrowIn = player;
                    }
                }
            }

            //设置发球人
            this.SetThrowInPlayerTask(playerToThrowIn, TaskType.PlayerAfterBallShotToThrowIn);
            return BehaviourTreeStatus.Success;
        }

        /// <summary>
        /// 发球点
        /// </summary>
        /// <param name="fouledPlayer"></param>
        /// <returns></returns>
        private Position GetThrowInPos(Player fouledPlayer)
        {
            Position p1 = Position.Empty;
            if (this.gameInfo.LeftField.IsOnMyEffectiveArea(fouledPlayer.Pos))
            {
                p1 = this.gameInfo.LeftField.GetFoulThrowInPos(fouledPlayer.Pos);
            }
            else
            {
                p1 = this.gameInfo.RightField.GetFoulThrowInPos(fouledPlayer.Pos);
            }
            return p1;
        }
    }
}
