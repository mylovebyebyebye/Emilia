﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 进球以后
    /// 准备去发界外球的事件
    /// </summary>
    public class BallShotToThrowIn : ToThrowInBaseEvent
    {
        private TacSubstitute tacSubs;
        public BallShotToThrowIn(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.tacSubs = new TacSubstitute(this.gameInfo, this.name);
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            int type = this.gameInfo.CurEvent.Param1;

            this.gameInfo.ClearEvent();

            int reason = (int)this.gameInfo.CurEvent.Param2;
            if (reason == (int)EBallShotThrowInReason.ShotClockVio ||
                reason == (int)EBallShotThrowInReason.ThrowInVio)
            {
                this.tacSubs.Do();
            }

            //篮球隐形s
            this.SetBallTask(GameEventType.BallShotThrowIn);

            //设置攻方、守方
            if (type != (int)EFreeThrowType.Technical)
            {
                this.gameInfo.ClearBallOwner();
                this.gameInfo.SetBallOwnTeam(this.gameInfo.GetAnotherTeam(this.gameInfo.AttackTeam));
            }

            //计时暂停
            this.gameInfo.Pause();

            //给所有人分角色
            this.SetDefTeamTask(TaskType.PlayerAfterBallShot);

            Player playerToThrowIn = null;
            int minDis = Int32.MaxValue;

            for (int i = 0; i < this.gameInfo.AttackTeam.PlayerCount; i++)
            {
                Player player = this.gameInfo.AttackTeam.Players[i];
                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.PlayerAfterBallShot;
                gt.DelayStart = 0;
                gt.FinishFrame = 0;
                player.SetCurrentTask(gt);
                if (player.Role != (int)PlayerRole.PG)
                {
                    int dis = this.gameInfo.DefTeam.AttackField.GetDistanceToBottomLine(player.Pos);
                    if (dis < minDis)
                    {
                        minDis = dis;
                        playerToThrowIn = player;
                    }
                }
            }

            //设置发球人
            //离底线最近的非PG
            this.SetThrowInPlayerTask(playerToThrowIn, TaskType.PlayerAfterBallShotToThrowIn);

            //发球点
            Position throwInPos = this.gameInfo.CurEvent.Pos;
            if (throwInPos == Position.Empty)
            {
                throwInPos = this.gameInfo.DefTeam.AttackField.GetBottomLineThrowInPos(this.gameInfo.Ball.GetCurTask().TargetPlayer.Pos);
            }
            this.gameInfo.Ball.GetCurTask().TargetPos = throwInPos;


            return BehaviourTreeStatus.Success;
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.BallShotToThrowIn;
        }


    }
}
