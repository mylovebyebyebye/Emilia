﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class FoulThrowIn : ThrowInBaseEvent
    {
        public FoulThrowIn(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.FoulThrowIn;
        }

        protected override TaskType GetPlayerTask()
        {
            return TaskType.PlayerReadyToBallShotThrowIn;
        }
    }
}
