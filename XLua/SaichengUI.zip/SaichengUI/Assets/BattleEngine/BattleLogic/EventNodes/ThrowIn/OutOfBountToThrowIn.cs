﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class OutOfBountToThrowIn : ToThrowInBaseEvent
    {
        private TacSubstitute tacSubs;
        public OutOfBountToThrowIn(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.tacSubs = new TacSubstitute(this.gameInfo, this.name);
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.OutOfBoundToThrowIn;
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            this.gameInfo.ClearEvent();

            if (this.gameInfo.CurEvent.Param1 == 1)
            {
                PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.OutOfBound, 0);
                this.gameInfo.AddGameInfo(pc);
            }

            this.tacSubs.Do();

            //所有人3秒清零
            this.gameInfo.Clear3SecondData();

            //篮球隐形
            this.SetBallTask(GameEventType.OutOfBoundThrowIn);
            //设置发球点
            this.gameInfo.Ball.GetCurTask().TargetPos = this.gameInfo.CurEvent.Pos;

            //计时暂停
            this.gameInfo.Pause();

            //给防守方分角色
            this.SetDefTeamTask(TaskType.PlayerAfterBallShot);

            //计算发球人，给进攻方分角色
            Player playerToThrowIn = null;
            double minDis = double.MaxValue;
            for (int i = 0; i < this.gameInfo.AttackTeam.PlayerCount; i++)
            {
                Player player = this.gameInfo.AttackTeam.Players[i];
                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.PlayerAfterBallShot;
                gt.DelayStart = 0;
                gt.FinishFrame = 0;
                player.SetCurrentTask(gt);
                if (player.Role != (int)PlayerRole.PG)
                {
                    double dis = this.gameInfo.CurEvent.Pos.Distance(player.Pos);
                    if (dis < minDis)
                    {
                        minDis = dis;
                        playerToThrowIn = player;
                    }
                }
            }

            //设置发球人
            //离底线最近的非PG
            this.SetThrowInPlayerTask(playerToThrowIn, TaskType.PlayerAfterBallShotToThrowIn);
            if(this.gameInfo.CurEvent.Param2 == (int)EFreeThrowType.Technical)
            {
                //违例发球，慢慢去
                playerToThrowIn.GetCurTask().Param1 = (int)EFreeThrowType.Technical;
            }

            return BehaviourTreeStatus.Success;
        }


    }
}
