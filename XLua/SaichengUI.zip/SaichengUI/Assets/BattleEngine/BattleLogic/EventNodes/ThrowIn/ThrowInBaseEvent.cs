﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public abstract class ThrowInBaseEvent : BaseGameEventSequenceNode
    {
        protected abstract TaskType GetPlayerTask();

        public ThrowInBaseEvent(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            //篮球现形
            this.SetBallTask();

            //所有人清空任务
            this.gameInfo.SetAllPlayerTask(this.GetPlayerTask(), 0, this.name,0);
            //设置发球人任务
            this.SetThrowInPlayerTask();

            return BehaviourTreeStatus.Success;
        }

        protected override void SetGameEventType()
        {
            throw new NotImplementedException();
        }

        protected void SetBallTask()
        {
            this.gameInfo.Ball.GetCurTask().TaskType = TaskType.BallOnThePlayer;
            Player player = this.gameInfo.CurEvent.Param4 as Player;
            this.gameInfo.Ball.SetOwner(player);
            this.gameInfo.Ball.Pos = this.gameInfo.Ball.Owner.Pos;
            this.gameInfo.Ball.GetCurTask().TargetPos = this.gameInfo.Ball.Owner.Pos;
            this.gameInfo.Ball.GetCurTask().FinishFrame = int.MaxValue;
        }

        protected void SetThrowInPlayerTask()
        {
            Player player = this.gameInfo.CurEvent.Param4 as Player;

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerToThrowIn;
            gt.FinishFrame = TimeFrameConverter.GetFrame(5.0f);

            player.SetCurrentTask(gt);
        }
    }
}
