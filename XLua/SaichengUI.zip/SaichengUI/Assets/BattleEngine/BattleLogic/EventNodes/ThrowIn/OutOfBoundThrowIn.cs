﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class OutOfBoundThrowIn : ThrowInBaseEvent
    {
        public OutOfBoundThrowIn(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.OutOfBoundThrowIn;
        }

        protected override TaskType GetPlayerTask()
        {
            return TaskType.PlayerReadyToBallShotThrowIn;
        }
    }
}
