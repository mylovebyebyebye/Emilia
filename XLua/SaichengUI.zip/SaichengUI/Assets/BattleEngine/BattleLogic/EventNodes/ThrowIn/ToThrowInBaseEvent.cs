﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class ToThrowInBaseEvent : BaseGameEventSequenceNode
    {
        public ToThrowInBaseEvent(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            throw new NotImplementedException();
        }

        protected override void SetGameEventType()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// 
        /// </summary>
        protected void SetBallTask(GameEventType nextEventType)
        {
            this.gameInfo.ClearBallOwner();
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.BallHiding;
            gt.FinishFrame = Int32.MaxValue;
            gt.DelayStart = TimeFrameConverter.GetFrame(Player.MaxDefRelationTime);
            gt.Param1 = (int)nextEventType;
            this.gameInfo.Ball.SetCurrentTask(gt);
        }

        protected void SetDefTeamTask(TaskType taskType)
        {
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player player = this.gameInfo.DefTeam.Players[i];

                GameTask gt = new GameTask(this.name);
                gt.TaskType = taskType;
                gt.DelayStart = 0;
                gt.FinishFrame = 0;
                player.SetCurrentTask(gt);
            }
        }

        protected void SetThrowInPlayerTask(Player player, TaskType taskType)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = taskType;
            gt.DelayStart = 0;
            gt.FinishFrame = 0;
            player.SetCurrentTask(gt);


            this.gameInfo.Ball.GetCurTask().TargetPlayer = player;
        }
    }
}
