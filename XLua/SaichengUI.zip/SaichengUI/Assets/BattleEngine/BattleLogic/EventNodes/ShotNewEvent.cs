﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{

    public class ShotNewEvent : BaseGameEventSequenceNode
    {
        TacNewShot tac;
        TacFillIn tacFillIn;

        public ShotNewEvent(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.tac = new TacNewShot(this.gameInfo, this.name);
            this.tacFillIn = new TacFillIn(this.gameInfo, this.name);
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            Player shooter = this.gameInfo.CurEvent.Param4 as Player;
            ShotType shotType = (ShotType)this.gameInfo.CurEvent.Param1;
            this.tac.Shot(shooter, shotType);

            //重新选择
            this.tacFillIn.ChooseDefAgain(shooter);

            return BehaviourTreeStatus.Success;
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.ShotNew;
        }
    }
}
