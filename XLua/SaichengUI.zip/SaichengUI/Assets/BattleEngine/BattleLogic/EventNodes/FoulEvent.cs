﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public enum FoulType
    {
        Normal   = 1,
        ShotFoul = 2,
        AttackFoul = 3,
    }

    public class FoulEvent : BaseGameEventSequenceNode
    {
        public FoulEvent(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {

        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.Foul;
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            this.gameInfo.Pause();

            this.gameInfo.ClearEvent();

            //所有人待机
            this.gameInfo.SetAllPlayerTask(TaskType.PlayerStandby, int.MaxValue, this.name);
            this.gameInfo.ClearBallOwner();

            //重置盯防
            this.gameInfo.ResetPosDef();

            //所有人3秒清零
            this.gameInfo.Clear3SecondData();

            //直播
            this.AddInfo();

            FoulType foulType = (FoulType)this.gameInfo.CurEvent.Param1;
            int points = (int)this.gameInfo.CurEvent.Param2;
            Player fouledPlayer = this.gameInfo.CurEvent.Param4 as Player;
            Player foulPlayer = this.gameInfo.CurEvent.Param5 as Player;

            if (foulType == FoulType.AttackFoul)
            {
                this.AttackFoul(foulPlayer, fouledPlayer);
            }
            else
            {
                //如果回合时间小于14秒，重置到14秒
                this.gameInfo.ResetTo14();

                //增加技术统计
                foulPlayer.Foul++;
                this.gameInfo.AddPersoanlBoxScore(foulPlayer, BoxScoreType.PF, 1);
                foulPlayer.OwnerTeam.AddFoul(this.gameInfo.Quarter, 1, this.gameInfo.QuarterTime);

                if (foulType == FoulType.ShotFoul)
                {
                    //进入罚球事件, 打手犯规的事件延迟触发
                    this.AddFreeThrowEvent(fouledPlayer, points, this.gameInfo.Ball.GetCurTask().FinishFrame + this.gameInfo.Frame + 1);
                }
                else if (foulPlayer.OwnerTeam.IsNeedBonusFreeThrow(this.gameInfo.Quarter))
                {
                    //犯规次数到加罚了
                    this.AddFreeThrowEvent(fouledPlayer, points);
                }
                else
                {
                    GameEvent ge = new GameEvent(GameEventType.FoulToThrowIn);
                    ge.Param4 = fouledPlayer;
                    ge.Param5 = foulPlayer;
                    this.gameInfo.AddGameEvent(ge);
                }
            }

            return BehaviourTreeStatus.Success;
        }

        private void AddFreeThrowEvent(Player freeThrower, int count, int startFrame = 0)
        {

            //进入罚球事件
            GameEvent ge = new GameEvent(GameEventType.FreeThrow);
            ge.Param1 = count;//总罚球次数
            ge.Param2 = 1;//当前第几罚

            ge.Param4 = freeThrower;

            ge.StartFrame = startFrame;

            this.gameInfo.AddGameEvent(ge);
        }

        private void AddInfo()
        {
            FoulType foulType = (FoulType)this.gameInfo.CurEvent.Param1;
            Player fouledPlayer = this.gameInfo.CurEvent.Param4 as Player;
            Player foulPlayer = this.gameInfo.CurEvent.Param5 as Player;
            PlayByPlayContent pc;
            if (foulType == FoulType.AttackFoul)
            {
                pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.FoulOnAtk, fouledPlayer.Id, foulPlayer.Id, (int)fouledPlayer.OwnerTeam.TeamType);
            }
            else if (foulType == FoulType.ShotFoul)
            {
                pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.FoulOnShot, foulPlayer.Id);
            }
            else
            {
                pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.FoulNormal, foulPlayer.Id);
            }
            this.gameInfo.AddGameInfo(pc);
        }

        private void AttackFoul(Player foulPlayer, Player fouledPlayer)
        {
            //进攻犯规交换球权
            this.gameInfo.ClearBallOwner();
            this.gameInfo.SetBallOwnTeam(this.gameInfo.DefTeam);

            this.gameInfo.StartNewRound();

            foulPlayer.Foul++;
            this.gameInfo.AddPersoanlBoxScore(foulPlayer, BoxScoreType.PF, 1);

            //进攻犯规算一次失误
            this.gameInfo.AddPersoanlBoxScore(foulPlayer, BoxScoreType.TOV, 1);


            GameEvent ge = new GameEvent(GameEventType.FoulToThrowIn);
            ge.Param4 = fouledPlayer;
            ge.Param5 = foulPlayer;
            this.gameInfo.AddGameEvent(ge);
        }
    }
}
