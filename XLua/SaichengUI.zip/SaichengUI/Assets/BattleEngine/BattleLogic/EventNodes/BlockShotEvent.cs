﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class BlockShotEvent : BaseGameEventSequenceNode
    {
        private TacBallOnTheFloor tacBallOnTheFloor;
        private TacCostStamina tacCostStamina;

        public BlockShotEvent(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.tacCostStamina = new TacCostStamina(this.gameInfo, this.name);
            this.tacBallOnTheFloor = new TacBallOnTheFloor(this.gameInfo, this.name);
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.BlockShot;
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            Player shooter = this.gameInfo.CurEvent.Param4 as Player;
            Player blocker = this.gameInfo.CurEvent.Param5 as Player;
            int points = this.gameInfo.CurEvent.Param1;

            int blockType = (int)this.gameInfo.CurEvent.Param3;

            //技术统计
            this.gameInfo.AddPersoanlBoxScore(shooter, BoxScoreType.BA, 1);
            this.gameInfo.AddPersoanlBoxScore(blocker, BoxScoreType.BLK, 1);
            this.gameInfo.AddPersoanlBoxScore(shooter, BoxScoreType.FGA, 1);
            if (points == 3)
            {
                this.gameInfo.AddPersoanlBoxScore(shooter, BoxScoreType.F3PA, 1);
            }
            if (blocker.Role != shooter.Role)
            {
                //协防盖帽
                this.gameInfo.AddPersoanlBoxScore(blocker, BoxScoreType.BlockFillIn, 1);
            }

            //描述
            PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.Block, blocker.Id);
            this.gameInfo.AddGameInfo(pc);
            //string msg = string.Format("球被 {0} 封盖了", blocker.Name);
            //this.gameInfo.AddGameInfo(msg);

            //扣体力
            this.tacCostStamina.Cost(EStaminaCost.Block, blocker);
    
            //投篮人与篮筐直线的角度
            Position basketPos = this.gameInfo.AttackTeam.AttackBasket;

            ZDBTable blockShotTable = ZDataManager.Instance.GetShotBlockTable();
            ZDB_Row_Data blockRow = blockShotTable.getDataByID(blockType);

            Position p1 = Position.Empty;
            //判断是大帽还是小帽
            if (this.IsBigRange(blockRow, blocker))
            {
                //大小帽，方向不一样
                Vector2D v = new Vector2D(basketPos, shooter.Pos);
                double angle = v.GetSlopeAngle();
                p1 = this.GetBigBlockPos(shooter.Pos, angle);
            }
            else
            {
                Vector2D v = new Vector2D(shooter.Pos, basketPos);
                double angle = v.GetSlopeAngle();
                //小帽
                double disToShooter = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, this.gameInfo.AttackTeam.AttackField, shooter);
                p1 = this.GetSmallBlockPos(shooter.Pos, angle, disToShooter);
            }
            Position start = this.gameInfo.Ball.Pos;
            Position end = p1;

            int speed = this.tacBallOnTheFloor.GetSpeed(blockRow.getCol((int)shot_blockFields.BallSpeed).getValueInt());

            int lastOwnerBehave = blockRow.getCol((int)shot_blockFields.AttackBehave).getValueInt();
            int touchBallBehave = blockRow.getCol((int)shot_blockFields.DefenceBehave).getValueInt();

            Vector2D v1 = new Vector2D(start, end);
            int targetAngle = (int)v1.GetSlopeAngle();
            //进入地板球
            this.tacBallOnTheFloor.StartBallOnTheFloor(EBallOnTheFloorSourceType.Block, shooter, lastOwnerBehave, blocker, touchBallBehave, start, targetAngle, speed);
            
            return BehaviourTreeStatus.Success;
        }

        private bool IsBigRange(ZDB_Row_Data blockRow, Player blocker)
        {
            int arrIndex = blockRow.getCol((int)shot_blockFields.AreaDefence).getValueInt();
            double areaValue = blockRow.getCol((int)shot_blockFields.AreaValue).getValueInt() * 1.0f;

            double pro = blocker.GetAttrByIndex(arrIndex) / areaValue * 10000;
            int random = this.gameInfo.RandomNext();

            if (pro >= random)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// 小帽落点
        /// </summary>
        /// <param name="startPos"></param>
        /// <param name="angle"></param>
        /// <param name="dis"></param>
        /// <returns></returns>
        private Position GetSmallBlockPos(Position startPos, double angle, double dis)
        {
            int random = this.gameInfo.RandomNext();
            int index = BlockManager.Instance.GetIndexRandomBlockAngle(random);

            int deltaAngle = ZDataManager.Instance.GetBlockAngleTable().getDataByRow(index).getCol((int)block_angleFields.Angle).getValueInt();

            //随机角度 angle +- delta
            int randomAngle = this.gameInfo.RandomNext((int)angle - deltaAngle, (int)angle + deltaAngle);
            //随机距离
            int randomDis = this.gameInfo.RandomNext(0, (int)dis);
            return startPos.GetPosByAngleRadius(randomAngle, randomDis);
        }

        /// <summary>
        /// 大帽落点
        /// </summary>
        /// <param name="startPos"></param>
        /// <param name="angle"></param>
        /// <param name="dis"></param>
        /// <returns></returns>
        private Position GetBigBlockPos(Position startPos, double angle)
        {
            int random = this.gameInfo.RandomNext();
            int index = BlockManager.Instance.GetIndexRandomBlockAngle(random);

            int deltaAngle = ZDataManager.Instance.GetBlockAngleTable().getDataByRow(index).getCol((int)block_angleFields.Angle).getValueInt();

            //随机角度 angle +- delta
            int randomAngle = this.gameInfo.RandomNext((int)angle - deltaAngle, (int)angle + deltaAngle);

            //随机距离
            int indexDis = BlockManager.Instance.GetIndexRandomBlockDistance(random);
            int disBlock = ZDataManager.Instance.GetBlockDistanceTable().getDataByRow(indexDis).getCol((int)block_distanceFields.Distance).getValueInt();
            return startPos.GetPosByAngleRadius(randomAngle, disBlock); 
        }

        private void SetBallTask(Position pos, TaskType taskType)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = taskType;
            gt.StartPos = this.gameInfo.Ball.Pos;
            gt.TargetPos = pos;
            gt.FinishFrame = gt.CalcFrameByTime(ParameterManager.Instance.GetValue(ParameterEnum.BlockBallFlyTime) * 1.0f / 1000);

            this.gameInfo.Ball.SetCurrentTask(gt);
        }

        private GameTask GetStandbyTask(int reationFrame)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            gt.FinishFrame = reationFrame;

            return gt;
        }

        private void SetOutOfBoundThrowInTask(Position p1)
        {
            this.gameInfo.ClearBallOwner();
            Field atkField = this.gameInfo.AttackTeam.AttackField;
            Field defField = this.gameInfo.DefTeam.AttackField;

            this.SetBallTask(p1, TaskType.BallMoveTo);

            //所有人待机
            this.gameInfo.SetAllPlayerTask(TaskType.PlayerStandby, int.MaxValue, this.name);

            Position posToThrowIn = Position.Empty;
            if (atkField.IsOnMe(p1))
            {
                //前场球
                posToThrowIn = atkField.GetSideThrowInPos(p1);
            }
            else
            {
                //后场球
                posToThrowIn = defField.GetSideThrowInPos(p1);
            }



            //界外球事件，延迟触发
            GameEvent ge = new GameEvent(GameEventType.OutOfBoundToThrowIn);
            ge.Pos = posToThrowIn;
            ge.Param1 = 1;
            ge.StartFrame = this.gameInfo.Ball.GetCurTask().FinishFrame + this.gameInfo.Frame + 1;
            this.gameInfo.AddGameEvent(ge);

        }
    }
}
