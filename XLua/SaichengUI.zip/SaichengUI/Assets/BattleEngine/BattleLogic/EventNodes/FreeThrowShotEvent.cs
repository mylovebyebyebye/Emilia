﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class FreeThrowShotEvent : BaseGameEventSequenceNode
    {
        public FreeThrowShotEvent(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {

        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            int count = this.gameInfo.CurEvent.Param1;
            int index = (int)this.gameInfo.CurEvent.Param2;
            int type = (int)this.gameInfo.CurEvent.Param3;
            Player freeThrower = this.gameInfo.CurEvent.Param4 as Player;

            //判进没进
            bool isGoal = false;
            int random = this.gameInfo.RandomNext(1, 100);
            if (freeThrower.GetAttribute(PlayerAttribute.FreeThrow) >= random)
            {
                isGoal = true;
            }
            //球的目标
            Position p1 = freeThrower.OwnerTeam.AttackBasket;
            if (!isGoal)
            {
                //如果没命中找一个点让球砸
                int Radius = ParameterManager.Instance.GetValue(ParameterEnum.BasketRadius) / 10;
                int pointCount = ParameterManager.Instance.GetValue(ParameterEnum.BasketPointCount);

                p1 = p1.GetPosByAngleRadius(360 / pointCount, Radius);
            }
            //球的事件
            {
                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.BallFreeThrow;
                gt.StartPos = this.gameInfo.Ball.Pos;
                gt.TargetPos = p1;
                gt.TargetPlayer = freeThrower;
                gt.Param1 = count;
                gt.Param2 = index;
                gt.Param3 = type;
                gt.Success = isGoal;
                gt.FinishFrame = gt.CalcTimeBySpeed(ParameterManager.Instance.GetValue(ParameterEnum.ShotBallSpeed) * 1.0f);

                this.gameInfo.Ball.SetCurrentTask(gt);
            }
            if (count == index && 
                type != (int)EFreeThrowType.Technical)//技犯不抢板
            {
                //最后一罚流程
                this.gameInfo.AttackTeam.AttackField.ClearReboundPos();
                for (int i = 0; i < GameInfo.TeamCount; i++)
                {
                    Team team = this.gameInfo.Teams[i];
                    for (int j = 0; j < team.PlayerCount; j++)
                    {
                        Player player = team.Players[j];
                        if (!player.IsSamePlayer(freeThrower))
                        {
                            GameTask gt = new GameTask(this.name);
                            gt.TaskType = TaskType.PlayerToGetRebound;
                            gt.DelayStart = 0;
                            gt.FinishFrame = 0;
                            player.SetCurrentTask(gt);
                        }
                    }
                }
                GameTask gt1 = new GameTask(this.name);
                gt1.TaskType = TaskType.PlayerStandby;
                gt1.DelayStart = 0;
                gt1.FinishFrame = int.MaxValue;
                freeThrower.SetCurrentTask(gt1);
            }

            return BehaviourTreeStatus.Success;
        }



        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.FreeThrowShot;
        }
    }
}
