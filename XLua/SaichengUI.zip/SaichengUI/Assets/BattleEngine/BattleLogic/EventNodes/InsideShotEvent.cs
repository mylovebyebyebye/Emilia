﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class InsideShotEvent : BaseGameEventSequenceNode
    {
        private TacSlamDunk tacSlumDunk;
        private TacHookShot tacHookShot;
        private TacFadeAwayShot tacFadeAway;
        private TacToShot tacToShot;

        public InsideShotEvent(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.tacSlumDunk = new TacSlamDunk(this.gameInfo, this.name);
            this.tacHookShot = new TacHookShot(this.gameInfo, this.name);
            this.tacFadeAway = new TacFadeAwayShot(this.gameInfo, this.name);
            this.tacToShot = new TacToShot(this.gameInfo, this.name);
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            Player atkPlayer = (Player)this.gameInfo.CurEvent.Param5;

            if (this.tacSlumDunk.IsSlamDunk(atkPlayer))
            {
                //扣篮
                GameEvent ge = new GameEvent(GameEventType.SlumDunk);
                ge.Param4 = atkPlayer;
                this.gameInfo.AddGameEvent(ge);
            }
            else if (this.tacHookShot.IsHook(atkPlayer))
            {
                this.gameInfo.AddPersoanlBoxScore(atkPlayer, BoxScoreType.Hooks, 1);

                this.tacToShot.DoToShot(ShotType.HookShot, atkPlayer);
                //勾手投篮
                //GameEvent gameEvent = new GameEvent(GameEventType.ShotNew);
                //gameEvent.Param1 = (int)ShotType.HookShot;
                //gameEvent.Param4 = atkPlayer;
                //this.gameInfo.AddGameEvent(gameEvent);
            }
            else if (this.tacFadeAway.IsFadeAwayShot(atkPlayer))
            {
                //后仰
                this.tacFadeAway.StartFadeAway(atkPlayer);
            }
            else
            {
                this.gameInfo.AddPersoanlBoxScore(atkPlayer, BoxScoreType.InsideShot, 1);

                //内线投篮
                this.tacToShot.DoToShot(ShotType.InsideShot, atkPlayer);
                //GameEvent gameEvent = new GameEvent(GameEventType.ShotNew);
                //gameEvent.Param1 = (int)ShotType.InsideShot;
                //gameEvent.Param4 = atkPlayer;
                //this.gameInfo.AddGameEvent(gameEvent);
            }

            return BehaviourTreeStatus.Success;
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.InsideShot;
        }
    }
}
