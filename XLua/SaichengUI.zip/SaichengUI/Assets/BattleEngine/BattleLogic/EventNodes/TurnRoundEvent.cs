﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class TurnRoundEvent : BaseGameEventSequenceNode
    {

        public TurnRoundEvent(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
        }

        protected override BehaviourTreeStatus ProcessEvent(TimeData time)
        {
            Player atkPlayer = this.gameInfo.CurEvent.Param5 as Player;
            Player defPlayer = this.gameInfo.CurEvent.Param4 as Player;
            Position targetPos = this.GetTurnRoundTargetPos(atkPlayer, defPlayer);

            int addFrame = 0;
            //向目标点移动
            addFrame += this.SetTurnRoundTask(atkPlayer, defPlayer, targetPos);
            //然后还要向篮筐移动
            addFrame += this.SetMoveToBasket(atkPlayer, targetPos);

            int startFrame = this.gameInfo.Frame + addFrame;
            //行动完以后，继续走突破流程
            this.DoCrossOver(atkPlayer, startFrame);

            return BehaviourTreeStatus.Success;
        }

        protected override void SetGameEventType()
        {
            this.eventType = GameEventType.TurnRound;
        }

        /// <summary>
        /// 移动到以防守人为圆心， 防守人圆柱体为半径的圆
        /// 与 进攻人篮筐连线垂直的 直线交点
        /// 转化为 求以防守人为极点， 圆柱体为半径， 进攻人与篮筐连线斜率+-90度为角度的两个点
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <param name="defPlayer"></param>
        /// <returns></returns>
        private Position GetTurnRoundTargetPos(Player atkPlayer, Player defPlayer)
        {
            Vector2D v = new Vector2D(atkPlayer.OwnerTeam.AttackBasket, atkPlayer.Pos);
            double angle = v.GetSlopeAngle();
            int random = this.gameInfo.RandomNext(1, 2);
            if (random == 1)
            {
                angle += 90;
            }
            else
            {
                angle -= 90;
            }
            int radius = ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea);

            Position p1 = defPlayer.Pos.GetPosByAngleRadius((int)angle, radius);
            return p1;
        }

        private int SetTurnRoundTask(Player atkPlayer, Player defPlayer, Position layUpPos )
        {
            //进攻人移动
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = atkPlayer.Pos;
            gt.TargetPos = layUpPos;
            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(atkPlayer, this.gameInfo.RandomSpeed());
            gt.SpeedLevel = speedLevel;
            gt.FinishFrame = gt.CalcTimeBySpeed(atkPlayer.GetAttribute(PlayerAttribute.Speed) * speedLevel / 10);
            this.gameInfo.Ball.GetCurTask().TaskType = TaskType.BallOnThePlayer;
            this.gameInfo.Ball.GetCurTask().FinishFrame = int.MaxValue;

            atkPlayer.SetCurrentTask(gt);

            //防守人待机
            double reactionTime = ParameterManager.Instance.GetValue(ParameterEnum.TurnRoundReactionTime) * 1.0f / 1000;
            GameTask gt1 = new GameTask(this.name);
            gt1.StartPos = defPlayer.Pos;
            gt1.FinishFrame = gt.FinishFrame + TimeFrameConverter.GetFrame(reactionTime);
            gt1.TaskType = TaskType.PlayerStandby;
            defPlayer.SetCurrentTask(gt1);

            return gt.FinishFrame;
        }

        private void DoCrossOver(Player atkPlayer, int startFrame)
        {
            GameEvent gameEvent = new GameEvent(GameEventType.CrossOver);
            gameEvent.Param4 = atkPlayer;
            gameEvent.StartFrame = startFrame;
            this.gameInfo.AddGameEvent(gameEvent);
        }

        /// <summary>
        /// 先向目标点移动，然后从目标点向篮筐移动一段时间
        /// </summary>
        /// <param name="atkPlayer"></param>
        /// <param name="targetPos"></param>
        /// <returns></returns>
        private int SetMoveToBasket(Player atkPlayer, Position lastLargetPos)
        {
            Position basketPos = atkPlayer.OwnerTeam.AttackBasket;
            //先随机速度
            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(atkPlayer, this.gameInfo.RandomSpeed());
            double speedInPixel = atkPlayer.GetSpeedInPixelByLevel(speedLevel);
            double time = ParameterManager.Instance.GetValueD(ParameterEnum.TurnRoundMoveToBasketTime) / 1000;
            //移动距离
            double moveDis = time * speedInPixel;

            Position target = Formula.ClosestIntersection(lastLargetPos, (double)moveDis, basketPos, lastLargetPos);

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = lastLargetPos;
            gt.TargetPos = target;
            gt.SpeedLevel = speedLevel;
            gt.FinishFrame = gt.CalcFrameByTime(time);

            atkPlayer.NextTask.Add(gt);

            return gt.FinishFrame;
        }
    }
}
