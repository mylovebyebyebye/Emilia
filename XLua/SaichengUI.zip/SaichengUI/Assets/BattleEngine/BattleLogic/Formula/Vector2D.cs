﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    /// <summary>
    /// 二维向量
    /// </summary>
    public class Vector2D
    {
        public int A { get; set; }
        public int B { get; set; }

        public Position Start;
        public Position End;

        public Vector2D(Position p1, Position p2)
        {
            this.A = p2.X - p1.X;
            this.B = p2.Y - p1.Y;
            this.Start = new Position(p1.X, p1.Y);
            this.End = new Position(p2.X, p2.Y);
        }

        /// <summary>
        /// 长度
        /// </summary>
        /// <returns></returns>
        public double GetLength()
        {
            return this.Start.Distance(this.End);
        }

        /// <summary>
        /// 叉乘
        /// </summary>
        /// <param name="v1"></param>
        /// <returns></returns>
        public int CrossProduct(Vector2D v1)
        {
            return (int)((this.A * v1.B) - (this.B * v1.A));
        }

        public int DotProduct(Vector2D v1)
        {
            return this.A * v1.A + this.B * v1.B;
        }

        /// <summary>
        /// 判断一个向量是否在自己的左边
        /// 
        /// </summary>
        /// <param name="v"></param>
        /// <returns></returns>
        public bool IsOnMyLeft(Vector2D v)
        {
            //y轴方向与正常坐标轴相反
            //导致B需要*-1才能判断方向
            int value = (int)((this.A * v.B * -1) - (this.B * v.A * -1));
            if (value >= 0)
            {
                return true;
            }
            return false;
        }

        public double DistancePointToVector2D(Position p)
        {
            Vector2D v = new Vector2D(this.Start, p);//AC
            double dist = this.CrossProduct(v) / this.Start.Distance(this.End);

            return Math.Abs(dist);
        }

        /// <summary>
        /// 直线外一点，向直线做垂线
        /// 求交点坐标
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public Position GetVerticalToVector(Position p)
        {
            if (this.A == 0)
            {
                //本向量与y平行
                return new Position(this.Start.X, p.Y);
            }
            else if(this.B == 0)
            {
                //本向量与x平行
                return new Position(p.X, this.Start.Y);
            }
            //double slope = this.GetSlope();//斜率

            double m = this.GetSlope();
            double b = (double)(this.Start.Y * -1) - (m * this.Start.X);

            double x = (m * p.Y * -1 + p.X - m * b) / (m * m + 1);
            double y = -1.0 * (m * m * p.Y * -1 + m * p.X + b) / (m * m + 1);

            //double x1 = (slope * this.Start.X + p.X / slope - p.Y + this.Start.Y) / (1 / slope + slope);
            //double y1 = (1 / slope * (x1 - p.X) - p.Y);

            return new Position((int)x, (int)y);
        }

        /// <summary>
        /// 获取跟X轴夹角
        /// </summary>
        /// <returns></returns>
        public double GetSlopeAngle()
        {
            //y坐标的增减方向与直角坐标系是反的，所以需要乘以-1
            double angle = Formula.GetAngle(Math.Atan2(this.B * -1, this.A));
            if (angle < 0)
            {
                angle += 360;
            }
            return angle;
        }

        public double GetSlope()
        {
            return this.B * -1.0 / this.A;
        }

        public double GetAngleWithAnotherVector(Vector2D v)
        {
            double angle = Math.Abs(this.GetSlopeAngle() - v.GetSlopeAngle());
            return angle;
        }
    }
}
