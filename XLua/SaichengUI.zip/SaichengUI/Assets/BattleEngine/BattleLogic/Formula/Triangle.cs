﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class Triangle
    {
        private List<Position> lstPoints = new List<Position>();

        private List<Vector2D> lstEdge = new List<Vector2D>();
        private Vector2D AB;
        private Vector2D BC;
        private Vector2D CA;

        public Triangle(List<Position> points)
        {
            if (points.Count != 3)
            {
                throw new Exception("三角形初始化错误");
            }
            for (int i = 0; i < 3; i++)
            {
                lstPoints.Add(points[i].Clone());
            }
            //进行逆时针排列
            this.MakeAntiClockWise();
        }

        public void MakeAntiClockWise()
        {
            Vector2D v1 = new Vector2D(this.lstPoints[0], this.lstPoints[1]);
            Vector2D v2 = new Vector2D(this.lstPoints[0], this.lstPoints[2]);
            if (v1.IsOnMyLeft(v2))
            {
                this.AB = v1;
                this.BC = new Vector2D(this.lstPoints[1], this.lstPoints[2]);
                this.CA = new Vector2D(this.lstPoints[2], this.lstPoints[0]);
            }
            else
            {
                this.AB = v2;
                this.BC = new Vector2D(this.lstPoints[2], this.lstPoints[1]);
                this.CA = new Vector2D(this.lstPoints[1], this.lstPoints[0]);
            }
            this.lstEdge.Add(this.AB);
            this.lstEdge.Add(this.BC);
            this.lstEdge.Add(this.CA);
        }

        /// <summary>
        /// 判断一个点是否在三角形内
        /// 如果有一个点D在三角形ABC内，那么沿着三角形的边界逆时针走，点D一定保持在边界的左边，也就是说点D在边AB、BC、CA的左
        /// 边。于是问题转化成如何去判断一个点P3是在射线P1P2的左边，这其实是个数学问题，通过判断P1P2和P1P3两个向量的叉积的正负来判断
        /// 二维向量的叉积公式：
        /// a（x1，y1），b（x2，y2），则a×b=（x1y2-x2y1）。
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public bool IsInMe(Position p)
        {
            bool isInMe = true;
            for (int i = 0; i < 3; i++)
            {
                Vector2D edge = this.lstEdge[i];
                Vector2D v = new Vector2D(edge.Start, p);

                if (!edge.IsOnMyLeft(v))
                {
                    isInMe = false;
                    break;
                }
            }
            return isInMe;
        }
    }
}
