﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class ProbabilityCalc
    {
        /// <summary>
        /// 根据一组概率加当前随机值，得到第几个概率被随机到
        /// </summary>
        /// <param name="lstPrb"></param>
        /// <param name="random"></param>
        /// <returns></returns>
        public static int GetPosition(List<int> lstPrb, int random)
        {
            int res = -1;
            int sum = 0;
            for (int i = 0; i < lstPrb.Count; i++)
            {
                sum += lstPrb[i];
                if (sum >= random)
                {
                    res = i;
                    break;
                }
            }
            return res;
        }
    }
}
