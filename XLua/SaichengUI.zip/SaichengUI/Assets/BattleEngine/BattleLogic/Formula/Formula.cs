﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class Formula
    {
        public static double MinDifference = 0.0000001f;

        /// <summary>
        /// 等腰三角形，底边两点坐标
        /// 已知顶点及底边中点，及底边长度
        /// </summary>
        /// <param name="vertices">顶点坐标</param>
        /// <param name="bottomMiddle">底边中点坐标</param>
        /// <param name="bottomLength">底边一半长度</param>
        /// <returns></returns>
        public static Triangle GetTriangle(Position vertices, Position bottomMiddle, double bottomHalfLength)
        {
            Position p1 = new Position();
            Position p2 = new Position();
            if (vertices.X - bottomMiddle.X == 0)
            {
                p1.X = bottomMiddle.X - bottomMiddle.X;
                p1.Y = bottomMiddle.Y;

                p2.X = bottomMiddle.X + bottomMiddle.X;
                p2.Y = bottomMiddle.Y;
            }
            else
            {
                p1.X = (int)(bottomMiddle.X - bottomHalfLength * Math.Sin(Math.Atan(vertices.Y - bottomMiddle.Y) / (vertices.X - bottomMiddle.X)));
                p1.Y = (int)(bottomMiddle.Y + bottomHalfLength * Math.Cos(Math.Atan(vertices.Y - bottomMiddle.Y) / (vertices.X - bottomMiddle.X)));


                p1.X = (int)(bottomMiddle.X + bottomHalfLength * Math.Sin(Math.Atan(vertices.Y - bottomMiddle.Y) / (vertices.X - bottomMiddle.X)));
                p1.Y = (int)(bottomMiddle.Y - bottomHalfLength * Math.Cos(Math.Atan(vertices.Y - bottomMiddle.Y) / (vertices.X - bottomMiddle.X)));
            }
            List<Position> lst = new List<Position>();
            lst.Add(vertices);
            lst.Add(p1);
            lst.Add(p2);

            Triangle t = new Triangle(lst);

            return t;
        }

        /// <summary>
        /// 直线与圆交点
        /// </summary>
        /// <param name="circle">圆心</param>
        /// <param name="radius">半径 像素</param>
        /// <param name="point1">直线起点</param>
        /// <param name="point2">直线终点</param>
        /// <param name="getFarIntersection">是否获取离起点更远的点</param>
        /// <returns></returns>
        public static Position ClosestIntersection(Position circle, double radius,
     Position point1, Position point2, bool getFarIntersection = false)
        {
            if (point1 == point2)
            {
                point2.X += 1;
            }

            Position intersection1;
            Position intersection2;
            int intersections = FindLineCircleIntersections(circle, radius, point1, point2, out intersection1, out intersection2);

            if (intersections == 1)
                return intersection1;//one intersection

            if (intersections == 2)
            {
                double dist1 = intersection1.Distance(point1);
                double dist2 = intersection2.Distance(point1);

                if (dist1 < dist2)
                    return getFarIntersection == false ? intersection1 : intersection2;
                else
                    return getFarIntersection == false ? intersection2 : intersection1;

            }
            return Position.Empty.Clone();
        }

        /// <summary>
        /// 直线与圆交点
        /// </summary>
        /// <param name="circle"></param>
        /// <param name="radius"></param>
        /// <param name="point1"></param>
        /// <param name="point2"></param>
        /// <param name="intersection1"></param>
        /// <param name="intersection2"></param>
        /// <returns></returns>
        private static int FindLineCircleIntersections(Position circle, double radius,
     Position point1, Position point2, out Position intersection1, out Position intersection2)
        {
            double dx, dy, A, B, C, det, t;

            dx = point2.X - point1.X;
            dy = point2.Y - point1.Y;

            A = dx * dx + dy * dy;
            B = 2 * (dx * (point1.X - circle.X) + dy * (point1.Y - circle.Y));
            C = (point1.X - circle.X) * (point1.X - circle.X) + (point1.Y - circle.Y) * (point1.Y - circle.Y) - radius * radius;

            det = B * B - 4 * A * C;
            if ((A <= Formula.MinDifference) || (det < 0))
            {
                // No real solutions.
                intersection1 = new Position(int.MaxValue, int.MaxValue);
                intersection2 = new Position(int.MaxValue, int.MaxValue);
                return 0;
            }
            else if (det == 0)
            {
                // One solution.
                t = -B / (2 * A);
                intersection1 = new Position((int)(point1.X + t * dx), (int)(point1.Y + t * dy));
                intersection2 = new Position(int.MaxValue, int.MaxValue);
                return 1;
            }
            else
            {
                // Two solutions.
                t = (double)((-B + Math.Sqrt(det)) / (2 * A));
                intersection1 = new Position((int)(point1.X + t * dx), (int)(point1.Y + t * dy));
                t = (double)((-B - Math.Sqrt(det)) / (2 * A));
                intersection2 = new Position((int)(point1.X + t * dx), (int)(point1.Y + t * dy));
                return 2;
            }
        }

        /// <summary>
        /// 根据速度，时间，起始位置，最终目标，算出这次该走到哪里
        /// </summary>
        /// <param name="speed"></param>
        /// <param name="frame"></param>
        /// <param name="curPos"></param>
        /// <param name="finalPos"></param>
        /// <returns></returns>
        public static Position GetTargetPos(double speed, double seconds, Position curPos, Position finalPos)
        {
            double moveDis = speed * seconds;

            Position pos = Formula.ClosestIntersection(curPos, (double)moveDis, finalPos, curPos);

            return pos;
        }

        /// <summary>
        /// 计算防守距离修正值
        /// 每回合只需计算一次
        /// </summary>
        /// <param name="player"></param>
        /// <param name="gameInfo"></param>
        /// <returns></returns>
        public static int GetDefDistanceRandom(Player player, GameInfo gameInfo)
        {
            //r=random(-1,1)×max(0,P_22-P_23/10×Diq)
            double param22 = ParameterManager.Instance.GetValue(ParameterEnum.DefDistanceParam1) * 1.0f;
            double param23 = ParameterManager.Instance.GetValue(ParameterEnum.DefDistanceParam2) * 1.0f;
            double random = (gameInfo.RandomNext() - 5000) * 1.0f / 5000;

            double value = param22 - param23 / 10 * player.GetAttribute(PlayerAttribute.DefenceIQ);
            //if (value < 0)
            //{
            //    value = 0;
            //}
            double result = random * value;
            return (int)Math.Floor(result);
        }

       
        /// <summary>
        /// 安全接球距离
        /// </summary>
        /// <param name="askBallPlayer"></param>
        /// <param name="passBallPos"></param>
        /// <returns></returns>
        public static double GetSafeGetBallRadius(Player askBallPlayer, Position passBallPos)
        {
            double dis = askBallPlayer.Pos.DistanceActualLength(passBallPos);
            double passBallSpeed = ParameterManager.Instance.GetValue(ParameterEnum.PassBallSpeed) * 1.0f;
            double maxSpeed = askBallPlayer.GetAttribute(PlayerAttribute.Speed);
            int reactionTime = ParameterManager.Instance.GetValue(ParameterEnum.ReactionTime) / 10;

            double Radius = dis / passBallSpeed * maxSpeed - maxSpeed * reactionTime;

            return Math.Abs(Radius);
        }

        public static double GetRadian(double angle)
        {
            return Math.PI * angle / 180.0;
        }

        public static double GetAngle(double radian)
        {
            return 180.0f * radian / Math.PI;
        }

        /// <summary>
        /// 两个距离是否在宽容度内
        /// </summary>
        /// <param name="dis1">大的 cm</param>
        /// <param name="dis2">小的 cm</param>
        /// <returns></returns>
        public static bool IsDisInPermissibleError(double dis1, double dis2)
        {
            if ( (dis1 - dis2) < ParameterManager.Instance.GetValue(ParameterEnum.PermissibleError))
            {
                return true;
            }
            return false;
        }

        public static bool IsDisInPermissByPixel(double pixel1, double pixel2, int PixelPermissibleError)
        {
            if ((pixel1 - pixel2) < PixelPermissibleError)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 两个点是否接近重合
        /// 其实就是距离小于一个值
        /// </summary>
        /// <param name="p1"></param>
        /// <param name="p2"></param>
        /// <returns></returns>
        public static bool IsCloseOverlap(Position p1, Position p2)
        {
            double dis = p1.DistanceActualLength(p2);
            if (dis < ParameterManager.Instance.GetValue(ParameterEnum.PermissibleError))
            {
                return true;
            }
            return false;
        }

        public static Position GetCircleByTwoPointsAndRadius(Position p1, Position p2, double radius, bool isOnMyLeft = true)
        {
            double q = Math.Sqrt(Math.Pow((p2.X - p1.X), 2) + Math.Pow((p2.Y - p1.Y), 2));
            double x1 = (p1.X + p2.X) * 1.0 / 2;
            double y1 = (p1.Y + p2.Y) * 1.0 / 2;

            double basex = Math.Sqrt(Math.Pow(radius, 2) - Math.Pow((q / 2), 2)) * (p1.Y - p2.Y) / q; //calculate once
            double basey = Math.Sqrt(Math.Pow(radius, 2) - Math.Pow((q / 2), 2)) * (p2.X - p1.X) / q; //calculate once

            Position c1 = Position.Empty ;
            Position c2 = Position.Empty;
            {
                double x = x1 - basex;
                double y = y1 - basey;
                c1 = new Position((int)x, (int)y);
            }
            
            {
                double x = x1 + basex;
                double y = y1 + basey;
                c2 = new Position((int)x, (int)y);
            }
            Position p;
            Vector2D v = new Vector2D(p1, p2);
            Vector2D vC1 = new Vector2D(p1, c1);
            if (isOnMyLeft)
            {
                if (v.IsOnMyLeft(vC1))
                {
                    p = c2;
                }
                else
                {
                    p = c1;
                }
            }
            else
            {
                if (v.IsOnMyLeft(vC1))
                {
                    p = c1;
                }
                else
                {
                    p = c2;
                }
            }
            return p;
        }

        /// <summary>
        /// 两个圆的交点
        /// </summary>
        /// <param name="c0">圆心0</param>
        /// <param name="radius0">半径0</param>
        /// <param name="c1">圆心1</param>
        /// <param name="radius1">半径1</param>
        /// <param name="intersection1">交点1</param>
        /// <param name="intersection2">交点2</param>
        /// <returns>交点个数</returns>
        public static int FindCircleCircleIntersections(Position c0, double radius0,Position c1, double radius1,out Position intersection1, out Position intersection2)
        {
            // Find the distance between the centers.
            int dx = c0.X - c1.X;
            int dy = c0.Y - c1.Y;
            double dist = Math.Sqrt(dx * dx + dy * dy);

            // See how many solutions there are.
            if (dist > radius0 + radius1)
            {
                // No solutions, the circles are too far apart.
                intersection1 = Position.Empty;
                intersection2 = Position.Empty;
                return 0;
            }
            else if (dist < Math.Abs(radius0 - radius1))
            {
                // No solutions, one circle contains the other.
                intersection1 = Position.Empty;
                intersection2 = Position.Empty;
                return 0;
            }
            else if ((dist == 0) && (radius0 == radius1))
            {
                // No solutions, the circles coincide.
                intersection1 = Position.Empty;
                intersection2 = Position.Empty;
                return 0;
            }
            else
            {
                // Find a and h.
                double a = (radius0 * radius0 -
                    radius1 * radius1 + dist * dist) / (2 * dist);
                double h = Math.Sqrt(radius0 * radius0 - a * a);

                // Find P2.
                double cx2 = c0.X + a * (c1.X - c0.X) / dist;
                double cy2 = c0.Y + a * (c1.Y - c0.Y) / dist;

                // Get the points P3.
                intersection1 = new Position(
                    (int)((cx2 + h * (c1.Y - c0.Y) / dist)),
                    (int)((cy2 - h * (c1.X - c0.X) / dist)));
                intersection2 = new Position(
                    (int)((cx2 - h * (c1.Y - c0.Y) / dist)),
                    (int)((cy2 + h * (c1.X - c0.X) / dist)));

                // See if we have 1 or 2 solutions.
                if (dist == radius0 + radius1) return 1;
                return 2;
            }
        }
    }
}
