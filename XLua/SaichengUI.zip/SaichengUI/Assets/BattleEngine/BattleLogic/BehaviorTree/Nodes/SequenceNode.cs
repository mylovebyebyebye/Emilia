﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BattleLogic;
using Common;

namespace FluentBehaviourTree
{
    /// <summary>
    /// Runs child nodes in sequence, until one fails.
    /// </summary>
    public class SequenceNode : IParentBehaviourTreeNode
    {
        /// <summary>
        /// Name of the node.
        /// </summary>
        protected string name;

        protected GameInfo gameInfo;

        private int ChildCount = 0;

        /// <summary>
        /// List of child nodes.
        /// </summary>
        protected List<IBehaviourTreeNode> children = new List<IBehaviourTreeNode>(); //todo: this could be optimized as a baked array.

        protected IBehaviourTreeNode[] m_szChildren;

        protected SequenceNode()
        {
            throw new Exception("this construct is illegal");
        }

        public SequenceNode(string name, GameInfo gameInfo)
        {
            this.name = name;
            this.gameInfo = gameInfo;
            this.CreateChildNode();
            this.FinishAdd();
        }

        protected virtual void CreateChildNode()
        { }

        protected void CopyToSz()
        {
            this.m_szChildren = new IBehaviourTreeNode[this.ChildCount];
            this.children.CopyTo(this.m_szChildren);
        }

        public BehaviourTreeStatus Tick(TimeData time)
        {
            for (int i = 0; i < this.ChildCount; i++)
            {
                var child = this.m_szChildren[i];
                var childStatus = child.Tick(time);
                if (childStatus != BehaviourTreeStatus.Success)
                {
                    return childStatus;
                }
            }
            return BehaviourTreeStatus.Success;
        }

        /// <summary>
        /// Add a child to the sequence.
        /// </summary>
        public void AddChild(IBehaviourTreeNode child)
        {
            children.Add(child);
            this.ChildCount++;
        }

        #region IBehaviourTreeNode Members

        public string GetName()
        {
            return this.name;
        }

        #endregion

        public void FinishAdd()
        {
            this.CopyToSz();
        }
    }
}
