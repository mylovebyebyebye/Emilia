﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BattleLogic;
using Common;

namespace FluentBehaviourTree
{
    /// <summary>
    /// Selects the first node that succeeds. Tries successive nodes until it finds one that doesn't fail.
    /// </summary>
    public class SelectorNode : IParentBehaviourTreeNode
    {
        protected SelectorNode()
        {
            throw new Exception("this constructor is illegal");
        }
        /// <summary>
        /// The name of the node.
        /// </summary>
        protected string name;

        protected GameInfo gameInfo;

        protected int ChildCount = 0;

        /// <summary>
        /// List of child nodes.
        /// </summary>
        protected List<IBehaviourTreeNode> children = new List<IBehaviourTreeNode>(); //todo: optimization, bake this to an array.

        protected IBehaviourTreeNode[] m_szChildren;


        public SelectorNode(string name, GameInfo gameInfo)
        {
            this.name = name;
            this.gameInfo = gameInfo;
            this.CreateChildNode();
            this.FinishAdd();
        }

        protected virtual void CreateChildNode()
        { }

        protected void CopyToSz()
        {
            this.m_szChildren = new IBehaviourTreeNode[this.ChildCount];
            this.children.CopyTo(this.m_szChildren);

        }

        public virtual BehaviourTreeStatus Tick(TimeData time)
        {
            for (int i = 0; i < this.ChildCount;i++ )
            {
                var child = this.m_szChildren[i];
                var childStatus = child.Tick(time);
                if (childStatus != BehaviourTreeStatus.Failure)
                {
                    return childStatus;
                }
                else
                {

                }
            }
            return BehaviourTreeStatus.Failure;
        }

        /// <summary>
        /// Add a child node to the selector.
        /// </summary>
        public void AddChild(IBehaviourTreeNode child)
        {
            children.Add(child);
            this.ChildCount++;
        }

        public void FinishAdd()
        {
            this.CopyToSz();
        }

        #region IBehaviourTreeNode Members

        public string GetName()
        {
            return this.name;
        }

        #endregion
    }
}
