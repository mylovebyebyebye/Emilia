﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class TimeFrameConverter
    {
        public static int FramesOneSecond = 30;

        public static void SetFrame(int frame)
        {
            FramesOneSecond = frame;
        }

        public static int GetFrame(double second)
        {
            int frame = (int)Math.Floor(second * FramesOneSecond + 0.5f) ;
            return frame > 0 ? frame : 1;
        }

        public static double ConvertFrameToSecond(int frame)
        {
            return (double)Math.Round(frame * 1.0f / FramesOneSecond, 2);
        }

        public static string GetTimeDesc(int second)
        {
            int sec = second % 60;
            int minute = second / 60;

            return string.Format("{0}:{1}", minute.ToString().PadLeft(2, '0'), sec.ToString().PadLeft(2, '0'));
        }

        
    }
}
