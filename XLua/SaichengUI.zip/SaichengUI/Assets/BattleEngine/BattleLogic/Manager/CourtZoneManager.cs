﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public enum PlayBookType
    {
        HandlerDriveToAtkCourt              =   1,//持球人过半场区域
        PGLuowei                            =   2,//PG落位区域
        SGLuowei                            =   3,//SG落位区域
        SFLuowei                            =   4,//SF落位区域
        PFLuowei                            =   5,//PF落位区域
        CLuowei                             =   6,//C落位区域
        CannotLuowei                        =   7,//非落位区域
        PGDefLuowei                         =   8,//PG默认防守区域
        SGDefLuowei                         =   9,//SG默认防守区域
        SFDefLuowei                         =   10,//SF默认防守区域
        PFDefLuowei                         =   11,//PF默认防守区域
        CDefLuowei                          =   12,//C默认防守落位

        Paowei2P1                           =   21,//2分跑位
        Paowei3P1                           =   22,//3分跑位

        InsideAtkJieYing2                   =   401,//篮下接应
        InsideAtkJieYing1                   =   402,//3分接应
    }

    public class PlayBook
    {
        public PlayBookType TacType;

        public List<int> TargetZoneList1;
        public List<int> TargetZoneList2;
        public List<int> TargetZoneList3;
        public List<int> TargetZoneList4;
        public List<int> TargetZoneList5;

        public void Init(FieldType fieldType, ZDB_Row_Data rowData )
        {
            int id = rowData.getCol((int)playbookFields.Id).getValueInt();
            this.TacType = (PlayBookType)id;

            int add = 0;
            if (fieldType == FieldType.Right)
            {
                add = CourtZoneManager.LeftZoneId;
            }

            this.TargetZoneList1 = this.GetZone(add, rowData.getCol((int)playbookFields.TargetZone1).getValueString());
            this.TargetZoneList2 = this.GetZone(add, rowData.getCol((int)playbookFields.TargetZone2).getValueString());
            this.TargetZoneList3 = this.GetZone(add, rowData.getCol((int)playbookFields.TargetZone3).getValueString());
            this.TargetZoneList4 = this.GetZone(add, rowData.getCol((int)playbookFields.TargetZone4).getValueString());
            this.TargetZoneList5 = this.GetZone(add, rowData.getCol((int)playbookFields.TargetZone5).getValueString());
        }

        private List<int> GetZone(int add,string source )
        {
            List<int> lst = new List<int>();
            string[] array = source.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < array.Length; i++)
            {
                int value = int.Parse(array[i]);
                if (value > 0)
                {
                    value += add;
                    lst.Add(value);
                }
            }
            return lst;
        }
    }

    public class CourtZoneManager
    {
        private Dictionary<int, CourtZone> dicCourtZone = new Dictionary<int, CourtZone>();
        private Dictionary<int, PlayBook> dicPlayBook = new Dictionary<int, PlayBook>();
        private List<CourtZone> lstCourtZone = new List<CourtZone>();
        private Position basetkPos;
        public static int LeftZoneId = 21;
        private FieldType fieldType;

        public void Init(FieldType fieldType, Position basetkPos)
        {
            this.basetkPos = basetkPos.Clone();
            this.fieldType = fieldType;

            this.InitCourtZone(fieldType);
            //加载跑位表
            this.InitPlayerBook(fieldType);
        }

        private void InitCourtZone(FieldType fieldType)
        {
            this.dicCourtZone.Clear();
            int court = 0;
            if (fieldType == FieldType.Right)
            {
                court = 1;
            }
            ZDBTable courtZoneTable = ZDataManager.Instance.GetCourtZoneTable();
            int count = courtZoneTable.getRowCount();
            for (int i = 0; i < count; i++)
            {
                ZDB_Row_Data rowData = courtZoneTable.getDataByRow(i);
                if (court == rowData.getCol((int)court_zoneFields.Court).getValueInt())
                {
                    int id = rowData.getCol((int)court_zoneFields.Id).getValueInt();
                    CourtZone cz = new CourtZone(this.basetkPos);
                    cz.Init(rowData);
                    this.dicCourtZone.Add(id, cz);
                    this.lstCourtZone.Add(cz);
                }
            }
        }

        private void InitPlayerBook(FieldType fieldType)
        {
            ZDBTable playerBookTable = ZDataManager.Instance.GetPlayBookTable();
            int count = playerBookTable.getRowCount();
            for (int i = 0; i < count; i++)
            {
                ZDB_Row_Data rowData = playerBookTable.getDataByRow(i);
                int id = rowData.getCol((int)playbookFields.Id).getValueInt();
                PlayBook pb = new PlayBook();
                pb.Init(fieldType, rowData);
                if (this.CheckPlayerBook(pb))
                {
                    this.dicPlayBook.Add(id, pb);
                }
            }
        }

        private bool CheckPlayerBook(PlayBook pb)
        {
            for (int i = 0; i < pb.TargetZoneList1.Count; i++)
            {
                this.CheckCoureZone(pb, pb.TargetZoneList1[i]);
            }
            for (int i = 0; i < pb.TargetZoneList2.Count; i++)
            {
                this.CheckCoureZone(pb, pb.TargetZoneList2[i]);
            }
            for (int i = 0; i < pb.TargetZoneList3.Count; i++)
            {
                this.CheckCoureZone(pb, pb.TargetZoneList3[i]);
            }
            for (int i = 0; i < pb.TargetZoneList4.Count; i++)
            {
                this.CheckCoureZone(pb, pb.TargetZoneList4[i]);
            }
            for (int i = 0; i < pb.TargetZoneList5.Count; i++)
            {
                this.CheckCoureZone(pb, pb.TargetZoneList5[i]);
            }
            return true;
        }
        private bool CheckCoureZone(PlayBook pb,int id)
        {
            if (!this.dicCourtZone.ContainsKey(id))
            {
                throw new Exception("PlayerBook id:" + (int)pb.TacType);
            }
            return true;
        }

        private CourtZone GetCourtZone(int zone)
        {
            if (!this.dicCourtZone.ContainsKey(zone))
            {
                throw new Exception("Error CourtZone:" + zone);
            }
            return this.dicCourtZone[zone];
        }

        private PlayBook GetPlayBook(int type)
        {
            if (!this.dicPlayBook.ContainsKey(type))
            {
                throw new Exception("Error CourtZone:" + type);
            }
            return this.dicPlayBook[type];
        }

        /// <summary>
        /// 持球人过半场位置
        /// </summary>
        /// <param name="curPos">持球人当前位置</param>
        /// <param name="random"></param>
        /// <returns></returns>
        public Position GetBallHandlerPreset(Position curPos, int random)
        {
            PlayBook pb = this.dicPlayBook[(int)PlayBookType.HandlerDriveToAtkCourt];
            int zone = this.GetMinDisZone(pb, curPos);
            CourtZone cz = this.GetCourtZone(zone);
            return cz.GetRandomPos(random);
        }

        /// <summary>
        /// 攻防落位位置
        /// </summary>
        /// <param name="role">场上位置</param>
        /// <param name="curPos">当前位置</param>
        /// <param name="random"></param>
        /// <returns></returns>
        public Position GetAtkPresetPosition(GameInfo gameInfo,Player player, int random, out int courtZone)
        {
            courtZone = 0;
            int index = player.Role - (int)PlayerRole.PG + (int)PlayBookType.PGLuowei;
            PlayBook pbDefault = this.GetPlayBook(index);
            PlayBook pbCannot = this.GetPlayBook((int)PlayBookType.CannotLuowei);
            //计算分值
            //初始化为0 
            List<int> lstScore = new List<int>();
            Dictionary<int, int> dicIndex = new Dictionary<int, int>();
            for (int i = 0; i < this.lstCourtZone.Count; i++)
            {
                //初始化为0,且记录id
                lstScore.Add(0);
                CourtZone cz = this.lstCourtZone[i];
                dicIndex.Add(cz.GetId(), i);
            }
            for (int i = 0; i < this.lstCourtZone.Count; i++)
            {
                CourtZone cz = this.lstCourtZone[i];
                int score = lstScore[i];
                int id = cz.GetId();
                if (pbCannot.TargetZoneList1.Contains(id))
                {
                    //不能被选中的，直接-1000000
                    score = -10000000;
                }
                else
                {
                    int preferid = id < LeftZoneId ? id : id - LeftZoneId;
                    if (player.PreferZoneList.Contains(preferid))
                    {
                        //偏好区域+2
                        score += 2;
                    }
                    else
                    {
                        //偏好区域的相邻区域+1
                        for (int j = 0; j < player.PreferZoneList.Count; j++)
                        {
                            int zone = player.PreferZoneList[j];
                            int z = this.GetRealId(zone);
                            CourtZone czPrefer = this.GetCourtZone(z);
                            if (czPrefer.NearByZoneList.Contains(id))
                            {
                                score += 1;
                                break;
                            }
                        }
                    }
                    if (pbDefault.TargetZoneList1.Contains(id))
                    {
                        //位置默认区域
                        score += 1;
                    }
                    //其他人
                    for (int j = 0; j < gameInfo.AttackTeam.PlayerCount; j++)
                    {
                        Player otherPlayer = gameInfo.AttackTeam.Players[j];

                        if (!otherPlayer.IsSamePlayer(player))
                        {
                            if (otherPlayer.IsInTask(TaskType.PlayerMoveToArea))
                            {
                                Position otherPos = otherPlayer.Pos;
                                otherPos = otherPlayer.GetCurTask().TargetPos;
                                if (cz.IsOnMe(otherPos))
                                {
                                    //落位区域或者在的区域
                                    score -= 2;
                                    for (int k = 0; k < cz.NearByZoneList.Count; k++)
                                    {
                                        int nearBy = cz.NearByZoneList[k];
                                        //相邻区域-1
                                        lstScore[dicIndex[nearBy]] -= 1;
                                    }
                                }
                            }
                        }
                    }
                }
                lstScore[i] = score;
            }
            int maxScore = int.MinValue;
            int maxIndex = -1;
            List<int> lstMaxIndex = new List<int>();
            //第三遍遍历，找出最大值
            for (int i = 0; i < lstScore.Count; i++)
            {
                if (lstScore[i] > maxScore)
                {
                    maxScore = lstScore[i];
                    lstMaxIndex.Clear();
                    lstMaxIndex.Add(i);
                    //maxIndex = i;
                }
                else if (lstScore[i] == maxScore)
                {
                    lstMaxIndex.Add(i);
                }
            }
            maxIndex = gameInfo.RandomNext(0, lstMaxIndex.Count - 1);
            CourtZone targetCZ = this.lstCourtZone[lstMaxIndex[maxIndex]];
            courtZone = targetCZ.GetId();
            return targetCZ.GetRandomPos(random);
        }

        /// <summary>
        /// 防守落位
        /// </summary>
        /// <param name="player"></param>
        /// <param name="random"></param>
        /// <returns></returns>
        public Position GetDefPresetPosition(Player player, int random)
        {
            int index = player.Role - (int)PlayerRole.PG + (int)PlayBookType.PGDefLuowei;
            PlayBook pb = this.GetPlayBook(index);
            int randomIndex = random % pb.TargetZoneList1.Count;
            int zone = pb.TargetZoneList1[randomIndex];
            CourtZone cz = this.GetCourtZone(zone);
            return cz.GetRandomPos(random);
        }

        /// <summary>
        /// 是否在防守落位区域
        /// 任一区域内均可
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public bool IsInMyDefPreset(Player player)
        {
            int index = player.Role - (int)PlayerRole.PG + (int)PlayBookType.PGDefLuowei;
            PlayBook pb = this.GetPlayBook(index);
            for (int i = 0; i < pb.TargetZoneList1.Count; i++)
            {
                int zone = pb.TargetZoneList1[i];
                CourtZone cz = this.GetCourtZone(zone);
                if (cz.IsOnMe(player.Pos))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 获取playbook中离自己最近的区域，随机一个点
        /// 如果自己在其中一个里面，直接返回自身位置
        /// </summary>
        /// <param name="player"></param>
        /// <param name="random"></param>
        /// <returns></returns>
        public Position GetNearestCourtZonePos(PlayBookType bookType, Player player, int random)
        {
            Position p = this.GetNearestCourtZonePosByBookId((int)bookType, player, random);
            return p;
        }

        /// <summary>
        /// 获取playbook中离自己最近的区域，随机一个点
        /// 如果自己在其中一个里面，直接返回自身位置
        /// </summary>
        /// <param name="player"></param>
        /// <param name="random"></param>
        /// <returns></returns>
        public Position GetNearestCourtZonePosByBookId(int playbookId, Player player, int random)
        {
            Position p = Position.Empty;
            PlayBook pb = this.GetPlayBook(playbookId);
            double minDis = double.MaxValue;
            int minCzId = -1;
            for (int i = 0; i < pb.TargetZoneList1.Count; i++)
            {
                int czId = pb.TargetZoneList1[i];
                CourtZone cz = this.GetCourtZone(czId);
                if (cz.IsOnMe(player.Pos))
                {
                    return player.Pos;
                }
                double dis = cz.DistanceToThis(player.Pos);
                if (dis < minDis)
                {
                    minDis = dis;
                    minCzId = czId;
                }
            }

            if (minCzId != -1)
            {
                CourtZone cz = this.GetCourtZone(minCzId);
                p = cz.GetRandomPos(random);
            }
            return p;
        }

        /// <summary>
        /// 随机获取一个点
        /// </summary>
        /// <param name="playBookId"></param>
        /// <param name="random"></param>
        /// <returns></returns>
        public Position GetRandomPosition(int playBookId, int random)
        {
            if (!this.dicPlayBook.ContainsKey(playBookId))
            {
                throw new Exception("Error playerbookId: {0}" + playBookId);
            }
            PlayBook pb = this.dicPlayBook[playBookId];
            int czCount = pb.TargetZoneList1.Count;
            int index = random % czCount;

            CourtZone cz = this.dicCourtZone[ pb.TargetZoneList1[index] ];

            return cz.GetRandomPos(random);
        }

        private int GetMinDisZone(PlayBook pb, Position pos)
        {
            double minDis = double.MaxValue;
            int minZone = 0;
            for (int i = 0; i < pb.TargetZoneList1.Count; i++)
            {
                int zone = pb.TargetZoneList1[i];
                double dis = this.DisToZone(pos, zone);
                if (dis < minDis)
                {
                    minDis = dis;
                    minZone = zone;
                }
            }
            return minZone;
        }

        private double DisToZone(Position pos, int zone)
        {
            CourtZone cz = this.dicCourtZone[zone];

            return cz.DistanceToThis(pos);
        }

        private int GetRealId(int czId)
        {
            return (this.fieldType == FieldType.Left) ? czId : (czId + LeftZoneId);
        }

        /// <summary>
        /// 是否在这个区域
        /// </summary>
        /// <param name="czId"></param>
        /// <param name="pos"></param>
        /// <returns></returns>
        public bool IsInCourtZone(int czId, Position pos)
        {
            if (this.dicCourtZone.ContainsKey(czId))
            {
                CourtZone cz = this.dicCourtZone[czId];
                if (cz.IsOnMe(pos))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 在pb上随机一系列点
        /// </summary>
        /// <param name="playerBook"></param>
        /// <param name="random"></param>
        /// <returns></returns>
        public List<Position> GetListPosition(PlayBookType playerBook, int random)
        {
            List<Position> lst = new List<Position>();
            PlayBook pb = this.GetPlayBook((int)playerBook);

            if (pb.TargetZoneList1.Count > 0)
            {
                lst.AddRange(this.GetPlayBookRandomList(pb.TargetZoneList1, random) );
            }
            if (pb.TargetZoneList2.Count > 0)
            {
                lst.AddRange(this.GetPlayBookRandomList(pb.TargetZoneList2, random));
            }
            if (pb.TargetZoneList3.Count > 0)
            {
                lst.AddRange(this.GetPlayBookRandomList(pb.TargetZoneList3, random));
            }
            if (pb.TargetZoneList4.Count > 0)
            {
                lst.AddRange(this.GetPlayBookRandomList(pb.TargetZoneList4, random));
            }
            if (pb.TargetZoneList5.Count > 0)
            {
                lst.AddRange(this.GetPlayBookRandomList(pb.TargetZoneList5, random));
            }
            return lst;
        }

        private List<Position> GetPlayBookRandomList(List<int> lstCourtZone, int random)
        {
            List<Position> lst = new List<Position>();
            for (int i = 0; i < lstCourtZone.Count; i++)
            {
                int czId = lstCourtZone[i];
                CourtZone cz = this.GetCourtZone(czId);
                lst.Add(cz.GetRandomPos(random));
            }
            return lst;
        }
    }
}
