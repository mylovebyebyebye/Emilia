﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{



    public class DistanceEntity
    {
        public int CalcFrame;
        public double DistanceInPixel;
        public double DistanceInCM;
    }

    /// <summary>
    /// 用来存储距离，减少运算次数
    /// </summary>
    public class DistanceManager
    {
        private const int DisCountPlayerToPlayer = 25;
        private const int DisCountPlayerToBasket = 10;

        private DistanceEntity[] m_szDistanceOtherTeam = new DistanceEntity[DistanceManager.DisCountPlayerToPlayer];
        private DistanceEntity[] m_szDistanceHomeTeam  = new DistanceEntity[DistanceManager.DisCountPlayerToPlayer];
        private DistanceEntity[] m_szDistanceAwayTeam = new DistanceEntity[DistanceManager.DisCountPlayerToPlayer];
        //到左篮筐的距离
        private DistanceEntity[] m_szDistanceLeftBasket = new DistanceEntity[DistanceManager.DisCountPlayerToBasket];
        private DistanceEntity[] m_szDistanceRightBasket = new DistanceEntity[DistanceManager.DisCountPlayerToBasket];


        public DistanceManager()
        {
            //初始化
            for (int i = 0; i < DistanceManager.DisCountPlayerToPlayer; i++)
            {
                DistanceEntity deOther = new DistanceEntity();
                deOther.CalcFrame = -1;
                m_szDistanceOtherTeam[i] = deOther;

                DistanceEntity deHome = new DistanceEntity();
                deHome.CalcFrame = -1;
                m_szDistanceHomeTeam[i] = deHome;

                DistanceEntity deAway = new DistanceEntity();
                deAway.CalcFrame = -1;
                m_szDistanceAwayTeam[i] = deAway;
            }
            for (int i = 0; i < DistanceManager.DisCountPlayerToBasket; i++)
            {
                DistanceEntity deLeft = new DistanceEntity();
                deLeft.CalcFrame = -1;
                m_szDistanceLeftBasket[i] = deLeft;

                DistanceEntity deRight = new DistanceEntity();
                deLeft.CalcFrame = -1;
                m_szDistanceRightBasket[i] = deRight;
            }
        }

        private void RefreshDisToPlayer(int frame, DistanceEntity de, Player player1, Player player2)
        {
            if (de.CalcFrame < frame)
            {
                //以前算的，这次就得更新了
                double distance = player1.Pos.Distance(player2.Pos);
                de.CalcFrame = frame;
                de.DistanceInPixel = distance;
                de.DistanceInCM = distance * Position.ActualLengthPerPoint;
            }
        }

        /// <summary>
        /// 敌对方距离
        /// </summary>
        /// <param name="player1"></param>
        /// <param name="player2"></param>
        /// <returns></returns>
        private DistanceEntity GetDistanceEntityToOtherTeamPlayer(Player player1, Player player2)
        {
            int index = -1;
            if (player1.TeamType == TeamType.Home)
            {
                index = (player1.Role - 1) * 5 + player2.Role - 1;
            }
            else
            {
                index = (player2.Role - 1) * 5 + player1.Role - 1;
            }
            DistanceEntity de = m_szDistanceOtherTeam[index];
            return de;
        }

        /// <summary>
        /// 本方距离
        /// </summary>
        /// <param name="player1"></param>
        /// <param name="player2"></param>
        /// <returns></returns>
        private DistanceEntity GetDistanceEntityToSameTeamPlayer(Player player1, Player player2)
        {
            int index = player1.Role * player2.Role - 1;
            if (player1.TeamType == TeamType.Home)
            {
                return m_szDistanceHomeTeam[index];
            }
            else
            {
                return m_szDistanceAwayTeam[index];
            }
        }

        /// <summary>
        /// 获取两个敌对方球员之间的距离
        /// </summary>
        /// <param name="player1"></param>
        /// <param name="player2"></param>
        /// <returns>距离 像素</returns>
        public double GetDistanceInPixelToOtherTeamPlayer(int frame, Player player1, Player player2)
        {
            DistanceEntity de = this.GetDistanceEntityToOtherTeamPlayer(player1, player2);
            this.RefreshDisToPlayer(frame, de, player1, player2);
            return de.DistanceInPixel;
        }

        /// <summary>
        /// 获取两个敌对方球员之间的距离
        /// </summary>
        /// <param name="frame"></param>
        /// <param name="player1"></param>
        /// <param name="player2"></param>
        /// <returns>距离 cm</returns>
        public double GetDistanceInCMToOtherTeamPlayer(int frame, Player player1, Player player2)
        {
            DistanceEntity de = this.GetDistanceEntityToOtherTeamPlayer(player1, player2);
            this.RefreshDisToPlayer(frame, de, player1, player2);
            return de.DistanceInCM;
        }

        /// <summary>
        /// 获取两个己方球员之间的距离
        /// </summary>
        /// <param name="frame"></param>
        /// <param name="player1"></param>
        /// <param name="player2"></param>
        /// <returns>距离 像素</returns>
        public double GetDistanceInPixelToSameTeamPlayer(int frame, Player player1, Player player2)
        {
            DistanceEntity de = this.GetDistanceEntityToSameTeamPlayer(player1, player2);
            this.RefreshDisToPlayer(frame, de, player1, player2);
            return de.DistanceInPixel;
        }

        /// <summary>
        /// 获取两个己方球员之间的距离
        /// </summary>
        /// <param name="frame"></param>
        /// <param name="player1"></param>
        /// <param name="player2"></param>
        /// <returns>距离 cm</returns>
        public double GetDistanceInCMToSameTeamPlayer(int frame, Player player1, Player player2)
        {
            DistanceEntity de = this.GetDistanceEntityToSameTeamPlayer(player1, player2);
            this.RefreshDisToPlayer(frame, de, player1, player2);
            return de.DistanceInCM;
        }

        /// <summary>
        /// 到某一块场地篮筐的距离
        /// </summary>
        /// <param name="frame"></param>
        /// <param name="field"></param>
        /// <param name="player"></param>
        /// <returns>单位 cm</returns>
        public double GetDistanceInCMToFieldBasket(int frame, Field field, Player player)
        {
            DistanceEntity de = this.GetDistanceEntityToFieldBasket(frame, field, player);
            return de.DistanceInCM;
        }

        /// <summary>
        /// 到某一块场地篮筐的距离
        /// </summary>
        /// <param name="frame"></param>
        /// <param name="field"></param>
        /// <param name="player"></param>
        /// <returns>单位 像素</returns>
        public double GetDistanceInPixelToFieldBasket(int frame, Field field, Player player)
        {
            DistanceEntity de = this.GetDistanceEntityToFieldBasket(frame, field, player);
            return de.DistanceInPixel;
        }

        /// <summary>
        /// 获取到篮筐的距离对象
        /// </summary>
        /// <param name="field"></param>
        /// <param name="player"></param>
        /// <returns>单位 cm</returns>
        private DistanceEntity GetDistanceEntityToFieldBasket(int frame, Field field, Player player)
        {
            DistanceEntity de;
            if (field.FieldType == FieldType.Left)
            {
                de = this.GetDistanceInCMToBasket( m_szDistanceLeftBasket,  player);
            }
            else
            {
                de = this.GetDistanceInCMToBasket( m_szDistanceRightBasket, player);
            }
            if (de.CalcFrame < frame)
            {
                //刷新
                double distance = field.GetBasketPos().Distance(player.Pos);
                de.CalcFrame = frame;
                de.DistanceInPixel = distance;
                de.DistanceInCM = distance * Position.ActualLengthPerPoint;
            }
            return de;
        }

        /// <summary>
        /// 获取实体
        /// home 0-4 away 5-9
        /// </summary>
        /// <param name="disToBakset"></param>
        /// <param name="player"></param>
        /// <returns></returns>
        private DistanceEntity GetDistanceInCMToBasket( DistanceEntity[] disToBakset,  Player player)
        {
            if (player.OwnerTeam.TeamType == TeamType.Home)
            {
                return disToBakset[player.Role - 1];
            }
            return disToBakset[player.Role + 4];
        }
    }
}
