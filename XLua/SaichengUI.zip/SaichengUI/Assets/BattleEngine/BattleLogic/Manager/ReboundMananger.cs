﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class ReboundMananger
    {

        private static ReboundMananger instance = null;
        public static ReboundMananger Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ReboundMananger();
                }
                return instance;
            }
        }

        /// <summary>
        /// 把reb1中的概率列转成一个List
        /// </summary>
        private List<int> lstReb1 = new List<int>();

        /// <summary>
        /// 把reb2中的概率列转成一个List
        /// </summary>
        private List<List<int>> lstReb2 = new List<List<int>>();
        

        private ReboundMananger()
        {
            this.Init();
        }


        private bool Init()
        {
            int count = ZDataManager.Instance.GetReb1Table().getRowCount();
            for (int i = 0; i < count; i++)
            {
                ZDB_Row_Data row = ZDataManager.Instance.GetReb1Table().getDataByRow(i);
                this.lstReb1.Add(row.getCol((int)reb1Fields.Number).getValueInt());
            }

            int rowCount = ZDataManager.Instance.GetReb2Table().getRowCount();
            int colCount = ZDataManager.Instance.GetReb2Table().getColCount();
            for (int j = 0; j < colCount; j++)
            {
                List<int> lst = new List<int>();
                for (int i = 0; i < rowCount; i++)
                {
                    ZDB_Row_Data row = ZDataManager.Instance.GetReb2Table().getDataByRow(i);
                    lst.Add(row.getCol(j).getValueInt());
                }
                this.lstReb2.Add(lst);
            }
            return true;
        }

        public int GetIndexRandomReb1(int random)
        {
            return ProbabilityCalc.GetPosition(this.lstReb1, random);
        }

        public int GetIndexRandomReb2(int colIndex,int random)
        {
            return ProbabilityCalc.GetPosition(this.lstReb2[colIndex], random);
        }
    }
}
