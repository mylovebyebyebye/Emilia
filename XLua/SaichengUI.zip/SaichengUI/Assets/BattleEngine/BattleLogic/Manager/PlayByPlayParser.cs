﻿using BattleLogic;
using Common.ZDB;

#if UNITY_5
using UnityEngine;
#endif

public class PlayByPlayParser
{
    enum EventParamType
    {
        None,
        Player,
        JustUse,
        TeamEnum,
        ShootType,
    }
    public string Time;
    public TeamType TargetTeam;
    public string MainInformation;
    public string CurrentScore;
    private GameInfo gameInfo;
    public PlayByPlayParser(GameInfo gameInfo,PlayByPlayContent _content)
    {
        this.gameInfo = gameInfo;
        Time = TimeFrameConverter.GetTimeDesc(_content.QuarterTime);
        TargetTeam = TeamType.Home;

        ZDBTable liveTable = ZDataManager.Instance.getTable("live_text");
        ZDB_Row_Data rowData = liveTable.getDataByID(_content.LiveTextId);

        string _param1 = null;
        if (_content.LiveTextId == 1033)//特殊处理:命中率//
        {
            _param1 = _getLogWithType(_content.LiveTextId,
                (EventParamType)rowData.getCol((int)live_textFields.Location0).getValueInt(), _content.Param1 / 100) + "%";
        }
        else
            _param1 = _getLogWithType(_content.LiveTextId,
                (EventParamType)rowData.getCol((int)live_textFields.Location0).getValueInt(), _content.Param1);

        string _param2 = _getLogWithType(_content.LiveTextId,
            (EventParamType)rowData.getCol((int)live_textFields.Location1).getValueInt(), _content.Param2);
        string _param3 = _getLogWithType(_content.LiveTextId,
            (EventParamType)rowData.getCol((int)live_textFields.Location2).getValueInt(), _content.Param3);
        string _param4 = _getLogWithType(_content.LiveTextId,
            (EventParamType)rowData.getCol((int)live_textFields.Location3).getValueInt(), _content.Param4);


        string[] _mainInfoKeys = rowData.getCol((int)live_textFields.Text).getValueString().Split(',');

        MainInformation = DawnLib.LanguageMgr.Self[_mainInfoKeys[_content.Index], _param1, _param2, _param3, _param4];
        if (string.IsNullOrEmpty(MainInformation))
        {
            MainInformation = "<PlayByPlayParser> 没有找到字段：" + _mainInfoKeys[_content.Index];
        }
#if UNITY_5
        CurrentScore = string.Format("{0}-{1}",
        gameInfo.GetTotalPoint(TeamType.Away),
        gameInfo.GetTotalPoint(TeamType.Home));
#endif

    }
    public string GetContent()
    {
        return string.Format("{0} {1} ", this.Time, this.MainInformation);
    }

    private string _getLogWithType(int liveTextID, EventParamType _type, int _param)
    {
        switch(_type)
        {
            case EventParamType.None:
                return string.Empty;
            case EventParamType.Player:
                {
                    ZDBTable liveTable = ZDataManager.Instance.getTable("player");
                    if (liveTable.hasID(_param) == false)
                    {
                        return string.Format("<PlayByPlayParser> livetext id : {0}  没有找到playerID：{1}", liveTextID, _param);
                    }
                    ZDB_Row_Data rowData = liveTable.getDataByID(_param);

                    return rowData.getCol((int)playerFields.Name).GetUTFString();
                }
            case EventParamType.JustUse:
                return _param.ToString();
            case EventParamType.TeamEnum:
                if (_param == (int)TeamType.Away)
                    return this.gameInfo.AwayTeam.Name;
                else
                    return this.gameInfo.HomeTeam.Name;
            case EventParamType.ShootType:
                {
                    ZDBTable liveTable = ZDataManager.Instance.getTable("shot");
                    ZDB_Row_Data rowData = liveTable.getDataByID(_param);

                    return DawnLib.LanguageMgr.Self[rowData.getCol((int)shotFields.Name).GetUTFString()];
                }
            default:
                return null;
        }
    }
}
