﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class TeamRatingEntity
    {
        /// <summary>
        /// 各项评分
        /// </summary>
        public List<double> LstScore = new List<double>();

        public int StartFrame;
        public int EndFrame;

        public TeamRatingEntity()
        {
            for (int i = (int)ETeamRatingType.Start; i < (int)ETeamRatingType.End; i++)
            {
                LstScore.Add(0.0);
            }
        }
    }

    public class TeamRatingManager
    {
        private double StaminaToTeamRatingParam;

        public TeamRatingManager()
        {
            this.StaminaToTeamRatingParam = ParameterManager.Instance.GetValue(ParameterEnum.TeamRatingStaminaParam) * 1.0 / 100000000; 
        }

        /// <summary>
        /// 计算评分
        /// </summary>
        /// <param name="gameInfo"></param>
        public void CaclTeamRating(int gameFrame, Team team)
        {
            this.FinishLast(gameFrame, team);

            int param69 = ParameterManager.Instance.GetValue(ParameterEnum.TeamRatingCOE);
            ZDBTable teamRatingTable = ZDataManager.Instance.GetTeamRatingTable();
            TeamRatingEntity te = new TeamRatingEntity();
            te.StartFrame = gameFrame;

            for (int i = 0; i < teamRatingTable.getRowCount(); i++)
            {
                ZDB_Row_Data rowData = teamRatingTable.getDataByRow(i);

                //1.进攻战术 2.防守战术
                int tacType = rowData.getCol((int)team_ratingFields.TacticType).getValueInt();
                //战术id
                int tacNo = rowData.getCol((int)team_ratingFields.TacticNo).getValueInt();
                if (tacType == 1)
                {
                    if (tacNo != (int)ETacticOff.BaseOff)
                    {
                        //战术不匹配，不用管
                        continue;
                    }
                }
                else
                {
                    if (tacNo != (int)ETacticDef.BaseDef)
                    {
                        continue;
                    }
                }
                int type = rowData.getCol((int)team_ratingFields.RatingType).getValueInt();
                int position = rowData.getCol((int)team_ratingFields.Position).getValueInt();

                Player player = team.Players[position - 1];
                double value = 0.0;
                for (int j = 0; j < 4; j++)
                {
                    int skill = rowData.getCol((int)team_ratingFields.Skill1 + 2 * j).getValueInt();
                    int weight = rowData.getCol((int)team_ratingFields.Weight1 + 2 * j).getValueInt();
                    if (skill != 0)
                    {
                        value += player.GetAttrByIndex(skill) * weight;
                    }
                }
                value = value / param69;
                //2017.1.5 增加体力影响
                double staminaAdd = player.CurStamina * this.StaminaToTeamRatingParam;
                if (staminaAdd > 1.0)
                {
                    staminaAdd = 1.0;
                }
                value = value * staminaAdd;
                te.LstScore[type] += Math.Round(value,2);
            }
            team.TeamRatingLst.Add(te);
        }

        public void FinishLast(int gameFrame, Team team)
        {
            TeamRatingEntity te = this.GetCurTeamRating(team);
            if (te != null)
            {
                te.EndFrame = gameFrame;
            }
        }

        public void CalcTeamRaingAndAddPlayerAttr(GameInfo gameInfo)
        {
            this.CaclTeamRating(gameInfo.GameFrame, gameInfo.HomeTeam);
            this.CaclTeamRating(gameInfo.GameFrame, gameInfo.AwayTeam);
            this.ImpaceAttribute(gameInfo);         
        }

        public void Finish(GameInfo gameInfo)
        {
            this.FinishLast(gameInfo.GameFrame, gameInfo.HomeTeam);
            this.FinishLast(gameInfo.GameFrame, gameInfo.AwayTeam);
        }

        private void ImpaceAttribute(GameInfo gameInfo)
        {
            Team homeTeam = gameInfo.HomeTeam;
            Team awayTeam = gameInfo.AwayTeam;

            TeamRatingEntity teHome = this.GetCurTeamRating(homeTeam);
            TeamRatingEntity teAway = this.GetCurTeamRating(awayTeam);
            //外线评级
            int homeDefSubAwayAtkOut = (int)( teHome.LstScore[(int)ETeamRatingType.OutsideDefence] - teAway.LstScore[(int)ETeamRatingType.OutsideScoring] );
            int awayDefSubHomeAtkOut = (int)( teAway.LstScore[(int)ETeamRatingType.OutsideDefence] - teHome.LstScore[(int)ETeamRatingType.OutsideScoring] );
            //内线评级
            int homeDefSubAwayAtkIn = (int)(teHome.LstScore[(int)ETeamRatingType.InsideDefence] - teAway.LstScore[(int)ETeamRatingType.InsideScoring]);
            int awayDefSubHomeAtkIn = (int)(teAway.LstScore[(int)ETeamRatingType.InsideDefence] - teHome.LstScore[(int)ETeamRatingType.InsideScoring]);
            //篮板评级
            int homeRebSubAwayReb = (int)(teHome.LstScore[(int)ETeamRatingType.Rebound] - teAway.LstScore[(int)ETeamRatingType.Rebound]);
            int awayRebSubHomeReb = homeRebSubAwayReb * -1;

            this.AddPlayerAttr(homeTeam, homeDefSubAwayAtkOut, homeDefSubAwayAtkIn, homeRebSubAwayReb);
            this.AddPlayerAttr(awayTeam, awayDefSubHomeAtkOut, awayDefSubHomeAtkIn, awayRebSubHomeReb);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="team"></param>
        /// <param name="defSubAtkOut"></param>
        /// <param name="defSubAtkIn"></param>
        /// <param name="rebSub"></param>
        private void AddPlayerAttr(Team team, int defSubAtkOut, int defSubAtkIn, int rebSub)
        {
            ZDBTable outTable = ZDataManager.Instance.GetTeamRatingOutsideTable();
            ZDBTable inTable = ZDataManager.Instance.GetTeamRatingInsideTable();
            ZDBTable rebTable = ZDataManager.Instance.GetTeamRatingReboundTable();
            ZDBTable[] szTables = { outTable, inTable, rebTable };
            int[] margins = { defSubAtkOut, defSubAtkIn,  rebSub};
            team.MaxHanlder = null;
            for (int i = 0; i < team.Players.Count; i++)
            {
                Player player = team.Players[i];

                for (int j = 0; j < szTables.Length; j++)
                {
                    int attr1, attr2, value1, value2;
                    this.GetModifyValue(szTables[j], margins[j], out attr1, out attr2, out value1, out value2);
                    if (attr1 > 0)
                    {
                        player.AddAttrByIndex(attr1, value1);
                    }
                    if (attr2 > 0)
                    {
                        player.AddAttrByIndex(attr2, value2);
                    }
                    team.SetMaxAbilityPlayer(player);
                }

                player.Reload();
            }
        }

        private void GetModifyValue(ZDBTable table, int margin, out int attr1, out int attr2, out int value1, out int value2)
        {
            int row = 0;
            if (margin == 0)
            {
                row = 100;
            }
            else
            {
                row = 100 + margin;
                if (row > 200)
                {
                    row = 200;
                }
                else if (row < 0)
                {
                    row = 0;
                }
            }
            ZDB_Row_Data rowData = table.getDataByRow(row);
            //所有表同结构
            attr1 = rowData.getCol((int)team_rating_insideFields.Skill1).getValueInt();
            value1 = rowData.getCol((int)team_rating_insideFields.Margin1).getValueInt();
            attr2 = rowData.getCol((int)team_rating_insideFields.Skill2).getValueInt();
            value2 = rowData.getCol((int)team_rating_insideFields.Margin2).getValueInt();
        }

        public TeamRatingEntity GetCurTeamRating(Team team)
        {
            if (team.TeamRatingLst.Count > 0)
            {
                return team.TeamRatingLst[team.TeamRatingLst.Count - 1];
            }
            return null;
        }

        public TeamRatingEntity GetTotalTeamRating(Team team)
        {
            if (team.TeamRatingLst.Count > 0)
            {
                if (team.TeamRatingLst.Count == 1)
                {
                    return team.TeamRatingLst[0];
                }
                else
                {
                    TeamRatingEntity teTotal = new TeamRatingEntity();
                    int totalFrame = 0;
                    //需要计算总评
                    for(int i = 0 ;i < team.TeamRatingLst.Count; i++)
                    {
                        TeamRatingEntity te = team.TeamRatingLst[i];
                        int processFrame = te.EndFrame - te.StartFrame;
                        totalFrame += processFrame;
                        for (int j = (int)ETeamRatingType.Start + 1; j < (int)ETeamRatingType.End; j++) 
                        {
                            teTotal.LstScore[j] += te.LstScore[j] * processFrame;
                        } 
                    }
                    for (int i = (int)ETeamRatingType.Start + 1; i < (int)ETeamRatingType.End; i++)
                    {
                        teTotal.LstScore[i] = Math.Round( teTotal.LstScore[i] / totalFrame, 2);
                    }
                    return teTotal;
                }
            }
            return null;
        }
    }
}
