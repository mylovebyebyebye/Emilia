﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class SpeedManager
    {
        private static object lockOjb = new object();

        private static SpeedManager instance = null;
        public static SpeedManager Instance
        {
            get
            {
                lock (lockOjb)
                {
                    if (instance == null)
                    {
                        instance = new SpeedManager();
                    }
                }
                return instance;
            }
        }

        private SpeedManager()
        {
            this.Init();
        }

        private bool Init()
        {
            return true;
        }
        /// <summary>
        /// 加速移动等级
        /// </summary>
        /// <param name="player"></param>
        /// <param name="random">1~100</param>
        /// <returns></returns>
        public int GetSpeedAccelerate(Player player, int random)
        {
            int staminaLevel = player.GetStaminaLevel();
            ZDB_Row_Data row = ZDataManager.Instance.GetSpeedAccelerateTable().getDataByID(staminaLevel);
            return this.GetSpeedLevel(row, random);
        }


        public int GetSpeedNormal(Player player, int random)
        {
            int staminaLevel = player.GetStaminaLevel();
            ZDB_Row_Data row = ZDataManager.Instance.GetSpeedNormalTable().getDataByID(staminaLevel);
            return this.GetSpeedLevel(row, random);
        }

        /// <summary>
        /// 随机速度等级
        /// </summary>
        /// <param name="row"></param>
        /// <param name="random"></param>
        /// <returns></returns>
        private int GetSpeedLevel(ZDB_Row_Data row, int random)
        {
            int speedLevel = 0;
            int sum = 0;
            for (int i = 0; i <= 10; i++)
            {
                sum += row.getCol(i + 2).getValueInt();
                if (sum >= random)
                {
                    speedLevel = i;
                    break;
                }
            }
            return speedLevel;
        }

        /// <summary>
        /// 球员移动修改了，有了加减速过程
        /// 用这个东西来打补丁
        /// </summary>
        /// <param name="player">球员</param>
        /// <param name="gt">原来的移动</param>
        /// <param name="isUseLastChoice">是否是后续任务，后续任务就取上一个任务的目标，且加到后续列表里</param>
        public void SetMoveTask(GameInfo gameInfo, Player player, GameTask gt,int maxFrame = int.MaxValue, bool isNextTask = false)
        {
            if (gameInfo.DefTeam != player.OwnerTeam)
            {
                List<GameTask> lst = this.GetAttackMoveTask(player, gt, maxFrame, isNextTask);
                if (lst.Count > 0)
                {
                    GameTask gtNew = lst[lst.Count - 1];
                    lst.RemoveAt(lst.Count - 1);
                    GameTask gtReset = this.ResetGameTask(gt, gtNew);
                    lst.Add(gtReset);
                }
                int index = 0;
                for (int i = 0; i < lst.Count; i++)
                {
                    GameTask gtReal = lst[i];
                    if (index == 0)
                    {
                        player.SetCurrentTask(gtReal);
                    }
                    else
                    {
                        player.NextTask.Add(gtReal);
                    }
                    index++;
                }
            }
        }

        /// <summary>
        /// 最后一个任务要置为跟输入的gametask一样
        /// </summary>
        /// <param name="gtSource"></param>
        /// <param name="gtNew"></param>
        private GameTask ResetGameTask(GameTask gtSource, GameTask gtNew)
        {
            GameTask gt = gtSource.Clone();
            gt.StartPos = gtNew.StartPos;
            gt.TargetPos = gtNew.TargetPos;
            gt.DeltaX = gtNew.DeltaX;
            gt.DeltaY = gtNew.DeltaY;
            gt.FinishFrame = gtNew.FinishFrame;
            gt.DelayStart = gtNew.DelayStart;

            return gt;
        }

        /// <summary>
        /// 非防守方移动过程
        /// </summary>
        /// <param name="player">球员</param>
        /// <param name="gt">原来的移动</param>
        /// <param name="isUseLastChoice">是否是后续任务，后续任务就取上一个任务的目标，且加到后续列表里</param>
        private List<GameTask> GetAttackMoveTask(Player player, GameTask gt, int maxFrame,bool isNextTask)
        {
            List<GameTask> lst = new List<GameTask>();
            //取当前运动的速度及目标
            int lastSpeedLevel = 0;
            Position lastTargetPos = player.Pos;
            GameTask lastGameTask = this.GetLastGameTask(player, isNextTask);
            if (lastGameTask != null)
            {
                lastSpeedLevel = lastGameTask.SpeedLevel;
                lastTargetPos = lastGameTask.TargetPos;
            }
            //这次的速度及目标
            int curSpeedLevel = gt.SpeedLevel;
            Position curTarget = gt.TargetPos;
            if (curSpeedLevel == 0)
            {
                curTarget = lastTargetPos;
            }
            Position startPos = player.Pos;
            int totalFrame = 0;
            //减速到什么速度等级
            int cutToSpeedLevel = this.GetSpeedCutToLevel(startPos, curTarget, curSpeedLevel, lastTargetPos, lastSpeedLevel);
            //减速过程
            totalFrame += this.AddSpeedCutTask(player, gt, maxFrame, startPos,  lastTargetPos, lastSpeedLevel, cutToSpeedLevel, lst);
            if (totalFrame > 0)
            {
                if (totalFrame >= maxFrame)
                {
                    return lst;
                }
                //说明有减速过程，下个任务的起点要换
                startPos = lst[lst.Count - 1].RealTarget;
            }
            //计算实际的最高速度等级
            int maxSpeedLevel = this.GetRealMaxSpeedLevel(player, cutToSpeedLevel, curSpeedLevel, startPos, curTarget);
            if (maxSpeedLevel > 0)
            {
                //加速过程
                int maxUpFrame = maxFrame - totalFrame;
                totalFrame += this.AddSpeedUpTask(player, gt, maxUpFrame, startPos, curTarget, cutToSpeedLevel, maxSpeedLevel, lst);
                if (totalFrame >= maxFrame)
                {
                    return lst;
                }
                if (lst.Count > 0)
                {
                    startPos = lst[lst.Count - 1].RealTarget;
                }

                //匀速过程
                //根据减速过程的距离，算匀速过程的终点
                double speedCutDis = this.GetSpeedCutToZeroDis(player, maxSpeedLevel);
                int maxUniformFram = maxFrame - totalFrame;
                totalFrame += this.AddSpeedUniformMotionTask(player, gt, maxUniformFram, startPos, curTarget, maxSpeedLevel, speedCutDis, lst);
                if (totalFrame >= maxFrame)
                {
                    return lst;
                }
                if (lst.Count > 0)
                {
                    startPos = lst[lst.Count - 1].RealTarget;
                }

                //减速过程
                int maxCutFrame = maxFrame - totalFrame;
                this.AddSpeedCutTask(player, gt, maxCutFrame, startPos, curTarget, maxSpeedLevel, 0, lst);
            }

            return lst;
        }

        /// <summary>
        /// 上次任务（其实就是当前在执行的任务）
        /// </summary>
        /// <param name="player"></param>
        /// <param name="isNextTask"></param>
        /// <returns></returns>
        private GameTask GetLastGameTask(Player player, bool isNextTask)
        {
            GameTask lastGameTask = player.GetCurTask();
            if (isNextTask)
            {
                if (player.NextTask.Count > 0)
                {
                    lastGameTask = player.NextTask[player.NextTask.Count - 1];
                }
                else
                {
                    lastGameTask = player.GetCurTask();
                }
            }
            else
            {
                if (player.IsInTask( TaskType.Unkown))
                {
                    lastGameTask = player.LastDoTask;
                }
            }
            return lastGameTask;
        }

        /// <summary>
        /// 计算减速等级
        /// </summary>
        /// <param name="curPos">当前位置</param>
        /// <param name="newTarget">目标位置</param>
        /// <param name="newSpeedLevel">目标速度</param>
        /// <param name="oldTarget">之前的目标位置</param>
        /// <param name="oldSpeedLevel">之前的速度</param>
        /// <returns>减速到多少</returns>
        private int GetSpeedCutToLevel(Position curPos, Position newTarget, int newSpeedLevel, Position oldTarget, int oldSpeedLevel)
        {

            Vector2D v1 = new Vector2D(curPos, oldTarget);
            Vector2D v2 = new Vector2D(curPos, newTarget);


            int toSpeedLevel = oldSpeedLevel;
            double angle = v1.GetAngleWithAnotherVector(v2);
            if (oldSpeedLevel > 0 & angle > 90)
            {
                //减速到0
                toSpeedLevel = 0;
            }
            else if (oldSpeedLevel > newSpeedLevel)
            {
                //减速到newspeedlevel
                toSpeedLevel = newSpeedLevel;
            }
            return toSpeedLevel;
        }

        /// <summary>
        /// 减速过程
        /// </summary>
        /// <param name="player">球员</param>
        /// <param name="gt">之前随出来的任务</param>
        /// <param name="maxFrame">最大运动帧数</param>
        /// <param name="start">当前位置</param>
        /// <param name="target">之前的目标</param>
        /// <param name="oldSpeedLevel">之前的运动速度</param>
        /// <param name="lst"></param>
        /// <returns>减速过程运动帧数</returns>
        private int AddSpeedCutTask(Player player, GameTask gtSource, int maxFrame, Position start,  Position target, int oldSpeedLevel, int toSpeedLevel,List<GameTask> lst)
        {
            if (start == target)
            {
                return 0;
            }

            Position startPos = start;
            int frame = 0;
            if (toSpeedLevel < oldSpeedLevel)
            {
                //减速过程
                ZDBTable speedChangeTable = ZDataManager.Instance.GetSpeedChangeTable();
                for (int i = oldSpeedLevel; i > toSpeedLevel; i--)
                {
                    ZDB_Row_Data rowData = speedChangeTable.getDataByID(i);
                    int minSec = rowData.getColByName(speed_changeFields.Decelerate.ToString()).getValueInt();
                    if (minSec > 0)
                    {
                        double seconds = minSec * 1.0f / 1000;

                        //运动距离
                        double dis = seconds * (player.GetSpeedInPixelByLevel(i));
                        Position targetPos = Formula.ClosestIntersection(startPos, (double)dis, start, target);

                        //分级减速
                        GameTask gt = this.GetGameTask(player, gtSource, startPos, targetPos, i, seconds);
                        frame += gt.FinishFrame;

                        lst.Add(gt);
                        if (frame >= maxFrame)
                        {
                            int overload = frame - maxFrame;
                            gt.FinishFrame -= overload;
                            frame = maxFrame;
                            break;
                        }

                        startPos = gt.RealTarget;
                    }
                }
            }

            return frame;
        }

        /// <summary>
        /// 加速过程
        /// </summary>
        /// <param name="player">球员</param>
        /// <param name="gt">没用</param>
        /// <param name="maxFrame">最长加速帧数</param>
        /// <param name="start">起点</param>
        /// <param name="target">目标点</param>
        /// <param name="startSpeedLevel">起步速度</param>
        /// <param name="maxSpeedLevel">最高速度</param>
        /// <param name="lst"></param>
        /// <returns>实际加速帧数</returns>
        private int AddSpeedUpTask(Player player,GameTask gtSource, int maxFrame, Position start, Position target, int startSpeedLevel, int maxSpeedLevel, List<GameTask> lst)
        {
            int frame = 0;
            for (int i = startSpeedLevel; i < maxSpeedLevel; i++)
            {
                ZDBTable speedChangeTable = ZDataManager.Instance.GetSpeedChangeTable();
                ZDB_Row_Data rowData = speedChangeTable.getDataByID(i);
                int minSec = rowData.getColByName(speed_changeFields.Accelerate.ToString()).getValueInt();
                if (minSec > 0)
                {
                    double seconds = minSec * 1.0f / 1000;
                    //分级加速
                    GameTask gt = this.GetGameTask(player, gtSource, start, target, i, seconds);
                    frame += gt.FinishFrame;

                    lst.Add(gt);
                    if (frame >= maxFrame)
                    {
                        int overload = frame - maxFrame;
                        gt.FinishFrame -= overload;
                        frame = maxFrame;
                        break;
                    }

                    start = gt.RealTarget;
                }
            }
            return frame;
        }

        /// <summary>
        /// 匀速运动过程
        /// </summary>
        /// <param name="player"></param>
        /// <param name="gt"></param>
        /// <param name="maxFrame"></param>
        /// <param name="start"></param>
        /// <param name="target"></param>
        /// <param name="speedLevel"></param>
        /// <param name="speedCutDis"></param>
        /// <param name="lst"></param>
        /// <returns></returns>
        private int AddSpeedUniformMotionTask(Player player, GameTask gtSource, int maxFrame, Position start, Position target, int speedLevel, double speedCutDis, List<GameTask> lst)
        {
            if (start == target)
            {
                return 0;
            }
            Position realTarget = target;
            if (speedCutDis > Formula.MinDifference)
            {
                //计算真实终点,起点终点连线， 跟 以终点为圆心，减速距离为半径的圆的交点
                realTarget = Formula.ClosestIntersection(target, Position.GetPix(speedCutDis), target, start);
            }

            double speedInPixel = player.GetSpeedInPixelByLevel(speedLevel);
            double sec = start.Distance(realTarget) / speedInPixel;

            GameTask gt = this.GetGameTask(player, gtSource, start, realTarget, speedLevel, (double)sec);

            lst.Add(gt);
            if (gt.FinishFrame > maxFrame)
            {
                gt.FinishFrame = maxFrame;
            }
            return gt.FinishFrame;
        }

        /// <summary>
        /// 计算真实的最高速度等级
        /// </summary>
        /// <param name="player">球员</param>
        /// <param name="speedLevel">随出来的最高速度等级</param>
        /// <param name="start">起点（根据之前的减速有可能不是球员当前位置）</param>
        /// <param name="target">目标点</param>
        /// <returns>实际最高速度等级</returns>
        private int GetRealMaxSpeedLevel(Player player, int lastSpeedLevel, int randomSpeedLevel, Position start, Position target)
        {
            int realMaxSpeedLevel = randomSpeedLevel;
            if (randomSpeedLevel > 0)
            {
                if (lastSpeedLevel > 10)
                {
                    lastSpeedLevel = 10;
                }

                double dis = start.DistanceActualLength(target);

                //读表，根据距离和当前的速度等级， 判断最高速度等级
                //这个表的解释问樊智
                ZDBTable speedUpDisTable = ZDataManager.Instance.GetSpeedUpDistanceTable();

                for (int i = 0; i < speedUpDisTable.getRowCount(); i++)
                {
                    ZDB_Row_Data rowData = speedUpDisTable.getDataByRow(i);
                    int maxDis = rowData.getColByName(speed_up_distanceFields.Distance.ToString()).getValueInt();
                    if (dis < maxDis)
                    {
                        int maxSpeed = rowData.getColByName("Speed" + lastSpeedLevel).getValueInt();
                        if (maxSpeed < randomSpeedLevel)
                        {
                            realMaxSpeedLevel = maxSpeed;
                        }
                    }
                }
            }
            return realMaxSpeedLevel;
        }

        /// <summary>
        /// 减速到0的距离
        /// </summary>
        /// <param name="player">球员</param>
        /// <param name="speedLevel">当前速度</param>
        /// <returns>距离</returns>
        private double GetSpeedCutToZeroDis(Player player, int speedLevel)
        {
            double dis = 0.0;
            //减速过程
            ZDBTable speedChangeTable = ZDataManager.Instance.GetSpeedChangeTable();
            for (int i = speedLevel; i > 0; i--)
            {
                ZDB_Row_Data rowData = speedChangeTable.getDataByID(i);
                int minSec = rowData.getColByName(speed_changeFields.Decelerate.ToString()).getValueInt();
                if (minSec > 0)
                {
                    double speed = player.GetSpeedByLevel(i);
                    dis += speed * (minSec * 1.0f / 1000);
                }
            }
            return dis;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="player"></param>
        /// <param name="gtSouce"></param>
        /// <param name="start"></param>
        /// <param name="target"></param>
        /// <param name="speedLevel"></param>
        /// <param name="seconds"></param>
        /// <returns></returns>
        private GameTask GetGameTask(Player player,GameTask gtSource, Position start, Position target, int speedLevel, double seconds)
        {
            GameTask gt = new GameTask(gtSource.Source, gtSource.TaskSource);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = start;
            gt.TargetPos = target;
            gt.SpeedLevel = speedLevel;
            gt.DelayStart = 0;
            double speedInPixel = player.GetSpeedInPixelByLevel(speedLevel);

            gt.FinishFrame = gt.CalcRealTargetByTimeSpeed(seconds, speedInPixel);

            if (gtSource.RecordPos != Position.Empty)
            {
                gt.RecordPos = gtSource.RecordPos.Clone();
            }
            gt.TargetPlayer = gtSource.TargetPlayer;

            return gt;
        }
    }
}
