﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class ShotTableManager
    {
        private static ShotTableManager instance = null;
        public static ShotTableManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ShotTableManager();
                }
                return instance;
            }
        }

        private List<ZDBTable> ShotTablesList = new List<ZDBTable>();

        private ShotTableManager()
        {
            this.Init();
        }

        private void Init()
        {
            ZDBTable shotIndexTable = ZDataManager.Instance.GetShotIndexTable();
            for (int i = 0; i < shotIndexTable.getRowCount(); i++)
            {
                ZDB_Row_Data rowData = shotIndexTable.getDataByRow(i);
                string tableName = rowData.getCol((int)shot_indexFields.SheetName).getValueString();
                ZDBTable table = ZDataManager.Instance.getTable(tableName);
                this.ShotTablesList.Add(table);
            }
        }

        /// <summary>
        /// 根据id获取对应的Shot有关的表
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public ZDBTable GetShotTableByIndex(int index)
        {
            if (index <= 0 || index > this.ShotTablesList.Count)
            {
                throw new Exception("error shot table index" + index);
            }
            return this.ShotTablesList[index - 1];
        }
    }
}
