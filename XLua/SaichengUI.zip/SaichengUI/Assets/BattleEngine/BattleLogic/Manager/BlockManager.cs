﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class BlockManager
    {
        private static object lockOjb = new object();

        private static BlockManager instance = null;
        public static BlockManager Instance
        {
            get
            {
                lock (lockOjb)
                {
                    if (instance == null)
                    {
                        instance = new BlockManager();
                    }
                }
                return instance;
            }
        }

        private List<int> lstBlockAngle = new List<int>();

        private List<int> lstBlockDistance = new List<int>();

        private BlockManager()
        {
            this.Init();
        }


        private bool Init()
        {
            int count = ZDataManager.Instance.GetBlockAngleTable().getRowCount();
            for (int i = 0; i < count; i++)
            {
                ZDB_Row_Data row = ZDataManager.Instance.GetBlockAngleTable().getDataByRow(i);
                this.lstBlockAngle.Add(row.getCol((int)block_angleFields.Chance).getValueInt());
            }

            int count1 = ZDataManager.Instance.GetBlockDistanceTable().getRowCount();
            for (int i = 0; i < count1; i++)
            {
                ZDB_Row_Data row = ZDataManager.Instance.GetBlockDistanceTable().getDataByRow(i);
                this.lstBlockDistance.Add((row.getCol((int)block_distanceFields.Chance)).getValueInt());
            }

            return true;
        }

        public int GetIndexRandomBlockAngle(int random)
        {
            return ProbabilityCalc.GetPosition(this.lstBlockAngle, random);
        }

        public int GetIndexRandomBlockDistance(int random)
        {
            return ProbabilityCalc.GetPosition(this.lstBlockDistance, random);
        }
    }
}
