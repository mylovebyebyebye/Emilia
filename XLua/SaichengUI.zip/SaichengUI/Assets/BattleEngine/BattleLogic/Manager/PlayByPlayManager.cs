﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayByPlayContent
    {
        public int QuarterTime;
        public int LiveTextId;
        public int Index;
        public int Param1;
        public int Param2;
        public int Param3;
        public int Param4;
    }

    public class PlayByPlayManager
    {

        private Dictionary<int, int> dicRandomCount;

        private bool isPlayByPlay = true;

        private static PlayByPlayManager instance = null;

        public static PlayByPlayManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new PlayByPlayManager();
                }
                return instance;
            }
        }

        private PlayByPlayManager()
        {
            this.Init();
        }

        private void Init()
        {
            this.dicRandomCount = new Dictionary<int, int>();

            ZDBTable liveTextTable = ZDataManager.Instance.GetLiveTextTable();
            foreach (EPlayeByPlayType playbyplayType in Enum.GetValues(typeof(EPlayeByPlayType)))
            {
                ZDB_Row_Data rowData = liveTextTable.getDataByID((int)playbyplayType);
                //找出可以随机几种直播内容
                string text = rowData.getCol((int)live_textFields.Text).getValueString();
                string[] array = text.Split(new char[]{','}, StringSplitOptions.RemoveEmptyEntries);

                this.dicRandomCount.Add((int)playbyplayType, array.Length);
            }
        }

        public void SetPlaybyPlay(bool isPlaybyPlay)
        {
            this.isPlayByPlay = isPlaybyPlay;
        }

        public PlayByPlayContent GetContent(GameInfo info, EPlayeByPlayType playbyplayType,  int param1, int param2 = 0, int param3 = 0, int param4 = 0)
        {
            if (!this.isPlayByPlay)
            {
                return null;
            }
            PlayByPlayContent content = new PlayByPlayContent();
            content.QuarterTime = (int)info.QuarterTime;
            content.LiveTextId = (int)playbyplayType;
            content.Index = info.RandomNext(0, this.dicRandomCount[(int)playbyplayType] - 1);
            content.Param1 = param1;
            content.Param2 = param2;
            content.Param3 = param3;
            content.Param4 = param4;

            return content;
        }
    }
}
