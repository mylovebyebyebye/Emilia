﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class TaskMoveTo
    {
        /// <summary>
        /// 根据当前位置，目标位置，移动时间，算这次要移动到哪里
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="finishFrame"></param>
        /// <param name="pos"></param>
        /// <returns></returns>
        public static bool Do(CourtObject obj)
        {
            GameTask curTask = obj.GetCurTask();
            if (curTask.FinishFrame <= 0)
            {
                return true;
            }
            if (curTask.FinishFrame >= 1)
            {
                if (curTask.FinishFrame == 1 && curTask.FinishToTarget)
                {
                    obj.Pos = curTask.TargetPos;
                }
                else
                {
                    int startX = curTask.StartPos.X;
                    int startY = curTask.StartPos.Y;
                    obj.Pos = new Position((int)(startX - curTask.DeltaX * curTask.ProcessFrame), (int)(startY - curTask.DeltaY * curTask.ProcessFrame));
                }
            }
            return true;
        }
    }
}
