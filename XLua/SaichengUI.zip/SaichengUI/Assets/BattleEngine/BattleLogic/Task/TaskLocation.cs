﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class TaskLocation
    {
        public static bool Do(CourtObject obj, Position pos)
        {
            obj.Pos = pos;
            return true;
        }
    }
}
