﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;

namespace BattleLogic
{
    public enum TaskType
    {

        Unkown                                              = 0,
        BallLocation                                        = 1,                   //直接出现在某个位置，没有移动过程
        BallStatic                                          = 2,                   //静止
        BallPassBall                                        = 3,                   //传球
        BallOnThePlayer                                     = 4,                   //跟随持球人
        BallShot                                            = 5,                   //投篮
        BallLayup                                           = 6,                   //上篮（包括扣篮）
        BallRebound                                         = 7,                   //篮板飞行
        BallHiding                                          = 8,                   //隐身
        BallBlockRebound                                    = 9,                   //投篮盖帽后的篮板
        BallReadyToFreeThrow                                = 10,                 //准备罚球
        BallFreeThrow                                       = 11,                   //罚球出手了
        BallMoveTo                                          = 12,                   //球动
        BallOnTheFloorBounce                                = 13,                   //地板球弹
        BallOnTheFloorRoll                                  = 14,                   //地板漆滚

        PlayerLocation                                      = 101,                 //直接出现在某个位置，没有移动过程
        PlayerStandby                                        = 102,                 //静止
        PlayerMoveTo                                        = 103,                 //移动到某个位置
        PlayerShot                                          = 104,                 //投篮
        PlayerLayup                                         = 105,                 //上篮

        PlayerLeave3SecondLane                              = 106,                 //出3秒区
        PlayerAskTheBall                                    = 107,                 //要球
        PlayerMoveToArea                                    = 108,                 //移动到预设区域
        //PlayerPassBall                                      = 109,                 //传球
        PlayerDriveToTheBasket                              = 110,                 //冲击篮筐
        PlayerDriveToAttackField                            = 111,                  //过半场
        PlayerOneOneOneDef                                  = 112,                  //人盯人防守
        PlayerLuoWeiDingRen                                 = 113,                  //落位盯人
        PlayerToGetPassBall                                 = 114,                  //去一个地点等接球
        PlayerMoveToAttackBasket                            = 115,                  //防守者追击
        PlayerPress                                         = 116,                  //紧逼
        PlayerDefShot                                       = 117,                  //防投篮人
        PlayerRebound                                       = 118,                  //抢篮板
        PlayerBoxOut                                        = 119,                  //篮板卡位
        PlayerStandToGetBall                                = 120,                  //等待要球
        PlayerMoveToThrowIn                                 = 121,                  //移动去发球
        PlayerToThrowIn                                     = 122,                  //等待发界外球的人
        PlayerMoveToGetThrowIn                              = 123,                  //移动去要球
        PlayerMoveToCrossOver                               = 124,                  //移动去触发突破判断
        PlayerPositioning                                   = 125,                  //跑位
        PlayerMoveToSpaceOut                                = 126,                  //拉开
        PlayerFastBreak                                     = 127,                  //快下
        PlayerToStealPassBall                               = 128,                  //防传球
        PlayerMoveToDefFastBreak                            = 129,                  //防快下
        PlayerMoveToFinishPickRoll                          = 130,                  //完成挡拆
        PlayerJumpDefShot                                   = 131,                  //跳起干扰投篮
        PlayerChangeDefTarget                               = 132,                  //更换防守目标

        PlayerToGetRebound                                  = 200,                  //去抢板
        PlayerTakePosStandby                                = 201,                  //抢位以后的静止
        PlayerTakePosPush                                   = 202,                  //抢位以后的推搡
        PlayerTakePosMove                                   = 203,                  //抢位后的移动
        PlayerAfterBallHitHoop                              = 204,                  //球到篮筐以后球员动作选择
        PlayerAfterBallHitMoveToBall                        = 205,                  //移动到篮板球的落点
        PlayerAfterBallShot                                 = 206,                  //球进了
        PlayerAfterBallShotToThrowIn                        = 207,                  //球进了以后的发球员
        PlayerReadyToBallShotThrowIn                        = 208,                  //准备发球进以后的界外球
        PlayerReadyToOutOfBoundThrowIn                      = 209,                  //准备发出界界外球
        PlayerInsideSingleAttack                            = 210,                  //内线单打配合
        PlayerOutsideSingleAttack                           = 211,                  //外线单打
        PlayerInsideAttackPrepare                           = 212,                  //内线进攻准备阶段  
        PlayerInsideAttack                                  = 213,                  //内线进攻阶段  
        PlayerBeginSlamDunk                                 = 214,                  //扣篮开始
        PlayerBeginFadeAway                                 = 215,                  //后仰跳投开始
        PlayerToGetBallOnTheFloor                           = 216,                  //抢地板球
        PlayerInsideAttackHelpDefence                       = 217,                  //背打协防
        PlayerInsideAttackJieYing                           = 218,                  //背打接应
        PlayerInsideAttackDoubled                           = 219,                  //背打包夹
        PlayerCover                                         = 220,                  //挡拆掩护
        PlayerPickRoll                                      = 221,                  //挡拆
        PlayerCoverPaowei                                   = 222,                  //跑位掩护
        PlayerToPassBall                                    = 223,                  //传球
        PlayerToGetPassBallNormal                           = 224,                  //常规传球接球
        PlayerToShot                                        = 225,                  //待出手状态


        TaskCanNotInterupt                                  = 1000,                 //以下是不可打断任务
        PlayerForceStandBy                                  = 1001,                 //强制待机
        PlayerForceMoveTo                                   = 1002,                 //强制移动
    }

    public class GameTask
    {

        public TaskType TaskType;

        protected Position targetPos;

        public Position TargetPos
        {
            get { return targetPos; }
            set 
            {
                targetPos = value;
                this.realTarget = targetPos;
            }
        }

        public Position StartPos;

        protected Position realTarget;

        public Position RealTarget
        {
            get { return this.realTarget; }
        }

        public Player TargetPlayer;

        public Player SecondPlayer;

        public int DelayStart;

        public int FinishFrame;

        public int ProcessFrame;

        public int Param1;
        public int Param2;
        public int Param3;
        public int Param4;

        public double DeltaX;
        public double DeltaY;

        public bool FinishToTarget;

        public bool Success;

        public int SpeedLevel;

        /// <summary>
        /// 增加了一个下一步任务
        /// </summary>
        public TaskType NextTask;
        /// <summary>
        /// 记录的位置
        /// </summary>
        public Position RecordPos;

        public string Source;

        private ETaskSource taskSource;

        public ETaskSource TaskSource
        {
            get { return taskSource; }
        }

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="source">来源（字符串型，主要用于调试）</param>
        /// <param name="eTaskSource">来源（用来做逻辑）</param>
        public GameTask(string source, ETaskSource eTaskSource = ETaskSource.Unkown)
        {
            this.Source = source;
            this.TaskType = TaskType.Unkown;
            this.TargetPlayer = null;
            this.FinishFrame = 1;
            this.DelayStart = 1;
            this.FinishToTarget = false;
            this.StartPos = Position.Empty;
            this.realTarget = Position.Empty;
            this.targetPos = Position.Empty;
            this.ProcessFrame = 0;
            this.Success = false;
            this.SpeedLevel = 0;
            this.Param3 = 0;
            this.NextTask = TaskType.Unkown;
            this.RecordPos = Position.Empty;
            this.SecondPlayer = null;
            this.taskSource = eTaskSource;
        }

        public void Clear()
        {
            this.DelayStart = 0;
            this.FinishFrame = 0;
            this.TaskType = TaskType.Unkown;
            this.NextTask = TaskType.Unkown;
        }

        /// <summary>
        /// 知道起点、终点和速度
        /// 计算飞行时间
        /// 速度单位 cm/s
        /// </summary>
        /// <param name="speed">速度单位 cm/s</param>
        /// <returns></returns>
        public int CalcTimeBySpeed(double speed)
        {
            double seconds = (double)this.StartPos.DistanceActualLength(this.TargetPos) / speed;
            return this.CalcFrameByTime(seconds);
        }

        /// <summary>
        /// 根据时间和速度，计算最终真实目的地，还有每一帧移动的坐标数
        /// 返回值为执行帧数
        /// </summary>
        /// <param name="seconds">秒数</param>
        /// <param name="speed">速度 单位 单位像素/每秒</param>
        public int CalcRealTargetByTimeSpeed(double seconds, double speed)
        {
            int finishFrame = TimeFrameConverter.GetFrame(seconds);
            this.realTarget = Formula.GetTargetPos(speed, seconds, this.StartPos, this.targetPos);

            if (this.realTarget != Position.Empty)
            {
                this.DeltaX = (this.StartPos.X - this.realTarget.X) * 1.0f / finishFrame;
                this.DeltaY = (this.StartPos.Y - this.realTarget.Y) * 1.0f / finishFrame;
            }

            return finishFrame;
        }

        /// <summary>
        /// 根据速度及最大执行时间，算这个的结束事件
        /// 有两种可能
        /// 1.速度足够，能到达目的地，那执行时间就是 距离/速度
        /// 2.速度不足，不能达到目的地，那执行时间就是最大时间， 到达目的地要进行更改
        /// </summary>
        /// <param name="speed">速度 单位像素/每秒</param>
        /// <param name="maxSeconds">秒数</param>
        /// <returns></returns>
        public int CalcRealTargetBySpeedMaxSeconds(ref double speed, double maxSeconds)
        {
            int finishFrame = 0;
            double distance = this.StartPos.Distance(this.TargetPos);
            double needSeconds = (double)(distance / speed);
            if (needSeconds > maxSeconds)
            {
                finishFrame = this.CalcRealTargetByTimeSpeed(maxSeconds, speed);
            }
            else
            {
                //修改了算法，如果指定时间能到达，就按指定时间来
                finishFrame = this.CalcFrameByTime(maxSeconds);
                speed = (double)(distance / maxSeconds);
            }
            return finishFrame;
        }

        /// <summary>
        /// 尽力到达目的地
        /// 如果到达不了就走到一半，返回最大移动时间
        /// 如果能提前到达，返回实际移动时间
        /// 速度单位为 像素每秒
        /// </summary>
        /// <param name="speed">像素每秒</param>
        /// <param name="maxSeconds"></param>
        /// <returns></returns>
        public int CalcRealTargetTryMyBest(double speed, double maxSeconds)
        {
            int finishFrame = 0;
            double distance = this.StartPos.Distance(this.TargetPos);
            double needSeconds = (double)(distance / speed);
            if (needSeconds > maxSeconds)
            {
                finishFrame = this.CalcRealTargetByTimeSpeed(maxSeconds, speed);
            }
            else
            {
                finishFrame = this.CalcFrameByTime(needSeconds);
            }
            return finishFrame;
        }

        /// <summary>
        /// 根据运行时间计算完成帧数
        /// 这种应该是一定能飞到的
        /// </summary>
        /// <param name="seconds">秒数</param>
        /// <returns></returns>
        public int CalcFrameByTime(double seconds)
        {
            int finishFrame = TimeFrameConverter.GetFrame(seconds);
            if (this.realTarget != Position.Empty)
            {
                this.DeltaX = (this.StartPos.X - this.realTarget.X) * 1.0f / finishFrame;
                this.DeltaY = (this.StartPos.Y - this.realTarget.Y) * 1.0f / finishFrame;
                this.FinishToTarget = true;
            }
            return finishFrame;
        }

        /// <summary>
        /// 节省效率
        /// 只有某些情況會复制
        /// </summary>
        /// <param name="source"></param>
        /// <param name="target"></param>
        public GameTask CloneTask()
        {
            GameTask gt = null;
            if (this.TaskType == TaskType.PlayerMoveToArea ||
                this.TaskType == TaskType.PlayerFastBreak)
            {
                gt = new GameTask(this.Source);
                gt.TaskType = this.TaskType;
                if (this.TargetPos != Position.Empty)
                {
                    gt.TargetPos = this.TargetPos.Clone();
                }
                if (this.StartPos != Position.Empty)
                {
                    gt.StartPos = this.StartPos.Clone();
                }
                gt.SpeedLevel = this.SpeedLevel;
                gt.Param1 = this.Param1;
                gt.Param2 = this.Param2;
                gt.Param3 = this.Param3;
                gt.Param4 = this.Param4;
                gt.FinishFrame = this.FinishFrame;
                gt.DeltaX = this.DeltaX;
                gt.DeltaY = this.DeltaY;
                gt.TargetPlayer = this.TargetPlayer;
                if (this.RecordPos != Position.Empty)
                {
                    gt.RecordPos = this.RecordPos.Clone();
                }
                gt.NextTask = this.NextTask;
                gt.SecondPlayer = this.SecondPlayer;
                gt.taskSource = this.taskSource;
            }
            return gt;
        }

        public GameTask Clone()
        {
            GameTask gt = new GameTask(this.Source);
            gt.TaskType = this.TaskType;
            if (this.TargetPos != Position.Empty)
            {
                gt.TargetPos = this.TargetPos.Clone();
            }
            if (this.StartPos != Position.Empty)
            {
                gt.StartPos = this.StartPos.Clone();
            }
            gt.SpeedLevel = this.SpeedLevel;
            gt.Param1 = this.Param1;
            gt.Param2 = this.Param2;
            gt.Param3 = this.Param3;
            gt.Param4 = this.Param4;
            gt.FinishFrame = this.FinishFrame;
            gt.DeltaX = this.DeltaX;
            gt.DeltaY = this.DeltaY;
            gt.TargetPlayer = this.TargetPlayer;
            if (this.RecordPos != Position.Empty)
            {
                gt.RecordPos = this.RecordPos.Clone();
            }
            gt.NextTask = this.NextTask;
            gt.SecondPlayer = this.SecondPlayer;
            gt.Source = this.Source;
            gt.taskSource = this.taskSource;
            return gt;
        }
    }
}
