﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class GameInfo
    {
        public List<GameEvent> gameEvents = new List<GameEvent>();

        public DistanceManager DisManager;

        public GameEvent CurEvent;

        private Field leftField;
        /// <summary>
        /// 左边半场
        /// </summary>
        public Field LeftField
        {
            get { return leftField; }
        }

        private Field rightField;
        /// <summary>
        /// 右边半场
        /// </summary>
        public Field RightField
        {
            get { return rightField; }
        }

        public BasketBall Ball;

        private Team homeTeam;

        public Team HomeTeam
        {
            get { return homeTeam; }
            set 
            {
                homeTeam = value;
                this.Teams[0] = value;
                this.boxScore.AddTeam(homeTeam);
            }
        }

        public TeamRatingManager TeamRaingMgr;

        private FakeRandom random;

        private Team awayTeam;

        public Team AwayTeam
        {
            get { return awayTeam; }
            set 
            { 
                awayTeam = value;
                this.Teams[1] = value;
                this.boxScore.AddTeam(awayTeam);
            }
        }

        public const int TeamCount = 2;

        public Team[] Teams = new Team[GameInfo.TeamCount];

        private const int QuarterFinishTime = 720;
        private const int OverTimeFinishTime = 300;
        private const int DefaultFinishTime = 2880;

        private Round curRound = new Round();

        public Round CurRound
        {
            get { return curRound; }
        }

        /// <summary>
        /// 新的24秒计时
        /// </summary>
        public void StartNewRound()
        {
            if (this.QuarterTime > 0)
            {
                this.curRound.Reset(this.GameFrame);
            }
        }

        public void ResetTo14()
        {
            this.curRound.ResetTo14S();
        }

        public double CurRoundRemaingTime
        {
            get
            {
                double seconds = TimeFrameConverter.ConvertFrameToSecond(this.CurRoundRemaingFrame);
                double quarterTime = this.QuarterTime;
                if (seconds > quarterTime)
                {
                    seconds = quarterTime;
                }
                if (seconds < 0)
                {
                    seconds = 0;
                }
                return seconds;
            }
        }

        private ScoreBoard scoreBoard;

        public ScoreBoard GetScoreBoard()
        {
            return this.scoreBoard;
        }

        private BoxScore boxScore;

        public BoxScore GetBoxScore()
        {
            return this.boxScore;
        }

        /// <summary>
        /// 当前回合剩余帧数
        /// </summary>
        public int CurRoundRemaingFrame
        {
            get
            {
                return this.curRound.FinishFrame;
            }
        }

        private int realFinishTime = 2880;

        public int RealFinishTime
        {
            get { return realFinishTime; }
            set { realFinishTime = value; }
        }

        private bool isPause = false;
        /// <summary>
        /// 是否暂停
        /// </summary>
        public bool IsPause
        {
            get { return isPause; }
            set { isPause = value; }
        }

        public void Pause()
        {
            this.isPause = true;
        }

        public void Resume()
        {
            this.isPause = false;
        }

        public void ResumeCurRound()
        {
            this.curRound.SetResume();
            if (this.IsPause)
            {
                this.Resume();
            }
        }

        private int gameFrame = 0;
        /// <summary>
        /// 比赛时间
        /// </summary>
        public int GameFrame
        {
            get
            {
                return this.gameFrame;
            }
        }

        public double GameTotalTime
        {
            get
            {
                return TimeFrameConverter.ConvertFrameToSecond(this.GameFrame);
            }
        }

        /// <summary>
        /// 真实时间，包括暂停、罚球
        /// </summary>
        public int Frame;

        public int TotalFrame
        {
            get
            {
                return (int)TimeFrameConverter.ConvertFrameToSecond(Frame);
            }
        }

        /// <summary>
        /// 上次刷体力的帧数
        /// </summary>
        public int LastCalcPhysical;
        /// <summary>
        /// 刷体力周期
        /// </summary>
        public int RefreshPhysicalCycle;
        /// <summary>
        /// 刷体力周期
        /// 单位：秒
        /// </summary>
        public double RefreshPhysicalCycleOnSecond;

        /// <summary>
        /// 每秒恢复的体力数
        /// </summary>
        public int OneSecondRestoreStamina;


        private int quarterTotalFrame;
        private int quarter = 0;
        public int Quarter
        {
            get
            {
                return this.quarter;
            }
            set
            {
                this.quarter = value;
                if (this.quarter <= 4)
                {
                    this.quarterTotalFrame = this.Quarter * TimeFrameConverter.GetFrame(GameInfo.QuarterFinishTime) ;
                }
                else
                {
                    this.quarterTotalFrame = TimeFrameConverter.GetFrame(GameInfo.QuarterFinishTime) * 4 + (TimeFrameConverter.GetFrame(GameInfo.OverTimeFinishTime) * (this.Quarter - 4));
                }
            }
        }


        public double QuarterTime
        {
            get
            {
                double seconds = this.GameTotalTime;

                if (this.Quarter <= 4)
                {
                    return this.Quarter * GameInfo.QuarterFinishTime - seconds;
                }
                else
                {
                    return (GameInfo.QuarterFinishTime * 4) + (GameInfo.OverTimeFinishTime * (this.Quarter - 4)) - seconds;
                }
            }
        }

        public int QuarterFrame
        {
            get
            {
                return this.quarterTotalFrame - this.gameFrame;
            }
        }

        public Team GetAnotherTeam(Team team)
        {
            if (team == this.Teams[0])
            {
                return this.Teams[1];
            }
            return this.Teams[0];
        }

        public Team AttackTeam
        {
            get
            {
                return this.Ball.OwnTeam;
            }
        }

        public Team LastAttackTeam { get; set; }

        public Team StartGameJumpWinTeam { get; set; }

        public Team DefTeam;

        public Team LeftToRight
        {
            get
            {
                int quarter = this.Quarter;
                if (quarter % 2 == 0)
                {
                    return this.Teams[1];
                }
                return this.Teams[0];
            }
        }

        public Team RightToLeft
        {
            get
            {
                int quarter = this.Quarter;
                if (quarter % 2 == 0)
                {
                    return this.Teams[0];
                }
                return this.Teams[1];
            }
        }

        public bool IsGameEventsNotNull(TimeData timedata)
        {
            if (this.gameEvents.Count() > 0)
            {
                GameEvent ge = this.gameEvents[0];
                if (ge.StartFrame == 0 || this.Frame >= ge.StartFrame)
                {
                    return true;
                }
            }
            return false;
        }

        public bool IsEveryBodyBusy(TimeData time)
        {
            if (this.Ball.IsFreeMethod())
            {
                return false;
            }
            for (int i = 0; i < GameInfo.TeamCount; i++)
            {
                Team team = this.Teams[i];
                if (team.FreeNum != 0)
                {
                    return false;
                }
            }
            return true;
        }

        public void AddGameEvent(GameEvent gameEvent)
        {
            gameEvent.AddIndex = this.gameEvents.Count;
            this.gameEvents.Add(gameEvent);
            this.gameEvents.Sort(GameEvent.CompareStartFrame);
        }

        public void PopEvent()
        {
            if (this.gameEvents.Count > 0)
            {
                this.CurEvent = this.gameEvents[0];
                this.gameEvents.RemoveAt(0);
            }
        }

        public void ClearEvent()
        {
            this.gameEvents.Clear();
        }

        /// <summary>
        /// [1,10000]随机一个数
        /// </summary>
        /// <returns></returns>
        public int RandomNext()
        {
            int random = this.random.RandomInt(1, 10000);
            return random;
        }

        public int RandomNext(int min, int max)
        {
            int random = this.random.RandomInt(min, max);
            return random;
        }

        public int RandomSpeed()
        {
            int random = this.random.RandomInt(1, 100);
            return random;
        }

        public int RandomSeed;

        public TacNewShot TacShot;

        public EGameStatus GameStatus;

        public GameInfo(int randomSeed)
        {
            this.myTree = new MyTree();
            this.timeData = new TimeData();
            this.DisManager = new DistanceManager();
            this.RandomSeed = randomSeed;
            this.LastCalcPhysical = 0;
            this.RefreshPhysicalCycleOnSecond = ParameterManager.Instance.GetValueD(ParameterEnum.CalcStaminaCycle) / 1000;
            this.RefreshPhysicalCycle = TimeFrameConverter.GetFrame(this.RefreshPhysicalCycleOnSecond);
            this.OneSecondRestoreStamina = ParameterManager.Instance.GetValue(ParameterEnum.OneSecondRestoreStamina);
            this.random = new FakeRandom();

            this.random.SetSeed(randomSeed);

            this.Ball = new BasketBall(this);

            this.leftField = new LeftField(FieldType.Left);
            this.rightField = new RightField(FieldType.Right);

            this.scoreBoard = new ScoreBoard();
            this.boxScore = new BoxScore();
            this.Quarter = 1;

            this.StartNewRound();

            this.TacShot = new TacNewShot(this, "");
            this.TeamRaingMgr = new TeamRatingManager();
            this.GameStatus = EGameStatus.NormalTime;
            

        }
        private bool over = false;
        public void SetOver()
        {
            this.over = true;
            this.FinishGame();
        }

        public bool IsOver()
        {
            if ( this.over && 
                !this.IsNotOver() )
            {
                return true;
            }
            return false;
        }

        public void FinishGame()
        {
            this.TeamRaingMgr.Finish(this);
        }

        /// <summary>
        /// 排除這些情況
        /// </summary>
        /// <returns></returns>
        public bool IsNotOver()
        {
            if (this.Ball.IsInTask( TaskType.BallShot) ||
               this.Ball.IsInTask( TaskType.BallLayup))
            {
                return true;
            }
            return false;
        }

        public void AddGameInfo(PlayByPlayContent content)
        {
            MessageBody body = new MessageBody(MessageType.PlaybyPlay, "", content);
            MessageHelper.SendMessage(body);
        }

        public void AddLog(string msg)
        {
            GameLogHelper.Instance.AddLog(msg);
        }

        public void AddPoint(Player player, int point)
        {
            this.scoreBoard.AddScore(player.OwnerTeam.TeamType, this.Quarter, point);
            this.boxScore.AddBoxScore(player.OwnerTeam.TeamType, player.RoleID, BoxScoreType.PTS, point);
        }

        public int GetPoint(TeamType team, int quarter)
        {
            return this.scoreBoard.GetQuarterPoint(team, quarter);
        }

        public int GetTotalPoint(TeamType team)
        {
            return this.scoreBoard.GetTotalPoint(team);
        }

        public void AddPersoanlBoxScore(Player player, BoxScoreType type, int score, bool addTeamBoxSorce = true)
        {
            this.boxScore.AddBoxScore(player.OwnerTeam.TeamType, player.RoleID, type, score, addTeamBoxSorce);
        }

        public string GetPersonalBoxScore(TeamType team, long roleId, BoxScoreType type)
        {
            return this.boxScore.GetPersonalBoxScore(team, roleId, type);
        }

        public string GetTeamBoxScore(TeamType team, BoxScoreType type)
        {
            return this.boxScore.GetTeamBoxScore(team, type);
        }

        public void AddGameFrame()
        {
            //有最后时刻出手的情况，这种情况下不增加比赛时间
            if (this.QuarterFrame > 0)
            {
                this.gameFrame++;
                this.curRound.AddFrame();
                //foreach (Team team in this.Teams)
                //{
                //    foreach (Player player in team.Players)
                //    {
                //        this.boxScore.AddBoxScore(team.TeamType, player.RoleID, BoxScoreType.FramePlayed, 1);
                //    }
                //}
            }
        }

        public void SetAllPlayerTask(TaskType taskType, int finishFrame, string source, int delayStart = 1)
        {
            for (int i = 0; i < GameInfo.TeamCount; i++)
            {
                Team team = this.Teams[i];
                for (int j = 0; j < team.PlayerCount; j++)
                {
                    Player player = team.Players[j];
                    GameTask gt = new GameTask(source);
                    gt.TaskType = taskType;
                    gt.FinishFrame = finishFrame;
                    gt.DelayStart = delayStart;
                    player.SetCurrentTask(gt);
                }
            }
        }

        public void ClearAllPlayerTask( TaskType exceptTask = TaskType.Unkown )
        {
            for (int i = 0; i < GameInfo.TeamCount; i++)
            {
                Team team = this.Teams[i];
                for (int j = 0; j < team.PlayerCount; j++)
                {
                    Player player = team.Players[j];
                    if (player.IsInTask(exceptTask))//在这些任务的不清
                    {
                        continue;
                    }
                    player.ClearTask();
                }
            }
        }

        /// <summary>
        /// 清除3秒数据
        /// </summary>
        public void Clear3SecondData()
        {
            for (int i = 0; i < GameInfo.TeamCount; i++)
            {
                Team team = this.Teams[i];
                for (int j = 0; j < team.PlayerCount; j++)
                {
                    Player player = team.Players[j];

                    player.ClearAttack3S();
                    player.ClearDef3S();
                }
            }
        }

        /// <summary>
        /// 设置持球人
        /// </summary>
        /// <param name="player"></param>
        public void SetBallOwner(Player player)
        {
            this.Ball.SetOwner(player);
            if (player != null)
            {
                player.IsCanCrossOver = true;
                this.SetBallOwnTeam(player.OwnerTeam);
            }
        }

        /// <summary>
        /// 设置持球球队
        /// </summary>
        /// <param name="team"></param>
        public void SetBallOwnTeam(Team team)
        {
            bool isChange = this.Ball.SetOwnTeam(team);
            if (isChange)
            {
                if (team == null)
                {
                    this.DefTeam = null;
                }
                else
                {
                    this.DefTeam = this.GetAnotherTeam(team);
                }

                this.Clear3SecondData();
                this.ClearSingleAttacker();
                this.ClearCrossOverDeBuff();

                this.ResetPosDef();
            }
        }

        /// <summary>
        /// 重置盯防对象
        /// </summary>
        public void ResetPosDef()
        {
            this.homeTeam.ResetPosDef();
            this.awayTeam.ResetPosDef();
        }

        public void ClearSingleAttacker()
        {
            this.HomeTeam.ClearSingleAttacker();
            this.AwayTeam.ClearSingleAttacker();
        }

        public void ClearCrossOverDeBuff()
        {
            this.HomeTeam.ClearCrossOverDebuffPlayer();
            this.AwayTeam.ClearCrossOverDebuffPlayer();
        }

        /// <summary>
        /// 是否在界内
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        public bool IsInBounds(Position pos)
        {
            if (this.AttackTeam.AttackField.IsOnMyEffectiveArea(pos) ||
                this.DefTeam.AttackField.IsOnMyEffectiveArea(pos))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 是否已经过了那么长时间
        /// </summary>
        /// <param name="oldFrame"></param>
        /// <param name="interval"></param>
        /// <returns></returns>
        public bool IsFramePassed(int oldFrame, int interval)
        {
            if (oldFrame + interval < this.gameFrame)
            {
                return true;
            }
            return false;
        }

        public void ClearBallOwner()
        {
            this.Ball.ClearOwner();
            //同时清掉要球标记
            if (this.homeTeam.AskBallPlayer != null)
            {
                this.homeTeam.AskBallPlayer = null;
            }
            if (this.awayTeam.AskBallPlayer != null)
            {
                this.awayTeam.AskBallPlayer = null;
            }
        }


        /// <summary>
        /// 是否陷入犯规麻烦
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public bool IsInFoulTrouble(Player player)
        {
            int quarter = this.Quarter;
            if (quarter > 4)
            {
                quarter = 4;
            }
            if (player.Foul >= quarter + 1)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 自身预期
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public double GetPlayerExpectHanlder(Player player)
        {
            double param26 = ParameterManager.Instance.GetValueD(ParameterEnum.HanlderExpectParam);

            double remainTime = this.CurRoundRemaingTime;
            double expect = this.GetPlayerExpectNormal(player);
            double remaingTime = remainTime / param26;
            if (expect > remaingTime)
            {
                expect = remaingTime;
            }
            return expect;
        }

        /// <summary>
        /// 无球人投篮期望
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public double GetPlayerExpectNormal(Player player)
        {
            ZDBTable tacticOffTable = ZDataManager.Instance.GetTacticOffecnsiveTable();
            ZDB_Row_Data rowData = tacticOffTable.getDataByID((int)ETacticOff.BaseOff);

            int pace = rowData.getCol((int)tactic_offensiveFields.Pace).getValueInt();
            double remainTime = this.CurRoundRemaingTime;
            double param16 = ParameterManager.Instance.GetValue(ParameterEnum.ShotMinExpect) * 1.0f;
            double param17 = ParameterManager.Instance.GetValue(ParameterEnum.ShotAddExpect) * 1.0f;
            double expect = (param16 + player.GetAttribute(PlayerAttribute.ShotIQ) * param17 / 50) / 100 + remainTime * remainTime / (pace * 100);
            return expect;
        }

        public void Init()
        {
            this.timeData.deltaTime = 0;
            this.myTree.Init(this);
            this.TeamRaingMgr.CalcTeamRaingAndAddPlayerAttr(this);
        }

        private MyTree myTree;
        private TimeData timeData;

        public void Update()
        {
            myTree.Tick(this.timeData);

            bool oldIsPause = this.IsPause;

            this.HomeTeam.Update(this);
            this.AwayTeam.Update(this);

            this.Ball.Update(this);

            if (oldIsPause && !this.IsPause)
            {
                foreach (Team team in this.Teams)
                {
                    foreach (Player player in team.Players)
                    {
                        player.UpdateFramePlayed(this);
                    }
                }
            }

            this.timeData.deltaTime++;
            this.Frame++;

            if (!this.IsPause)
            {
                this.AddGameFrame();
            }
        }

        /// <summary>
        /// 暂停、节间休息等恢复所有人的体力
        /// </summary>
        /// <param name="time"></param>
        public void RestoreAllPlayerStaminaOnBench(double time)
        {
            this.RestoreAllPlayerStaminaOnBenchByTime(this.homeTeam, time);
            this.RestoreAllPlayerStaminaOnBenchByTime(this.awayTeam, time);
        }

        private void RestoreAllPlayerStaminaOnBenchByTime(Team team, double time)
        {
            for (int j = 0; j < team.PlayerCount; j++)
            {
                Player player = team.Players[j];
                player.RestoreStaminaOnBench(time, this.OneSecondRestoreStamina);
            }
            int benchCount = team.BenchPlayers.Count;
            for (int j = 0; j < benchCount; j++)
            {
                Player player = team.BenchPlayers[j];
                player.RestoreStaminaOnBench(time, this.OneSecondRestoreStamina);
            }
        }
    }
}
