﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class EventProcessNode : SequenceNode
    {
        public EventProcessNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {

        }

        protected override void CreateChildNode()
        {
            ConditionNode isHaveEvent = new ConditionNode("判断是否存在事件", this.gameInfo.IsGameEventsNotNull);
            this.AddChild(isHaveEvent);

            ActionNode popEvent = new ActionNode("处理事件", this.PopEvent);
            this.AddChild(popEvent);

            SelectorNode selectEvent = new EventSelectorNode("选择处理事件子树", this.gameInfo);
            this.AddChild(selectEvent);
        }

        private BehaviourTreeStatus PopEvent(TimeData time)
        {
            this.gameInfo.PopEvent();
            return BehaviourTreeStatus.Success;
        }
    }
}
