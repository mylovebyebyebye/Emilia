﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Common;
using Entity;

namespace BattleLogic
{
    public class PassBallNode : SequenceNode
    {
        public PassBallNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            ConditionNode condition = new ConditionNode("是否传球", this.IsNeedPassBall);
            this.AddChild(condition);

            ActionNode passBall = new ActionNode("传球战术", this.PassBallNew);
            this.AddChild(passBall);
        }


        private bool IsNeedPassBall(TimeData time)
        {
            List<TaskType> lst = new List<TaskType>();
            //lst.Add(TaskType.PlayerShot);
            //lst.Add(TaskType.PlayerLayup);
            //lst.Add(TaskType.PlayerDriveToTheBasket);

            //球在某人手里、有要球人、球不在准备投篮、持球人没有在上篮
            if (this.gameInfo.Ball.Owner != null && 
                this.gameInfo.Ball.Owner.OwnerTeam.AskBallPlayer != null && 
                !this.gameInfo.Ball.IsInTask( TaskType.BallShot) &&
                !lst.Contains(this.gameInfo.Ball.Owner.GetCurTask().TaskType))
            {
                return true;
            }
            return false;
        }


        /// <summary>
        /// 获取传球落点
        /// </summary>
        /// <returns></returns>
        private Position GetPassBallPos(Player passBallPlayer, Player askBallPlayer)
        {
            Position circle = Position.Empty;//落点圆心
            int askBallPlayerSpeedLevel = askBallPlayer.GetCurTask().SpeedLevel;
            //double dis = passBallPlayer.Pos.DistanceActualLength(askBallPlayer.Pos);
            double dis = this.gameInfo.DisManager.GetDistanceInCMToSameTeamPlayer(this.gameInfo.Frame, passBallPlayer, askBallPlayer);
            if (askBallPlayerSpeedLevel == 0)
            {
                circle = askBallPlayer.Pos;
            }
            else
            {
                circle = askBallPlayer.GetCurTask().TargetPos;
                if (circle == Position.Empty)
                {
                    circle = askBallPlayer.Pos;
                }

                double askBallPlayerSpeed = askBallPlayer.GetSpeedByLevel(askBallPlayerSpeedLevel);
                double ballSpeed = ParameterManager.Instance.GetValueD(ParameterEnum.PassBallSpeed);
                double param353 = ParameterManager.Instance.GetValueD(ParameterEnum.PassBallParam1);

                double askBallMoveRadius = dis / (ballSpeed + param353) * askBallPlayerSpeed;

                double disToTarget = askBallPlayer.Pos.DistanceActualLength(circle);

                if (disToTarget > askBallMoveRadius)
                {
                    Position oldCircle = circle.Clone();
                    //到不了移动位置,重算
                    circle = Formula.ClosestIntersection(askBallPlayer.Pos, Position.GetPix(askBallMoveRadius), oldCircle, askBallPlayer.Pos);
                } 
            }
            //半径
            double param379 = ParameterManager.Instance.GetValueD(ParameterEnum.PassBallParam2);
            double param380 = ParameterManager.Instance.GetValueD(ParameterEnum.PassBallParam3);
            double radius = dis * param379 / (passBallPlayer.GetAttribute(PlayerAttribute.Passing) + param380);
            int randomAngle = this.gameInfo.RandomNext(0, 359);
            int randomRadius = this.gameInfo.RandomNext(0, (int)radius);

            Position p1 = circle.GetPosByAngleRadius(randomAngle, randomRadius);
            return p1;
        }

        /// <summary>
        /// 新版传球
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        private BehaviourTreeStatus PassBallNew(TimeData time)
        {
            Team attackTeam = this.gameInfo.Ball.Owner.OwnerTeam;

            Player passBallPlayer = this.gameInfo.Ball.Owner;
            Player askBallPlayer = attackTeam.AskBallPlayer;

            //获取传球落点
            Position passBallPos = this.GetPassBallPos(passBallPlayer, askBallPlayer);

            //传球人
            this.SetPassBallTask(passBallPlayer, askBallPlayer, passBallPos);

            //接球人
            this.SetGetBallTask(passBallPlayer, askBallPlayer, passBallPos);

            //清掉要球人
            attackTeam.AskBallPlayer = null;

            return BehaviourTreeStatus.Success;
        }

        /// <summary>
        /// 转为传球人
        /// </summary>
        /// <param name="passBallPlayer"></param>
        private void SetPassBallTask(Player passBallPlayer, Player askBallPlayer, Position passBallPos)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerToPassBall;
            gt.RecordPos = passBallPos;
            gt.TargetPlayer = askBallPlayer;
            gt.DelayStart = 0;

            passBallPlayer.SetCurrentTask(gt);
        }

        /// <summary>
        /// 转为接球人
        /// </summary>
        /// <param name="passBallPlayer"></param>
        /// <param name="askBallPlayer"></param>
        /// <param name="passBallPos"></param>
        private void SetGetBallTask(Player passBallPlayer, Player askBallPlayer, Position passBallPos)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerToGetPassBallNormal;
            gt.RecordPos = passBallPos;
            gt.TargetPlayer = passBallPlayer;
            gt.DelayStart = 0;

            askBallPlayer.SetCurrentTask(gt);
        }

    }
}
