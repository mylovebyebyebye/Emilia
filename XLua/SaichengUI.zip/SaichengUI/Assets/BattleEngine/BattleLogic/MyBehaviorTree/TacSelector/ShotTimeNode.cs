﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class ShotTimeNode : SequenceNode
    {
        private TacToShot tacToShot;
        public ShotTimeNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.tacToShot = new TacToShot(this.gameInfo, this.name);
        }

        private int lastCalcFrame = 0;

        protected override void CreateChildNode()
        {
            ConditionNode isShotTime = new ConditionNode("是否在准备出手", this.IsShotTime);
            this.AddChild(isShotTime);

            ActionNode defShot = new ActionNode("扑投篮", this.DefShot);
            this.AddChild(defShot);
        }

        private bool IsShotTime(TimeData time)
        {
            Player player = this.gameInfo.Ball.Owner;
            if (player != null &&
                player.IsInTask( TaskType.PlayerShot) &&
                player.GetCurTask().DelayStart > 0 
               )
            {
                if(this.lastCalcFrame <= this.gameInfo.GameFrame)
                {
                    //加了个条件，不能老在算这个
                    this.lastCalcFrame = this.gameInfo.GameFrame + player.GetCurTask().DelayStart;
                    return true;
                }
            }
            return false;
        }

        private BehaviourTreeStatus DefShot(TimeData time)
        {
            //先算对位防守人
            Player shooter = this.gameInfo.Ball.Owner;
            Player defHandler = shooter.GetMyPosDefPlayer();
            double dis = double.MaxValue;
            if (defHandler != null)
            {
                //dis = defHandler.Pos.DistanceActualLength(shooter.Pos);
                dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, shooter, defHandler);
            }
            if (this.IsToDefShot(shooter, defHandler))
            {
                this.DefShot(shooter, defHandler);
            }
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player player = this.gameInfo.DefTeam.Players[i];
                //其他防守人
                if (defHandler == null || !player.IsSamePlayer(defHandler))
                {
                    double disToShooter = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, shooter, player);
                    if (dis > ParameterManager.Instance.GetValue(ParameterEnum.DefRangeRadius))
                    {
                        //投篮人的对位防守人距离很远
                        if (disToShooter <= ParameterManager.Instance.GetValue(ParameterEnum.DefShotDis1) &&
                            this.IsToDefShot(shooter, player))
                        {
                            this.DefShot(shooter, player);
                        }
                    }
                    else
                    {
                        //投篮人的对位防守人距离很近
                        if (disToShooter <= ParameterManager.Instance.GetValue(ParameterEnum.DefShotDis2) &&
                            this.IsToDefShot(shooter, player))
                        {
                            this.DefShot(shooter, player);
                        }
                    }
                }
            }


            return BehaviourTreeStatus.Success;
        }

        /// <summary>
        /// 决定是否去干扰投篮
        /// </summary>
        /// <param name="shooter"></param>
        /// <param name="defPlayer"></param>
        /// <returns></returns>
        private bool IsToDefShot(Player shooter, Player defPlayer)
        {
            if (defPlayer == null || defPlayer.DefShotCD > this.gameInfo.Frame)
            {
                return false;
            }
            //double dis = defPlayer.Pos.DistanceActualLength(shooter.Pos);
            double dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, shooter, defPlayer);
            double minDis = ParameterManager.Instance.GetValue(ParameterEnum.DefMinDis) * 1.0f;
            if (dis < minDis)
            {
                dis = minDis;
            }
            int pfCount = Convert.ToInt32(this.gameInfo.GetPersonalBoxScore(defPlayer.OwnerTeam.TeamType, defPlayer.RoleID, BoxScoreType.PF));
            //根据当前节数和犯规次数，用的公式不一样
            int param = this.gameInfo.Quarter;
            if (param > 4)
            {
                param = 4;
            }
            param += 1;

            double shotContest = defPlayer.GetAttribute(PlayerAttribute.ShotContest) * ParameterManager.Instance.GetValue(ParameterEnum.ShotContestCOE) / 100;

            int pro = 0;
            if (pfCount < param)
            {
                pro = (int)(shotContest / dis * 10000);
            }
            else if (pfCount == param)
            {
                pro = (int)((shotContest / dis - pfCount * 1.0f / 10) * 10000);
            }
            else
            {
                pro = (int)((shotContest / dis - pfCount * 1.0f / 5) * 10000);
            }
            int random = this.gameInfo.RandomNext();
            if (pro > random)
            {
                return true;
            }
            return false;
        }

        private void DefShot(Player shooter, Player defPlayer)
        {
            this.tacToShot.DisturnShotByShotType((ShotType)shooter.GetCurTask().Param1, shooter, defPlayer);
            //GameTask gt = new GameTask(this.name);
            //gt.TaskType = TaskType.PlayerMoveTo;
            //gt.StartPos = defPlayer.Pos;
            //gt.DelayStart = this.GetDelayFrame();

            ////扑投篮人的位置
            //Position nextPosition = shooter.Pos;
            //double Radius = ParameterManager.Instance.GetValue(ParameterEnum.DefMinDis) * 1.0f / Position.ActualLengthPerPoint;
            //double distance = this.gameInfo.AttackTeam.AttackBasket.Distance(shooter.Pos);

            //double shotTime = TimeFrameConverter.ConvertFrameToSecond(shooter.GetCurTask().DelayStart - this.GetDelayFrame());

            ////离他远才需要扑
            //if (distance > Radius)
            //{
            //    Position p1 = Formula.ClosestIntersection(this.gameInfo.AttackTeam.AttackBasket, (double)(distance - Radius), shooter.Pos, this.gameInfo.AttackTeam.AttackBasket);
            //    //看扑到位置的时间跟出手者的出手时间差
            //    if (p1 != Position.Empty)
            //    {
            //        gt.TargetPos = p1;
            //        int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(defPlayer, this.gameInfo.RandomSpeed());

            //        double seconds = (double)gt.StartPos.DistanceActualLength(gt.TargetPos) /  defPlayer.GetSpeedByLevel(speedLevel);
            //        if(shotTime < seconds)
            //        {
            //            seconds = shotTime;
            //        }
            //        gt.FinishFrame = gt.CalcRealTargetByTimeSpeed(seconds, defPlayer.GetSpeedInPixelByLevel(speedLevel));
            //        gt.SpeedLevel = speedLevel;
            //    }
            //}
            //else
            //{
            //    gt.TaskType = TaskType.PlayerStandby;
            //    gt.StartPos = defPlayer.Pos;
            //    gt.TargetPos = defPlayer.Pos;
            //    gt.DelayStart = this.GetDelayFrame();
            //    gt.FinishFrame = TimeFrameConverter.GetFrame(shotTime);
            //}
            //defPlayer.SetCurrentTask(gt);
        }


        protected int GetDelayFrame()
        {
            return TimeFrameConverter.GetFrame(this.GetDelaySeconds());
        }

        protected double GetDelaySeconds()
        {
            return ParameterManager.Instance.GetValue(ParameterEnum.CrossOverReactionTime) * 1.0f / 1000;
        }
    }
}
