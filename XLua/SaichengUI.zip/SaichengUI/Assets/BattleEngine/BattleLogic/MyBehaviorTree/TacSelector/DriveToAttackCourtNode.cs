﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common;

namespace BattleLogic
{
    public class DriveToAttackCourtNode : SequenceNode
    {
        private int lastFrame = 0;
        private int minInterval;
        private double minIntervalTime = 0.5f;
        public DriveToAttackCourtNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.minInterval = TimeFrameConverter.GetFrame(this.minIntervalTime);
        }

        protected override void CreateChildNode()
        {
            ConditionNode isEnable = new ConditionNode("是否触发默认过半场战术", this.IsEnable);
            this.AddChild(isEnable);

            ActionNode tacActive = new ActionNode("执行过半场", this.DriveToAttackField);
            this.AddChild(tacActive);
        }

        private bool IsEnable(TimeData time)
        {
            Player ballHandler = this.gameInfo.Ball.Owner;
            if (ballHandler == null || this.gameInfo.IsPause )
            {
                return false;
            }
            if ( !this.gameInfo.IsFramePassed(this.lastFrame, this.minInterval) )
            {
                return false;
            }
            Player defPlayer = ballHandler.GetMyPosDefPlayer();
            //持球人在后场待机，而且没有被紧逼
            if ( ballHandler.GetCurTask() != null && 
                this.gameInfo.GetAnotherTeam(ballHandler.OwnerTeam).AttackField.IsOnMyEffectiveArea(ballHandler.Pos) && 
                ballHandler.GetCurTask().TaskType == TaskType.PlayerStandby &&
                (defPlayer == null || !defPlayer.IsInTask(TaskType.PlayerPress)))
            {
                this.lastFrame = this.gameInfo.GameFrame;
                return true;
            }
            return false;
        }

        private BehaviourTreeStatus DriveToAttackField(TimeData time)
        {
            Player ballHandler = this.gameInfo.Ball.Owner;

            {
                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.BallOnThePlayer;
                gt.TargetPlayer = ballHandler;
                gt.FinishFrame = int.MaxValue;
                this.gameInfo.Ball.SetCurrentTask(gt);
            }

            this.gameInfo.Ball.GetCurTask().TaskType = TaskType.BallOnThePlayer;
            this.gameInfo.Ball.GetCurTask().TargetPlayer = ballHandler;
            this.gameInfo.Ball.GetCurTask().FinishFrame = int.MaxValue;

            for (int i = 0; i < ballHandler.OwnerTeam.PlayerCount; i++)
            {
                Player player = ballHandler.OwnerTeam.Players[i];
                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.PlayerDriveToAttackField;
                gt.FinishFrame = 0;
                gt.DelayStart = 0;
                player.SetCurrentTask(gt);
            }

            return BehaviourTreeStatus.Success;
        }

       
    }
}
