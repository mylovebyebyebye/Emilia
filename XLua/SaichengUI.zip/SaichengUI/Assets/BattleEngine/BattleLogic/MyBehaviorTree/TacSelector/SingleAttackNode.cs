﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class SingleAttackNode : SequenceNode
    {
        /// <summary>
        /// 单打方式 
        /// 1.内线
        /// 2.外线
        /// </summary>
        private int attackType = 0;
        /// <summary>
        /// 选定的战术ID
        /// </summary>
        private int tacId = 0;

        private int lastGameFrame = 0;

        public SingleAttackNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {

        }

        protected override void CreateChildNode()
        {
            ConditionNode isSingleAttack = new ConditionNode("是否进入单打战术", this.IsSingleAttack);
            this.AddChild(isSingleAttack);

            ActionNode calcAttackPlayerType = new ActionNode("计算单打人及单打方式", this.CalcAttackPlayerType);
            this.AddChild(calcAttackPlayerType);

            ActionNode setSingleAttackTac = new ActionNode("安排战术", this.SetSingleAttackTac);
            this.AddChild(setSingleAttackTac);
        }
        
        private bool IsSingleAttack(TimeData time)
        {
            if (this.gameInfo.IsPause)
            {
                return false;
            }
            //不能一直进入单打判断
            if ( !this.gameInfo.IsFramePassed(this.lastGameFrame, 2) )
            {
                return false;
            }
            this.lastGameFrame = this.gameInfo.GameFrame;
            Player handler = this.gameInfo.Ball.Owner;
            //持球人在前场
            //进攻方所有人都在待机
            if (handler != null && 
                handler.OwnerTeam.AttackField.IsOnMyEffectiveArea(handler.Pos))
            {
                bool isSingleAttack = true;
                for (int i = 0; i < handler.OwnerTeam.PlayerCount; i++)
                {
                    Player player = handler.OwnerTeam.Players[i];
                    if (player.GetCurTask().FinishFrame > 0 &&
                        !player.IsInTask( TaskType.PlayerStandby))
                    {
                        isSingleAttack = false;
                        break;
                    }
                }
                return isSingleAttack;
            }
            return false;
        }

        private BehaviourTreeStatus CalcAttackPlayerType(TimeData time)
        {
            //如果已存在单打人，则不需要重新计算
            if (this.gameInfo.AttackTeam.SingleAttacker == null)
            {
                this.gameInfo.AttackTeam.ClearSingleAttacker();

                //去掉有突破失败debuff的人，同时取得最大运球及内投
                double maxDriving = 0f;
                double maxInsideShot = 0f;
                List<Player> lstPlayer = this.GetPlayers(ref maxDriving, ref maxInsideShot);

                List<double> lstInsideValue = new List<double>();
                double sumInside = 0f;

                List<double> lstOutsideValue = new List<double>();
                double sumOutside = 0f;

                //计算每个人内线单打能力和外线单打能力
                for (int i = 0; i < lstPlayer.Count; i++)
                {
                    Player player = lstPlayer[i];

                    double insideValue = this.GetInsideValue(player, maxInsideShot);
                    lstInsideValue.Add(insideValue);
                    sumInside += insideValue;

                    double ousideValue = this.GetOutsideValue(player, maxDriving);
                    lstOutsideValue.Add(ousideValue);
                    sumOutside += ousideValue;
                }
                
                //计算单打人、单打方式及战术
                int random = this.gameInfo.RandomNext();
                int sum = 0;
                ZDBTable tacOffTable = ZDataManager.Instance.GetTacticOffecnsiveTable();
                int count = tacOffTable.getRowCount();
                for(int i = 0;i<lstPlayer.Count;i++)
                {
                    for(int j = 0;j<count;j++)
                    {
                        ZDB_Row_Data rowData = tacOffTable.getDataByRow(j);
                        int insideIso = rowData.getCol((int)tactic_offensiveFields.InsideIsolation).getValueInt();
                        int outsideIso = rowData.getCol((int)tactic_offensiveFields.OutsideIsolation).getValueInt();
                        //内线单打概率
                        int insidePro = (int)((lstInsideValue[i] / sumInside) * (insideIso * 1.0f / (insideIso + outsideIso)) * 10000);

                        sum += insidePro;
                        if (sum >= random)
                        {
                            this.gameInfo.AttackTeam.SetSingleAttacker(lstPlayer[i]);
                            this.attackType = 1;
                            this.tacId = j;
                            break;
                        }

                        //外线单打
                        int outsidePro = (int)((lstOutsideValue[i] / sumOutside) * (outsideIso * 1.0f / (insideIso + outsideIso)) * 10000);
                        sum += outsidePro;
                        if (sum >= random)
                        {
                            this.gameInfo.AttackTeam.SetSingleAttacker(lstPlayer[i]);
                            this.attackType = 2;
                            this.tacId = j;
                            break;
                        }
                    }
                    if (this.gameInfo.AttackTeam.SingleAttacker != null)
                    {
                        break;
                    }
                }
            }

            return BehaviourTreeStatus.Success;
        }

        /// <summary>
        /// 去掉有突破失败debuff的人
        /// 同时取得最大运球及内投
        /// </summary>
        /// <returns></returns>
        private List<Player> GetPlayers(ref double maxDriving, ref double maxInsideShot)
        {
            List<Player> lst = new List<Player>();
            for (int i = 0; i < this.gameInfo.AttackTeam.PlayerCount; i++)
            {
                Player player = this.gameInfo.AttackTeam.Players[i];
                if (player.IsCanCrossOver)
                {
                    lst.Add(player);
                    if (player.GetAttribute(PlayerAttribute.Driving) > maxDriving)
                    {
                        maxDriving = player.GetAttribute(PlayerAttribute.Driving);
                    }
                    if (player.GetAttribute(PlayerAttribute.InsideShot) > maxInsideShot)
                    {
                        maxInsideShot = player.GetAttribute(PlayerAttribute.InsideShot);
                    }
                }
            }
            return lst;
        }

        /// <summary>
        /// 内线单打值
        /// </summary>
        /// <param name="player"></param>
        /// <param name="maxInsideShot"></param>
        /// <returns></returns>
        private double GetInsideValue(Player player, double maxInsideShot)
        {
            double value = player.GetAttribute(PlayerAttribute.InsideShot) / maxInsideShot - ParameterManager.Instance.GetValue(ParameterEnum.InsideShotMin) * 1.0f / 100;
            if (value < 0)
            {
                value = 0;
            }
            return value;
        }

        /// <summary>
        /// 外线单打值
        /// </summary>
        /// <param name="player"></param>
        /// <param name="maxDriving"></param>
        /// <returns></returns>
        private double GetOutsideValue(Player player, double maxDriving)
        {
            double value = player.GetAttribute(PlayerAttribute.Driving) / maxDriving - ParameterManager.Instance.GetValue(ParameterEnum.OutsideDrivingMin) * 1.0f / 100;
            if (value < 0)
            {
                value = 0;
            }
            return value;
        }

        private BehaviourTreeStatus SetSingleAttackTac(TimeData time)
        {
            if (this.gameInfo.AttackTeam.SingleAttacker == null)
            {
                return BehaviourTreeStatus.Failure;
            }
            if (this.attackType == 1)
            {
                this.InsideAttack();
            }
            else if (this.attackType == 2)
            {
                this.OutsideAttack();
            }

            return BehaviourTreeStatus.Success;
        }

        private void InsideAttack()
        {
            for (int i = 0; i < this.gameInfo.AttackTeam.PlayerCount; i++)
            {
                Player player = this.gameInfo.AttackTeam.Players[i];

                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.PlayerInsideSingleAttack;
                gt.FinishFrame = 0;
                gt.DelayStart = 0;

                player.SetCurrentTask(gt);
            }
            //要球点算一下
            this.gameInfo.AttackTeam.SingleAttacker.GetCurTask().RecordPos = this.CalcInsideAskBallPos();
        }

        /// <summary>
        /// 获取内线单打要球点
        /// </summary>
        /// <returns></returns>
        private Position CalcInsideAskBallPos()
        {
            double Radius = this.gameInfo.RandomNext(
                                ParameterManager.Instance.GetValue(ParameterEnum.InsideAtkAskBallMin),
                                ParameterManager.Instance.GetValue(ParameterEnum.InsideAtkAskBallMax));
            Position p1 = Formula.ClosestIntersection(this.gameInfo.AttackTeam.AttackBasket,
                                                        Position.GetPix(Radius),
                                                        this.gameInfo.AttackTeam.SingleAttacker.Pos,
                                                        this.gameInfo.AttackTeam.AttackBasket);
            return p1;
        }

        private void OutsideAttack()
        {
            for (int i = 0; i < this.gameInfo.AttackTeam.PlayerCount; i++)
            {
                Player player = this.gameInfo.AttackTeam.Players[i];

                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.PlayerOutsideSingleAttack;
                gt.FinishFrame = 0;
                gt.DelayStart = 0;

                player.SetCurrentTask(gt);
            }
        }
    }
}
