﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{

    public class BoxOutNode : SequenceNode
    {
        private List<Player> lstAtkRebound = new List<Player>();
        private List<Player> lstDefBoxOut = new List<Player>();
        private TacRebound tac;

        public BoxOutNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.tac = new TacRebound(this.gameInfo,this.name);
        }

        private int CompareDisFromBasket(Player p1, Player p2)
        {
            //double dis1 = p1.Pos.Distance(this.gameInfo.AttackTeam.AttackBasket);
            //double dis2 = p2.Pos.Distance(this.gameInfo.AttackTeam.AttackBasket);
            double dis1 = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, this.gameInfo.AttackTeam.AttackField, p1);
            double dis2 = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, this.gameInfo.AttackTeam.AttackField, p2);
            return dis1.CompareTo(dis2);
        }

        protected override void CreateChildNode()
        {
            ConditionNode isBallShot = new ConditionNode("是否球在飞", this.IsBallShot);
            this.AddChild(isBallShot);

            ActionNode group = new ActionNode("球员分组", this.GroupPlayer);
            this.AddChild(group);

            ConditionNode condition = new ConditionNode("是否进入卡位安排", this.IsBoxOut);
            this.AddChild(condition);

            ActionNode boxOut = new ActionNode("安排卡位", this.BoxOut);
            this.AddChild(boxOut);
        }

        private bool IsBallShot(TimeData time)
        {
            if (this.gameInfo.Ball.IsInTask( TaskType.BallShot) || 
                this.gameInfo.Ball.IsInTask(TaskType.BallFreeThrow))
            {
                return true;
            }
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player player = this.gameInfo.DefTeam.Players[i];
                if (player.IsInTask( TaskType.PlayerBoxOut))
                {
                    player.SetCurrentTask(this.tac.GetReboundTask(player));
                }
            }
            return false;
        }

        private BehaviourTreeStatus GroupPlayer(TimeData time)
        {
            this.lstAtkRebound.Clear();
            this.lstDefBoxOut.Clear();

            for (int i = 0; i < this.gameInfo.AttackTeam.PlayerCount; i++)
            {
                Player player = this.gameInfo.AttackTeam.Players[i];
                if (player.GetCurTask() != null)
                {
                    if (player.IsInTask( TaskType.PlayerRebound))
                    {
                        this.lstAtkRebound.Add(player);
                    }
                }
            }
            this.lstAtkRebound.Sort(this.CompareDisFromBasket);

            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player player = this.gameInfo.DefTeam.Players[i];
                if (player.IsInTask( TaskType.PlayerBoxOut) &&
                    player.GetCurTask().TargetPlayer == null)
                {
                    this.lstDefBoxOut.Add(player);
                }
            }
            return BehaviourTreeStatus.Success;
        }

        private bool IsBoxOut(TimeData time)
        {
            if (this.lstDefBoxOut.Count > 0)
            {
                return true;
            }
            return false;
        }

        private BehaviourTreeStatus BoxOut(TimeData time)
        {
            //从攻方来找守方
            for (int i = 0; i < lstAtkRebound.Count; i++)
            {
                Player atkPlayer = lstAtkRebound[i];
                int speedLevel = 10;
                Position p1 = null;
                Player minDisPlayer = this.GetMinDisPlayer(atkPlayer, ref speedLevel, ref p1);
                if (minDisPlayer != null)
                {
                    this.lstDefBoxOut.Remove(minDisPlayer);
                    this.AddBoxOutTask(atkPlayer, minDisPlayer, speedLevel, p1);
                }
            }
            //没找到事做的守方就去抢篮板
            for (int i = 0; i < this.lstDefBoxOut.Count; i++)
            {
                Player defPlayer = this.lstDefBoxOut[i];
                defPlayer.SetCurrentTask(this.tac.GetReboundTask(defPlayer));
            }
            return BehaviourTreeStatus.Success;
        }

        private Player GetMinDisPlayer(Player atkPlayer, ref int speedLevel, ref Position p1)
        {
            double minDis = Int32.MaxValue;
            Player minDisPlayer = null;
            Position boxOutPos = null;
            for (int i = 0; i < this.lstDefBoxOut.Count; i++)
            {
                Player defPlayer = this.lstDefBoxOut[i];
                //离抢篮板的进攻球员最近的
                //又加了一个能卡上我
                if (this.IsMinDis(atkPlayer, defPlayer, ref minDis) &&
                    this.IsCanBoxOut(atkPlayer, defPlayer, ref speedLevel, ref boxOutPos))
                {
                    p1 = boxOutPos;
                    minDisPlayer = defPlayer;
                }
            }
            return minDisPlayer;
        }

        private bool IsCanBoxOut(Player atkPlayer, Player defPlayer, ref int speedLevel, ref Position p1)
        {
            Vector2D v = new Vector2D(this.gameInfo.AttackTeam.AttackBasket, atkPlayer.Pos);

            double Radius = (double)v.DistancePointToVector2D(defPlayer.Pos);//点到直线的距离
            p1 = Formula.ClosestIntersection(defPlayer.Pos, Radius, atkPlayer.Pos, this.gameInfo.AttackTeam.AttackBasket);
            if (p1 != Position.Empty)
            {
                speedLevel = SpeedManager.Instance.GetSpeedAccelerate(defPlayer, this.gameInfo.RandomSpeed());
                double defTime = defPlayer.Pos.Distance(p1) / defPlayer.GetSpeedInPixelByLevel(speedLevel);
                double aktTime = atkPlayer.Pos.Distance(p1) / atkPlayer.GetSpeedInPixelByLevel(atkPlayer.GetCurTask().SpeedLevel);
                //看谁能先到那个点
                if (defTime <= aktTime)
                {
                    return true;
                }
            }
            return false;
        }

        //离得最近且离篮筐要比我近
        private bool IsMinDis(Player atkPlayer, Player defPlayer,ref double minDis)
        {
            double dis = 0d;
            if (this.IsInRunRadius(atkPlayer, defPlayer, ref dis))
            {
                if ( dis < minDis)
                {
                    //double dis1 = atkPlayer.Pos.Distance(this.gameInfo.AttackTeam.AttackBasket);
                    //double dis2 = defPlayer.Pos.Distance(this.gameInfo.AttackTeam.AttackBasket);
                    double dis1 = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, this.gameInfo.AttackTeam.AttackField, atkPlayer);
                    double dis2 = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, this.gameInfo.AttackTeam.AttackField, defPlayer);
                    if (dis2 < dis1)
                    {
                        minDis = dis;
                        return true;
                    }
                }
            }
            return false;
        }

        private bool IsInRunRadius(Player atkPlayer, Player defPlayer, ref double distance)
        {
            distance = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, atkPlayer, defPlayer);
            //distance = defPlayer.Pos.DistanceActualLength(atkPlayer.Pos);
            if (distance < ParameterManager.Instance.GetValue(ParameterEnum.RunRadius))
            {
                return true; 
            }
            return false;
        }

        private void AddBoxOutTask(Player atkPlayer, Player defPlayer, int speedLevel, Position p1)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerBoxOut;
            gt.StartPos = defPlayer.Pos;
            gt.FinishFrame = this.gameInfo.Ball.GetCurTask().FinishFrame;
            gt.DelayStart = this.gameInfo.Ball.GetCurTask().DelayStart;
            gt.TargetPlayer = atkPlayer;
            gt.TargetPos = p1;

            double seconds = TimeFrameConverter.ConvertFrameToSecond(gt.FinishFrame);
            double speedInPixel = defPlayer.GetSpeedInPixelByLevel(speedLevel);
            gt.FinishFrame = gt.CalcRealTargetByTimeSpeed(seconds, speedInPixel);

            defPlayer.SetCurrentTask(gt);
        }

    }
}
