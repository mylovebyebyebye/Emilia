﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class Attack3SecondViolationNode : SequenceNode
    {
        private int atk3SViolationFrame;
        private Player atk3SPlayer;

        public Attack3SecondViolationNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.atk3SViolationFrame = TimeFrameConverter.GetFrame(3.0f);
        }

        protected override void CreateChildNode()
        {
            ConditionNode isAtk3SViolation = new ConditionNode("是否进攻3秒违例", this.IsAtk3SViolation);
            this.AddChild(isAtk3SViolation);

            ActionNode atk3SViolation = new ActionNode("进攻3秒违例", this.Atk3SViolation);
            this.AddChild(atk3SViolation);
        }

        private bool IsAtk3SViolation(TimeData time)
        {
            this.atk3SPlayer = null; 
            //攻方是否有人3秒违例
            if (this.gameInfo.AttackTeam != null &&
                !this.gameInfo.IsPause)
            {
                for (int i = 0; i < this.gameInfo.AttackTeam.PlayerCount; i++)
                {
                    Player player = this.gameInfo.AttackTeam.Players[i];

                    if (player.AtkIn3SecondFrame >= this.atk3SViolationFrame)
                    {
                        this.atk3SPlayer = player;
                        return true;
                    }
                }
            }
            return false;
        }

        private BehaviourTreeStatus Atk3SViolation(TimeData time)
        {
            Team atkTeam = this.gameInfo.AttackTeam;
            Team defTeam = this.gameInfo.DefTeam;

            PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.Atk3S, this.atk3SPlayer.Id, (int)defTeam.TeamType);
            this.gameInfo.AddGameInfo(pc);

            //清事件
            this.gameInfo.ClearEvent();

            //技术统计
            this.gameInfo.AddPersoanlBoxScore(this.atk3SPlayer, BoxScoreType.TOV, 1);

            //交换球权
            this.gameInfo.ClearBallOwner();
            this.gameInfo.SetBallOwnTeam(defTeam);

            //清所有人事件
            this.gameInfo.ClearAllPlayerTask();

            //24秒计时
            this.gameInfo.Pause();
            this.gameInfo.StartNewRound();

            Position posToThrowIn = atkTeam.AttackField.GetFTLineSideInsection(this.gameInfo.RandomNext(1, 2) - 1);

            //发界外球
            GameEvent ge = new GameEvent(GameEventType.OutOfBoundToThrowIn);
            ge.Pos = posToThrowIn;
            this.gameInfo.AddGameEvent(ge);


            return BehaviourTreeStatus.Success;
        }
    }
}
