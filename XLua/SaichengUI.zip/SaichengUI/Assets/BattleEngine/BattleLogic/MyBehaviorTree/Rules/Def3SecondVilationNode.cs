﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Entity;

namespace BattleLogic
{
    public class Def3SecondVilationNode : SequenceNode
    {
        private int def3SViolationFrame;
        private Player def3SPlayer;

        public Def3SecondVilationNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.def3SViolationFrame = TimeFrameConverter.GetFrame(3.0f);
        }

        protected override void CreateChildNode()
        {
            ConditionNode isDef3SViolation = new ConditionNode("是否防守3秒违例", this.IsDef3SViolation);
            this.AddChild(isDef3SViolation);

            ActionNode def3SViolation = new ActionNode("防守3秒违例", this.Def3SViolation);
            this.AddChild(def3SViolation);
        }

        private bool IsDef3SViolation(TimeData time)
        {
            this.def3SPlayer = null;
            //攻方是否有人3秒违例
            if (this.gameInfo.DefTeam != null &&
                !this.gameInfo.IsPause)
            {
                for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
                {
                    Player player = this.gameInfo.DefTeam.Players[i];
                    if (player.Def3SecondFrame >= this.def3SViolationFrame)
                    {
                        this.def3SPlayer = player;
                        return true;
                    }
                }
            }
            return false;
        }

        private BehaviourTreeStatus Def3SViolation(TimeData time)
        {
            Team atkTeam = this.gameInfo.AttackTeam;

            Player ftPlayer = this.GetFreeThrowPlayer(atkTeam);

            PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.Def3S, this.def3SPlayer.Id, ftPlayer.Id);
            this.gameInfo.AddGameInfo(pc);

            //清事件
            this.gameInfo.ClearEvent();

            //技术统计
            //this.gameInfo.AddPersoanlBoxScore(this.def3SPlayer, BoxScoreType.TOV, 1);

            //清所有人事件
            this.gameInfo.ClearAllPlayerTask();

            //24秒计时
            this.gameInfo.Pause();
            this.gameInfo.CurRound.ResetTo14S();

            //罚球
            GameEvent ge = new GameEvent(GameEventType.FreeThrow);
            ge.Param1 = 1;//总罚球次数
            ge.Param2 = 1;//当前第几罚
            ge.Param3 = (int)EFreeThrowType.Technical;
            ge.Param4 = ftPlayer;
            ge.StartFrame = 0;

            this.gameInfo.AddGameEvent(ge);


            return BehaviourTreeStatus.Success;
        }

        /// <summary>
        /// 获取罚球队员
        /// 场上罚球最好的人
        /// </summary>
        /// <param name="team"></param>
        /// <returns></returns>
        private Player GetFreeThrowPlayer(Team team)
        {
            double maxFreeThrow = 0f;
            Player ftPlayer = null;
            for (int i = 0; i < team.PlayerCount; i++)
            {
                Player player = team.Players[i];

                double ft = player.GetAttribute(PlayerAttribute.FreeThrow);
                if (player.GetAttribute(PlayerAttribute.FreeThrow) > maxFreeThrow)
                {
                    maxFreeThrow = ft;
                    ftPlayer = player;
                }
            }
            return ftPlayer;
        }
    }
}
