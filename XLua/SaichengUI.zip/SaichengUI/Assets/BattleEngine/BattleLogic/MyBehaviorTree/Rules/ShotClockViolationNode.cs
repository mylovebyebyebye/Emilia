﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class ShotClockViolationNode : SequenceNode
    {
        private List<TaskType> lstBallTask;
        public ShotClockViolationNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            //这些行为需要判24秒
            this.lstBallTask = new List<TaskType>();
            this.lstBallTask.Add(TaskType.BallOnThePlayer);
            this.lstBallTask.Add(TaskType.BallPassBall);
            this.lstBallTask.Add(TaskType.BallMoveTo);
            this.lstBallTask.Add(TaskType.BallOnTheFloorBounce);
            this.lstBallTask.Add(TaskType.BallOnTheFloorRoll);
        }

        protected override void CreateChildNode()
        {
            ConditionNode isShotClockViolation = new ConditionNode("是否24秒违例", this.IsShotClockViolation);
            this.AddChild(isShotClockViolation);

            ActionNode shotClockViolation = new ActionNode("24秒违例的行为", this.ShotClockViolation);
            this.AddChild(shotClockViolation);
        }

        private bool IsShotClockViolation(TimeData time)
        {
            if (this.gameInfo.CurRound.IsShotClockViolation())
            {
                //球在投篮飞行过程中也不算
                if (this.gameInfo.Ball.GetCurTask() == null ||
                    (this.lstBallTask.Contains(this.gameInfo.Ball.GetCurTask().TaskType) )
                    )
                {
                    return true;
                }
            }
            return false;
        }

        private BehaviourTreeStatus ShotClockViolation(TimeData time)
        {
            Team atkTeam = this.gameInfo.AttackTeam;
            Team defTeam = this.gameInfo.DefTeam;

            this.gameInfo.ClearEvent();

            PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.ShotTimeVio, (int)atkTeam.TeamType, (int)defTeam.TeamType);
            this.gameInfo.AddGameInfo(pc);

            this.gameInfo.StartNewRound();
            Field defField = atkTeam.AttackField;
            Position posToThrowIn = defField.GetSideThrowInPos(this.gameInfo.Ball.Pos);

            //设置攻方、守方
            //this.gameInfo.SetBallOwnTeam(defTeam);
            this.gameInfo.ClearBallOwner();

            GameEvent ge = new GameEvent(GameEventType.BallShotToThrowIn);
            ge.Pos = posToThrowIn;
            ge.Param2 = (int)EBallShotThrowInReason.ShotClockVio;
            this.gameInfo.AddGameEvent(ge);


            return BehaviourTreeStatus.Success;
        }

    }
}
