﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common;

namespace BattleLogic
{
    public class RoundCommonNode : SequenceNode
    {


        public RoundCommonNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {

        }

        protected override void CreateChildNode()
        {
            ConditionNode isRoundCommon = new ConditionNode("是否是普通回合", this.IsRoundCommon);
            this.AddChild(isRoundCommon);

            SequenceNode playerChoice = new PlayerChoiceNode("场上球员事件选择", this.gameInfo);
            this.AddChild(playerChoice);

            SelectorNode tacSelect = new TacSelectorNode("战术选择", this.gameInfo);
            this.AddChild(tacSelect);

            //ActionNode updateAll = new ActionNode("刷所有人的任务", this.RefreshTask);
            //this.AddChild(updateAll);

        }

        private bool IsRoundCommon(TimeData time)
        {
            return true;
        }


    }
}
