﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using BattleLogic.Tactical;
using Common;

namespace BattleLogic
{
    public class StartGameNode : SequenceNode
    {
        private TacJumpball tacJumpBall;

        public StartGameNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacJumpBall = new TacJumpball(this.gameInfo, this.name);
        }

        protected override void CreateChildNode()
        {
            ConditionNode isStartGame = new ConditionNode("是否比赛开始第一帧", this.IsStartGame);
            this.AddChild(isStartGame);

            ActionNode homeJump = new ActionNode("主队跳球战术", this.HomeJumpTactics);
            this.AddChild(homeJump);
            ActionNode awayJump = new ActionNode("客队跳球战术", this.AwayJumpTactics);
            this.AddChild(awayJump);

            ActionNode basketBallPos = new ActionNode("篮球位置", this.SetBasketBallPos);
            this.AddChild(basketBallPos);

            //发送跳球事件
            ActionNode jumpballEvent = new ActionNode("开场跳球事件", this.AddJumpBallEvent);
            this.AddChild(jumpballEvent);
        }

        public bool IsStartGame(TimeData time)
        {
            if (time.deltaTime == 0)
            {
                return true;
            }
            return false;
        }

        private BehaviourTreeStatus HomeJumpTactics(TimeData time)
        {
            this.tacJumpBall.Do(this.gameInfo.HomeTeam);
            return BehaviourTreeStatus.Success;
        }

        private BehaviourTreeStatus AwayJumpTactics(TimeData time)
        {
            this.tacJumpBall.Do(this.gameInfo.AwayTeam);
            return BehaviourTreeStatus.Success;
        }

        public BehaviourTreeStatus AddJumpBallEvent(TimeData time)
        {
            GameEvent gameEvent = new GameEvent(GameEventType.JumpBall);
            //中圈跳球
            gameEvent.Param1 = 1;
            gameEvent.Param2 = (long)EJumpBallType.GameStart;
            gameEvent.Param4 = this.gameInfo.HomeTeam.Players[this.gameInfo.HomeTeam.Players.Count - 1];
            gameEvent.Param5 = this.gameInfo.AwayTeam.Players[this.gameInfo.AwayTeam.Players.Count - 1];
            this.gameInfo.AddGameEvent(gameEvent);

            this.gameInfo.Pause();

            PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.StartGameJump, ((Player)gameEvent.Param4).Id, ((Player)gameEvent.Param5).Id);
            this.gameInfo.AddGameInfo(pc);

            return BehaviourTreeStatus.Success;
        }

        public BehaviourTreeStatus SetBasketBallPos(TimeData time)
        {
            GameTask task = new GameTask(this.name);
            task.TargetPos = new Position(506, 300);
            task.TaskType = TaskType.BallLocation;
            task.DelayStart = 0;
            this.gameInfo.Ball.SetCurrentTask(task);

            return BehaviourTreeStatus.Success;
        }
    }
}
