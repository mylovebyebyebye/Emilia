﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class MyTree
    {
        private IBehaviourTreeNode rootNode;

        public void Init(GameInfo gameInfo)
        {
            var builder = new BehaviourTreeBuilder();


            RootNode rootSelectNode = new RootNode("根节点", gameInfo);
            builder.Sequence(rootSelectNode);
            rootSelectNode.FinishAdd();
            builder.End();

            this.rootNode = builder.Build();
        }

        public void Tick(TimeData time)
        {
            if (this.rootNode == null)
            {
                throw new Exception("尚未初始化");
            }
            this.rootNode.Tick(time);
        }
    }
}
