﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class EventSelectorNode : SelectorNode
    {
        public EventSelectorNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {

        }

        protected override void CreateChildNode()
        {
            BaseGameEventSequenceNode startGameJumpBallEvent = new JumpBallEvent("跳球事件", this.gameInfo);
            this.AddChild(startGameJumpBallEvent);

            BaseGameEventSequenceNode shotEvent = new ShotNewEvent("出手事件", this.gameInfo);
            this.AddChild(shotEvent);

            //BaseGameEventSequenceNode shotEvent = new ShotEvent("投篮事件", this.gameInfo);
            //this.AddChild(shotEvent);

            InsideShotEvent insideShot = new InsideShotEvent("内线投篮", this.gameInfo);
            this.AddChild(insideShot);

            //SlumDunkEvent slumDunk = new SlumDunkEvent("扣篮", this.gameInfo);
            //this.AddChild(slumDunk);

            //HookShotEvent hook = new HookShotEvent("勾手", this.gameInfo);
            //this.AddChild(hook);

            //FadeAwayShotEvent fadeAway = new FadeAwayShotEvent("后仰投篮事件", this.gameInfo);
            //this.AddChild(fadeAway);

            BaseGameEventSequenceNode defFoulEvent = new FoulEvent("防守犯规事件", this.gameInfo);
            this.AddChild(defFoulEvent);

            BaseGameEventSequenceNode freeThrowEvent = new FreeThrowEvent("罚球事件", this.gameInfo);
            this.AddChild(freeThrowEvent);

            BaseGameEventSequenceNode freeThrowShotEvent = new FreeThrowShotEvent("罚球出手事件", this.gameInfo);
            this.AddChild(freeThrowShotEvent);

            BaseGameEventSequenceNode blockEvent = new BlockShotEvent("盖帽事件", this.gameInfo);
            this.AddChild(blockEvent);

            BaseGameEventSequenceNode ballShotThrwoIn = new BallShotThrowIn("界外球事件", this.gameInfo);
            this.AddChild(ballShotThrwoIn);

            BaseGameEventSequenceNode shotToThrowInEvent = new BallShotToThrowIn("进球后准备发界外球事件", this.gameInfo);
            this.AddChild(shotToThrowInEvent);

            BaseGameEventSequenceNode outOfBoundToThrowIn = new OutOfBountToThrowIn("出界界外球事件", this.gameInfo);
            this.AddChild(outOfBoundToThrowIn);

            BaseGameEventSequenceNode outOfBoundThrowIn = new OutOfBoundThrowIn("出界准备发界外球事件", this.gameInfo);
            this.AddChild(outOfBoundThrowIn);

            BaseGameEventSequenceNode foulToThrowIn = new FoulToThrowIn("犯规准备发界外球", this.gameInfo);
            this.AddChild(foulToThrowIn);

            BaseGameEventSequenceNode foulThrowIn = new FoulThrowIn("犯规界外球", this.gameInfo);
            this.AddChild(foulThrowIn);

            BaseGameEventSequenceNode crossOverEvent = new CrossOverEvent("突破事件", this.gameInfo);
            this.AddChild(crossOverEvent);

            TurnRoundEvent turnRound = new TurnRoundEvent("转身突破", this.gameInfo);
            this.AddChild(turnRound);

            BaseGameEventSequenceNode layupEvent = new LayupEvent("上篮", this.gameInfo);
            this.AddChild(layupEvent);

            BaseGameEventSequenceNode slumDunkEvent = new SlumDunkEvent("扣篮", this.gameInfo);
            this.AddChild(slumDunkEvent);

            BaseGameEventSequenceNode afterTakePos = new AfterTakePosEvent("抢位后事件", this.gameInfo);
            this.AddChild(afterTakePos);

            BaseGameEventSequenceNode rebound = new BallHitHoopEvent("砸到篮筐", this.gameInfo);
            this.AddChild(rebound);

            StealEvent steal = new StealEvent("抢断", this.gameInfo);
            this.AddChild(steal);

            BaseGameEventSequenceNode startQuarter = new StartQuarterThrowIn("开始新的节", this.gameInfo);
            this.AddChild(startQuarter);
        }

    }
}
