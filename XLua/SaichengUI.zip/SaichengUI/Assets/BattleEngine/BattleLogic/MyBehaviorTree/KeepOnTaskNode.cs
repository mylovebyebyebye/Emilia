﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common;

namespace BattleLogic
{
    public class KeepOnTaskNode : SequenceNode
    {
        public KeepOnTaskNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {

        }

        protected override void CreateChildNode()
        {
            ConditionNode isEveryBodyBusy = new ConditionNode("是否全部有事干", this.gameInfo.IsEveryBodyBusy);
            this.AddChild(isEveryBodyBusy);

            ActionNode nullEvent = new ActionNode("那就跳过此次遍历", this.DoNothing);
            this.AddChild(nullEvent);
        }

        private BehaviourTreeStatus DoNothing(TimeData time)
        {
            return BehaviourTreeStatus.Success;
        }
    }
}
