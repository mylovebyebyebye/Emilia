﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class BallBehavior
    {
        private GameInfo gameInfo;
        private BasketBall ball;

        private BallOnThePlayerNode             updateOnThePlayer;
        private BallMoveToNode                  updateMoveTo;
        private BallPassBallNode                updatePassBall;
        private BallShotNode                    updateShot;
        private BallShotNode                    updateLayup;
        private BallLocationNode                updateLocation;
        private BallReboundNode                 updateRebound;
        private BallReadyToFreeThrow            updateReadyToFT;
        private BallFreeThrowShotNode           updateFreeThrow;
        private BallOnTheFloorBounce            updateBallBounce;
        private BallOnTheFloorRoll              updateBallRoll;
        private BallStaticNode                  updateStandby;

        public BallBehavior(GameInfo gameInfo, BasketBall ball)
        {
            this.gameInfo = gameInfo;
            this.ball = ball;
            this.InitUpdateTree();
        }

        private void InitUpdateTree()
        {
            updateOnThePlayer = new BallOnThePlayerNode("在球员手上", this.gameInfo);
            updateOnThePlayer.SetBall(this.ball);

            updateMoveTo = new BallMoveToNode("移动", this.gameInfo);
            updateMoveTo.SetBall(this.ball);

            updatePassBall = new BallPassBallNode("传球", this.gameInfo);
            updatePassBall.SetBall(this.ball);

            updateShot = new BallShotNode("投篮", this.gameInfo);
            updateShot.SetBall(this.ball);

            updateLayup = new BallShotNode("上篮", this.gameInfo);
            updateLayup.SetBall(this.ball);
            updateLayup.SetType(TaskType.BallLayup);

            updateLocation = new BallLocationNode("定位", this.gameInfo);
            updateLocation.SetBall(this.ball);

            updateRebound = new BallReboundNode("篮板球", this.gameInfo);
            updateRebound.SetBall(this.ball);

            updateReadyToFT = new BallReadyToFreeThrow("准备罚球", this.gameInfo);
            updateReadyToFT.SetBall(this.ball);

            updateFreeThrow = new BallFreeThrowShotNode("罚球", this.gameInfo);
            updateFreeThrow.SetBall(this.ball);

            updateBallBounce = new BallOnTheFloorBounce("地板球弹地", this.gameInfo);
            updateBallBounce.SetBall(this.ball);

            updateBallRoll = new BallOnTheFloorRoll("地板球滚动", this.gameInfo);
            updateBallRoll.SetBall(this.ball);

            updateStandby = new BallStaticNode("待机", this.gameInfo);
            updateStandby.SetBall(this.ball);
        }

        public void TickUpdate()
        {
            TaskType taskType = this.ball.GetCurTask().TaskType;
            switch (taskType)
            {
                case TaskType.BallOnThePlayer:
                    {
                        updateOnThePlayer.Process();
                    }
                    break;
                case TaskType.BallMoveTo:
                    {
                        updateMoveTo.Process();
                    }
                    break;
                case TaskType.BallPassBall:
                    {
                        updatePassBall.Process();
                    }
                    break;
                case TaskType.BallShot:
                    {
                        updateShot.Process();
                    }
                    break;
                case TaskType.BallLayup:
                    {
                        updateLayup.Process();
                    }
                    break;
                case TaskType.BallLocation:
                    {
                        updateLocation.Process();
                    }
                    break;
                case TaskType.BallRebound:
                    {
                        updateRebound.Process();
                    }
                    break;
                case TaskType.BallReadyToFreeThrow:
                    {
                        updateReadyToFT.Process();
                    }
                    break;
                case TaskType.BallFreeThrow:
                    {
                        updateFreeThrow.Process();
                    }
                    break;
                case TaskType.BallOnTheFloorBounce:
                    {
                        updateBallBounce.Process();
                    }
                    break;
                case TaskType.BallOnTheFloorRoll:
                    {
                        updateBallRoll.Process();
                    }
                    break;
                case TaskType.BallStatic:
                    {
                        updateStandby.Process();
                    }
                    break;
            }

            //this.updateRootNode.Tick(TimeData.Null);
        }
    }
}
