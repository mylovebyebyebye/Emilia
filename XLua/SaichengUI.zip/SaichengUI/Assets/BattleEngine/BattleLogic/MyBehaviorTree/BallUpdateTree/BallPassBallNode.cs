﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class BallPassBallNode : BallBaseUpdateNode
    {
        private TacBallOnTheFloor tacBallOnTheFloor;
        private TacPassBall tacPassBall;
        public BallPassBallNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacBallOnTheFloor = new TacBallOnTheFloor(this.gameInfo, this.name);
            this.tacPassBall = new TacPassBall(this.gameInfo, this.name);
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.BallPassBall;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            TaskMoveTo.Do(this.ball);
            if (this.ball.GetCurTask().FinishFrame == 1)
            {
                this.gameInfo.ResumeCurRound();

                if (this.ball.GetCurTask().Param1 == 0)//默认情况这样，新改的传球是由接球人来干这个判断了
                {
                    //传球结束
                    this.ball.GetCurTask().TaskType = TaskType.BallOnThePlayer;
                    this.ball.GetCurTask().TargetPlayer = this.ball.GetCurTask().TargetPlayer;
                    this.ball.GetCurTask().FinishFrame = int.MaxValue;

                    this.gameInfo.SetBallOwner(this.ball.GetCurTask().TargetPlayer);

                    //PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.GetPassBall2, this.ball.Owner.Id);
                    //this.gameInfo.AddGameInfo(pc);
                }
                else
                {
                    Player getBallPlayer = this.ball.GetCurTask().TargetPlayer;
                    Player passBallPlayer = this.ball.GetCurTask().SecondPlayer;
                    if (this.tacPassBall.IsGetBall(getBallPlayer, passBallPlayer))
                    {
                        this.tacPassBall.GetPassBall(getBallPlayer, passBallPlayer);
                    }
                    else
                    {
                        //到点了还没人拿着，直接变地板球
                        //进入地板球
                        int speed = ParameterManager.Instance.GetValue(ParameterEnum.PassBallSpeed);
                        Vector2D v1 = new Vector2D(this.gameInfo.Ball.GetCurTask().StartPos, this.gameInfo.Ball.GetCurTask().TargetPos);
                        int angle = (int)v1.GetSlopeAngle();

                        this.tacBallOnTheFloor.StartBallOnTheFloor(EBallOnTheFloorSourceType.PassBall, passBallPlayer, 0, passBallPlayer, 0, this.ball.Pos, angle, speed);  
                    }
                }
            }
            return BehaviourTreeStatus.Success;
        }
    }
}
