﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class BallLocationNode : BallBaseUpdateNode
    {
        public BallLocationNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.BallLocation;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            this.ball.Pos = this.ball.GetCurTask().RealTarget;
            return BehaviourTreeStatus.Success;
        }
    }
}
