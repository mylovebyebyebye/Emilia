﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public abstract class BallBaseUpdateNode : SequenceNode
    {
        protected TaskType taskType;
        protected BasketBall ball;

        protected abstract void SetTaskType();
        protected abstract BehaviourTreeStatus Process(TimeData time);

        public TaskType GetTaskType()
        {
            return this.taskType;
        }

        public void Process()
        {
            this.Process(TimeData.Null);
        }

        public BallBaseUpdateNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.ball = null;
            this.SetTaskType();
        }
        public void SetBall(BasketBall ball)
        {
            this.ball = ball;
        }

        protected override void CreateChildNode()
        {
            ConditionNode isLocation = new ConditionNode(this.taskType.ToString(), this.IsMyCharge);
            this.AddChild(isLocation);

            ActionNode processNode = new ActionNode("BallUpdateAction", this.Process);
            this.AddChild(processNode);
        }
        protected bool IsMyCharge(TimeData time)
        {
            if (this.ball == null)
            {
                throw new Exception("篮球节点未初始化");
            }

            if (this.ball.IsInTask(this.taskType))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 投篮和上篮一样，加个接口。。
        /// </summary>
        /// <param name="taskType"></param>
        public void SetType(TaskType taskType)
        {
            this.taskType = taskType;
        }
    }
}
