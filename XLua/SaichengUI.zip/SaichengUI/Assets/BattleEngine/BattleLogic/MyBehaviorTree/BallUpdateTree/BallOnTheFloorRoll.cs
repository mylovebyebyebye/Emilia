﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class BallOnTheFloorRoll : BallBaseUpdateNode
    {
        private TacBallOnTheFloor tac;
        public BallOnTheFloorRoll(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacBallOnTheFloor(this.gameInfo, this.name);
        }
        protected override void SetTaskType()
        {
            this.taskType = TaskType.BallOnTheFloorRoll;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            TaskMoveTo.Do(this.ball);
            //每一帧判出界
            if (this.tac.IsOutOfBound())
            {
                this.tac.OutOfBound((EBallOnTheFloorSourceType)this.ball.GetCurTask().Param1);
            }
            return BehaviourTreeStatus.Success;
        }
    }
}
