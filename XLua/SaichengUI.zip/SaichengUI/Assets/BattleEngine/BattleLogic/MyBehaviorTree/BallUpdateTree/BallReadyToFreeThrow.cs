﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class BallReadyToFreeThrow : BallBaseUpdateNode
    {

        public BallReadyToFreeThrow(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.BallReadyToFreeThrow;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            TaskLocation.Do(this.ball, this.ball.GetCurTask().TargetPlayer.Pos);
            return BehaviourTreeStatus.Success;
        }
    }
}
