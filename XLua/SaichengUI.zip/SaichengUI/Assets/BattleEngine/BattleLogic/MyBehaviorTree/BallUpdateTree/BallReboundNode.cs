﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class BallReboundNode : BallBaseUpdateNode
    {
        private TacBallOnTheFloor tacBallOnTheFloor;
        public BallReboundNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacBallOnTheFloor = new TacBallOnTheFloor(this.gameInfo, this.name);
        }


        protected override void SetTaskType()
        {
            this.taskType = TaskType.BallRebound;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            TaskMoveTo.Do(this.ball);
            if (this.ball.GetCurTask().FinishFrame == 1)
            {
                if (this.ball.GetCurTask().TargetPlayer != null)
                {
                    Player getBallPlayer = this.ball.GetCurTask().TargetPlayer;

                    this.gameInfo.AddPersoanlBoxScore(getBallPlayer,
                        this.ball.GetCurTask().Param2 == 1 ? BoxScoreType.DREB : BoxScoreType.OREB, 1);
                    if (this.ball.GetCurTask().Param2 == 1)
                    {
                        //防守篮板，重置24秒
                        this.gameInfo.StartNewRound();

                        PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.DefRebound, getBallPlayer.Id);
                        gameInfo.AddGameInfo(pc);
                    }
                    else
                    {
                        //进攻篮板
                        PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.OffRebound, getBallPlayer.Id);
                        gameInfo.AddGameInfo(pc);
                    }

                    this.gameInfo.SetBallOwner(this.ball.GetCurTask().TargetPlayer);

                    this.ball.GetCurTask().TaskType = TaskType.BallOnThePlayer;
                    this.ball.GetCurTask().FinishFrame = Int32.MaxValue;

                    this.gameInfo.ClearAllPlayerTask(TaskType.PlayerFastBreak);

                    //因为现在只有打筐的篮板，所以24秒肯定重置
                    //this.gameInfo.StartNewRound();
                    this.gameInfo.ResumeCurRound();
                }
                else if(this.ball.GetCurTask().SecondPlayer != null)
                {
                    Player shooter = this.ball.GetCurTask().SecondPlayer;
                    //进入地板球
                    int speed = ParameterManager.Instance.GetValue(ParameterEnum.BallHoopReboundSpeed);
                    Vector2D v1 = new Vector2D(this.gameInfo.Ball.GetCurTask().StartPos, this.gameInfo.Ball.GetCurTask().TargetPos);
                    int angle = (int)v1.GetSlopeAngle();

                    this.tacBallOnTheFloor.StartBallOnTheFloor(EBallOnTheFloorSourceType.Rebound, shooter, 0, shooter, 0, this.ball.Pos, angle, speed);
                }
            }
            return BehaviourTreeStatus.Success;
        }
    }
}
