﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class BallStaticNode : BallBaseUpdateNode
    {
        public BallStaticNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.BallStatic;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            return BehaviourTreeStatus.Success;
        }
    }
}
