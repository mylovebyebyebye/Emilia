﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class BallFreeThrowShotNode : BallBaseUpdateNode
    {
        private TacSubstitute TacSubs;
        public BallFreeThrowShotNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.TacSubs = new TacSubstitute(this.gameInfo, this.name);
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.BallFreeThrow;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            TaskMoveTo.Do(this.ball);
            if (this.gameInfo.Ball.GetCurTask().FinishFrame == 1)
            {
                int count = (int)this.gameInfo.Ball.GetCurTask().Param1;
                int index = (int)this.gameInfo.Ball.GetCurTask().Param2;
                int type = this.gameInfo.Ball.GetCurTask().Param3;
                Player freeThrower = this.gameInfo.Ball.GetCurTask().TargetPlayer;
                bool isGoal = this.gameInfo.Ball.GetCurTask().Success;
                Field atkField = freeThrower.OwnerTeam.AttackField;

                //直播
                PlayByPlayContent pc;
                if (isGoal)
                {
                    pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.FreeThrowIn, freeThrower.Id, index);
                }
                else
                {
                    pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.FreeThrowNotIn, freeThrower.Id, index);
                }
                //技术统计
                this.gameInfo.AddPersoanlBoxScore(freeThrower, BoxScoreType.FTA, 1);
                if (isGoal)
                {
                    this.gameInfo.AddPersoanlBoxScore(freeThrower, BoxScoreType.FTM, 1);
                    this.gameInfo.AddPoint(freeThrower, 1);
                }
                this.gameInfo.AddGameInfo(pc);
                if (count == index)
                {
                    //最后一罚
                    //判断进没进
                    //进了底线界外球, 没进砸筐流程
                    //技犯罚球，没进也不走抢板流程
                    if (type == (int)EFreeThrowType.Technical)
                    {
                        //技术犯规，发界外球
                        Position posToThrowIn = this.gameInfo.AttackTeam.AttackField.GetFTLineSideInsection(this.gameInfo.RandomNext(1, 2) - 1);

                        //发界外球
                        GameEvent ge = new GameEvent(GameEventType.OutOfBoundToThrowIn);
                        ge.Param2 = type;
                        ge.Pos = posToThrowIn;
                        this.gameInfo.AddGameEvent(ge);
                    }
                    else if (!isGoal)
                    {
                        GameEvent ge = new GameEvent(GameEventType.BallHitHoop);
                        ge.Param4 = freeThrower;
                        //把之前的事件清掉，犯规什么的都不算了
                        this.gameInfo.ClearEvent();
                        this.gameInfo.AddGameEvent(ge);
                    }
                    else
                    {
                        //最后一罚，球进了，可以触发换人
                        this.TacSubs.Do();

                        //球进了，发界外球事件
                        GameEvent ge = new GameEvent(GameEventType.BallShotToThrowIn);
                        ge.Param1 = type;
                        ge.Param2 = (int)EBallShotThrowInReason.FreeThrow;
                        this.gameInfo.ClearEvent();
                        this.gameInfo.AddGameEvent(ge);
                    }
                }
                else
                {
                    //安排球落点
                    Position p1 = atkField.GetBasketPos();
                    if (!isGoal)
                    {
                        int minDis = ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea);
                        int maxDis = ParameterManager.Instance.GetValue(ParameterEnum.HookRange);
                        int Radius = this.gameInfo.RandomNext(minDis, maxDis);

                        int angle = this.gameInfo.RandomNext(atkField.FreeThrowMinAngle,atkField.FreeThrowMaxAngle );

                        p1 = p1.GetPosByAngleRadius(angle, Radius);
                    }

                    GameTask gt = new GameTask(this.name);
                    gt.TaskType = TaskType.BallMoveTo;
                    gt.StartPos = this.ball.Pos;
                    gt.TargetPos = p1;
                    gt.FinishFrame = gt.CalcFrameByTime((ParameterManager.Instance.GetValue(ParameterEnum.FreeThrowInterval)) * 1.0f / 1000);
                    this.ball.SetCurrentTask(gt);


                    //继续罚球,延迟触发
                    GameEvent ge = new GameEvent(GameEventType.FreeThrow);
                    ge.Param1 = count;//总罚球次数
                    ge.Param2 = index+1;//当前第几罚
                    ge.Param4 = freeThrower;
                    ge.StartFrame = this.gameInfo.Frame + this.gameInfo.Ball.GetCurTask().FinishFrame + 1;
                    this.gameInfo.AddGameEvent(ge);
                }
            }
            return BehaviourTreeStatus.Success;
        }

        private void SetBallTask()
        {
 
        }
    }
}
