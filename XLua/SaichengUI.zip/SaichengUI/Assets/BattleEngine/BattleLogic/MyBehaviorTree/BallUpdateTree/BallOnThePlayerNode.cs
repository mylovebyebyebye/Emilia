﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class BallOnThePlayerNode : BallBaseUpdateNode
    {
        public BallOnThePlayerNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.BallOnThePlayer;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            if (this.ball.Owner != this.ball.GetCurTask().TargetPlayer)
            {
                this.gameInfo.SetBallOwner(this.ball.GetCurTask().TargetPlayer);
            }
            TaskLocation.Do(this.ball, this.ball.GetCurTask().TargetPlayer.Pos);
            if (this.ball.GetCurTask().FinishFrame == 1)
            {
                this.ball.GetCurTask().FinishFrame = 2;
            }
            return BehaviourTreeStatus.Success;
        }
    }
}
