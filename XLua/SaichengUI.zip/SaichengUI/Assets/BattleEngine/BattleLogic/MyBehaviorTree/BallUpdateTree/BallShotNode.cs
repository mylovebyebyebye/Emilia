﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class BallShotNode : BallBaseUpdateNode
    {
        public BallShotNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.BallShot;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            if (this.ball.GetCurTask().Param4 != (int)ShotType.SlumDunk)
            {
                TaskMoveTo.Do(this.ball);
            }
            else
            {
                TaskLocation.Do(this.ball, this.ball.GetCurTask().TargetPos);
            }
            if (this.ball.GetCurTask().FinishFrame == 1)
            {
                Player shooter = this.ball.GetCurTask().TargetPlayer;
                PlayByPlayContent pc;
                //直播
                if (this.ball.GetCurTask().Success)
                {
                    if (this.ball.GetCurTask().Param3 != 1)
                    {
                        pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.ShotIn, shooter.Id);
                    }
                    else
                    {
                        //加罚单独加了个直播
                        pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.BallShotAndOne, shooter.Id);
                    }

                    if (this.ball.GetCurTask().Param1 == 1)
                    {
                        //助攻的技术统计
                        this.gameInfo.AddPersoanlBoxScore(this.ball.GetCurTask().SecondPlayer, BoxScoreType.AST, 1);

                        pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.ShotInByAst, this.ball.GetCurTask().SecondPlayer.Id);
                    }
                }
                else
                {
                    pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.ShotNotIn, shooter.Id);
                }
                //这个时候要开始抢板什么的

                //开启新的24秒
                this.gameInfo.StartNewRound();

                //没犯规
                if (this.ball.GetCurTask().Param3 != 1)
                {
                    this.gameInfo.AddPersoanlBoxScore(shooter, BoxScoreType.FGA, 1);
                    if (this.ball.GetCurTask().Param2 == 3)
                    {
                        this.gameInfo.AddPersoanlBoxScore(shooter, BoxScoreType.F3PA, 1);
                    }
                    //没进就发个篮板事件
                    if (!this.ball.GetCurTask().Success)
                    {
                        GameEvent ge = new GameEvent(GameEventType.BallHitHoop);
                        ge.Param4 = shooter;
                        //把之前的事件清掉，犯规什么的都不算了
                        this.gameInfo.ClearEvent();
                        this.gameInfo.AddGameEvent(ge);
                    }
                    else
                    {
                        this.gameInfo.AddPoint(shooter, this.ball.GetCurTask().Param2);

                        if (this.ball.GetCurTask().Param2 > 1)
                        {
                            this.gameInfo.AddPersoanlBoxScore(shooter, BoxScoreType.FGM, 1);
                            if (this.ball.GetCurTask().Param2 == 3)
                            {
                                this.gameInfo.AddPersoanlBoxScore(shooter, BoxScoreType.F3PM, 1);
                            }
                        }

                        //球进了，发界外球事件
                        GameEvent ge = new GameEvent(GameEventType.BallShotToThrowIn);
                        ge.Param2 = (int)EBallShotThrowInReason.BallShot;
                        this.gameInfo.ClearEvent();
                        this.gameInfo.AddGameEvent(ge);       
                    }
                }
                else
                {
                    //犯规了~ 
                    if (this.ball.GetCurTask().Success)
                    {
                        this.gameInfo.AddPoint(this.ball.GetCurTask().TargetPlayer, this.ball.GetCurTask().Param2);

                        this.gameInfo.AddPersoanlBoxScore(shooter, BoxScoreType.FGA, 1);
                        this.gameInfo.AddPersoanlBoxScore(shooter, BoxScoreType.FGM, 1);
                        if (this.ball.GetCurTask().Param2 == 3)
                        {
                            this.gameInfo.AddPersoanlBoxScore(shooter, BoxScoreType.F3PA, 1);
                            this.gameInfo.AddPersoanlBoxScore(shooter, BoxScoreType.F3PM, 1);
                        }
                    }
                }
                this.gameInfo.AddGameInfo(pc);
            }
            return BehaviourTreeStatus.Success;
        }
    }
}
