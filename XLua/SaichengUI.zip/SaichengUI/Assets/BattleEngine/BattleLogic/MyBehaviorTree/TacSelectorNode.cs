﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class TacSelectorNode : SelectorNode
    {
        public TacSelectorNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {

        }

        protected override void CreateChildNode()
        {
            //ActionNode isPause = new ActionNode("是否停表", this.IsPause);
            //this.AddChild(isPause);

            ShotTimeNode defShotNode = new ShotTimeNode("扑投篮", this.gameInfo);
            this.AddChild(defShotNode);

            SequenceNode passBall = new PassBallNode("传球节点", this.gameInfo);
            this.AddChild(passBall);

            SequenceNode singleAtk = new SingleAttackNode("单打", this.gameInfo);
            this.AddChild(singleAtk);

            SequenceNode driveToAttackField = new DriveToAttackCourtNode("过半场战术", this.gameInfo);
            this.AddChild(driveToAttackField);

            SequenceNode boxOutNode = new BoxOutNode("安排卡位", this.gameInfo);
            this.AddChild(boxOutNode);

            ActionNode defaultTac = new ActionNode("默认战术", this.Default);
            this.AddChild(defaultTac);
        }

        private BehaviourTreeStatus Default(TimeData time)
        {
            return BehaviourTreeStatus.Success;
        }

        private BehaviourTreeStatus IsPause(TimeData time)
        {
            if (this.gameInfo.IsPause)
            {
                return BehaviourTreeStatus.Success;
            }
            return BehaviourTreeStatus.Failure;
        }

    }
}
