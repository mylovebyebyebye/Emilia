﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class RootNode : SequenceNode
    {
        public RootNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            ActionNode refreshStamina = new ActionNode("刷体力", this.RefreshStamina);
            this.AddChild(refreshStamina);

            RootSelecotor rootSelect = new RootSelecotor("根选择", this.gameInfo);
            this.AddChild(rootSelect);
        }

        /// <summary>
        /// 刷体力
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        private BehaviourTreeStatus RefreshStamina(TimeData time)
        {
            if (this.gameInfo.LastCalcPhysical + this.gameInfo.RefreshPhysicalCycle <= this.gameInfo.Frame)
            {
                this.gameInfo.LastCalcPhysical = this.gameInfo.Frame;
                for (int i = 0; i < GameInfo.TeamCount; i++)
                {
                    Team team = this.gameInfo.Teams[i];
                    for (int j = 0; j < team.PlayerCount; j++)
                    {
                        Player player = team.Players[j];
                        player.CalcStamina();
                    }
                    int benchCount = team.BenchPlayers.Count;
                    for (int j = 0; j < benchCount; j++)
                    {
                        Player player = team.BenchPlayers[j];
                        player.RestoreStaminaOnBench( this.gameInfo.RefreshPhysicalCycleOnSecond, this.gameInfo.OneSecondRestoreStamina );
                    }
                }
            }
            return BehaviourTreeStatus.Success;
        }

    }
}
