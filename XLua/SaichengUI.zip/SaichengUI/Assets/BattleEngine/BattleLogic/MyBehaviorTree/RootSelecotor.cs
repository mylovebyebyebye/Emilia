﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class RootSelecotor : SelectorNode
    {
        public RootSelecotor(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {

        }

        protected override void CreateChildNode()
        {
            SequenceNode eventProcessNode = new EventProcessNode("事件处理子树", this.gameInfo);
            this.AddChild(eventProcessNode);

            IsQuarterOverNode isQuarterOver = new IsQuarterOverNode("一节是否结束", this.gameInfo);
            this.AddChild(isQuarterOver);

            ShotClockViolationNode shotClockViolation = new ShotClockViolationNode("24秒违例", this.gameInfo);
            this.AddChild(shotClockViolation);

            Attack3SecondViolationNode atk3SVio = new Attack3SecondViolationNode("进攻3秒违例", this.gameInfo);
            this.AddChild(atk3SVio);

            Def3SecondVilationNode def3SVio = new Def3SecondVilationNode("防守3秒违例", this.gameInfo);
            this.AddChild(def3SVio);

            SequenceNode keepOnTaskNode = new KeepOnTaskNode("持续执行任务子树", this.gameInfo);
            this.AddChild(keepOnTaskNode);

            SequenceNode startGameNode = new StartGameNode("开场子树", this.gameInfo);
            this.AddChild(startGameNode);

            SequenceNode roundCommonNode = new RoundCommonNode("普通回合", this.gameInfo);
            this.AddChild(roundCommonNode);
        }
    }
}
