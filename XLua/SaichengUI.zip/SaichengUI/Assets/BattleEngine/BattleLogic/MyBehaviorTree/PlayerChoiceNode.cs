﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerChoiceNode : SequenceNode
    {
        public PlayerChoiceNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            ActionNode calcScoringExpect = new ActionNode("计算攻方所有人得分预期", this.CalcScoringExpect);
            this.AddChild(calcScoringExpect);

            ActionNode attackTeamChoice = new ActionNode("攻方事件选择", this.AttackTeamChoice);
            this.AddChild(attackTeamChoice);

            ActionNode defTeamChoice = new ActionNode("防守方事件选择", this.DefTeamChoice);
            this.AddChild(defTeamChoice);

            //ActionNode defTeamChoice = new ActionNode("防守方事件选择", this.DefTeamChoice);
            //this.AddChild(defTeamChoice);
        }

        private BehaviourTreeStatus CalcScoringExpect(TimeData time)
        {
            Team attack = this.gameInfo.AttackTeam;
            if (attack != null)
            {
                attack.MaxScoringPlayer = null;
                for (int i = 0; i < attack.PlayerCount; i++)
                {
                    Player player = attack.Players[i];
                    double scoringExpect = player.CalcScoringExpect(this.gameInfo);
                    //long test = stopwatch.ElapsedMilliseconds;
                    //stopwatch.Reset();
                    if (attack.MaxScoringPlayer == null)
                    {
                        attack.MaxScoringPlayer = player;
                    }
                    else if (attack.MaxScoringPlayer.ScoringExpect < scoringExpect)
                    {
                        attack.MaxScoringPlayer = player;
                    }
                }
            }
            return BehaviourTreeStatus.Success;
        }

        private BehaviourTreeStatus AttackTeamChoice(TimeData time)
        {
            Team attackTeam = this.gameInfo.Ball.OwnTeam;
            if (attackTeam == null)
            {
                attackTeam = this.gameInfo.LastAttackTeam;
            }
            //attackTeam.AskBallPlayer = null;

            for (int i = 0; i < attackTeam.PlayerCount; i++)
            {
                Player player = attackTeam.Players[i];
                player.ChoiceAtkTask();
            }

            //TacPlayerChoice.BallHanlderChoice(this.gameInfo);

            return BehaviourTreeStatus.Success;
        }

        private BehaviourTreeStatus DefTeamChoice(TimeData time)
        {
            Team attackTeam = this.gameInfo.Ball.OwnTeam;
            if (attackTeam == null)
            {
                attackTeam = this.gameInfo.LastAttackTeam;
            }
            Team defTeam = this.gameInfo.GetAnotherTeam(attackTeam);
            for (int i = 0; i < defTeam.PlayerCount; i++)
            {
                Player player = defTeam.Players[i];
                player.ChoiceDefTask();
            }
            return BehaviourTreeStatus.Success;
        }
    }
}
