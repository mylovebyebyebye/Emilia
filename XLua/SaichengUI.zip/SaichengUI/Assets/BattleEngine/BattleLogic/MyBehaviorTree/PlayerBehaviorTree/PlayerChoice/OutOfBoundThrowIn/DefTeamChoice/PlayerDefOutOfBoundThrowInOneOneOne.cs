﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 盯发球人
    /// </summary>
    public class PlayerDefOutOfBoundThrowInOneOneOne : PlayerDefOneOneOneChoiceNode
    {
        public PlayerDefOutOfBoundThrowInOneOneOne(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        /// <summary>
        /// 发球点在前场，且我防的人是发球人
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        protected override bool IsOneOneOne(FluentBehaviourTree.TimeData time)
        {
            Field atkField = this.gameInfo.AttackTeam.AttackField;
            Position pos = this.gameInfo.Ball.GetCurTask().TargetPos;
            Player toThrowIn = this.gameInfo.Ball.GetCurTask().TargetPlayer;
            Player myPosAttacker = this.player.GetMyPosAttacker();
            if (toThrowIn.IsSamePlayer(myPosAttacker) && 
              atkField.IsOnMe(pos))
            {
                return true;
            }
            return false;
        }

    }
}
