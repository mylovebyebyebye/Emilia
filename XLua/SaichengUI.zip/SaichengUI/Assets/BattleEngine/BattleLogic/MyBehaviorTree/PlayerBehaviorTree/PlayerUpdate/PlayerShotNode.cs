﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerShotNode : PlayerBaseUpdateNode
    {
        public PlayerShotNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerShot;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            ShotType shotType = (ShotType)this.player.GetCurTask().Param1;
            if (shotType == ShotType.JumpShot3P)
            {
                this.gameInfo.AddPersoanlBoxScore(this.player, BoxScoreType.JumpShot3, 1);
            }
            else if(shotType == ShotType.JumpShot2P)
            {
                this.gameInfo.AddPersoanlBoxScore(this.player, BoxScoreType.JumpShot2, 1);
            }

            GameEvent gameEvent = new GameEvent(GameEventType.ShotNew);
            gameEvent.Param1 = (int)shotType;
            gameEvent.Param4 = this.player;
            gameInfo.AddGameEvent(gameEvent);
            return BehaviourTreeStatus.Success;
        }
    }
}
