﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class PlayerReboundNode : PlayerBaseUpdateNode
    {
        private int NextTakePositionFrame = 0;
        
        public PlayerReboundNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }
        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerRebound;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            //抢位判断
            bool isTakePos = false;

            if (this.gameInfo.Frame >= this.NextTakePositionFrame)
            {
                Player toTakePosPlayer;
                this.NextTakePositionFrame = this.gameInfo.Frame + TimeFrameConverter.GetFrame(Player.MaxDefRelationTime);
                if (this.IsNeedTakePosition(out toTakePosPlayer))
                {
                    isTakePos = true;

                    Player winner, loser;
                    //看谁抢位成功了
                    this.CalcTakePostion(toTakePosPlayer, out winner, out loser);

                    int needFrame = this.SetTakePosMove(winner, loser);

                    //看时间要不要触发下一个推人判断事件
                    int maxFrame = this.gameInfo.Ball.GetCurTask().FinishFrame;
                    if (needFrame < maxFrame)
                    {
                        GameEvent ge = new GameEvent(GameEventType.AfterTakePosition);
                        ge.Param4 = winner;
                        ge.Param5 = loser;
                        ge.StartFrame = this.gameInfo.Frame + needFrame + 1;
                        this.gameInfo.AddGameEvent(ge);
                    }
                }
            }
            if (!isTakePos)//没有进行抢位就继续跑
            {
                //如果离目的地距离小于一定值就不动了
                double dis = this.player.Pos.DistanceActualLength(this.player.GetCurTask().TargetPos);
                if (dis > ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea))
                {
                    TaskMoveTo.Do(this.player);
                }
            }

            return BehaviourTreeStatus.Success;
        }

        private bool IsNeedTakePosition(out Player toTakePostion)
        {
            toTakePostion = null;
            for (int i = 0; i < GameInfo.TeamCount; i++)
            {
                Team team = this.gameInfo.Teams[i];
                if (team != this.player.OwnerTeam)
                {
                    for (int j = 0; j < team.PlayerCount; j++)
                    {
                        Player enermy = team.Players[i];	
                        
                        //在125参数距离内，且不属于已经抢位过的人
                        if(!enermy.IsInTask( TaskType.PlayerTakePosStandby) && 
                            !enermy.IsInTask(TaskType.PlayerTakePosMove))
                        {
                            double dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, enermy, this.player);
                            //double dis = enermy.Pos.DistanceActualLength(this.player.Pos);
                            if (dis < ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea))
                            {
                                toTakePostion = enermy;
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }

        private void CalcTakePostion(Player toTakePos, out Player winner, out Player loser)
        {
            //抢位成功
            double pro = this.player.GetAttribute(PlayerAttribute.BoxOut) / (this.player.GetAttribute(PlayerAttribute.BoxOut) + toTakePos.GetAttribute(PlayerAttribute.BoxOut)) * 10000;
            if (pro >= this.gameInfo.RandomNext())
            {
                //自己赢了
                winner = this.player;
                loser = toTakePos;
            }
            else
            {
                winner = toTakePos;
                loser = this.player;
            }
        }

        /// <summary>
        /// 抢位之后的移动
        /// </summary>
        /// <param name="winner"></param>
        /// <param name="loser"></param>
        private int SetTakePosMove(Player winner, Player loser)
        {

            //抢位之后的移动
            Position basketPos = this.gameInfo.AttackTeam.AttackBasket;
            //double disLoserToBasket = basketPos.DistanceActualLength(loser.Pos);
            double disLoserToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, this.gameInfo.AttackTeam.AttackField, loser);
            //double disWinnerToBasket = basketPos.DistanceActualLength(winner.Pos);
            double disWinnerToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, this.gameInfo.AttackTeam.AttackField, winner);

            double RadiusRestrictedArea = ParameterManager.Instance.GetValue(ParameterEnum.RestrictedArea) ;
            double RadiusPlayerArea = ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea) ;

            int maxFrame = this.gameInfo.Ball.GetCurTask().FinishFrame;
            double maxSeconds = TimeFrameConverter.ConvertFrameToSecond(maxFrame);

            Position pWinnerMoveTo = Position.Empty;
            Position pLoserMoveTo = Position.Empty;

            Position loserPos = loser.Pos;
            if (loserPos == basketPos)
            {
                int angleRandom = this.gameInfo.RandomNext(1, 12);
                loserPos = basketPos.GetPosByAngleRadius(30 * angleRandom, 5);
            }

            if (disLoserToBasket > (RadiusRestrictedArea + RadiusPlayerArea))
            {
                //失败者到篮筐距离>124+125
                //表现，失败者不动，成功者向k点移动，，重合停止，加速移动
                //目标位置，k点，失败者圆柱体，与他到篮筐直线的交点，离篮筐近的交点，位置完全重合
                pWinnerMoveTo = Formula.ClosestIntersection(loser.Pos, Position.GetPix(RadiusPlayerArea), basketPos, loserPos);
            }
            else if (disLoserToBasket < (RadiusRestrictedArea - RadiusPlayerArea))
            {
                //失败者到篮筐距离<124-125
                //表现，失败者不动，成功者向k点移动，重合停止，加速移动
                //目标位置，k点，离篮筐远的人的圆柱体范围，与他到篮筐直线的交点，离篮筐远的交点，位置完全重合
                pWinnerMoveTo = Formula.ClosestIntersection(loser.Pos, Position.GetPix(RadiusPlayerArea), basketPos, loserPos, true);
            }
            else if ((disLoserToBasket - RadiusPlayerArea) > Formula.MinDifference)
            {
                //124-125<失败者到篮筐距离<124+125，不等于125
                //表现，失败者不动，成功者向k点移动，重合停止，加速移动
                //目标位置，k点，失败者到篮筐的直线，与合理冲撞区线的交点，位置完全重合
                
                double Radius = (double)(disLoserToBasket - RadiusRestrictedArea);
                if (Radius > 0)
                {
                    //这在合理冲撞区外面，往里走
                    pWinnerMoveTo = Formula.ClosestIntersection(loser.Pos, Position.GetPix(Radius), basketPos, loserPos);
                }
                else
                {
                    //在合理冲撞区内，往外走
                    Radius = Radius * -1;
                    pWinnerMoveTo = Formula.ClosestIntersection(loser.Pos, Position.GetPix(Radius), basketPos, loserPos, true);
                }
                
            }
            else
            {
                pWinnerMoveTo = loser.Pos;
                //等于125
                if (disWinnerToBasket > disLoserToBasket)
                {
                    pLoserMoveTo = Formula.ClosestIntersection(loser.Pos, Position.GetPix(RadiusPlayerArea), basketPos, loserPos);
                }
                else
                {
                    pLoserMoveTo = Formula.ClosestIntersection(loser.Pos, Position.GetPix(RadiusPlayerArea), basketPos, loserPos, true);
                }
            }
            //安排移动, 以胜利方为准
            int needFrame = this.AfterTakePosMove(winner, pWinnerMoveTo, maxSeconds);
            double needSeconds = TimeFrameConverter.ConvertFrameToSecond(needFrame);
            if (pLoserMoveTo != Position.Empty)
            {
                this.AfterTakePosMove(loser, pLoserMoveTo, needSeconds);
            }
            else
            {
                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.PlayerStandby;
                gt.FinishFrame = maxFrame;
                loser.SetCurrentTask(gt);
            }
            return needFrame;
        }

        private int AfterTakePosMove(Player player, Position target, double maxSeconds)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerTakePosMove;
            gt.StartPos = player.Pos;
            gt.TargetPos = target;

            //加速移动
            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(player, this.gameInfo.RandomSpeed());

            double speedInPixel = player.GetSpeedInPixelByLevel(speedLevel);
            gt.FinishFrame = gt.CalcRealTargetTryMyBest(speedInPixel, maxSeconds);
            gt.SpeedLevel = speedLevel;

            player.SetCurrentTask(gt);

            return gt.FinishFrame;
        }
    }
}
