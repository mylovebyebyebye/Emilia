﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerInisideSingleAtkNoBallOutOf3S : PlayerBaseChoiceNode
    {
        TacMoveOut3SArea tac;

        public PlayerInisideSingleAtkNoBallOutOf3S(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacMoveOut3SArea(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            return this.player.IsNeedOut3S();
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.tac.Do(this.player);
            this.player.GetCurTask().NextTask = TaskType.PlayerInsideSingleAttack;
            
            return BehaviourTreeStatus.Success;
        }
    }
}
