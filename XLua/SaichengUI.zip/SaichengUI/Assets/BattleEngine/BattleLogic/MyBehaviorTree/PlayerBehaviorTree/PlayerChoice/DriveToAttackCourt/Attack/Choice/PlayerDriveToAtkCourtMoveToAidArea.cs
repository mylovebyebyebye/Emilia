﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 去接应
    /// </summary>
    public class PlayerDriveToAtkCourtMoveToAidArea : PlayerBaseChoiceNode
    {
        TacThrowIn tac;
        public PlayerDriveToAtkCourtMoveToAidArea(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacThrowIn(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            //到这里直接进行安全判定
            if (this.tac.IsInSafeArea(this.player, this.gameInfo.Ball.Pos))
            {
                if (this.gameInfo.IsInBounds(this.player.Pos))
                {
                    return false;
                }
            }
            return true;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            Position p1 = this.tac.GetAskBallPos(this.player, this.gameInfo.Ball.Pos);

            int speedLevel = SpeedManager.Instance.GetSpeedNormal(this.player, this.gameInfo.RandomSpeed());

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = p1;
            double speed = this.player.GetSpeedInPixelByLevel(speedLevel);
            gt.FinishFrame = gt.CalcRealTargetBySpeedMaxSeconds( ref speed, 0.4f);
            gt.SpeedLevel = this.player.GetSpeedLevelByRealSpeed(speed);
            gt.NextTask = TaskType.PlayerDriveToAttackField;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
