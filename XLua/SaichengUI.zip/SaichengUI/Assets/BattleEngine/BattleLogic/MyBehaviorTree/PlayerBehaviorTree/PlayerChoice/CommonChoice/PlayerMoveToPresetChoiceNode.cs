﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerMoveToPresetChoiceNode : PlayerBaseChoiceNode
    {
        private TacLuowei tac;
        public PlayerMoveToPresetChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacLuowei(this.gameInfo, this.name);
        }


        protected override bool IsMyCharge(TimeData time)
        {
            //球是否在后场，不是本方控球最高
            //球在前场，不在预设区域内
            Team attackTeam = gameInfo.Ball.OwnTeam;
            Field attackField = attackTeam.AttackField;
            if (!attackField.IsOnMyEffectiveArea(this.player.Pos))
            {
                if (!attackTeam.MaxHanlder.IsSamePlayer(this.player))
                {
                    return true;
                }
            }
            //else if (!attackField.IsOnPresetArea(this.player.Role, this.player.Pos))
            //{
            //    return true;
            //}
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.tac.Do(this.player);
            return BehaviourTreeStatus.Success;
        }
    }
}
