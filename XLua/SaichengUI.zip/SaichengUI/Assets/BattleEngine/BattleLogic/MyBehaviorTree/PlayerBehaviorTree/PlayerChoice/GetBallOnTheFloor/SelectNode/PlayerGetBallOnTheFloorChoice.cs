﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerGetBallOnTheFloorChoice : PlayerChoiceBaseSelector
    {
        public PlayerGetBallOnTheFloorChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            PlayerGetBallOnTheFloorFinish finish = new PlayerGetBallOnTheFloorFinish("是否已经有其他人得球", this.gameInfo);
            this.AddChild(finish);

            PlayerGetBallOnTheFloorGet get = new PlayerGetBallOnTheFloorGet("自己是否得球", this.gameInfo);
            this.AddChild(get);

            ActionNode move = new ActionNode("向球移动去抢球", this.MoveToGetBall);
            this.AddChild(move);
        }

        private BehaviourTreeStatus MoveToGetBall(TimeData time)
        {
            double seconds = 0.1f;

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = this.gameInfo.Ball.Pos;

            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(this.player, this.gameInfo.RandomSpeed());
            double speedInPix = this.player.GetSpeedInPixelByLevel(speedLevel);
            gt.FinishFrame = gt.CalcRealTargetTryMyBest(speedInPix, seconds);
            gt.SpeedLevel = speedLevel;
            gt.NextTask = TaskType.PlayerToGetBallOnTheFloor;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
