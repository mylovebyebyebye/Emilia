﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 暂时不用，攻方行为跟进球以后的界外球一致
    /// </summary>
    public class PlayerAtkOutOfBoundNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerAtkOutOfBoundNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.player.IsInTask( TaskType.PlayerReadyToOutOfBoundThrowIn) ||
                    this.player.IsInTask( TaskType.PlayerToThrowIn))
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            throw new NotImplementedException();
        }
    }
}
