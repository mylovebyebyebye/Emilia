﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 不是单打人，且持球，就待机
    /// </summary>
    public class PlayerOutsideSingleAtkNoBallStandby : PlayerBaseChoiceNode
    {
        public PlayerOutsideSingleAtkNoBallStandby(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            //如果是持球人
            Player handler = this.gameInfo.Ball.Owner;
            if(this.player.IsSamePlayer(handler))
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            gt.FinishFrame = TimeFrameConverter.GetFrame(Player.MaxDefRelationTime);
            gt.NextTask = TaskType.PlayerOutsideSingleAttack;
            gt.RecordPos = this.player.GetCurTask().RecordPos;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
