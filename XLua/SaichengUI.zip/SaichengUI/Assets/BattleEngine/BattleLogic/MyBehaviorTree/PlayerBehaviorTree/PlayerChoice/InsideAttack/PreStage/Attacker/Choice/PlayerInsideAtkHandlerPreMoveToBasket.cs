﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    /// <summary>
    /// 向篮筐移动
    /// </summary>
    public class PlayerInsideAtkHandlerPreMoveToBasket : PlayerBaseChoiceNode
    {
        public PlayerInsideAtkHandlerPreMoveToBasket(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }


        protected override bool IsMyCharge(TimeData time)
        {
            Player defPlayer = this.player.GetMyPosDefPlayer();
            //double disToBasket = this.player.OwnerTeam.AttackBasket.DistanceActualLength(this.player.Pos);
            double disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, this.player.OwnerTeam.AttackField, this.player);
            //不在防守人范围内，没到达上篮距离
            if (disToBasket > ParameterManager.Instance.GetValue(ParameterEnum.LayupDistance))
            {
                if (defPlayer == null)
                {
                    return true;
                }
                double disToDef = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, this.player, defPlayer);
                //double disToDef = defPlayer.Pos.DistanceActualLength(this.player.Pos);
                if (disToDef > ParameterManager.Instance.GetValue(ParameterEnum.InsideAttackDefDis))
                {
                    return true;
                }
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            double seconds = ParameterManager.Instance.GetValueD(ParameterEnum.InsideAttackAtkMoveTime) / 1000;

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = this.player.OwnerTeam.AttackBasket;
            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(player, this.gameInfo.RandomSpeed());
            gt.FinishFrame = gt.CalcRealTargetByTimeSpeed(seconds, player.GetSpeedInPixelByLevel(speedLevel));
            gt.SpeedLevel = speedLevel;
            gt.NextTask = TaskType.PlayerInsideAttackPrepare;

            this.player.SetCurrentTask(gt);

            this.gameInfo.Ball.GetCurTask().TaskType = TaskType.BallOnThePlayer;
            this.gameInfo.Ball.GetCurTask().FinishFrame = int.MaxValue;

            return BehaviourTreeStatus.Success;
        }
    }
}
