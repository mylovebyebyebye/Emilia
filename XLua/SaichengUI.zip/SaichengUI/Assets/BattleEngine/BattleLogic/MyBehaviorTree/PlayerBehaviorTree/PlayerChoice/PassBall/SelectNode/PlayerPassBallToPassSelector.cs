﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class PlayerPassBallToPassSelector : PlayerChoiceBaseSelector
    {
        private int lastStandbyFrame = 0;
        private double standbyTime = 1.5f;
        private int standbyFrame;
        private TacStandby tacStandby;
        private TacCostStamina tacCostStamina;
        private TacFillIn tacFillIn;
        private double ballSpeed;

        public PlayerPassBallToPassSelector(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacCostStamina = new TacCostStamina(this.gameInfo, this.name);
            this.tacFillIn = new TacFillIn(this.gameInfo, this.name);
            this.tacStandby = new TacStandby(this.gameInfo, this.name);
            this.standbyFrame = TimeFrameConverter.GetFrame(standbyTime);
            this.ballSpeed = ParameterManager.Instance.GetValueD(ParameterEnum.PassBallSpeed);
        }

        protected override void CreateChildNode()
        {
            //ActionNode standby = new ActionNode("传球准备", this.Standby);
            //this.AddChild(standby);

            ActionNode pass = new ActionNode("传球", this.DoPass);
            this.AddChild(pass);
        }

        private BehaviourTreeStatus Standby(TimeData time)
        {
            if (this.gameInfo.IsFramePassed(this.lastStandbyFrame, this.standbyFrame))
            {
                this.lastStandbyFrame = this.gameInfo.Frame;

                //传球准备时间
                Player askBallPlayer = this.player.GetCurTask().TargetPlayer;
                Position passBallPos = this.player.GetCurTask().RecordPos;
                double param518 = ParameterManager.Instance.GetValueD(ParameterEnum.PassBallParam7);
                double param519 = ParameterManager.Instance.GetValueD(ParameterEnum.PassBallParam8);
                double dis = this.gameInfo.DisManager.GetDistanceInCMToSameTeamPlayer(this.gameInfo.Frame, this.player, askBallPlayer);
                double seconds = dis / (this.player.GetAttribute(PlayerAttribute.Passing) + param518) * param519 / 1000;

                this.tacStandby.DoMoveInSituBySeconds(this.player, (double)seconds);
                this.player.GetCurTask().TargetPlayer = askBallPlayer;
                this.player.GetCurTask().RecordPos = passBallPos;
                this.player.GetCurTask().NextTask = TaskType.PlayerToPassBall;

                return BehaviourTreeStatus.Success;
            }
            return BehaviourTreeStatus.Failure;
        }

        private BehaviourTreeStatus DoPass(TimeData time)
        {
            //清掉事件
            this.gameInfo.ClearEvent();

            Team attackTeam = this.gameInfo.Ball.Owner.OwnerTeam;

            //安排球飞行
            this.SetBallTask(attackTeam);

            //直播
            this.AddGameInfo();

            //记录传球信息（用来算助攻）
            attackTeam.SetPassBallInfo(this.gameInfo.GameFrame, this.player);
            this.player.LastPassBallFrame = this.gameInfo.Frame;

            //抢断判断
            Player askBallPlayer = this.player.GetCurTask().TargetPlayer;
            this.CalcStealPassBall(this.player, askBallPlayer, this.player.GetCurTask().RecordPos);

            //清空持球人
            this.gameInfo.ClearBallOwner();

            //传球人
            this.player.ClearTask();

            //扣传球人体力
            this.tacCostStamina.Cost(EStaminaCost.PassBall, this.player);

            //如果传球人是单打人，则清掉单打人标记
            if (this.player.IsSamePlayer(attackTeam.SingleAttacker))
            {
                attackTeam.ClearSingleAttacker();
            }

            //重新选择防守对象
            this.tacFillIn.ChooseDefAgain(this.player);

            return BehaviourTreeStatus.Success;
        }

        private void SetBallTask(Team attackTeam)
        {
            Player askBallPlayer = this.player.GetCurTask().TargetPlayer;
            Position target = this.player.GetCurTask().RecordPos;

            GameTask ballTask = new GameTask(this.name);
            ballTask.TaskType = TaskType.BallPassBall;
            ballTask.TargetPlayer = askBallPlayer;
            ballTask.SecondPlayer = this.player;
            ballTask.TargetPos = target;
            ballTask.StartPos = this.gameInfo.Ball.Pos;
            ballTask.Param1 = 1;
            ballTask.FinishFrame = ballTask.CalcTimeBySpeed(ballSpeed);
            this.gameInfo.Ball.SetCurrentTask(ballTask);
        }

        private void AddGameInfo()
        {
            Player targetPlayer = this.player.GetCurTask().TargetPlayer;

            PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.PassBall, this.gameInfo.Ball.Owner.Id, targetPlayer.Id);
            this.gameInfo.AddGameInfo(pc);

            //string str = string.Format("{0} 把球传给了 {1} {5} 投篮预期:{2} 突破预期:{3} 内线得分预期:{6} 当前体力:{4}",
            //   this.gameInfo.Ball.Owner.Name,
            //   targetPlayer.Name,
            //   Math.Round(targetPlayer.ShotScoringExpect, 2),
            //   Math.Round(targetPlayer.CrossOverExpect, 2),
            //   targetPlayer.CurStamina,
            //   targetPlayer.Pos.ToString(),
            //   Math.Round(targetPlayer.InsideScoringExpect, 2));
            //this.gameInfo.AddGameInfo(str);
        }

        /// <summary>
        /// 计算抢断传球
        /// </summary>
        /// <param name="passBallPlayer"></param>
        /// <param name="askBallPlayer"></param>
        /// <param name="passBallPos"></param>
        private void CalcStealPassBall(Player passBallPlayer, Player askBallPlayer, Position passBallPos)
        {
            //目标点在界外，啥也不干
            if (!this.gameInfo.IsInBounds(passBallPos))
            {
                return;
            }

            double disAskBallToPassBallPosMax = ParameterManager.Instance.GetValue(ParameterEnum.PassBallParam6);

            double disAskBallToPassBallPlayerPos = this.gameInfo.DisManager.GetDistanceInCMToSameTeamPlayer(this.gameInfo.Frame, askBallPlayer, passBallPlayer);
            //double disAskBallToPassBallPlayerPos = askBallPlayer.Pos.DistanceActualLength(passBallPlayer.Pos);

            int maxCount = ParameterManager.Instance.GetValue(ParameterEnum.PassBallParam5);
            int count = 0;

            double disPassBallPlayerToPassBallPos = passBallPlayer.Pos.DistanceActualLength(passBallPos);
            double radius = disPassBallPlayerToPassBallPos / Position.GetPix(ParameterManager.Instance.GetValueD(ParameterEnum.PassBallParam4));
            double stealParam = ParameterManager.Instance.GetValue(ParameterEnum.StealPro);
            double stealParam2 = ParameterManager.Instance.GetValue(ParameterEnum.StealPro);

            Triangle triangle = Formula.GetTriangle(passBallPlayer.Pos, passBallPos, radius);
            Vector2D vPassToTarget = new Vector2D(passBallPlayer.Pos, passBallPos);

            //在一定范围内的球员才需要判是否去抢断
            Team defTeam = this.gameInfo.GetAnotherTeam(passBallPlayer.OwnerTeam);
            for (int i = 0; i < defTeam.PlayerCount; i++)
            {
                Player defPlayer = defTeam.Players[i];

                if (count >= maxCount)
                {
                    break;
                }
                double dis = passBallPos.Distance(defPlayer.Pos);
                if (dis < radius || triangle.IsInMe(defPlayer.Pos))
                {
                    double stealAttr = defPlayer.GetAttribute(PlayerAttribute.Steal);
                    double disParam = dis / stealParam2;
                    double stealPro = stealAttr / stealParam / disParam / (disParam + 1) * 10000;
                    if (stealPro > this.gameInfo.RandomNext())
                    {
                        Position stealPos;
                        //进行抢断
                        if (disAskBallToPassBallPlayerPos > disAskBallToPassBallPosMax)
                        {
                            stealPos = passBallPos;
                        }
                        else
                        {
                            //计算抢断点
                            //double disToPassBallPlayer = defPlayer.Pos.Distance(passBallPlayer.Pos);
                            double disToPassBallPlayer = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, defPlayer, passBallPlayer);
                            if (disToPassBallPlayer < disPassBallPlayerToPassBallPos)
                            {
                                stealPos = vPassToTarget.GetVerticalToVector(defPlayer.Pos);
                            }
                            else
                            {
                                stealPos = passBallPos;
                            }
                        }

                        this.SetStealTask(passBallPlayer, defPlayer, stealPos);

                        count++;
                    }
                }
            }
        }

        /// <summary>
        /// 设置抢断人
        /// </summary>
        /// <param name="passBallPlayer"></param>
        /// <param name="stealPlayer"></param>
        /// <param name="stealPos"></param>
        private void SetStealTask(Player passBallPlayer, Player stealPlayer, Position stealPos)
        {
            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(stealPlayer, this.gameInfo.RandomSpeed());
            double playerSpeed = stealPlayer.GetSpeedByLevel(speedLevel);
            double playerSpeedInPixel = stealPlayer.GetSpeedInPixelByLevel(speedLevel);
            Position ballPos = this.gameInfo.Ball.Pos;

            double ballToStealPosTime = stealPos.DistanceActualLength(ballPos) / this.ballSpeed;
            double stealPlayerToStealPosTime = stealPos.DistanceActualLength(stealPlayer.Pos) / playerSpeed;
            if (ballToStealPosTime < stealPlayerToStealPosTime)
            {
                //到不了抢断点，直接向抢断点移动 时间1
                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.PlayerMoveTo;
                gt.StartPos = stealPlayer.Pos;
                gt.TargetPos = stealPos;
                gt.SpeedLevel = speedLevel;
                gt.FinishFrame = gt.CalcRealTargetByTimeSpeed((double)ballToStealPosTime, playerSpeedInPixel);

                stealPlayer.SetCurrentTask(gt);

            }
            else
            {
                //向抢断点移动时间2
                {
                    GameTask gt = new GameTask(this.name);
                    gt.TaskType = TaskType.PlayerMoveTo;
                    gt.TargetPlayer = passBallPlayer;
                    gt.StartPos = stealPlayer.Pos;
                    gt.TargetPos = stealPos;
                    gt.SpeedLevel = speedLevel;
                    gt.FinishFrame = gt.CalcRealTargetByTimeSpeed((double)stealPlayerToStealPosTime, playerSpeedInPixel);

                    stealPlayer.SetCurrentTask(gt);
                }

                //待机时间1-时间2
                {
                    double time2 = (double)(ballToStealPosTime - stealPlayerToStealPosTime);
                    if (time2 > 0)
                    {
                        //待机后触发抢断判断
                        GameTask gt = new GameTask(this.name);
                        gt.TargetPlayer = passBallPlayer;
                        gt.TaskType = TaskType.PlayerToStealPassBall;
                        gt.FinishFrame = TimeFrameConverter.GetFrame(time2);

                        stealPlayer.NextTask.Add(gt);
                    }
                }
            }
        }
    }
}
