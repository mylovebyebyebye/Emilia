﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerFadeAwayAtkFouled : PlayerBaseChoiceNode
    {
        private Player foulPlayer;
        private TacFoul tacFoul;
        public PlayerFadeAwayAtkFouled(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacFoul = new TacFoul(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            //看看有没有人能犯规
            this.foulPlayer = null;
            double maxDis = ParameterManager.Instance.GetValue(ParameterEnum.InsideAttackDefDis) * 1.0f;

            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player defPlayer = this.gameInfo.DefTeam.Players[i];
                double disToMe = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, this.player, defPlayer);
                if (disToMe < maxDis)
                {
                    //范围内才需要算概率
                    if (this.tacFoul.IsFoul(EFoulType.FadeAwayDefFoul, this.player, defPlayer))
                    {
                        this.foulPlayer = defPlayer;
                        return true;
                    }
                }
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.gameInfo.AddPersoanlBoxScore(this.foulPlayer, BoxScoreType.FoulOnFadeAway, 1);

            //改为犯规事件
            GameEvent ge = new GameEvent(GameEventType.Foul);
            ge.Param1 = (int)FoulType.ShotFoul;
            ge.Param2 = 2;
            ge.Param4 = this.player;
            ge.Param5 = this.foulPlayer;

            this.gameInfo.AddGameEvent(ge);

            return BehaviourTreeStatus.Success;
        }
    }
}
