﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDriveToAtkCourtAskBall : PlayerBaseChoiceNode
    {
        TacStandby tac;
        private TacAskBall tacAskBall;
        public PlayerDriveToAtkCourtAskBall(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacStandby(this.gameInfo, this.name);
            this.tacAskBall = new TacAskBall(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if ( this.gameInfo.IsInBounds(this.player.Pos))
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            if (this.gameInfo.Ball.Owner != null)
            {
                this.tacAskBall.Do(this.player);
            }
            else
            {
                this.tac.Do(this.player, TimeFrameConverter.GetFrame(Player.MaxDefRelationTime));
                this.player.GetCurTask().NextTask = TaskType.PlayerDriveToAttackField;
            }
            return BehaviourTreeStatus.Success;
        }
    }
}
