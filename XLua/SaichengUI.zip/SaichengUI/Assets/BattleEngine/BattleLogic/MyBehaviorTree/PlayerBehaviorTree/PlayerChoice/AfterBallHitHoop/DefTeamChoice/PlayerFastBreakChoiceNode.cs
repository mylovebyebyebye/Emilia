﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    /// <summary>
    /// 快下
    /// </summary>
    public class PlayerFastBreakChoiceNode : PlayerBaseChoiceNode
    {
        private TacFastBreak tac;

        public PlayerFastBreakChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacFastBreak(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            int Radius = ParameterManager.Instance.GetValue(ParameterEnum.ReboundPlacement);
            double dis = this.player.Pos.DistanceActualLength(this.gameInfo.Ball.GetCurTask().TargetPos);
            if (dis > Radius)
            {
                //范围外且对位没有去抢落点
                Player attacker = this.player.GetMyPosAttacker();
                if (attacker != null && !attacker.IsInTask(TaskType.PlayerAfterBallHitMoveToBall))
                {
                    //这里有个隐藏东西， 离篮筐最近的三人才有可能下快攻
                    if (this.player.GetCurTask().Param1 == 1)
                    {
                        if (this.tac.IsNeedFastBreak(this.player))
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.tac.Do(this.player);
            return BehaviourTreeStatus.Success;
        }
    }
}
