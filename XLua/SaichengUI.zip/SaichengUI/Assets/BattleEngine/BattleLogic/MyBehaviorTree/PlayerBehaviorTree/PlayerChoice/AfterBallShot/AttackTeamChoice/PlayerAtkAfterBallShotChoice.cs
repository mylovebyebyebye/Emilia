﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerAtkAfterBallShotChoice : PlayerChoiceBaseSelector
    {
        public PlayerAtkAfterBallShotChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }


        protected override void CreateChildNode()
        {
            PlayerAtkAfterBallShotToThrowInChoice moveToThrowIn = new PlayerAtkAfterBallShotToThrowInChoice("去发球", this.gameInfo);
            this.AddChild(moveToThrowIn);

            PlayerAtkAfterBallShotMoveToGetBall moveToGetBall = new PlayerAtkAfterBallShotMoveToGetBall("移动要球", this.gameInfo);
            this.AddChild(moveToGetBall);

            PlayerAtkAfterBallShotToGetBall getBall = new PlayerAtkAfterBallShotToGetBall("原地要球", this.gameInfo);
            this.AddChild(getBall);

            PlayerMoveToPresetChoiceNode moveToPreset = new PlayerMoveToPresetChoiceNode("落位进攻", this.gameInfo);
            this.AddChild(moveToPreset);

            ActionNode standBy = new ActionNode("待机", this.StandBy);
            this.AddChild(standBy);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            gt.FinishFrame = Int32.MaxValue;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
