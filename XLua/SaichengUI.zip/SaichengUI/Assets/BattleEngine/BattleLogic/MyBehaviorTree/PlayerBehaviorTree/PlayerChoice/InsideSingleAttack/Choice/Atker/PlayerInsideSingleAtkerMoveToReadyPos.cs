﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerInsideSingleAtkerMoveToReadyPos : PlayerBaseChoiceNode
    {
        public PlayerInsideSingleAtkerMoveToReadyPos(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            for (int i = 0; i < this.player.OwnerTeam.PlayerCount; i++)
            {
                Player player = this.player.OwnerTeam.Players[i];
                if (player.IsInTask( TaskType.PlayerMoveToSpaceOut))
                {
                    return true;
                }
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            Field atkField = this.gameInfo.AttackTeam.AttackField;
            Position askBallPos = this.gameInfo.AttackTeam.SingleAttacker.GetCurTask().RecordPos;
            Position p1 = Position.Empty;
            if (atkField.IsIn3Second(askBallPos))
            {
                double Radius = askBallPos.DistanceActualLength(atkField.GetBasketPos());
                //三秒区内，找个刚好出去的点
                while (true)
                {
                    Radius += 50;//每次加50，直到正好出去
                    p1 = Formula.ClosestIntersection(atkField.GetBasketPos(), Position.GetPix(Radius), askBallPos, atkField.GetBasketPos());
                    if (!atkField.IsIn3Second(p1))
                    {
                        break;
                    }
                }
            }
            else
            {
                //三秒区外，准备点即要球点
                p1 = askBallPos;
            }

            int speedLevel = SpeedManager.Instance.GetSpeedNormal(this.player, this.gameInfo.RandomSpeed());

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = p1;
            gt.RecordPos = this.player.GetCurTask().RecordPos;
            gt.SpeedLevel = speedLevel;
            gt.FinishFrame = gt.CalcTimeBySpeed( this.player.GetSpeedByLevel(speedLevel) );
            gt.NextTask = TaskType.PlayerInsideSingleAttack;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
