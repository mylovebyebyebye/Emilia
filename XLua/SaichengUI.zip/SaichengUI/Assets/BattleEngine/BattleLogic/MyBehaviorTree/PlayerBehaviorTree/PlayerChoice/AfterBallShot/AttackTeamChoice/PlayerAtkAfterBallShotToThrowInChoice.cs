﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    /// <summary>
    /// 去发球
    /// </summary>
    public class PlayerAtkAfterBallShotToThrowInChoice : PlayerBaseChoiceNode
    {
        public PlayerAtkAfterBallShotToThrowInChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.player.IsInTask( TaskType.PlayerAfterBallShotToThrowIn))
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            Position throwInPos = this.gameInfo.Ball.GetCurTask().TargetPos;

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveToThrowIn;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = throwInPos;
            if (this.player.GetCurTask().Param1 != (int)EFreeThrowType.Technical)
            {
                int random = this.gameInfo.RandomSpeed();
                int speedLevel = SpeedManager.Instance.GetSpeedNormal(this.player, random);
                gt.FinishFrame = gt.CalcTimeBySpeed(this.player.GetSpeedByLevel(speedLevel));
                gt.SpeedLevel = speedLevel;
            }
            else
            {
                //违例发球
                double speed = ParameterManager.Instance.GetValueD(ParameterEnum.TechnicalThrowInSpeed);
                int speedLevel = this.player.GetSpeedLevelByRealSpeed(speed);
                gt.FinishFrame = gt.CalcTimeBySpeed(speed);
                gt.SpeedLevel = speedLevel;
            }

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
