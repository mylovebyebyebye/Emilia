﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerToThrowInNode : PlayerBaseUpdateNode
    {
        public PlayerToThrowInNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerToThrowIn;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            //是否叫暂停无视

            //判断是否5秒违例
            if (this.player.GetCurTask().FinishFrame == 1)
            {
                PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.ThrowInVio, (int)this.player.OwnerTeam.TeamType);
                this.gameInfo.AddGameInfo(pc);


                this.gameInfo.ClearEvent();
                this.gameInfo.StartNewRound();
                Position posToThrowIn = this.player.Pos;
                this.gameInfo.ClearBallOwner();

                //todo 5秒违例
                GameEvent ge = new GameEvent(GameEventType.BallShotToThrowIn);
                ge.Pos = posToThrowIn;
                ge.Param2 = (int)EBallShotThrowInReason.ThrowInVio;
                this.gameInfo.AddGameEvent(ge);
            }

            return BehaviourTreeStatus.Success;
        }
    }
}
