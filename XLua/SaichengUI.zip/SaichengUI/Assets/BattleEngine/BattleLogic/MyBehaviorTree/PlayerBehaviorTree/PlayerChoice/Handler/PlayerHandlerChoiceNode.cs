﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerHandlerChoiceNode : PlayerChoiceBaseSelector
    {
        public PlayerHandlerChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            PlayerAttackBasketChoiceNode atkBasket = new PlayerAttackBasketChoiceNode("冲击篮筐", this.gameInfo);
            this.AddChild(atkBasket);

            PlayerInsideAttack insideAtk = new PlayerInsideAttack("内线进攻", this.gameInfo);
            this.AddChild(insideAtk);

            PlayerShotChoiceNode shotNode = new PlayerShotChoiceNode("投篮", this.gameInfo);
            this.AddChild(shotNode);

            PlayerHandlerOutOf3SChoice outOf3S = new PlayerHandlerOutOf3SChoice("持球人出3秒", this.gameInfo);
            this.AddChild(outOf3S);

            //PlayerDriveToAttackCourt driveToCourt = new PlayerDriveToAttackCourt("过半场", this.gameInfo);
            //this.AddChild(driveToCourt);

            ActionNode standby = new ActionNode("待机", this.StandBy);
            this.AddChild(standby);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            gt.FinishFrame = TimeFrameConverter.GetFrame(Player.MaxDefRelationTime);
            this.player.SetCurrentTask(gt);
            return BehaviourTreeStatus.Success;
        }
    }
}
