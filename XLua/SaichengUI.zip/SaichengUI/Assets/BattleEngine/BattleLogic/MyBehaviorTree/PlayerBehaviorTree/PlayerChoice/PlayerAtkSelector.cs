﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerAtkSelector : PlayerFastChoiceBaseSelector
    {
        private PlayerPassBallToPassSeqNode passball;
        private PlayerPassBallToGetPassBallSeqNode getPassBall;
        private PlayerSlumDunkAtkNode slumDunk;
        private PlayerFadeAwayAtkNode fadeAway;
        private PlayerDriveToAttackCourtNode driveToAtkField;
        private PlayerInsideAtkHanlderPreNode insideAttack;
        private PlayerOutsideSingleAttackNode outsideSingleAttack;
        private PlayerCoverSeqNode cover;
        private PlayerCoverPaoweiSeqNode coverPaowei;
        private PlayerInsideSingleAttackNode insideSingleAttack;
        private PlayerAtkInsideAtkDoubledNode insideAtkDoubled;
        private PlayerAtkBallShotThrowInNode ballShotThrowIn;
        private PlayerAtkAfterBallShotChoiceNode atkAfterBallShot;
        private PlayerAttackReboundNode attackRebound;
        private PlayerGetBallOnTheFloorNode getBallOnTheFloor;
        private PlayerAttackAfterBallHitHoopChoiceNode atkAfterBallHitHoop;
        private PlayerDefAfterBallHitHoopChoiceNode defAfterBallHitHoop;
        private PlayerToShotSeqNode toShotNode;

        public PlayerAtkSelector(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            passball = new PlayerPassBallToPassSeqNode("传球", this.gameInfo);
            passball.SetPlayer(this.player);
            this.AddChild(passball);

            getPassBall = new PlayerPassBallToGetPassBallSeqNode("传球的接球", this.gameInfo);
            getPassBall.SetPlayer(this.player);
            this.AddChild(getPassBall);

            slumDunk = new PlayerSlumDunkAtkNode("扣篮", this.gameInfo);
            slumDunk.SetPlayer(this.player);
            this.AddChild(slumDunk);

            fadeAway = new PlayerFadeAwayAtkNode("后仰", this.gameInfo);
            fadeAway.SetPlayer(this.player);
            this.AddChild(fadeAway);

            driveToAtkField = new PlayerDriveToAttackCourtNode("过半场", this.gameInfo);
            driveToAtkField.SetPlayer(this.player);
            this.AddChild(driveToAtkField);

            insideAttack = new PlayerInsideAtkHanlderPreNode("内线进攻准备阶段", this.gameInfo);
            insideAttack.SetPlayer(this.player);
            this.AddChild(insideAttack);

            outsideSingleAttack = new PlayerOutsideSingleAttackNode("外线单打", this.gameInfo);
            outsideSingleAttack.SetPlayer(this.player);
            this.AddChild(outsideSingleAttack);

            cover = new PlayerCoverSeqNode("掩护", this.gameInfo);
            cover.SetPlayer(this.player);
            this.AddChild(cover);

            coverPaowei = new PlayerCoverPaoweiSeqNode("掩护跑位", this.gameInfo);
            coverPaowei.SetPlayer(this.player);
            this.AddChild(coverPaowei);

            insideSingleAttack = new PlayerInsideSingleAttackNode("内线单打", this.gameInfo);
            insideSingleAttack.SetPlayer(this.player);
            this.AddChild(insideSingleAttack);

            insideAtkDoubled = new PlayerAtkInsideAtkDoubledNode("背打被包夹", this.gameInfo);
            insideAtkDoubled.SetPlayer(this.player);
            this.AddChild(insideAtkDoubled);

            ballShotThrowIn = new PlayerAtkBallShotThrowInNode("进球后界外球攻方选择", this.gameInfo);
            ballShotThrowIn.SetPlayer(this.player);
            this.AddChild(ballShotThrowIn);

            atkAfterBallShot = new PlayerAtkAfterBallShotChoiceNode("进球后的攻方选择", this.gameInfo);
            atkAfterBallShot.SetPlayer(this.player);
            this.AddChild(atkAfterBallShot);

            attackRebound = new PlayerAttackReboundNode("攻方篮板", this.gameInfo);
            attackRebound.SetPlayer(this.player);
            this.AddChild(attackRebound);

            getBallOnTheFloor = new PlayerGetBallOnTheFloorNode("抢地板球", this.gameInfo);
            getBallOnTheFloor.SetPlayer(this.player);
            this.AddChild(getBallOnTheFloor);


            atkAfterBallHitHoop = new PlayerAttackAfterBallHitHoopChoiceNode("攻方篮板砸框后事件", this.gameInfo);
            atkAfterBallHitHoop.SetPlayer(this.player);
            this.AddChild(atkAfterBallHitHoop);

            defAfterBallHitHoop = new PlayerDefAfterBallHitHoopChoiceNode("防守方篮板砸框后事件", this.gameInfo);
            defAfterBallHitHoop.SetPlayer(this.player);
            this.AddChild(defAfterBallHitHoop);

            toShotNode = new PlayerToShotSeqNode("待投篮", this.gameInfo);
            toShotNode.SetPlayer(this.player);
            this.AddChild(toShotNode);
        }

        public override BehaviourTreeStatus TickSwitchCase(TaskType taskType, TimeData time)
        {
            switch (taskType)
            {
                case TaskType.PlayerToPassBall:
                    {
                        return this.passball.Tick(time);
                    }
                case TaskType.PlayerToGetPassBallNormal:
                    {
                        return this.getPassBall.Tick(time);
                    }
                case TaskType.PlayerBeginSlamDunk:
                    {
                        return this.slumDunk.Tick(time);
                    }
                case TaskType.PlayerBeginFadeAway:
                    {
                        return this.fadeAway.Tick(time);
                    }
                case TaskType.PlayerDriveToAttackField:
                    {
                        return this.driveToAtkField.Tick(time);
                    }
                case TaskType.PlayerInsideAttackPrepare:
                    {
                        return this.insideAttack.Tick(time);
                    }
                case TaskType.PlayerOutsideSingleAttack:
                    {
                        return this.outsideSingleAttack.Tick(time);
                    }
                case TaskType.PlayerCover:
                    {
                        return this.cover.Tick(time);
                    }
                case TaskType.PlayerCoverPaowei:
                    {
                        return this.coverPaowei.Tick(time);
                    }
                case TaskType.PlayerInsideSingleAttack:
                    {
                        return this.insideSingleAttack.Tick(time);
                    }
                case TaskType.PlayerInsideAttackDoubled:
                    {
                        return this.insideAtkDoubled.Tick(time);
                    }
                case TaskType.PlayerReadyToBallShotThrowIn:
                case TaskType.PlayerToThrowIn:
                    {
                        return this.ballShotThrowIn.Tick(time);
                    }
                case TaskType.PlayerAfterBallShot:
                case TaskType.PlayerAfterBallShotToThrowIn:
                    {
                        return this.atkAfterBallShot.Tick(time);
                    }
                case TaskType.PlayerToGetRebound:
                    {
                        return this.attackRebound.Tick(time);
                    }
                case TaskType.PlayerToGetBallOnTheFloor:
                    {
                        return this.getBallOnTheFloor.Tick(time);
                    }
                case TaskType.PlayerAfterBallHitHoop:
                    {
                        if (this.player.OwnerTeam == this.gameInfo.LastAttackTeam)
                        {
                            return this.atkAfterBallHitHoop.Tick(time);
                        }
                        else
                        {
                            return this.defAfterBallHitHoop.Tick(time);
                        }
                    }
                case TaskType.PlayerToShot:
                    {
                        return this.toShotNode.Tick(time);
                    }
            }
            return BehaviourTreeStatus.Failure;
        }
    }
}
