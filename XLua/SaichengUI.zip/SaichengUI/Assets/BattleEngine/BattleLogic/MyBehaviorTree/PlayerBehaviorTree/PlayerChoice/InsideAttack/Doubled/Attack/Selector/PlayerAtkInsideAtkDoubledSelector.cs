﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerAtkInsideAtkDoubledSelector : PlayerChoiceBaseSelector
    {
        private TacStandby tac;
        private TacInsideAtkDoubled tacDoubled;
        public PlayerAtkInsideAtkDoubledSelector(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacStandby(this.gameInfo, this.name);
            this.tacDoubled = new TacInsideAtkDoubled(this.gameInfo, this.name);
        }

        protected override void CreateChildNode()
        {
            //取消该状态
            ActionNode cancel = new ActionNode("取消该状态", this.Cancel);
            this.AddChild(cancel);

            //各种事件
            ActionNode anyEvents = new ActionNode("各种事件", this.AnyEvents);
            this.AddChild(anyEvents);

            ActionNode standBy = new ActionNode("待机", this.StandBy);
            this.AddChild(standBy);
        }

        private BehaviourTreeStatus Cancel(TimeData time)
        {
            if (this.gameInfo.Ball.Owner != this.player)
            {
                this.player.ClearTask();
                return BehaviourTreeStatus.Success;
            }
            return BehaviourTreeStatus.Failure;
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            this.SpecialStandby();

            //待机之后继续这个
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerInsideAttackDoubled;
            gt.DelayStart = 0;
            gt.FinishFrame = 0;

            this.player.NextTask.Add(gt);

            return BehaviourTreeStatus.Success;
        }

        private BehaviourTreeStatus AnyEvents(TimeData time)
        {
            if (this.tacDoubled.IsAnyEventsHappened(this.player))
            {
                //防止再次触发单打
                this.SpecialStandby();
                return BehaviourTreeStatus.Success;
            }

            return BehaviourTreeStatus.Failure;
        }

        private void SpecialStandby()
        {
            double seconds = ParameterManager.Instance.GetValueD(ParameterEnum.InsideAtkDoubledStandbyTime) / 1000;
            //待机
            this.tac.DoMoveInSituBySeconds(this.player, seconds);
        }
    }
}
