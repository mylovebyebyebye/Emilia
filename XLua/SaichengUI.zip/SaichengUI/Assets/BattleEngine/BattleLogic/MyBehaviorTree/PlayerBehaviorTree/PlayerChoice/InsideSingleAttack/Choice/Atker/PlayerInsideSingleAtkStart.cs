﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    /// <summary>
    /// 开始背打
    /// </summary>
    public class PlayerInsideSingleAtkStart : PlayerBaseChoiceNode
    {
        private TacInsideAttack tac;
        public PlayerInsideSingleAtkStart(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacInsideAttack(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.gameInfo.Ball.Owner == this.player)
            {
                //距离篮筐距离得小于这个
                double disMax = ParameterManager.Instance.GetValue(ParameterEnum.InsideAtkAskBallMax);
                //double disToBasket = this.player.Pos.DistanceActualLength(this.player.OwnerTeam.AttackBasket);
                double disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, this.player.OwnerTeam.AttackField, this.player);
                if (Formula.IsDisInPermissibleError(disToBasket, disMax))
                {
                    return true;
                }
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.player.OwnerTeam.ClearSingleAttacker();

            this.tac.StartInsideAttack(this.player);

            return BehaviourTreeStatus.Success;
        }
    }
}
