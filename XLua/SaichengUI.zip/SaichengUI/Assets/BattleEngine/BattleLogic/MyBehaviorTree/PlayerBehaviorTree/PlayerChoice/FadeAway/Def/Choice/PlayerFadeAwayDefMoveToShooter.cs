﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerFadeAwayDefMoveToShooter : PlayerBaseChoiceNode
    {
        public PlayerFadeAwayDefMoveToShooter(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {

        }

        protected override bool IsMyCharge(TimeData time)
        {
            Player handler = this.gameInfo.Ball.Owner;
            //double disToAtker = handler.Pos.DistanceActualLength(this.player.Pos);
            double disToAtker = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, this.player, handler);
            double minDis = ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea) * 1.0f;
            if (!Formula.IsDisInPermissibleError(disToAtker, minDis))
            {
                if (!Formula.IsDisInPermissibleError(disToAtker, 0))
                {
                    return true;
                }
            }

            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = this.gameInfo.Ball.Owner.Pos;
            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(this.player, this.gameInfo.RandomSpeed());
            gt.FinishFrame = gt.CalcRealTargetByTimeSpeed(0.1f, this.player.GetSpeedInPixelByLevel(speedLevel));
            gt.SpeedLevel = speedLevel;


            gt.NextTask = TaskType.PlayerBeginFadeAway;
            gt.RecordPos = this.player.GetCurTask().RecordPos;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
