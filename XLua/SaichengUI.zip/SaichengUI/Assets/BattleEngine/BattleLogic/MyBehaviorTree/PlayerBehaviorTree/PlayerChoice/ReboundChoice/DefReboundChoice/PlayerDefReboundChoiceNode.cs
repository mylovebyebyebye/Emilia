﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerDefReboundChoiceNode : PlayerChoiceBaseSelector
    {
        TacStandby tac;
        public PlayerDefReboundChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacStandby(this.gameInfo, this.name);
        }

        protected override void CreateChildNode()
        {
            PlayerDefReboundFastBreakChoiceNode fastBreak = new PlayerDefReboundFastBreakChoiceNode("快下", this.gameInfo);
            this.AddChild(fastBreak);

            PlayerDefBoxOutChoiceNode boxOut = new PlayerDefBoxOutChoiceNode("卡位", this.gameInfo);
            this.AddChild(boxOut);

            PlayerReboundChoiceNode rebound = new PlayerReboundChoiceNode("冲抢篮板", this.gameInfo);
            this.AddChild(rebound);

            ActionNode standby = new ActionNode("待机", this.StandBy);
            this.AddChild(standby);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            this.tac.Do(this.player, this.tac.GetMaxStandbyFrame());
            return BehaviourTreeStatus.Success;
        }
    }
}
