﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerCoverSelector : PlayerChoiceBaseSelector
    {
        private TacStandby tac;
        private TacMoveOut3SArea tacOut3S;
        public PlayerCoverSelector(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacStandby(this.gameInfo, this.name);
            this.tacOut3S = new TacMoveOut3SArea(this.gameInfo, this.name);
        }

        protected override void CreateChildNode()
        {
            ActionNode finish = new ActionNode("结束", this.Finish);
            this.AddChild(finish);

            PlayerCoverMove move = new PlayerCoverMove("移动去掩护(挡拆)", this.gameInfo);
            this.AddChild(move);

            ActionNode outOf3S = new ActionNode("出三秒", this.OutOf3S);
            this.AddChild(outOf3S);

            ActionNode standby = new ActionNode("待机", this.StandBy);
            this.AddChild(standby);
        }

        private BehaviourTreeStatus OutOf3S(TimeData time)
        {
            if (this.player.IsNeedOut3S())
            {
                this.tacOut3S.Do(this.player);
                this.player.GetCurTask().NextTask = TaskType.PlayerCover;
                return BehaviourTreeStatus.Success;
            }
            return BehaviourTreeStatus.Failure;
        }

        private BehaviourTreeStatus Finish(TimeData time)
        {
            Player handler = this.gameInfo.Ball.Owner;
            if (handler == null)
            {
                this.player.ClearTask();
                return BehaviourTreeStatus.Success;
            }
            Player defPlayer = handler.GetMyPosDefPlayer();
            if (defPlayer == null)
            {
                this.player.ClearTask();
                return BehaviourTreeStatus.Success;
            }
            return BehaviourTreeStatus.Failure;
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            double seconds = ParameterManager.Instance.GetValueD(ParameterEnum.PickRollMoveTime) / 1000;
            this.tac.Do(this.player, TimeFrameConverter.GetFrame(seconds));
            this.player.GetCurTask().NextTask = TaskType.PlayerCover;

            return BehaviourTreeStatus.Success;
        }
    }
}
