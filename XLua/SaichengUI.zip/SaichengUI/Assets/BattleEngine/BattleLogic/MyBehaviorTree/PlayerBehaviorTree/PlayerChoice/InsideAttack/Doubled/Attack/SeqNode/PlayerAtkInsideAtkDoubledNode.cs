﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 背打包夹
    /// 进攻人
    /// </summary>
    public class PlayerAtkInsideAtkDoubledNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerAtkInsideAtkDoubledNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.player.IsInTask( TaskType.PlayerInsideAttackDoubled))
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerAtkInsideAtkDoubledSelector("背打被包夹", this.gameInfo);
        }
    }
}
