﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerMoveToGetThrowInNode : PlayerBaseUpdateNode
    {
        public PlayerMoveToGetThrowInNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerMoveToGetThrowIn;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            TaskMoveTo.Do(this.player);
            //判断是否在接球安全区域内
            //接球安全区域内没有防守球员
            Position throwInPos = this.gameInfo.Ball.GetCurTask().TargetPos;
            double safeGetBallRadius = Formula.GetSafeGetBallRadius(this.player, throwInPos);
            bool isSafe = true;
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player def = this.gameInfo.DefTeam.Players[i];
                double dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, this.player, def);
                //double dis = def.Pos.DistanceActualLength(this.player.Pos);
                if (dis < safeGetBallRadius)
                {
                    isSafe = false;
                    break;
                }
            }
            if (isSafe || this.player.GetCurTask().FinishFrame == 1)
            {
                //如果在安全区域内就转化为球人
                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.PlayerReadyToBallShotThrowIn;
                gt.FinishFrame = 1;
                gt.DelayStart = 1;
                player.SetCurrentTask(gt);
            }

            return BehaviourTreeStatus.Success;
        }
    }
}
