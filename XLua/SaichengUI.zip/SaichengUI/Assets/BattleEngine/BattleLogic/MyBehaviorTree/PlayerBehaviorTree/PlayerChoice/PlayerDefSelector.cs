﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDefSelector : PlayerFastChoiceBaseSelector
    {
        private PlayerSlumDunkDefNode defDunk;
        private PlayerFadeAwayDefNode defFadeAway;
        private PlayerInsideAtkDefPreNode defInsideAtkPre;
        private PlayerDefInsideAtkHelpDefNode defInsideAtkHelpDef;
        private PlayerDefInsideAtkDoubledNode defInsideAtkDoubled;
        private PlayerDefOutofBoundThrowInNode defOutOfBoundThrowIn;
        private PlayerDefAfterBallShotNode defAfterBallShot;
        private PlayerDefReboundNode defRebound;
        private PlayerGetBallOnTheFloorNode getBallOnTheFloor;
        private PlayerAttackAfterBallHitHoopChoiceNode atkAfterBallHitHoop;
        private PlayerDefAfterBallHitHoopChoiceNode defAfterBallHitHoop;

        public PlayerDefSelector(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            defDunk = new PlayerSlumDunkDefNode("防扣篮", this.gameInfo);
            defDunk.SetPlayer(this.player);
            this.AddChild(defDunk);

            defFadeAway = new PlayerFadeAwayDefNode("防后仰", this.gameInfo);
            defFadeAway.SetPlayer(this.player);
            this.AddChild(defFadeAway);

            defInsideAtkPre = new PlayerInsideAtkDefPreNode("内线进攻准备阶段防守", this.gameInfo);
            defInsideAtkPre.SetPlayer(this.player);
            this.AddChild(defInsideAtkPre);

            defInsideAtkHelpDef = new PlayerDefInsideAtkHelpDefNode("背打协防", this.gameInfo);
            defInsideAtkHelpDef.SetPlayer(this.player);
            this.AddChild(defInsideAtkHelpDef);

            defInsideAtkDoubled = new PlayerDefInsideAtkDoubledNode("背打包夹", this.gameInfo);
            defInsideAtkDoubled.SetPlayer(this.player);
            this.AddChild(defInsideAtkDoubled);

            defOutOfBoundThrowIn = new PlayerDefOutofBoundThrowInNode("边线界外球防守", this.gameInfo);
            defOutOfBoundThrowIn.SetPlayer(this.player);
            this.AddChild(defOutOfBoundThrowIn);

            defAfterBallShot = new PlayerDefAfterBallShotNode("进球后的防守方选择", this.gameInfo);
            defAfterBallShot.SetPlayer(this.player);
            this.AddChild(defAfterBallShot);

            defRebound = new PlayerDefReboundNode("防守方篮板", this.gameInfo);
            defRebound.SetPlayer(this.player);
            this.AddChild(defRebound);

            getBallOnTheFloor = new PlayerGetBallOnTheFloorNode("抢地板球", this.gameInfo);
            getBallOnTheFloor.SetPlayer(this.player);
            this.AddChild(getBallOnTheFloor);

            atkAfterBallHitHoop = new PlayerAttackAfterBallHitHoopChoiceNode("攻方篮板砸框后事件", this.gameInfo);
            atkAfterBallHitHoop.SetPlayer(this.player);
            this.AddChild(atkAfterBallHitHoop);

            defAfterBallHitHoop = new PlayerDefAfterBallHitHoopChoiceNode("防守方篮板砸框后事件", this.gameInfo);
            defAfterBallHitHoop.SetPlayer(this.player);
            this.AddChild(defAfterBallHitHoop);
        }

        public override BehaviourTreeStatus TickSwitchCase(TaskType curTaskType, TimeData time)
        {
            switch (curTaskType)
            {
                case TaskType.PlayerBeginSlamDunk:
                    {
                        return this.defDunk.Tick(time);
                    }
                case TaskType.PlayerBeginFadeAway:
                    {
                        return this.defFadeAway.Tick(time);
                    }
                case TaskType.PlayerInsideAttackPrepare:
                    {
                        return this.defInsideAtkPre.Tick(time);
                    }
                case TaskType.PlayerInsideAttackHelpDefence:
                    {
                        return this.defInsideAtkHelpDef.Tick(time);
                    }
                case TaskType.PlayerInsideAttackDoubled:
                    {
                        return this.defInsideAtkDoubled.Tick(time);
                    }
                case TaskType.PlayerToThrowIn:
                    {
                        return this.defOutOfBoundThrowIn.Tick(time);
                    }
                case TaskType.PlayerAfterBallShot:
                    {
                        return this.defAfterBallShot.Tick(time);
                    }
                case TaskType.PlayerToGetRebound:
                    {
                        return this.defRebound.Tick(time);
                    }
                case TaskType.PlayerToGetBallOnTheFloor:
                    {
                        return this.getBallOnTheFloor.Tick(time);
                    }
                case TaskType.PlayerAfterBallHitHoop:
                    {
                        if (this.player.OwnerTeam == this.gameInfo.LastAttackTeam)
                        {
                            return this.atkAfterBallHitHoop.Tick(time);
                        }
                        else
                        {
                            return this.defAfterBallHitHoop.Tick(time);
                        }
                    }
            }
            return BehaviourTreeStatus.Failure;
        }
    }
}
