﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDefChoiceNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerDefChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.player.OwnerTeam == this.gameInfo.DefTeam)
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerDefSelector("防守选择",this.gameInfo);
        }
    }
}
