﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerGetBallOnTheFloorFinish : PlayerBaseChoiceNode
    {
        public PlayerGetBallOnTheFloorFinish(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {

        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.gameInfo.Ball.Owner != null)
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.player.ClearTask();
            return BehaviourTreeStatus.Success;
        }
    }
}
