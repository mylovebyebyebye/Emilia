﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerToGetBallNode : PlayerBaseUpdateNode
    {
        public PlayerToGetBallNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerToGetPassBall;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            //移动到一个点接球，如果在那个点，就等着
            if (this.player.Pos != this.player.GetCurTask().TargetPos)
            {
                TaskMoveTo.Do(this.player);
            }
            if (this.player.GetCurTask().FinishFrame == 1)
            {
                //要球结束
                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.PlayerStandby;
                gt.FinishFrame = 1;
                gt.NextTask = this.player.GetCurTask().NextTask;
                gt.RecordPos = this.player.GetCurTask().RecordPos;

                this.player.SetCurrentTask(gt);

            }
            return BehaviourTreeStatus.Success;
        }
    }
}
