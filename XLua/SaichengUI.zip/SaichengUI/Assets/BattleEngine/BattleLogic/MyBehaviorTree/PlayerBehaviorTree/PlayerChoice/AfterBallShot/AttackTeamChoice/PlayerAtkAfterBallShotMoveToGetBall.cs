﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    /// <summary>
    /// 移动接球
    /// </summary>
    public class PlayerAtkAfterBallShotMoveToGetBall : PlayerBaseChoiceNode
    {
        TacThrowIn tac;
        public PlayerAtkAfterBallShotMoveToGetBall(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacThrowIn(this.gameInfo,this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            //是攻方PG
            if (this.player.Role != (int)PlayerRole.PG)
            {
                return false;
            }
            //在接球区域内
            Position throwInPos = this.gameInfo.Ball.GetCurTask().TargetPos;
            if (throwInPos == Position.Empty)
            {
                if (this.gameInfo.Ball.GetCurTask().TaskType == TaskType.BallOnThePlayer)
                {
                    throwInPos = this.gameInfo.Ball.Owner.Pos;
                }
                else
                {
                    return false;
                }
            }
            double Radius = ParameterManager.Instance.GetValue(ParameterEnum.DisToGetThrowIn);
            double disToThrowIn = throwInPos.DistanceActualLength(this.player.Pos);
            if (disToThrowIn <= Radius)
            {
                return false;
            }

            //接球安全区域内没有防守球员
            double safeGetBallRadius = Formula.GetSafeGetBallRadius(this.player, throwInPos);
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player def = this.gameInfo.DefTeam.Players[i];
                double dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, def, this.player);
                //double dis = def.Pos.DistanceActualLength(this.player.Pos);
                if (Formula.IsDisInPermissibleError(dis, safeGetBallRadius))
                {
                    return true;
                }
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            //移动到与发球点距离 等于 param 173的位置
            Position throwInPos = this.gameInfo.Ball.GetCurTask().TargetPos;
            if (throwInPos == Position.Empty)
            {
                throwInPos = this.gameInfo.Ball.Pos;
            }
            Position p1 = this.tac.GetAskBallPos(this.player, throwInPos);

            int speedLevel = SpeedManager.Instance.GetSpeedNormal(this.player, this.gameInfo.RandomSpeed());

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveToGetThrowIn;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = p1;
            gt.SpeedLevel = speedLevel;
            gt.FinishFrame = gt.CalcTimeBySpeed( this.player.GetSpeedByLevel(speedLevel) );

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
