﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerAtkOutOfBoundChoice : PlayerChoiceBaseSelector
    {
        public PlayerAtkOutOfBoundChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            PlayerAtkBallShotThrowInWait moveToThrowIn = new PlayerAtkBallShotThrowInWait("等待要球", this.gameInfo);
            this.AddChild(moveToThrowIn);

            PlayerAtkBallShotAskBallChoice askBall = new PlayerAtkBallShotAskBallChoice("要球", this.gameInfo);
            this.AddChild(askBall);

            PlayerAtkAfterBallShotMoveToGetBall moveToGetBall = new PlayerAtkAfterBallShotMoveToGetBall("移动要球", this.gameInfo);
            this.AddChild(moveToGetBall);

            PlayerMoveToPresetChoiceNode moveToPreset = new PlayerMoveToPresetChoiceNode("落位进攻", this.gameInfo);
            this.AddChild(moveToPreset);

            ActionNode standBy = new ActionNode("待机", this.StandBy);
            this.AddChild(standBy);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            gt.FinishFrame = TimeFrameConverter.GetFrame(Player.MaxDefRelationTime);

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
