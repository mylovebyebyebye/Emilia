﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    /// <summary>
    /// 拉开
    /// </summary>
    public class PlayerOutsideSingleAtkNoBallSpaceOut : PlayerBaseChoiceNode
    {
        private double maxRadius = 400.0f;
        private Position targetPos = Position.Empty;
        private double minMove = 20.0f;
        private TacNewShot tacShot;

        public PlayerOutsideSingleAtkNoBallSpaceOut(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacShot = new TacNewShot(this.gameInfo, this.name);
        }


        private Position GetSpaceOutTarget()
        {
            Position basketPos = this.player.OwnerTeam.AttackBasket;
            Field atkField = this.player.OwnerTeam.AttackField;

            Position p1 = Position.Empty;
            //半径
            double radius = this.GetSpaceOutRadius() * Position.ActualLengthPerPoint;
            //计算拉开角度
            double angle = this.GetSpaceOutAngle();

            p1 = basketPos.GetPosByAngleRadius(angle, (int)(radius));
            if (!atkField.IsOnMyEffectiveArea(p1))//在界外
            {
                //出底线
                if (atkField.IsOutOfBottomLine(p1))
                {
                    p1 = basketPos.GetPosByAngleRadius((int)(angle) + 180, (int)radius);
                }
                else
                {
                    //出边线
                    if (p1.Y < atkField.TopLeft.Y)
                    {
                        p1 = new Position(p1.X, atkField.TopLeft.Y + 2);
                    }
                    else
                    {
                        p1 = new Position(p1.X, atkField.BtmRight.Y - 2);
                    }
                }
            }
            return p1;
        }

        /// <summary>
        /// 拉开半径
        /// 单位像素
        /// </summary>
        /// <returns></returns>
        private double GetSpaceOutRadius()
        {
            Field atkField = this.player.OwnerTeam.AttackField;
            Player singleAtker = this.gameInfo.AttackTeam.SingleAttacker;
            int cutOffPoint = ParameterManager.Instance.GetValue(ParameterEnum.SpaceOutCutOffPoint);

            double radius = 0f;
            //计算拉开半径
            if (this.player.GetAttribute(PlayerAttribute.JumpShot3) > cutOffPoint)
            {
                //拉到三分线外
                radius = atkField.TopOfTheCircle3PDistance;
            }
            else
            {
                ZDB_Row_Data rowData = this.tacShot.GetShotPercentage((int)EExpectionType.CrossOver);
                radius = this.tacShot.GetDefPlayerRange(singleAtker, rowData);
                double max = Position.GetPix(this.maxRadius);
                if (radius > max)
                {
                    radius = max;
                }

                radius += Position.GetPix(ParameterManager.Instance.GetValue(ParameterEnum.DefRangeRadius));
            }

            return radius;
        }

        private double GetSpaceOutAngle()
        {
            Field atkField = this.player.OwnerTeam.AttackField;
            Player singleAtker = this.gameInfo.AttackTeam.SingleAttacker;
            double angle = 0;

            int spaceOutAngle = ParameterManager.Instance.GetValue(ParameterEnum.SpaceOutAngle);

            //单打人与X轴夹角
            Vector2D vSingleAtker = new Vector2D(atkField.GetBasketPos(), singleAtker.Pos);
            double angleSingleAtker = vSingleAtker.GetSlopeAngle();

            //自己与X轴夹角
            Vector2D vPlayer = new Vector2D(atkField.GetBasketPos(), this.player.Pos);
            double anglePlayer = vPlayer.GetSlopeAngle();

            double minAngle = this.GetAngle(angleSingleAtker - spaceOutAngle);
            double maxAngle = this.GetAngle(angleSingleAtker + spaceOutAngle);

            if (anglePlayer > minAngle && anglePlayer <= angleSingleAtker)
            {
                angle = this.GetAngle(anglePlayer - spaceOutAngle);
            }
            else if (anglePlayer >= angleSingleAtker && anglePlayer < maxAngle)
            {
                angle = this.GetAngle(anglePlayer + spaceOutAngle);
            }
            else
            {
                angle = anglePlayer;
            }

            return angle;
        }


        private double GetAngle(double angle)
        {
            if (angle < 0)
            {
                angle += 360;
            }
            else if (angle > 360)
            {
                angle -= 360;
            }
            return angle;
        }



        protected override bool IsMyCharge(TimeData time)
        {
            int random = this.gameInfo.RandomNext(1, 100);
            if (this.player.GetAttribute(PlayerAttribute.SpaceOut) >= random)
            {
                this.targetPos = this.GetSpaceOutTarget();
                if (this.targetPos != Position.Empty &&
                    this.targetPos.DistanceActualLength(this.player.Pos) > this.minMove)
                {
                    return true;
                }
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            int speedLevel = SpeedManager.Instance.GetSpeedNormal(this.player, this.gameInfo.RandomSpeed());

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveToSpaceOut;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = this.targetPos;
            gt.SpeedLevel = speedLevel;
            gt.FinishFrame = gt.CalcTimeBySpeed( this.player.GetSpeedByLevel(speedLevel) );
            gt.NextTask = TaskType.PlayerOutsideSingleAttack;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
