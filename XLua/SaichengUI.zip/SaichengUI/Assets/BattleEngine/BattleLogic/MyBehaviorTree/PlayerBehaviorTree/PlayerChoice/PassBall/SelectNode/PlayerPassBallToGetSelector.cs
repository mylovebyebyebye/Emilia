﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerPassBallToGetSelector : PlayerChoiceBaseSelector
    {
        private double moveTime = 0.1f;
        TacPassBall tacPassBall;
        TacStandby tacStandby;
        public PlayerPassBallToGetSelector(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacPassBall = new TacPassBall(this.gameInfo, this.name);
            this.tacStandby = new TacStandby(this.gameInfo, this.name);
        }

        protected override void CreateChildNode()
        {
            ActionNode standbyAlways = new ActionNode("一直原地移动", this.StandbyAlways);
            this.AddChild(standbyAlways);

            ActionNode move = new ActionNode("向接球点移动", this.Move);
            this.AddChild(move);

            ActionNode getBall = new ActionNode("拿到球", this.GetBall);
            this.AddChild(getBall);

            ActionNode standby = new ActionNode("原地移动", this.Standby);
            this.AddChild(standby);
        }

        /// <summary>
        /// 拿到球判断
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        private BehaviourTreeStatus GetBall(TimeData time)
        {
            Player passBallPlayer = this.player.GetCurTask().TargetPlayer;
            if (this.tacPassBall.IsGetBall(this.player, passBallPlayer))
            {
                this.tacPassBall.GetPassBall(this.player, passBallPlayer);

                return BehaviourTreeStatus.Success;
            }

            return BehaviourTreeStatus.Failure;
        }

        /// <summary>
        /// 向接球点移动
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        private BehaviourTreeStatus Move(TimeData time)
        {
            Position target = this.player.GetCurTask().RecordPos;
            Player passBallPlayer = this.player.GetCurTask().TargetPlayer;

            double disMin = ParameterManager.Instance.GetValue(ParameterEnum.PassBallParam10);
            double dis = this.player.Pos.DistanceActualLength(target);
            if (dis < disMin)
            {
                //到达一定距离不用动了
                return BehaviourTreeStatus.Failure;
            }

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = target;

            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(this.player, this.gameInfo.RandomSpeed());
            gt.SpeedLevel = speedLevel;
            double speedInPixel = this.player.GetSpeedInPixelByLevel(speedLevel);
            gt.FinishFrame = gt.CalcRealTargetBySpeedMaxSeconds(ref speedInPixel, this.moveTime);
            gt.RecordPos = target;
            gt.TargetPlayer = passBallPlayer;
            gt.NextTask = TaskType.PlayerToGetPassBallNormal;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;

        }

        /// <summary>
        /// 传球出界就不去捡了
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        private BehaviourTreeStatus StandbyAlways(TimeData time)
        {
            Position target = this.player.GetCurTask().RecordPos;
            if (!this.gameInfo.IsInBounds(target))
            {
                this.tacStandby.DoMoveInSituByFrame(this.player, int.MaxValue);
                return BehaviourTreeStatus.Success;
            }
            return BehaviourTreeStatus.Failure;
        }

        private BehaviourTreeStatus Standby(TimeData time)
        {
            Position target = this.player.GetCurTask().RecordPos;
            Player passBallPlayer = this.player.GetCurTask().TargetPlayer;

            this.tacStandby.DoMoveInSituBySeconds(this.player, this.moveTime);
            GameTask gt = this.player.GetCurTask();
            gt.RecordPos = target;
            gt.TargetPlayer = passBallPlayer;
            gt.NextTask = TaskType.PlayerToGetPassBallNormal;

            return BehaviourTreeStatus.Success;
        }
    }
}
