﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerMoveToDefFastBreak : PlayerBaseUpdateNode
    {
        private int lastCalcTime = 0;
        private int interval = 0;
        public PlayerMoveToDefFastBreak(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.interval = TimeFrameConverter.GetFrame(0.1f);
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerMoveToDefFastBreak;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            TaskMoveTo.Do(this.player);
            if (this.gameInfo.IsFramePassed(this.lastCalcTime, this.interval))
            {
                if (this.gameInfo.Ball.Owner != null)
                {
                    this.player.GetCurTask().FinishFrame = 0;
                }
            }
            return BehaviourTreeStatus.Success;
        }
    }
}
