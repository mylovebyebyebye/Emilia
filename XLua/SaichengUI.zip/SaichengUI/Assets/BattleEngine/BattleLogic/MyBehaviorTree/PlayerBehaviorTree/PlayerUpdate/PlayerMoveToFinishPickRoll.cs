﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerMoveToFinishPickRoll : PlayerBaseUpdateNode
    {
        private TacFillIn tacFillIn;
        public PlayerMoveToFinishPickRoll(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacFillIn = new TacFillIn(this.gameInfo, this.name);
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerMoveToFinishPickRoll;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            TaskMoveTo.Do(this.player);
            if (this.player.GetCurTask().FinishFrame == 1)
            {
                //到达目标点，呼唤对方来补防。。。
                this.tacFillIn.Do(EFillInType.PickRoll, this.player);
            }
            return BehaviourTreeStatus.Success;
        }
    }
}
