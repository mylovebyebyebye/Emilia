﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerOutsideSingleAttackChoice : PlayerChoiceBaseSelector
    {
        public PlayerOutsideSingleAttackChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            PlayerOutsideSingleAtkNoBallNode noBall = new PlayerOutsideSingleAtkNoBallNode("非单打人", this.gameInfo);
            this.AddChild(noBall);

            PlayerOutsideSingleAtkerNode atker = new PlayerOutsideSingleAtkerNode("单打人", this.gameInfo);
            this.AddChild(atker);

            ActionNode standBy = new ActionNode("待机", this.StandBy);
            this.AddChild(standBy);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            gt.FinishFrame = TimeFrameConverter.GetFrame(Player.MaxDefRelationTime);
           // gt.NextTask = TaskType.PlayerOutsideSingleAttack;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
