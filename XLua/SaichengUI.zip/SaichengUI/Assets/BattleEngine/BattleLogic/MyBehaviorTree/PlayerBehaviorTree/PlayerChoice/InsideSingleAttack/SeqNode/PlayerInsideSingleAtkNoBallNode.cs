﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerInsideSingleAtkNoBallNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerInsideSingleAtkNoBallNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            // 内线单打，要球要位选择
            Player handler = this.gameInfo.Ball.Owner;
            Player singleAtker = this.gameInfo.AttackTeam.SingleAttacker;
            if ( this.player.IsSamePlayer(handler))
            {
                return false;
            }
            if ( !this.player.IsSamePlayer(singleAtker ))
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerInsideSingleAtkNoBallChoice("内线单打无球人", this.gameInfo);
        }
    }
}
