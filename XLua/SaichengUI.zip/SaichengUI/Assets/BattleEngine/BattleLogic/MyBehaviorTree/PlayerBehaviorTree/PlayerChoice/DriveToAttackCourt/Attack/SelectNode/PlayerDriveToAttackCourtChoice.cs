﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class PlayerDriveToAttackCourtChoice : PlayerChoiceBaseSelector
    {
        public PlayerDriveToAttackCourtChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            PlayerDriveToAtkCourtNoBallAtkerNode noBallAtker = new PlayerDriveToAtkCourtNoBallAtkerNode("无球人", this.gameInfo);
            this.AddChild(noBallAtker);

            PlayerDriveToAtkCourtHanlderNode handler = new PlayerDriveToAtkCourtHanlderNode("持球人", this.gameInfo);
            this.AddChild(handler);
        }
    }
}
