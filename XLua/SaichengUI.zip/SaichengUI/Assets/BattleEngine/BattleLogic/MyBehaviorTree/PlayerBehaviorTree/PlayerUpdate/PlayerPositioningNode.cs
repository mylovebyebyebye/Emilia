﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerPositioningNode : PlayerBaseUpdateNode
    {
        private TacPaoWei tac;
        private TacAskBall tacAskBall;
        public PlayerPositioningNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacPaoWei(this.gameInfo, this.name);
            this.tacAskBall = new TacAskBall(this.gameInfo, this.name);
        }
        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerPositioning;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            TaskMoveTo.Do(this.player);
            if (this.player.GetCurTask().FinishFrame == 1)
            {
                if (this.IsNeedAskBall())
                {
                    this.tacAskBall.Do(this.player);
                }
                else if (this.tac.IsReachTarget(this.player))
                {
                    if (!this.tac.IsAllClear(this.player))
                    {
                        this.tac.DoNextSegment(this.player);
                    }
                }
                else
                {
                    this.tac.DoThisSegmentNext(this.player);
                }
            }
            return BehaviourTreeStatus.Success;
        }



        private bool IsNeedAskBall()
        {
            this.player.ForceCalcScoringExpect(this.gameInfo);

            Player handler = this.gameInfo.Ball.Owner;
            if (handler == null || handler.IsSamePlayer(this.player))
            {
                return false;
            }
            bool isAskBall = this.tacAskBall.IsAskBall(this.player, handler);
            return isAskBall;
        }
    }
}
