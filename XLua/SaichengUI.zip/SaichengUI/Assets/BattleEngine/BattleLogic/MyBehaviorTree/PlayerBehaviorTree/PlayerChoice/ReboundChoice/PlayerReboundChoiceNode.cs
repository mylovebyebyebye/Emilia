﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    /// <summary>
    /// 抢篮板
    /// </summary>
    public class PlayerReboundChoiceNode : PlayerBaseChoiceNode
    {
        private TacRebound tac;

        public PlayerReboundChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacRebound(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            //篮板过低不冲板
            if (this.player.GetAttribute(PlayerAttribute.Rebounding) < ParameterManager.Instance.GetValue(ParameterEnum.MinRebound))
            {
                return false;
            }
            //在后场不抢
            if (!this.gameInfo.AttackTeam.AttackField.IsOnMyEffectiveArea(this.player.Pos))
            {
                return false;
            }
            //double distance = player.Pos.DistanceActualLength(this.gameInfo.AttackTeam.AttackBasket);
            double distance = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, this.gameInfo.AttackTeam.AttackField, player);
            double tacAdd = 0;//战术加成，暂定为0
            double rebCOE = ParameterManager.Instance.GetValue(ParameterEnum.ReboundCOE) * 1.0f;
            int probability = (int)Math.Floor((player.GetAttribute(PlayerAttribute.Rebounding) + tacAdd) / distance * rebCOE * 10000);

            if (probability < this.gameInfo.RandomNext())
            {
                return false;
            }

            return true;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.player.SetCurrentTask(this.tac.GetReboundTask(this.player));

            return BehaviourTreeStatus.Success;
        }
    }
}
