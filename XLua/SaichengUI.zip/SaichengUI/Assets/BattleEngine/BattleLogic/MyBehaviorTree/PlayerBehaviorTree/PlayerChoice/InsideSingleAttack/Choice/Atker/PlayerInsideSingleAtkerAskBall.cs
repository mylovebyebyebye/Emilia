﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 要球
    /// </summary>
    public class PlayerInsideSingleAtkerAskBall : PlayerBaseChoiceNode
    {
        private TacAskBall tacAskBall;
        public PlayerInsideSingleAtkerAskBall(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacAskBall = new TacAskBall(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.gameInfo.Ball.Owner == this.player)
            {
                return false;
            }
            //没人在拉开，且在要球点
            for (int i = 0; i < this.player.OwnerTeam.PlayerCount; i++)
            {
                Player player = this.player.OwnerTeam.Players[i];
                if (player.IsInTask( TaskType.PlayerMoveToSpaceOut))
                {
                    return false;
                }
            }
            if (this.player.Pos == this.player.GetCurTask().RecordPos)
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            //一旦触发要球，所有人清掉，内线单打战术buf
            Team attackTeam = gameInfo.Ball.OwnTeam;
            for (int i = 0; i < attackTeam.PlayerCount; i++)
            {
                Player player = attackTeam.Players[i];
                player.ClearTask();
            }

            this.tacAskBall.Do(this.player);
            this.player.GetCurTask().NextTask = TaskType.PlayerInsideSingleAttack;

            return BehaviourTreeStatus.Success;
        }
    }
}
