﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerJumpDefShot : PlayerBaseUpdateNode
    {
        private TacStandby tacStandby;

        public PlayerJumpDefShot(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacStandby = new TacStandby(this.gameInfo, this.name);
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerJumpDefShot;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            GameTask gt = this.player.GetCurTask();

            int freezeJ = gt.Param1;
            int defenceTimeJ = gt.Param2;
            int staminaCost = gt.Param3;

            //强制待机freezeJ
            int freezeFrame = TimeFrameConverter.GetFrame(freezeJ);
            this.tacStandby.DoForceStandby(this.player, freezeJ);
            this.player.DefShotCD = this.gameInfo.Frame + freezeFrame;

            //防守效果增强
            int addDefenceFrame = TimeFrameConverter.GetFrame(defenceTimeJ);
            this.player.DefShotPercentFrame = this.gameInfo.Frame + addDefenceFrame;

            //扣体力
            this.player.CurStamina += staminaCost;

            return BehaviourTreeStatus.Success;
        }
    }
}
