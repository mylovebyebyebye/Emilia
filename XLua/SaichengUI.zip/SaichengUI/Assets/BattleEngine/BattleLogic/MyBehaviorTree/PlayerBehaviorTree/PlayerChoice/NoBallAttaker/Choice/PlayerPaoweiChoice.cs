﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerPaoweiChoice : PlayerBaseChoiceNode
    {
        private TacPaoWei tac;
        public PlayerPaoweiChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacPaoWei(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if(this.tac.IsNeedPaoWei(this.player))
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.tac.Do(this.player);
            return BehaviourTreeStatus.Success;
        }
    }
}
