﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDriveToTheBasketNode : PlayerBaseUpdateNode
    {
        public PlayerDriveToTheBasketNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerDriveToTheBasket;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            TaskMoveTo.Do(this.player);
            if (this.player.GetCurTask().FinishFrame == 1)
            {
                //突破修改
                GameEvent gameEvent = new GameEvent(GameEventType.CrossOver);
                gameEvent.Param4 = this.player;
                gameEvent.Param5 = this.player.GetMyPosDefPlayer();
                gameInfo.AddGameEvent(gameEvent);
            }
            return BehaviourTreeStatus.Success;
        }
    }
}
