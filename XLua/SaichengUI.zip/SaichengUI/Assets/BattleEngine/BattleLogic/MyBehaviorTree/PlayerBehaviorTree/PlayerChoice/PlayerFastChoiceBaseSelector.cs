﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public abstract class PlayerFastChoiceBaseSelector : PlayerChoiceBaseSelector
    {
        public abstract BehaviourTreeStatus TickSwitchCase(TaskType taskType, TimeData time);

        protected PlayerFastChoiceBaseSelector()
        {
            throw new Exception("this constructor is illegal");
        }

        public PlayerFastChoiceBaseSelector(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        public override BehaviourTreeStatus Tick(TimeData time)
        {
            GameTask gt = this.player.GetCurTask();
            if (gt == null)
            {
                return BehaviourTreeStatus.Failure;
            }
            return this.TickSwitchCase(gt.TaskType, time);
        }
    }
}
