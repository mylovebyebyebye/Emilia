﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class PlayerDefShotChoiceNode : PlayerDefHanlderChoiceBaseNode
    {
        public PlayerDefShotChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            ConditionNode shot = new ConditionNode("是否扑投篮", this.IsHandlerShot);
            this.AddChild(shot);

            ActionNode defShot = new ActionNode("扑投篮", this.DefShot);
            this.AddChild(defShot);
        }

        private bool IsHandlerShot(TimeData time)
        {
            if (this.gameInfo.Ball.Owner.IsInTask(TaskType.PlayerShot))
            {
                //持球人投篮且在我的防守区域内
                Player handler = this.gameInfo.Ball.Owner;
                double dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, this.player, handler);
                //double dis = this.gameInfo.Ball.Owner.Pos.DistanceActualLength(this.player.Pos);
                double defDis = ParameterManager.Instance.GetValue(ParameterEnum.ShotDefDisParam) * 1.0f;
                if (dis < defDis)
                {
                    return true;
                }
            }
            return false;
        }

        private BehaviourTreeStatus DefShot(TimeData time)
        {
            Player ballHandler = this.gameInfo.Ball.Owner;

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = this.player.Pos;
            gt.DelayStart = this.GetDelayFrame();

            double Radius = ParameterManager.Instance.GetValue(ParameterEnum.DefMinDis) * 1.0f / Position.ActualLengthPerPoint;
            //double distance = this.gameInfo.AttackTeam.AttackBasket.Distance(ballHandler.Pos);
            double distance = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, this.gameInfo.AttackTeam.AttackField, ballHandler);
            //离他远才需要扑
            if (distance > Radius)
            {
                Position p1 = Formula.ClosestIntersection(this.gameInfo.AttackTeam.AttackBasket, (double)(distance - Radius), ballHandler.Pos, this.gameInfo.AttackTeam.AttackBasket);
                //看扑到位置的时间跟出手者的出手时间差
                if (p1 != Position.Empty)
                {
                    gt.TargetPos = p1;
                    int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(player, this.gameInfo.RandomSpeed());

                    double seconds = (double)gt.StartPos.DistanceActualLength(gt.TargetPos) / this.player.GetSpeedByLevel(speedLevel);
                    double realActionTime = ballHandler.GetAttribute(PlayerAttribute.ShootTime) / 1000 - this.GetDelaySeconds();
                    if (realActionTime < seconds)
                    {
                        seconds = realActionTime;
                    }
                    gt.FinishFrame = gt.CalcRealTargetByTimeSpeed(seconds, this.player.GetSpeedInPixelByLevel(speedLevel));
                    gt.SpeedLevel = speedLevel;
                }
            }
            else
            {
                gt.TaskType = TaskType.PlayerStandby;
                gt.StartPos = this.player.Pos;
                gt.TargetPos = this.player.Pos;
                gt.DelayStart = this.GetDelayFrame();
            }
            this.player.SetCurrentTask(gt);
            return BehaviourTreeStatus.Success;
        }
    }
}
