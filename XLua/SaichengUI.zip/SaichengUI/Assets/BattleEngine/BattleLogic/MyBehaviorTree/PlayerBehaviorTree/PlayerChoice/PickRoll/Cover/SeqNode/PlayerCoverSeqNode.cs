﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 掩护节点
    /// </summary>
    public class PlayerCoverSeqNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerCoverSeqNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.player.IsInTask( TaskType.PlayerCover))
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerCoverSelector("掩护", this.gameInfo);
        }
    }
}
