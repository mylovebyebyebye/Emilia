﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 传球人
    /// </summary>
    public class PlayerPassBallToPassSeqNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerPassBallToPassSeqNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.player.IsInTask( TaskType.PlayerToPassBall))
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerPassBallToPassSelector("传球人", this.gameInfo);
        }
    }
}
