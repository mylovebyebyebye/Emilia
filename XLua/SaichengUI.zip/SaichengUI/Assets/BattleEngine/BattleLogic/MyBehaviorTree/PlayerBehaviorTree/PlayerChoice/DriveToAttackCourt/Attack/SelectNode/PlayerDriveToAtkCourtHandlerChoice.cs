﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDriveToAtkCourtHandlerChoice : PlayerChoiceBaseSelector
    {
        TacDriveToAtkCourt tacDriveTo;
        TacStandby tacStandby;
        public PlayerDriveToAtkCourtHandlerChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacDriveTo = new TacDriveToAtkCourt(this.gameInfo, this.name);
            this.tacStandby = new TacStandby(this.gameInfo, this.name);
        }

        protected override void CreateChildNode()
        {
            PlayerDriveToAtkCourtFinish finish = new PlayerDriveToAtkCourtFinish("过半场结束", this.gameInfo);
            this.AddChild(finish);

            //紧逼，没有

            //运球过半场
            PlayerDriveToAtkCourt driveTo = new PlayerDriveToAtkCourt("运球过半场", this.gameInfo);
            this.AddChild(driveTo);

            //待机300ms
            PlayerDriveToAtkHanlderWait wait = new PlayerDriveToAtkHanlderWait("等待", this.gameInfo);
            this.AddChild(wait);

            //最后就看是过半场还是待机
            ActionNode final = new ActionNode("最后选择", this.FinalChoice);
            this.AddChild(final);
        }

        private BehaviourTreeStatus FinalChoice(TimeData time)
        {
            if (this.tacDriveTo.GetPro(this.player) > 0)
            {
                //过半场
                this.tacDriveTo.Do(this.player);
            }
            else
            {
                //待机
                this.tacStandby.Do(this.player, TimeFrameConverter.GetFrame(Player.MaxDefRelationTime));
            }
            this.player.GetCurTask().NextTask = TaskType.PlayerDriveToAttackField;
            return BehaviourTreeStatus.Success;
        }
    }
}
