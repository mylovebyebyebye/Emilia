﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 内线进攻防守人
    /// 准备阶段
    /// </summary>
    public class PlayerInsideAtkDefPreNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerInsideAtkDefPreNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            Player attacker = this.player.GetMyPosAttacker();
            
            if (this.player.IsInTask( TaskType.PlayerInsideAttackPrepare) && 
                attacker != null)
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerInsideAtkDefPreChoice("内线进攻准备阶段防守人", this.gameInfo);
        }
    }
}
