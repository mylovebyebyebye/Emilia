﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerToStealPassBallNode : PlayerBaseUpdateNode
    {
        private TacSteal tac;

        public PlayerToStealPassBallNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            tac = new TacSteal(this.gameInfo, this.name);
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerToStealPassBall;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            if (this.player.GetCurTask().FinishFrame == 1)
            {
                //球还没到人手里才可能抢断
                if (this.gameInfo.Ball.Owner != null)
                {
                    return BehaviourTreeStatus.Success;
                }

                //抢断判断
                int disMax = ParameterManager.Instance.GetValue(ParameterEnum.PassBallParam11);
                double disToBall = this.gameInfo.Ball.Pos.DistanceActualLength(this.player.Pos);
                if (disToBall < disMax)
                {
                    Player passBallPlayer = this.player.GetCurTask().TargetPlayer;
                    if (this.tac.IsSteal(EStealSource.PassBall, passBallPlayer, this.player))
                    {
                        this.gameInfo.AddPersoanlBoxScore(this.player, BoxScoreType.StealPassBall, 1);

                        if (this.gameInfo.IsPause)
                        {
                            this.gameInfo.Resume();
                        }

                        //抢断
                        GameEvent ge = new GameEvent(GameEventType.Steal);
                        ge.Param1 = (int)EStealSource.PassBall;
                        ge.Param4 = passBallPlayer;
                        ge.Param5 = this.player;
                        this.gameInfo.AddGameEvent(ge);
                    }
                }
            }

            return BehaviourTreeStatus.Success;
        }
    }
}
