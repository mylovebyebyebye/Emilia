﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDefAfterBallHitHoopChoice : PlayerChoiceBaseSelector
    {
        public PlayerDefAfterBallHitHoopChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            PlayerFastBreakChoiceNode faskBreak = new PlayerFastBreakChoiceNode("快下", this.gameInfo);
            this.AddChild(faskBreak);

            PlayerMoveToReboundPlacementNode moveTo = new PlayerMoveToReboundPlacementNode("向落点移动", this.gameInfo);
            this.AddChild(moveTo);

            ActionNode standBy = new ActionNode("待机", this.StandBy);
            this.AddChild(standBy);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            gt.DelayStart = this.gameInfo.Ball.GetCurTask().DelayStart;
            gt.FinishFrame = this.gameInfo.Ball.GetCurTask().FinishFrame;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
