﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerAttackBasketChoiceNode : PlayerBaseChoiceNode
    {
        TacAttackBasket tac;
        public PlayerAttackBasketChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacAttackBasket(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.player.IsCanCrossOver)
            {
                double expect = this.gameInfo.GetPlayerExpectHanlder(this.player);
                if (this.player.CrossOverExpect >= expect)
                {
                    return true;
                }
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.tac.Do(this.player);
            return BehaviourTreeStatus.Success;
        }
    }
}
