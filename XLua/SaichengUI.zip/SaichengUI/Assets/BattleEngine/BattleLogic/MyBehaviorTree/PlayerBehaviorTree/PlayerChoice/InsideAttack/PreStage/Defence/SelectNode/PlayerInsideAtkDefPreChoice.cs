﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerInsideAtkDefPreChoice : PlayerChoiceBaseSelector
    {
        public PlayerInsideAtkDefPreChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            //取消该状态
            ActionNode cancel = new ActionNode("取消该状态", this.Cancel);
            this.AddChild(cancel);

            //向落位位置移动 
            PlayerInsideAtkDefPreMoveToLuoWei moveToLuowei = new PlayerInsideAtkDefPreMoveToLuoWei("向落位位置移动", this.gameInfo);
            this.AddChild(moveToLuowei);

            //待机
            ActionNode standby = new ActionNode("待机", this.Standby);
            this.AddChild(standby);
        }

        private BehaviourTreeStatus Cancel(TimeData time)
        {
            Player attacker = this.player.GetMyPosAttacker();
            if (attacker == null || this.gameInfo.Ball.Owner != attacker)
            {
                this.player.ClearTask();
                return BehaviourTreeStatus.Success;
            }
            return BehaviourTreeStatus.Failure;
        }

        private BehaviourTreeStatus Standby(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            gt.FinishFrame = TimeFrameConverter.GetFrame(Player.MaxDefRelationTime);
            gt.NextTask = TaskType.PlayerInsideAttackPrepare;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
