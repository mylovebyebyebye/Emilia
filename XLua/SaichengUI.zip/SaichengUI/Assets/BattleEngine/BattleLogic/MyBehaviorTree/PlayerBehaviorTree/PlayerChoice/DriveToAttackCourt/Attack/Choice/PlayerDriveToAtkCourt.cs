﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerDriveToAtkCourt : PlayerBaseChoiceNode
    {
        TacDriveToAtkCourt tac;
        public PlayerDriveToAtkCourt(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacDriveToAtkCourt(this.gameInfo,this.name);
        }

        protected override bool IsMyCharge(FluentBehaviourTree.TimeData time)
        {
            if(this.player.IsSamePlayer(this.gameInfo.AttackTeam.MaxHanlder))
            {
                //控球最高
                return true;
            }
            if(this.tac.IsNeedDriveToAtkCourt(this.player))
            {
                //随机到过半场
                return true;
            }
            return false;
        }


        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.tac.Do(player);
            this.player.GetCurTask().NextTask = TaskType.PlayerDriveToAttackField;
            return BehaviourTreeStatus.Success;
        }

    }
}
