﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerGetBallOnTheFloorGet : PlayerBaseChoiceNode
    {
        private TacBallOnTheFloor tac;
        public PlayerGetBallOnTheFloorGet(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacBallOnTheFloor(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.tac.IsGetBall(this.player))
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            //2017.1.12 增加出界判断
            if (this.gameInfo.IsInBounds(this.player.Pos))
            {
                this.tac.GetBall(this.player);
            }
            else
            {
                //在界外拿到球
                this.gameInfo.Ball.Pos = player.Pos;
                this.tac.OutOfBound((EBallOnTheFloorSourceType)this.gameInfo.Ball.GetCurTask().Param1, this.player);
                this.gameInfo.Ball.ClearTask();
            }
            return BehaviourTreeStatus.Success;
        }
    }
}
