﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public abstract class PlayerBaseUpdateNode : SequenceNode
    {
        protected TaskType taskType;
        protected Player player;

        protected abstract void SetTaskType();
        protected abstract BehaviourTreeStatus Process(TimeData time);

        public TaskType GetTaskType()
        {
            return this.taskType;
        }

        public void Process()
        {
            this.Process(TimeData.Null);
        }

        public PlayerBaseUpdateNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.player = null;
            this.SetTaskType();
        }

        public void SetTaskType(TaskType task)
        {
            this.taskType = task;
        }

        public void SetPlayer(Player player)
        {
            this.player = player;
        }

        protected override void CreateChildNode()
        {
            ConditionNode isLocation = new ConditionNode(this.taskType.ToString(), this.IsMyCharge);
            this.AddChild(isLocation);

            ActionNode processNode = new ActionNode("PlayerUpdateAction", this.Process);
            this.AddChild(processNode);
        }

        protected bool IsMyCharge(TimeData time)
        {
            if(this.player == null)
            {
                throw new Exception("球员节点未初始化");
            }

            if (this.player.IsInTask( this.taskType))
            {
                return true;
            }
            return false;
        }

    }
}
