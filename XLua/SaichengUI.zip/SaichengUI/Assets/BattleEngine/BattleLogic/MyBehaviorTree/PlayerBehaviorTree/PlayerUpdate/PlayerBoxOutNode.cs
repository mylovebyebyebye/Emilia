﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerBoxOutNode : PlayerBaseUpdateNode
    {
        TacStandby tac;

        public PlayerBoxOutNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacStandby(this.gameInfo, this.name);
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerBoxOut;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            if (this.player.GetCurTask().StartPos == Position.Empty)
            {
                this.tac.Do(this.player, TimeFrameConverter.GetFrame( Player.MaxDefRelationTime) );
            }
            else
            {
                //如果离目的地距离小于一定值就不动了
                double dis = this.player.Pos.DistanceActualLength(this.player.GetCurTask().TargetPos);
                if (dis > ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea))
                {
                    TaskMoveTo.Do(this.player);
                }
            }


            return BehaviourTreeStatus.Success;
        }
    }
}
