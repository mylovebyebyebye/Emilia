﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 内线进攻
    /// </summary>
    public class PlayerInsideAttack : PlayerBaseChoiceNode
    {
        private TacInsideAttack tac;
        public PlayerInsideAttack(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacInsideAttack(this.gameInfo, this.name);
        }


        protected override bool IsMyCharge(TimeData time)
        {
            //内线得分预期
            double expect = this.gameInfo.GetPlayerExpectHanlder( this.player);
            if (this.player.InsideScoringExpect >= expect)
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.tac.StartInsideAttack(this.player);
            return BehaviourTreeStatus.Success;
        }
    }
}
