﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 进球以后
    /// 新的攻方选择
    /// </summary>
    public class PlayerAtkAfterBallShotChoiceNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerAtkAfterBallShotChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if(this.player.IsInTask( TaskType.PlayerAfterBallShot) || 
                    this.player.IsInTask( TaskType.PlayerAfterBallShotToThrowIn)) 
            {
                 return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerAtkAfterBallShotChoice("球进以后攻方选择", this.gameInfo);
        }
    }
}
