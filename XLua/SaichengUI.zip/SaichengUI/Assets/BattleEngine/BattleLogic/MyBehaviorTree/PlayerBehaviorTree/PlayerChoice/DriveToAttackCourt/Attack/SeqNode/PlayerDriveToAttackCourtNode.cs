﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDriveToAttackCourtNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerDriveToAttackCourtNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.player.IsInTask( TaskType.PlayerDriveToAttackField))
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerDriveToAttackCourtChoice("过半场选择", this.gameInfo);
        }
    }
}
