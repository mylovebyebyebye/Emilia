﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerMoveToThrowIn : PlayerBaseUpdateNode
    {
        public PlayerMoveToThrowIn(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }


        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerMoveToThrowIn;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            TaskMoveTo.Do(this.player);
            if (this.player.GetCurTask().FinishFrame == 1)
            {
                //到达发球点
                GameEvent ge = new GameEvent((GameEventType)this.gameInfo.Ball.GetCurTask().Param1);
                ge.Param4 = this.player;//发球人
                this.gameInfo.AddGameEvent(ge);
            }
            return BehaviourTreeStatus.Success;
        }
    }
}
