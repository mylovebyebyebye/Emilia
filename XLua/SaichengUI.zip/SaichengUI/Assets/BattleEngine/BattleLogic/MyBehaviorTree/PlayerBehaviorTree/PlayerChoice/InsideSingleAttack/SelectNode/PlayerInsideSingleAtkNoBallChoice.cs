﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerInsideSingleAtkNoBallChoice : PlayerChoiceBaseSelector
    {
        public PlayerInsideSingleAtkNoBallChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }


        protected override void CreateChildNode()
        {
            //出3秒
            PlayerInisideSingleAtkNoBallOutOf3S moveOut3S = new PlayerInisideSingleAtkNoBallOutOf3S("内线单打出3秒", this.gameInfo);
            this.AddChild(moveOut3S);

            //拉开 
            PlayerInsideSingleAtkNoBallSpaceOut spaceOut = new PlayerInsideSingleAtkNoBallSpaceOut("拉开", this.gameInfo);
            this.AddChild(spaceOut);

            ActionNode standBy = new ActionNode("待机", this.StandBy);
            this.AddChild(standBy);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            gt.FinishFrame = TimeFrameConverter.GetFrame(Player.MaxDefRelationTime); 
            //gt.NextTask = TaskType.PlayerInsideSingleAttack;


            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
