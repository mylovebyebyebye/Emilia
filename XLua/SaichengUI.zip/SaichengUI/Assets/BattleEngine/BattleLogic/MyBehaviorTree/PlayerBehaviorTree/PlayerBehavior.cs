﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using BattleLogic;

namespace BattleLogic
{
    public class PlayerBehavior
    {
        private IBehaviourTreeNode choiceRootNode;

        private IBehaviourTreeNode atkChoiceRootNode;

        private IBehaviourTreeNode defChoiceRootNode;

        private GameInfo gameInfo;
        private Player player;

        public PlayerBehavior(GameInfo gameInfo, Player player)
        {
            this.gameInfo = gameInfo;
            this.player = player;
            this.InitUpdateTree();
            this.InitAtkChoiceTree();
            this.InitDefChoiceTree();
        }

        private void InitAtkChoiceTree()
        {
            var builder = new BehaviourTreeBuilder();
            SelectorNode rootNode = new SelectorNode("球员选择根节点", this.gameInfo);

            PlayerAtkChoiceNode atkChoice = new PlayerAtkChoiceNode("攻方时选择集合", this.gameInfo);
            atkChoice.SetPlayer(this.player);
            rootNode.AddChild(atkChoice);

            PlayerBallHanlderNode ballHanlder = new PlayerBallHanlderNode("持球人", this.gameInfo);
            ballHanlder.SetPlayer(this.player);
            rootNode.AddChild(ballHanlder);

            PlayerAttackNoBallNode noBallAttaker = new PlayerAttackNoBallNode("无球人", this.gameInfo);
            noBallAttaker.SetPlayer(this.player);
            rootNode.AddChild(noBallAttaker);

            rootNode.FinishAdd();

            builder.Selector(rootNode);
            builder.End();

            this.atkChoiceRootNode = builder.Build();
            ((SelectorNode)atkChoiceRootNode).FinishAdd();
        }

        private void InitDefChoiceTree()
        {
            var builder = new BehaviourTreeBuilder();
            SelectorNode rootNode = new SelectorNode("球员选择根节点", this.gameInfo);

            PlayerDefChoiceNode defChoice = new PlayerDefChoiceNode("防守方时选择集合", this.gameInfo);
            defChoice.SetPlayer(this.player);
            rootNode.AddChild(defChoice);

            PlayerDefHanlderNode defBallHanlder = new PlayerDefHanlderNode("防持球人", this.gameInfo);
            defBallHanlder.SetPlayer(this.player);
            rootNode.AddChild(defBallHanlder);

            PlayerDefNoBallNode defNoBall = new PlayerDefNoBallNode("防无球人", this.gameInfo);
            defNoBall.SetPlayer(this.player);
            rootNode.AddChild(defNoBall);

            rootNode.FinishAdd();

            builder.Selector(rootNode);
            builder.End();

            this.defChoiceRootNode = builder.Build();
            ((SelectorNode)defChoiceRootNode).FinishAdd();
        }

        private void InitChoiceTree()
        {
            var builder = new BehaviourTreeBuilder();
            SelectorNode rootNode = new SelectorNode("球员选择根节点", this.gameInfo);

            PlayerAtkChoiceNode atkChoice = new PlayerAtkChoiceNode("攻方时选择集合", this.gameInfo);
            atkChoice.SetPlayer(this.player);
            rootNode.AddChild(atkChoice);

            PlayerDefChoiceNode defChoice = new PlayerDefChoiceNode("防守方时选择集合", this.gameInfo);
            defChoice.SetPlayer(this.player);
            rootNode.AddChild(defChoice);

            PlayerAttackAfterBallHitHoopChoiceNode atkAfterBallHitHoop = new PlayerAttackAfterBallHitHoopChoiceNode("攻方篮板砸框后事件", this.gameInfo);
            atkAfterBallHitHoop.SetPlayer(this.player);
            rootNode.AddChild(atkAfterBallHitHoop);

            PlayerDefAfterBallHitHoopChoiceNode defAfterBallHitHoop = new PlayerDefAfterBallHitHoopChoiceNode("防守方篮板砸框后事件", this.gameInfo);
            defAfterBallHitHoop.SetPlayer(this.player);
            rootNode.AddChild(defAfterBallHitHoop);

            PlayerGetBallOnTheFloorNode getBallOnTheFloor = new PlayerGetBallOnTheFloorNode("抢地板球", this.gameInfo);
            getBallOnTheFloor.SetPlayer(this.player);
            rootNode.AddChild(getBallOnTheFloor);

            PlayerBallHanlderNode ballHanlder = new PlayerBallHanlderNode("持球人",this.gameInfo);
            ballHanlder.SetPlayer(this.player);
            rootNode.AddChild(ballHanlder);

            PlayerAttackNoBallNode noBallAttaker = new PlayerAttackNoBallNode("无球人", this.gameInfo);
            noBallAttaker.SetPlayer(this.player);
            rootNode.AddChild(noBallAttaker);

            PlayerDefHanlderNode defBallHanlder = new PlayerDefHanlderNode("防持球人", this.gameInfo);
            defBallHanlder.SetPlayer(this.player);
            rootNode.AddChild(defBallHanlder);

            PlayerDefNoBallNode defNoBall = new PlayerDefNoBallNode("防无球人", this.gameInfo);
            defNoBall.SetPlayer(this.player);
            rootNode.AddChild(defNoBall);

            rootNode.FinishAdd();

            builder.Selector(rootNode);
            builder.End();

            this.choiceRootNode = builder.Build();
            ((SelectorNode)choiceRootNode).FinishAdd();
        }

        private PlayerMoveToNode                updateMoveTo;
        private PlayerTakePosMove               updateTakePosMove;
        private PlayerMoveToThrowIn             updateMoveToThrowIn;
        private PlayerMoveToGetThrowInNode      updateMoveToGetThrowIn;
        private PlayerToThrowInNode             updateWaitToThrowIn;
        private PlayerMoveToAreaNode            updateMoveToPresetArea;
        private PlayerPositioningNode           updatePosition;
        private PlayerFastBreakNode             updateFastBreak;
        private PlayerMoveToNode                updateMoveToSpaceOut;
        private PlayerMoveToNode                updateMoveToBallPlacement;
        private PlayerMoveToNode                updateForceMoveTo;
        private PlayerReboundNode               updateRebound;
        private PlayerBoxOutNode                updateBoxOut;
        private PlayerDefOneOneOneNode          updateDefOneOneOne;
        private PlayerShotNode                  updateShot;
        private PlayerLayupNode                 updateLayup;
        private PlayerDriveToTheBasketNode      updateDriveToTheBasket;
        private PlayerMoveToCrossOver           updateMoveToCrossOver;
        private PlayerToGetBallNode             updateToGetBall;
        private PlayerLocationNode              updateLocation;
        private PlayerStandbyNode               updateStandby;
        private PlayerStandbyNode               updateTakePosStanby;
        private PlayerStandbyNode               updateForceStandby;
        private PlayerToStealPassBallNode       updateStealPassBall;
        private PlayerMoveToDefFastBreak        updateMoveToDefFaskBreak;
        private PlayerMoveToFinishPickRoll      updateMoveToFinishPickRoll;
        private PlayerJumpDefShot               updateJumpDefShot;
        private PlayerChangeDefTarget           updateChangeDefTarget;

        private void InitUpdateTree()
        {
            updateMoveTo = new PlayerMoveToNode("移动", this.gameInfo);
            updateMoveTo.SetPlayer(this.player);

            this.updateMoveToFinishPickRoll = new PlayerMoveToFinishPickRoll("完成挡拆", this.gameInfo);
            this.updateMoveToFinishPickRoll.SetPlayer(this.player);

            updateTakePosMove = new PlayerTakePosMove("抢位后的移动", this.gameInfo);
            updateTakePosMove.SetPlayer(this.player);

            updateMoveToThrowIn = new PlayerMoveToThrowIn("移动到发球点", this.gameInfo);
            updateMoveToThrowIn.SetPlayer(this.player);

            updateMoveToGetThrowIn = new PlayerMoveToGetThrowInNode("移动到接球点", this.gameInfo);
            updateMoveToGetThrowIn.SetPlayer(this.player);

            updateWaitToThrowIn = new PlayerToThrowInNode("发球人等待要球", this.gameInfo);
            updateWaitToThrowIn.SetPlayer(this.player);

            //跟moveto是一样的
            updateMoveToPresetArea = new PlayerMoveToAreaNode("移动到预设区域", this.gameInfo);
            updateMoveToPresetArea.SetPlayer(this.player);

            updatePosition = new PlayerPositioningNode("跑位", this.gameInfo);
            updatePosition.SetPlayer(this.player);

            updateFastBreak = new PlayerFastBreakNode("快下", this.gameInfo);
            updateFastBreak.SetPlayer(this.player);

            //拉开
            updateMoveToSpaceOut = new PlayerMoveToNode("拉开", this.gameInfo);
            updateMoveToSpaceOut.SetPlayer(this.player);
            updateMoveToSpaceOut.SetTaskType(TaskType.PlayerMoveToSpaceOut);
            
            //篮板后向球移动
            updateMoveToBallPlacement = new PlayerMoveToNode("篮板后向球移动", this.gameInfo);
            updateMoveToBallPlacement.SetPlayer(this.player);
            updateMoveToBallPlacement.SetTaskType(TaskType.PlayerAfterBallHitMoveToBall);

            //强制移动
            updateForceMoveTo = new PlayerMoveToNode("强制移动不可打断", this.gameInfo);
            updateForceMoveTo.SetTaskType(TaskType.PlayerForceMoveTo);
            updateForceMoveTo.SetPlayer(this.player);

            updateRebound = new PlayerReboundNode("篮板", this.gameInfo);
            updateRebound.SetPlayer(this.player);

            updateBoxOut = new PlayerBoxOutNode("卡位", this.gameInfo);
            updateBoxOut.SetPlayer(this.player);

            updateDefOneOneOne = new PlayerDefOneOneOneNode("跟防", this.gameInfo);
            updateDefOneOneOne.SetPlayer(this.player);

            updateShot = new PlayerShotNode("投篮", this.gameInfo);
            updateShot.SetPlayer(this.player);

            updateLayup = new PlayerLayupNode("上篮", this.gameInfo);
            updateLayup.SetPlayer(this.player);

            updateDriveToTheBasket = new PlayerDriveToTheBasketNode("冲击篮筐", this.gameInfo);
            updateDriveToTheBasket.SetPlayer(this.player);

            updateMoveToCrossOver = new PlayerMoveToCrossOver("移动到触发突破判断", this.gameInfo);
            updateMoveToCrossOver.SetPlayer(this.player);

            updateToGetBall = new PlayerToGetBallNode("接球", this.gameInfo);
            updateToGetBall.SetPlayer(this.player);

            updateLocation = new PlayerLocationNode("定位", this.gameInfo);
            updateLocation.SetPlayer(this.player);

            updateStandby = new PlayerStandbyNode("待机", this.gameInfo);
            updateStandby.SetPlayer(this.player);

            updateTakePosStanby = new PlayerStandbyNode("卡位待机", this.gameInfo);
            updateTakePosStanby.SetTaskType(TaskType.PlayerTakePosStandby);
            updateTakePosStanby.SetPlayer(this.player);

            updateForceStandby = new PlayerStandbyNode("强制待机不可打断", this.gameInfo);
            updateForceStandby.SetTaskType(TaskType.PlayerForceStandBy);
            updateForceStandby.SetPlayer(this.player);

            this.updateStealPassBall = new PlayerToStealPassBallNode("抢断传球", this.gameInfo);
            this.updateStealPassBall.SetTaskType(TaskType.PlayerToStealPassBall);
            this.updateStealPassBall.SetPlayer(this.player);

            this.updateMoveToDefFaskBreak = new PlayerMoveToDefFastBreak("防快下", this.gameInfo);
            this.updateMoveToDefFaskBreak.SetTaskType(TaskType.PlayerMoveToDefFastBreak);
            this.updateMoveToDefFaskBreak.SetPlayer(this.player);

            this.updateJumpDefShot = new PlayerJumpDefShot("跳起干扰投篮", this.gameInfo);
            this.updateJumpDefShot.SetPlayer(this.player);

            this.updateChangeDefTarget = new PlayerChangeDefTarget("更换防守对象", this.gameInfo);
            this.updateChangeDefTarget.SetPlayer(this.player);
            
        }

        public void TickUpdate()
        {
            TaskType taskType = this.player.GetCurTask().TaskType;
            switch (taskType)
            {
                case TaskType.PlayerMoveTo:
                    {
                        updateMoveTo.Process();
                    }
                    break;
                case TaskType.PlayerTakePosMove:
                    {
                        updateTakePosMove.Process();
                    }
                    break;
                case TaskType.PlayerMoveToThrowIn:
                    {
                        updateMoveToThrowIn.Process();
                    }
                    break;
                case TaskType.PlayerMoveToGetThrowIn:
                    {
                        updateMoveToGetThrowIn.Process();
                    }
                    break;
                case TaskType.PlayerToThrowIn:
                    {
                        updateWaitToThrowIn.Process();
                    }
                    break;
                case TaskType.PlayerMoveToArea:
                    {
                        updateMoveToPresetArea.Process();
                    }
                    break;
                case TaskType.PlayerPositioning:
                    {
                        updatePosition.Process();
                    }
                    break;
                case TaskType.PlayerFastBreak:
                    {
                        updateFastBreak.Process();
                    }
                    break;
                case TaskType.PlayerMoveToSpaceOut:
                    {
                        updateMoveToSpaceOut.Process();
                    }
                    break;
                case TaskType.PlayerAfterBallHitMoveToBall:
                    {
                        updateMoveToBallPlacement.Process();
                    }
                    break;
                case TaskType.PlayerForceMoveTo:
                    {
                        updateForceMoveTo.Process();
                    }
                    break;
                case TaskType.PlayerRebound:
                    {
                        updateRebound.Process();
                    }
                    break;
                case TaskType.PlayerBoxOut:
                    {
                        updateBoxOut.Process();
                    }
                    break;
                case TaskType.PlayerOneOneOneDef:
                    {
                        updateDefOneOneOne.Process();
                    }
                    break;
                case TaskType.PlayerShot:
                    {
                        updateShot.Process();
                    }
                    break;
                case TaskType.PlayerLayup:
                    {
                        updateLayup.Process();
                    }
                    break;
                case TaskType.PlayerDriveToTheBasket:
                    {
                        updateDriveToTheBasket.Process();
                    }
                    break;
                case TaskType.PlayerMoveToCrossOver:
                    {
                        updateMoveToCrossOver.Process();
                    }
                    break;
                case TaskType.PlayerToGetPassBall:
                    {
                        updateToGetBall.Process();
                    }
                    break;
                case TaskType.PlayerLocation:
                    {
                        updateLocation.Process();
                    }
                    break;
                case TaskType.PlayerStandby:
                    {
                        updateStandby.Process();
                    }
                    break;
                case TaskType.PlayerTakePosStandby:
                    {
                        updateTakePosStanby.Process();
                    }
                    break;
                case TaskType.PlayerForceStandBy:
                    {
                        updateForceStandby.Process();
                    }
                    break;
                case TaskType.PlayerToStealPassBall:
                    {
                        this.updateStealPassBall.Process();
                    }
                    break;
                case TaskType.PlayerMoveToDefFastBreak:
                    {
                        this.updateMoveToDefFaskBreak.Process();
                    }
                    break;
                case TaskType.PlayerMoveToFinishPickRoll:
                    {
                        this.updateMoveToFinishPickRoll.Process();
                    }
                    break;
                case TaskType.PlayerJumpDefShot:
                    {
                        this.updateJumpDefShot.Process();
                    }
                    break;
                case TaskType.PlayerChangeDefTarget:
                    {
                        this.updateChangeDefTarget.Process();
                    }
                    break;
            }
            
            //this.updateRootNode.Tick(TimeData.Null);
        }

        public void TickChoice()
        {
            if( !this.player.IsFree && !this.player.IsNeedOut3S() )
            {
                return;
            }
            this.choiceRootNode.Tick(TimeData.Null);
        }

        public void TickAtkChoice()
        {
            if (!this.player.IsFree && !this.player.IsNeedOut3S())
            {
                return;
            }
            this.atkChoiceRootNode.Tick(TimeData.Null);
        }

        public void TickDefChoice()
        {
            if (!this.player.IsFree && !this.player.IsNeedOut3S())
            {
                return;
            }
            this.defChoiceRootNode.Tick(TimeData.Null);
        }
    }
}
