﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDefAfterBallShotNode : PlayerChoiceBaseSequenceNode
    {

        public PlayerDefAfterBallShotNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if ( this.player.IsInTask( TaskType.PlayerAfterBallShot))
            {
                if (this.gameInfo.Ball.Owner == null)
                {
                    return true;
                }
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerDefAfterBallShotChoice("进球后防守方选择", this.gameInfo);
        }
    }
}
