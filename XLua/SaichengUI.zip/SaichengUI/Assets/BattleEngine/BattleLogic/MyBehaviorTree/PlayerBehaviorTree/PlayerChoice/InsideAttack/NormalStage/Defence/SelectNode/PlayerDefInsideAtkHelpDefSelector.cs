﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerDefInsideAtkHelpDefSelector : PlayerChoiceBaseSelector
    {
        public PlayerDefInsideAtkHelpDefSelector(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            //取消该状态
            ActionNode cancel = new ActionNode("取消该状态", this.Cancel);
            this.AddChild(cancel);

            //是否进入协防区域
            ActionNode enterHelpDefArea = new ActionNode("进入协防区域", this.EnterHelpDefArea);
            this.AddChild(enterHelpDefArea);

            //向背打人移动100ms
            ActionNode moveToAtker = new ActionNode("向背打人移动", this.MoveToAtker);
            this.AddChild(moveToAtker);
        }

        private BehaviourTreeStatus Cancel(TimeData time)
        {
            Player attacker = this.player.GetCurTask().TargetPlayer;
            if (attacker == null || attacker.GetCurTask().TaskSource != ETaskSource.InsideAttack)
            {
                //如果背打人已经不在背打了，就不在进行这个事情
                this.player.ClearTask();
                return BehaviourTreeStatus.Success;
            }
            return BehaviourTreeStatus.Failure;
        }

        /// <summary>
        /// 判断是否进入协防区域
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        private BehaviourTreeStatus EnterHelpDefArea(TimeData time)
        {
            Player attacker = this.player.GetCurTask().TargetPlayer;
            double minDis = ParameterManager.Instance.GetValueD(ParameterEnum.InsideAtkHelpDefArea);
            double dis = this.player.Pos.DistanceActualLength(this.player.GetCurTask().TargetPlayer.Pos);

            if (Formula.IsDisInPermissibleError(dis , minDis))
            {
                //到达协防位置
                //清掉之前的事件
                this.gameInfo.ClearEvent();

                //协防人和背打人进入 包夹状态
                this.player.SetCurrentTask(this.GetDoubledTask(attacker));
                attacker.SetCurrentTask(this.GetDoubledTask(attacker));

                //背打人的防守人也进入协防状态
                List<Player> lst = attacker.GetAllMyPosDefPlayers();
                for (int i = 0; i < lst.Count; i++)
                {
                    Player player = lst[i];
                    player.SetCurrentTask(this.GetDoubledTask(attacker));
                }

                return BehaviourTreeStatus.Success;
            }

            return BehaviourTreeStatus.Failure;
        }

        private GameTask GetDoubledTask(Player atkPlayer)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerInsideAttackDoubled;
            gt.TargetPlayer = atkPlayer;

            return gt;
        }

        private BehaviourTreeStatus MoveToAtker(TimeData time)
        {
            Player attacker = this.player.GetCurTask().TargetPlayer;
            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(this.player, this.gameInfo.RandomSpeed());
            double speedInPix = this.player.GetSpeedInPixelByLevel(speedLevel);
            double seconds = ParameterManager.Instance.GetValueD(ParameterEnum.InsideAtkDoubledStandbyTime) / 1000;

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = attacker.Pos;
            gt.FinishFrame = gt.CalcRealTargetByTimeSpeed(seconds, speedInPix);

            this.player.SetCurrentTask(gt);

            GameTask gt1 = new GameTask(this.name);
            gt1.TaskType = TaskType.PlayerInsideAttackHelpDefence;
            gt1.TargetPlayer = attacker;
            gt1.DelayStart = 0;
            this.player.NextTask.Add(gt1);

            return BehaviourTreeStatus.Success;
        }
    }
}
