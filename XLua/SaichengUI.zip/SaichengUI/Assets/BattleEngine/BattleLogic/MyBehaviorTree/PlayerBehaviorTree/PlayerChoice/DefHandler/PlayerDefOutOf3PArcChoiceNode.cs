﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    /// <summary>
    /// 三分线外的顶防
    /// </summary>
    public class PlayerDefOutOf3PArcChoiceNode : PlayerDefHanlderChoiceBaseNode
    {
        public PlayerDefOutOf3PArcChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            ConditionNode is3PArcDef = new ConditionNode("是否三分线落位", this.Is3PArcDef);
            this.AddChild(is3PArcDef);

            ActionNode defOn3PArc = new ActionNode("三分线落位防守", this.DefOn3PArc);
            this.AddChild(defOn3PArc);
        }

        private bool Is3PArcDef(TimeData time)
        {
            Player handler = this.gameInfo.Ball.Owner;
            Field attackField = this.gameInfo.AttackTeam.AttackField;
            Field defAtkField = this.gameInfo.DefTeam.AttackField;
            //处于本方进攻半场的时候，直接去后场落位
            if (defAtkField.IsOnMyEffectiveArea(this.player.Pos))
            {
                return true;
            }

            //持球人离篮筐距离大于指定距离，且不在我的防守区域
            double minDis = ParameterManager.Instance.GetValue(ParameterEnum.DefHandlerLuoWeiDis) * 1.0f;
            //double dis = attackField.GetBasketPos().DistanceActualLength(handler.Pos);
            double dis = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, attackField, handler);
            
            if (dis > minDis)
            {
                double disToPlayer = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, handler, this.player);
                if (!this.player.IsInMyDefArea(disToPlayer))
                {
                    return true;
                }
            }
            return false;
        }

        private BehaviourTreeStatus DefOn3PArc(TimeData time)
        {
            Player handler = this.gameInfo.Ball.Owner;
            Field attackField = this.gameInfo.AttackTeam.AttackField;
            //篮筐跟持球人连线，跟三分交点
            Position p1 = Formula.ClosestIntersection(attackField.GetBasketPos(), attackField.TopOfTheCircle3PDistance + 5, handler.Pos, attackField.GetBasketPos());


            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            if (this.IsNeedDelay(handler))
            {
                gt.DelayStart = this.GetDelayFrame();
            }
            gt.StartPos = this.player.Pos;
            gt.TargetPos = p1;

            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(player, this.gameInfo.RandomSpeed());
            double speedInPixel = this.player.GetSpeedInPixelByLevel(speedLevel);
            gt.FinishFrame = gt.CalcRealTargetBySpeedMaxSeconds(ref speedInPixel, Player.MaxDefRelationTime);
            gt.SpeedLevel = this.player.GetSpeedLevelByRealSpeed(speedInPixel);
            gt.TargetPlayer = handler;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
