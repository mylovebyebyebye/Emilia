﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerFadeAwayDefChoice : PlayerChoiceBaseSelector
    {
        private TacStandby tac;
        public PlayerFadeAwayDefChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacStandby(this.gameInfo,this.name);
        }

        protected override void CreateChildNode()
        {
            PlayerFadeAwayDefMoveToShooter move = new PlayerFadeAwayDefMoveToShooter("向投篮人移动", this.gameInfo);
            this.AddChild(move);

            ActionNode standBy = new ActionNode("待机", this.StandBy);
            this.AddChild(standBy);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            this.tac.Do(this.player, int.MaxValue);
            return BehaviourTreeStatus.Success;
        }
    }
}
