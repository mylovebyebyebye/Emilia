﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    /// <summary>
    /// 把卡位当成抢篮板的一种
    /// </summary>
    public class PlayerDefBoxOutChoiceNode : PlayerReboundChoiceNode
    {
        public PlayerDefBoxOutChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            ConditionNode isToBoxOut = new ConditionNode("是否卡位", this.IsToBoxOut);
            this.AddChild(isToBoxOut);

            ActionNode toBoxOut = new ActionNode("卡位", this.ToBoxOut);
            this.AddChild(toBoxOut);
        }

        /// <summary>
        /// 是否卡位
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        private bool IsToBoxOut(TimeData time)
        {
            double tacAdd = 0;//战术加成，暂定为0    
            double boxOutCOE = ParameterManager.Instance.GetValue(ParameterEnum.BoxOutCOE) * 1.0f;
            double distance = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, this.gameInfo.AttackTeam.AttackField, this.player);
            //double distance = this.player.Pos.DistanceActualLength(this.gameInfo.AttackTeam.AttackBasket);
            int probability = (int)Math.Floor((player.GetAttribute(PlayerAttribute.BoxOut) + tacAdd) / distance * boxOutCOE * 10000);
            if (probability < this.gameInfo.RandomNext())
            {
                return false;
            }
            return true;
        }

        private BehaviourTreeStatus ToBoxOut(TimeData time)
        {
            //找卡位人
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerBoxOut;
            gt.StartPos = this.player.Pos;
            gt.DelayStart = this.gameInfo.Ball.GetCurTask().DelayStart;
            gt.FinishFrame = this.gameInfo.Ball.GetCurTask().FinishFrame;
            //触发了卡位，具体卡位规则去卡位战术里做

            this.player.SetCurrentTask(gt);


            return BehaviourTreeStatus.Success;
        }
    }
}
