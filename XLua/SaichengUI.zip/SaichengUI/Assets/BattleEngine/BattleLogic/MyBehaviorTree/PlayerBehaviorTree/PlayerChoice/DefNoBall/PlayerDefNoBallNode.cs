﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDefNoBallNode : PlayerChoiceBaseSequenceNode
    {

        public PlayerDefNoBallNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            Player myPosAtker = this.player.GetMyPosAttacker();
            if (this.gameInfo.Ball.Owner != null )
            {
                if (myPosAtker == null || !myPosAtker.IsSamePlayer(this.gameInfo.Ball.Owner))
                {
                    return true;
                }
            }
            else if (this.gameInfo.Ball.OwnTeam != null)
            {
                if (this.gameInfo.Ball.OwnTeam != this.player.OwnerTeam)
                {
                    return true;
                }
            }
           
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerDefNoBallChoiceNode("防无球人选择", this.gameInfo);
        }
    }
}
