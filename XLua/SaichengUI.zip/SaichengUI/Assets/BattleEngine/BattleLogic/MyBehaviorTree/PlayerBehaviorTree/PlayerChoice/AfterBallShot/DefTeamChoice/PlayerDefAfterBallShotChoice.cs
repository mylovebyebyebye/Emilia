﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDefAfterBallShotChoice : PlayerChoiceBaseSelector
    {
        public PlayerDefAfterBallShotChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            PlayerDefLuoWeiChoiceNode luowei = new PlayerDefLuoWeiChoiceNode("落位防守", this.gameInfo);
            this.AddChild(luowei);


            ActionNode standBy = new ActionNode("待机", this.StandBy);
            this.AddChild(standBy);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            gt.FinishFrame = TimeFrameConverter.GetFrame(Player.MaxDefRelationTime);

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
