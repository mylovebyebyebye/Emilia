﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class PlayerFadeAwayAtkChoice : PlayerChoiceBaseSelector
    {
        public PlayerFadeAwayAtkChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            PlayerFadeAwayAtkFouled foul = new PlayerFadeAwayAtkFouled("犯规", this.gameInfo);
            this.AddChild(foul);

            PlayerFadeAwayAtkShot shot = new PlayerFadeAwayAtkShot("出手", this.gameInfo);
            this.AddChild(shot);

            ActionNode flyToShot = new ActionNode("向投篮点移动", this.MoveToBasket);
            this.AddChild(flyToShot);
        }

        private BehaviourTreeStatus MoveToBasket(TimeData time)
        {
            //计算出手点
            Position basket = this.gameInfo.AttackTeam.AttackBasket;
            double moveTime = (ParameterManager.Instance.GetValue(ParameterEnum.FadeAwayMoveTimeParam1) * 1.0f +
                             this.player.GetAttribute(PlayerAttribute.FadeAway) * ParameterManager.Instance.GetValue(ParameterEnum.FadeAwayMoveTimeParam2)) / 1000;
            double moveSpeed = ParameterManager.Instance.GetValue(ParameterEnum.FadeAwayMoveSpeed) * 1.0f;

            double dis = moveTime * moveSpeed;
            //面对篮筐，往后跳
            Position p1 = Formula.ClosestIntersection(this.player.GetCurTask().RecordPos, Position.GetPix(dis), basket, this.player.GetCurTask().RecordPos, true);

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = p1;
            gt.FinishFrame = gt.CalcRealTargetByTimeSpeed(0.1f, Position.GetPix(moveSpeed));
            gt.SpeedLevel = this.player.GetSpeedLevelByRealSpeed(Position.GetPix(moveSpeed));

            gt.NextTask = TaskType.PlayerBeginFadeAway;
            gt.RecordPos = this.player.GetCurTask().RecordPos;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
