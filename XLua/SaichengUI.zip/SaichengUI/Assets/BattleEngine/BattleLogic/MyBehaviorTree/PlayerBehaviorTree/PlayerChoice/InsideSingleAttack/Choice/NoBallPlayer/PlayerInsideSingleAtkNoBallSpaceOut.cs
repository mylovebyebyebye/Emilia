﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    /// <summary>
    /// 拉开
    /// </summary>
    public class PlayerInsideSingleAtkNoBallSpaceOut : PlayerBaseChoiceNode
    {
        private Position targetPos;

        public PlayerInsideSingleAtkNoBallSpaceOut(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

       
        private Position GetSpaceOutTarget()
        {
            Field atkField = this.player.OwnerTeam.AttackField;
            int cutOffPoint = ParameterManager.Instance.GetValue(ParameterEnum.SpaceOutCutOffPoint);
            Position p1 = Position.Empty;
            if (this.player.GetAttribute(PlayerAttribute.JumpShot3) > cutOffPoint)
            {
                double disToBasket = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, atkField, this.player);
                if (atkField.Is3P(this.player.Pos, disToBasket))
                {
                    //如果在三分线外就不用拉开了
                    return p1;
                }
                double radius = 0f;
                if (atkField.IsCorner(this.player.Pos))
                {
                    //如果在角里, 上下移动即可
                    Position basketPos = atkField.GetBasketPos();
                    if (this.player.Pos.Y < basketPos.Y)
                    {
                        // 向上移动
                        p1 = new Position(this.player.Pos.X, basketPos.Y - atkField.Corner3PDistance - 1);
                    }
                    else
                    {
                        //向下移动
                        p1 = new Position(this.player.Pos.X, basketPos.Y + atkField.Corner3PDistance + 1);
                    }
                }
                else
                {
                    //否则直接3分线外
                    radius = atkField.TopOfTheCircle3PDistance + 1;
                    p1 = Formula.ClosestIntersection(atkField.GetBasketPos(), radius, this.player.Pos, atkField.GetBasketPos());
                }
            }
            else
            {
                //目标点在直线上单打人【内线单打要球点】到篮筐的距离加上P_119（当前为200cm）的位置
                Player singleAtker = this.player.OwnerTeam.SingleAttacker;
                if (singleAtker.GetCurTask().RecordPos != Position.Empty)
                {
                    double dis = singleAtker.GetCurTask().RecordPos.DistanceActualLength(atkField.GetBasketPos());

                    double radius = (double)dis + ParameterManager.Instance.GetValue(ParameterEnum.DefRangeRadius);

                    p1 = Formula.ClosestIntersection(atkField.GetBasketPos(), Position.GetPix(radius), this.player.Pos, atkField.GetBasketPos());
                }
            }
            return p1;
        }



        protected override bool IsMyCharge(TimeData time)
        {
            int random = this.gameInfo.RandomNext(1, 100);
            if (this.player.GetAttribute(PlayerAttribute.SpaceOut) >= random)
            {
                this.targetPos = this.GetSpaceOutTarget();
                if (this.targetPos != Position.Empty)
                {
                    //无球人距篮筐的距离大于【拉开目标点】到篮筐的距离，不执行【拉开】行为，进入【待机】行为
                    //double playerToBasket = this.player.Pos.Distance(this.player.OwnerTeam.AttackBasket);
                    double playerToBasket = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, this.player.OwnerTeam.AttackField, this.player);
                    double targetToBasket = this.targetPos.Distance(this.player.OwnerTeam.AttackBasket);
                    if (playerToBasket < targetToBasket)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            int speedLevel = SpeedManager.Instance.GetSpeedNormal(this.player, this.gameInfo.RandomSpeed());

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveToSpaceOut;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = this.targetPos;
            gt.SpeedLevel = speedLevel;
            gt.FinishFrame = gt.CalcTimeBySpeed( this.player.GetSpeedByLevel(speedLevel) );
            gt.NextTask = TaskType.PlayerInsideSingleAttack;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
