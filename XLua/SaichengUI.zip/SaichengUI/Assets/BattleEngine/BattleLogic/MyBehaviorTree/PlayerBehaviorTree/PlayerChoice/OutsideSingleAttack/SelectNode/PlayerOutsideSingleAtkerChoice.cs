﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerOutsideSingleAtkerChoice : PlayerChoiceBaseSelector
    {
        private TacStandby tac;
        public PlayerOutsideSingleAtkerChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacStandby(this.gameInfo, this.name);
        }

        protected override void CreateChildNode()
        {
            //队友全部选择完才能进选择流程
            //没选择的话什么事也不干
            PlayerOutsideSingleAtkerDoNothing doNothing = new PlayerOutsideSingleAtkerDoNothing("什么也不做", this.gameInfo);
            this.AddChild(doNothing);

            PlayerOutsideSingleAtkerAskBall askBall = new PlayerOutsideSingleAtkerAskBall("要球", this.gameInfo);
            this.AddChild(askBall);

            ActionNode isAnyBodyCover = new ActionNode("是否有人在掩护", this.IsAnyBodyCover);
            this.AddChild(isAnyBodyCover);

            //突破
            PlayerOutsideSingleAtkerCrossOver crossOver = new PlayerOutsideSingleAtkerCrossOver("突破", this.gameInfo);
            this.AddChild(crossOver);

            ActionNode standBy = new ActionNode("待机", this.StandBy);
            this.AddChild(standBy);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            this.tac.Do(this.player, TimeFrameConverter.GetFrame(Player.MaxDefRelationTime));

            return BehaviourTreeStatus.Success;
        }

        private BehaviourTreeStatus IsAnyBodyCover(TimeData time)
        {
            bool isAnyBodyCover = false;
            for (int i = 0; i < this.player.OwnerTeam.PlayerCount; i++)
            {
                Player otherPlayer = this.player.OwnerTeam.Players[i];
                if (!otherPlayer.IsSamePlayer(this.player))
                {
                    if (otherPlayer.GetCurTask().TaskType == TaskType.PlayerCover ||
                        otherPlayer.GetCurTask().NextTask == TaskType.PlayerCover)
                    {
                        isAnyBodyCover = true;
                        break;
                    }
                }
            }

            if (isAnyBodyCover)
            {
                //有人在掩护就等他掩护完
                this.tac.Do(this.player, TimeFrameConverter.GetFrame(Player.MaxDefRelationTime));
                this.player.GetCurTask().NextTask = TaskType.PlayerOutsideSingleAttack;

                return BehaviourTreeStatus.Success;
            }
            else
            {
                return BehaviourTreeStatus.Failure;
            }
        }
    }
}
