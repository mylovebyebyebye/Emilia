﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerInsideSingleAtkMoveToBasket : PlayerBaseChoiceNode
    {
        public PlayerInsideSingleAtkMoveToBasket(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.gameInfo.Ball.Owner == this.player)
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            Position basketPos = this.player.OwnerTeam.AttackBasket;
            double disMax = ParameterManager.Instance.GetValue(ParameterEnum.InsideAtkAskBallMax);

            Position p1 = Formula.ClosestIntersection(basketPos, Position.GetPix(disMax), this.player.Pos, basketPos);
            int speedLevel = SpeedManager.Instance.GetSpeedNormal(this.player, this.gameInfo.RandomSpeed());

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = p1;
            gt.RecordPos = this.player.GetCurTask().RecordPos;
            gt.SpeedLevel = speedLevel;
            gt.FinishFrame = gt.CalcTimeBySpeed( this.player.GetSpeedByLevel(speedLevel) );
            gt.NextTask = TaskType.PlayerInsideSingleAttack;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
