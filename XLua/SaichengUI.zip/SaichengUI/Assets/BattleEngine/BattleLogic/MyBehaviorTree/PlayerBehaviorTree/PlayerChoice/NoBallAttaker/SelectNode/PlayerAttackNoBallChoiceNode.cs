﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerAttackNoBallChoiceNode : PlayerChoiceBaseSelector
    {

        public PlayerAttackNoBallChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            PlayerNoBallAtkerMoveToPresetChoice luowei = new PlayerNoBallAtkerMoveToPresetChoice("无球人落位", this.gameInfo);
            this.AddChild(luowei);

            PlayerHandlerOutOf3SChoice outOf3S = new PlayerHandlerOutOf3SChoice("无球人出3秒", this.gameInfo);
            this.AddChild(outOf3S);

            //PlayerMoveToPresetChoiceNode moveToPreset = new PlayerMoveToPresetChoiceNode("移动到预设区域", this.gameInfo);
            //this.AddChild(moveToPreset);

            PlayerAskBallChoiceNode askball = new PlayerAskBallChoiceNode("要球", this.gameInfo);
            this.AddChild(askball);

            //PlayerPaoweiChoice paowei = new PlayerPaoweiChoice("无球人跑位", this.gameInfo);
            //this.AddChild(paowei);

            ActionNode standby = new ActionNode("待机", this.StandBy);
            this.AddChild(standby);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            gt.FinishFrame = TimeFrameConverter.GetFrame(Player.MaxDefRelationTime);
            this.player.SetCurrentTask(gt);
            return BehaviourTreeStatus.Success;
        }

    }
}
