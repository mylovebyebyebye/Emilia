﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerBallHanlderNode : PlayerChoiceBaseSequenceNode
    {

        public PlayerBallHanlderNode(string name,  GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }


        protected override bool IsMyCharge(TimeData time)
        {
            if(this.player.IsSamePlayer(this.gameInfo.Ball.Owner))
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerHandlerChoiceNode("持球人选择", this.gameInfo);
        }
    }
}
