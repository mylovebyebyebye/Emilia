﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    /// <summary>
    /// 待机
    /// </summary>
    public class PlayerInsideAtkHanlderPreStandby : PlayerBaseChoiceNode
    {
        private TacStandby tac;
        public PlayerInsideAtkHanlderPreStandby(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacStandby(this.gameInfo, this.name);
        }


        protected override bool IsMyCharge(TimeData time)
        {
            //对位防守人不在待机状态，我就待机
            Player defPlayer = this.player.GetMyPosDefPlayer();
            if (defPlayer != null)
            {
                if (!defPlayer.IsInTask( TaskType.PlayerStandby))
                {
                    return true;
                }
            }

            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            double seconds = ParameterManager.Instance.GetValueD(ParameterEnum.InsideAttackAtkMoveTime) / 1000;


            Position record = this.player.GetCurTask().RecordPos.Clone();
            this.tac.DoMoveInSituBySeconds(this.player, seconds);
            this.player.GetCurTask().NextTask = TaskType.PlayerInsideAttackPrepare;
            this.player.GetCurTask().RecordPos = record;


            return BehaviourTreeStatus.Success;
        }
    }
}
