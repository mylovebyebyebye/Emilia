﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class PlayerAtkChoiceNode : PlayerChoiceBaseSequenceNode
    {

        public PlayerAtkChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(FluentBehaviourTree.TimeData time)
        {
            if (this.player.OwnerTeam == this.gameInfo.AttackTeam)
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerAtkSelector("进攻选择", this.gameInfo);
        }
    }
}
