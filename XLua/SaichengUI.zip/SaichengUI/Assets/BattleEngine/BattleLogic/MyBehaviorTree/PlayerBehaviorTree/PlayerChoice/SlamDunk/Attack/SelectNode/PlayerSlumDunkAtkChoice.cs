﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class PlayerSlumDunkAtkChoice : PlayerChoiceBaseSelector
    {
        public PlayerSlumDunkAtkChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            PlayerSlumDunkAtkBlockAgainst ba = new PlayerSlumDunkAtkBlockAgainst("被盖", this.gameInfo);
            this.AddChild(ba);

            PlayerSlumDunkAtkFouled fouled = new PlayerSlumDunkAtkFouled("犯规", this.gameInfo);
            this.AddChild(fouled);

            PlayerSlumDunkAtkDunk dunk = new PlayerSlumDunkAtkDunk("扣篮", this.gameInfo);
            this.AddChild(dunk);

            ActionNode moveToBasket = new ActionNode("向篮筐移动", this.MoveToBasket);
            this.AddChild(moveToBasket);
        }

        private BehaviourTreeStatus MoveToBasket(TimeData time)
        {
            Position basket = this.gameInfo.AttackTeam.AttackBasket;
            double playerArea = ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea) * 1.0f;
            double disToBasket = this.player.GetCurTask().RecordPos.DistanceActualLength(basket);
            double seconds = (ParameterManager.Instance.GetValue(ParameterEnum.SlamDunkBaseTime) * 1.0f + this.player.GetAttribute(PlayerAttribute.Dunk) * ParameterManager.Instance.GetValue(ParameterEnum.SlamDunkFlyTimeCOE)) / 1000;
            double speed = disToBasket / seconds;
            //移动速度及移动目的地
            double speedInPix = Position.GetPix(speed);
            Position p1 = Formula.ClosestIntersection(basket, Position.GetPix(playerArea), this.player.Pos, basket);

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = p1;
            gt.FinishFrame = gt.CalcRealTargetByTimeSpeed(0.1f, speedInPix);
            gt.SpeedLevel = this.player.GetSpeedLevelByRealSpeed(speedInPix);

            gt.NextTask = TaskType.PlayerBeginSlamDunk;
            gt.RecordPos = this.player.GetCurTask().RecordPos;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
