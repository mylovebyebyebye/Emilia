﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerOutsideSingleAtkerNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerOutsideSingleAtkerNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            Player singleAtker = this.gameInfo.AttackTeam.SingleAttacker;
            if (this.player.IsSamePlayer(singleAtker))
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerOutsideSingleAtkerChoice("外线单打人", this.gameInfo);
        }
    }
}
