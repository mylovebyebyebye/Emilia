﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 等待接球人要球
    /// </summary>
    public class PlayerAtkBallShotThrowInWait : PlayerBaseChoiceNode
    {

        public PlayerAtkBallShotThrowInWait(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.player.IsInTask( TaskType.PlayerToThrowIn))
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            //什么也不做
            return BehaviourTreeStatus.Success;
        }
    }
}
