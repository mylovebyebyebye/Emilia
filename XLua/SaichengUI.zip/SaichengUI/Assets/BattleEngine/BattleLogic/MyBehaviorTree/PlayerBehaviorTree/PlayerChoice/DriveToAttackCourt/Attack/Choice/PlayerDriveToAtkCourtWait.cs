﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDriveToAtkCourtWait : PlayerBaseChoiceNode
    {
        private double minInterval = 1f;
        private int lastProcessFrame = 0;
        private double waitTime = 0.4f;
        private int minIntervalFrame = 0;
        TacStandby tac;
        public PlayerDriveToAtkCourtWait(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacStandby(this.gameInfo, this.name);
            this.minIntervalFrame = TimeFrameConverter.GetFrame(this.minInterval);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            //不是控球最高且1秒内没干过这事
            if (!this.gameInfo.AttackTeam.MaxHanlder.IsSamePlayer(this.player) &&
                this.gameInfo.IsFramePassed(this.lastProcessFrame, minIntervalFrame) )
            {
                this.lastProcessFrame = this.gameInfo.GameFrame;
                return true;
            }
            return false; 
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.tac.Do(this.player, TimeFrameConverter.GetFrame(this.waitTime) );
            this.player.GetCurTask().NextTask = TaskType.PlayerDriveToAttackField;

            return BehaviourTreeStatus.Success;
        }
    }
}
