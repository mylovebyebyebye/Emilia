﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDefReboundNode : PlayerChoiceBaseSequenceNode
    {

        public PlayerDefReboundNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if ( this.player.IsInTask( TaskType.PlayerToGetRebound))
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerDefReboundChoiceNode("守方篮板选择", this.gameInfo);
        }
    }
}
