﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerOutsideSingleAttackNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerOutsideSingleAttackNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }


        protected override bool IsMyCharge(TimeData time)
        {
            if (this.player.IsInTask( TaskType.PlayerOutsideSingleAttack) &&
                this.player.OwnerTeam.SingleAttacker != null)
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerOutsideSingleAttackChoice("外线单打角色", this.gameInfo);
        }
    }
}
