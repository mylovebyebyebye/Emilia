﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class PlayerDefOutOfBoundThrowInChoice : PlayerChoiceBaseSelector
    {
        public PlayerDefOutOfBoundThrowInChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            PlayerDefOutOfBoundThrowInOneOneOne oneDef = new PlayerDefOutOfBoundThrowInOneOneOne("盯防", this.gameInfo);
            this.AddChild(oneDef);
        }
    }
}
