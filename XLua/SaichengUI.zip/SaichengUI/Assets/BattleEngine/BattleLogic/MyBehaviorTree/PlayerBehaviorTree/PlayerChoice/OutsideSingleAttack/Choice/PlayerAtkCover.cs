﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class PlayerAtkCover : PlayerBaseChoiceNode
    {
        public PlayerAtkCover(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            //是否进入掩护
            //1.人数在掩护上限人数之内
            //2.单打人的防守人数量=1
            //3.持球人到篮筐距离大于param475
            //4.持球人x坐标在一定范围内
            //符合以上条件才需要计算概率

            //1.
            if (!this.IsCoverNumInLimit())
            {
                return false;
            }
            //2.
            Player singleAtker = this.player.OwnerTeam.SingleAttacker;
            if (singleAtker.GetAllMyPosDefPlayers().Count != 1)
            {
                return false;
            }
            //3.
            //double disToBasket = singleAtker.Pos.DistanceActualLength(this.player.OwnerTeam.AttackBasket);
            double disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, this.player.OwnerTeam.AttackField, singleAtker);
            int minDis = ParameterManager.Instance.GetValue(ParameterEnum.CoverMinToBasket);
            if (disToBasket < minDis)
            {
                return false;
            }
            //4.
            int minX = ParameterManager.Instance.GetValue(ParameterEnum.CoverHandlerX1);
            int maxX = ParameterManager.Instance.GetValue(ParameterEnum.CoverHandlerX2);
            if (singleAtker.Pos.X < minX || singleAtker.Pos.X > maxX)
            {
                return false;
            }

            //计算自己的概率
            if (this.IsNeedToCover())
            {
                return true;
            }

            return false;
        }

        private bool IsCoverNumInLimit()
        {
            int count = 0;
            int maxCount = ParameterManager.Instance.GetValue(ParameterEnum.CoverMaxNum);
            for (int i = 0; i < this.player.OwnerTeam.PlayerCount; i++)
            {
                Player otherPlayer = this.player.OwnerTeam.Players[i];
                if (!otherPlayer.IsSamePlayer(this.player))
                {
                    if (otherPlayer.GetCurTask().TaskType == TaskType.PlayerCover ||
                        otherPlayer.GetCurTask().NextTask == TaskType.PlayerCover)
                    {
                        count++;
                    }
                }
            }
            if (count >= maxCount)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// 是否去掩护
        /// </summary>
        /// <returns></returns>
        private bool IsNeedToCover()
        {
            //进攻战术表
            ZDBTable tacOffTable = ZDataManager.Instance.GetTacticOffecnsiveTable();
            ZDB_Row_Data tacOffRow = tacOffTable.getDataByID((int)ETacticOff.BaseOff);
            int pickRollType = tacOffRow.getCol((int)tactic_offensiveFields.PickRollType).getValueInt();
            //挡拆参数表
            ZDBTable pickRollTable = ZDataManager.Instance.GetPickRollTable();
            ZDB_Row_Data rowData = pickRollTable.getDataByID(pickRollType);

            double pickRollAttr = this.player.GetAttribute(PlayerAttribute.PickRoll);
            int value = rowData.getCol((int)pickroll_typeFields.Value1 + this.player.Role - 1).getValueInt();
            double rollParam = rowData.getCol(this.player.Role + 1).getValueInt() * 1.0f;

            double pro = pickRollAttr / value + rollParam / 100;
            pro = pro * 10000;
            if (pro > this.gameInfo.RandomNext())
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerCover;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = this.player.Pos;
            gt.TargetPlayer = this.player.OwnerTeam.SingleAttacker;

            this.player.SetCurrentTask(gt);
            return BehaviourTreeStatus.Success;
        }
    }
}
