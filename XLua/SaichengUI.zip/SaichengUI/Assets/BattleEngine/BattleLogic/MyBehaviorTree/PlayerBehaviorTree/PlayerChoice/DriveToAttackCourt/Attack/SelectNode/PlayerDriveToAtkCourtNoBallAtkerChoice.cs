﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDriveToAtkCourtNoBallAtkerChoice : PlayerChoiceBaseSelector
    {
        TacStandby tac;
        public PlayerDriveToAtkCourtNoBallAtkerChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacStandby(this.gameInfo, this.name);
        }

        protected override void CreateChildNode()
        {
            PlayerDriveToAtkCourtFinish finish = new PlayerDriveToAtkCourtFinish("过半场结束",this.gameInfo);
            this.AddChild(finish);

            //出3秒
            PlayerDriveToAtkCourtMoveOut3S moveOut3S = new PlayerDriveToAtkCourtMoveOut3S("过半场出3秒", this.gameInfo);
            this.AddChild(moveOut3S);

            //跑位没有
            ActionNode paowei = new ActionNode("跑位", this.Paowei);
            this.AddChild(paowei);

            //落位
            PlayerBaseChoiceNode moveToPreset = new PlayerDriveToAtkCourtLuowei("落位", this.gameInfo);
            this.AddChild(moveToPreset);

            //待机400ms
            PlayerDriveToAtkCourtWait wait = new PlayerDriveToAtkCourtWait("待机400ms", this.gameInfo);
            this.AddChild(wait);

            //去接应区域
            PlayerDriveToAtkCourtMoveToAidArea move = new PlayerDriveToAtkCourtMoveToAidArea("移动到接球区域", this.gameInfo);
            this.AddChild(move);

            //要球
            PlayerDriveToAtkCourtAskBall askBall = new PlayerDriveToAtkCourtAskBall("要球", this.gameInfo);
            this.AddChild(askBall);

            ActionNode standby = new ActionNode("待机", this.StandBy);
            this.AddChild(standby);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            this.tac.Do(this.player, TimeFrameConverter.GetFrame(Player.MaxDefRelationTime));
            this.player.GetCurTask().NextTask = TaskType.PlayerDriveToAttackField;
            return BehaviourTreeStatus.Success;
        }

        private BehaviourTreeStatus Paowei(TimeData time)
        {
            if (this.player.LastDoTask != null &&
                this.player.LastDoTask.TaskType == TaskType.PlayerFastBreak)
            {
                this.player.SetCurrentTask(this.player.LastDoTask);
                this.player.GetCurTask().StartPos = this.player.Pos;
                return BehaviourTreeStatus.Success;
            }
            return BehaviourTreeStatus.Failure;
        }
    }
}
