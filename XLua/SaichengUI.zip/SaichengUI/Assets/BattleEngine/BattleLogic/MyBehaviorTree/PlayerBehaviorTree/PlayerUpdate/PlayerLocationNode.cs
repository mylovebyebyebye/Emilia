﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerLocationNode : PlayerBaseUpdateNode
    {
        public PlayerLocationNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerLocation;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            this.player.Pos = this.player.GetCurTask().RealTarget;
            return BehaviourTreeStatus.Success;
        }
    }
}
