﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 跑位的掩护
    /// </summary>
    public class PlayerCoverPaoweiSeqNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerCoverPaoweiSeqNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.player.IsInTask( TaskType.PlayerCoverPaowei))
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerCoverPaoweiSelector("掩护跑位选择", this.gameInfo);
        }
    }
}
