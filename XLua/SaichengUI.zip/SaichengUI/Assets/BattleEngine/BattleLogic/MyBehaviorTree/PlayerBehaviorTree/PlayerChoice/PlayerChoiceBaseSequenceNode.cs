﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public abstract class PlayerChoiceBaseSequenceNode : SequenceNode
    {
        protected Player player;
        protected PlayerChoiceBaseSelector choice;

        protected abstract bool IsMyCharge(TimeData time);

        protected abstract PlayerChoiceBaseSelector GetMySelector();

        protected PlayerChoiceBaseSequenceNode()
        {
            throw new Exception("this constructor is illegal");
        }

        public PlayerChoiceBaseSequenceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        public void SetPlayer(Player player)
        {
            this.player = player;
            this.choice.SetPlayer(this.player);
        }

        protected override void CreateChildNode()
        {
            ConditionNode isLocation = new ConditionNode("是否对位持球人", this.IsMyCharge);
            this.AddChild(isLocation);

            this.choice = this.GetMySelector();
            this.choice.SetPlayer(this.player);
            this.AddChild(choice);
        }
    }
}
