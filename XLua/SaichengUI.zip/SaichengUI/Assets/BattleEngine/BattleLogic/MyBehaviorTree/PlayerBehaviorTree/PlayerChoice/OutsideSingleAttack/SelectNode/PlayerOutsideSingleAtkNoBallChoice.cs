﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerOutsideSingleAtkNoBallChoice : PlayerChoiceBaseSelector
    {
        public PlayerOutsideSingleAtkNoBallChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }


        protected override void CreateChildNode()
        {
            //如果持球，待机
            PlayerOutsideSingleAtkNoBallStandby waitAskBall = new PlayerOutsideSingleAtkNoBallStandby("等待要球", this.gameInfo);
            this.AddChild(waitAskBall);

            //出三秒
            PlayerOutsideSingleAtkNoBallMoveOut3S moveOut3S = new PlayerOutsideSingleAtkNoBallMoveOut3S("外线单打出3秒", this.gameInfo);
            this.AddChild(moveOut3S);

            //掩护（for挡拆）
            PlayerAtkCover cover = new PlayerAtkCover("掩护",this.gameInfo);
            this.AddChild(cover);

            //拉开 
            PlayerOutsideSingleAtkNoBallSpaceOut spaceOut = new PlayerOutsideSingleAtkNoBallSpaceOut("拉开", this.gameInfo);
            this.AddChild(spaceOut);

            ActionNode standBy = new ActionNode("待机", this.StandBy);
            this.AddChild(standBy);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            //gt.NextTask = TaskType.PlayerOutsideSingleAttack; 
            gt.FinishFrame = TimeFrameConverter.GetFrame(Player.MaxDefRelationTime); 

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
