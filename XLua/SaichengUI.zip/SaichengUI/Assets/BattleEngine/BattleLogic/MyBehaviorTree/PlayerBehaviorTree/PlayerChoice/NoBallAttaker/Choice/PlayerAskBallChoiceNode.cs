﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerAskBallChoiceNode : PlayerBaseChoiceNode
    {
        private TacAskBall tac;

        public PlayerAskBallChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacAskBall(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            //后场，本方控球最高
            //前场，在预设区域内，且本方得分预期最高
            Player handler = this.gameInfo.Ball.Owner;

            if (this.player.IsSamePlayer(handler))
            {
                return false;
            }
            if (!this.gameInfo.IsInBounds(this.player.Pos))
            {
                return false;
            }
            //
            //1.	当前本方有持球人角色
            //2.	无球人得分期望大于【持球人得分期望】
            //3.	无球人得分期望大于【自身期望】
            if (this.tac.IsAskBall(this.player, handler))
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.tac.Do(this.player);

            return BehaviourTreeStatus.Success;
        }
    }
}
