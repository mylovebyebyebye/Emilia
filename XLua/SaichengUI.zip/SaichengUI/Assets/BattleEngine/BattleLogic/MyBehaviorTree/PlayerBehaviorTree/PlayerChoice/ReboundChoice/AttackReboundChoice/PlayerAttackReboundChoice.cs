﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerAttackReboundChoice : PlayerChoiceBaseSelector
    {
        TacStandby tac;
        TacLuowei tacLuoWei;
        public PlayerAttackReboundChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacStandby(this.gameInfo,this.name);
            this.tacLuoWei = new TacLuowei(this.gameInfo, this.name);
        }

        protected override void CreateChildNode()
        {

            PlayerReboundChoiceNode rebound = new PlayerReboundChoiceNode("篮板", this.gameInfo);
            this.AddChild(rebound);

            ActionNode backToDef = new ActionNode("退防", this.BackToDef);
            this.AddChild(backToDef);

            ActionNode standby = new ActionNode("待机", this.StandBy);
            this.AddChild(standby);
        }

        private BehaviourTreeStatus BackToDef(TimeData time)
        {
            this.tacLuoWei.Do(this.player, this.gameInfo.DefTeam.AttackField);
            return BehaviourTreeStatus.Success;
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            double maxTime = ParameterManager.Instance.GetValue(ParameterEnum.MaxStandbyTime) * 1.0f / 1000;
            int frame = this.gameInfo.Ball.GetCurTask().FinishFrame;
            if (frame > TimeFrameConverter.GetFrame(maxTime))
            {
                frame = TimeFrameConverter.GetFrame(maxTime);
            }
            this.tac.Do(this.player, frame);
            return BehaviourTreeStatus.Success;
        }
    }
}
