﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerAtkBallShotThrowInNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerAtkBallShotThrowInNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.player.IsInTask( TaskType.PlayerReadyToBallShotThrowIn) ||
                    this.player.IsInTask( TaskType.PlayerToThrowIn))
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerAtkBallShotThrowInChoice("进球界外球攻方选择", this.gameInfo);
        }
    }
}
