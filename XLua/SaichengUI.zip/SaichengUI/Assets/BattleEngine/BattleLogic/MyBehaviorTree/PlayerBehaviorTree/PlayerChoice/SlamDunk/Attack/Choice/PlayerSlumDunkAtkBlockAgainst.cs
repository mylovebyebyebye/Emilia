﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class PlayerSlumDunkAtkBlockAgainst : PlayerBaseChoiceNode
    {
        private Player blockPlayer;
        public PlayerSlumDunkAtkBlockAgainst(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {

        }

        protected override bool IsMyCharge(TimeData time)
        {
            //看看有没有人能盖我
            this.blockPlayer = null;
            double maxDis = ParameterManager.Instance.GetValue(ParameterEnum.InsideAttackDefDis) * 1.0f;
            double blockCOE =  ParameterManager.Instance.GetValue(ParameterEnum.BlockShotCOE) * 1.0f;
            double blockAgainstCOE =  ParameterManager.Instance.GetValue(ParameterEnum.BlockAgainstCOE) * 1.0f;
            int random = this.gameInfo.RandomNext();
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player defPlayer = this.gameInfo.DefTeam.Players[i];
                double disToMe = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, this.player, defPlayer);
                //double disToMe = this.player.Pos.DistanceActualLength(defPlayer.Pos);
                if (disToMe < maxDis)
                {
                    //范围内才需要算概率
                    double blockRate = defPlayer.GetAttribute(PlayerAttribute.Block) * blockCOE / (this.player.GetAttribute(PlayerAttribute.Dunk) * blockAgainstCOE) * 10000;
                    if (blockRate > random)
                    {
                        this.blockPlayer = defPlayer;
                        return true;
                    }
                }
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {

            //不管进没进，球都不属于这个人了
            this.gameInfo.ClearBallOwner();
            //盖帽
            GameEvent ge = new GameEvent(GameEventType.BlockShot);
            ge.Param1 = 2;
            ge.Param3 = (int)ShotType.SlumDunk;
            ge.Param4 = this.player;
            ge.Param5 = this.blockPlayer;
            this.gameInfo.AddGameEvent(ge);

            return BehaviourTreeStatus.Success;
        }
    }
}
