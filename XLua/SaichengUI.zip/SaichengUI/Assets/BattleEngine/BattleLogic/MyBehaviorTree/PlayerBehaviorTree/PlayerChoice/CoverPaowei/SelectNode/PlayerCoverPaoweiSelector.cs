﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerCoverPaoweiSelector : PlayerChoiceBaseSelector
    {
        private TacStandby tacStandby;
        private TacFoul tacFoul;
        private double standByTime = 0.1f;

        public PlayerCoverPaoweiSelector(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacStandby = new TacStandby(this.gameInfo, this.name);
            this.tacFoul = new TacFoul(this.gameInfo, this.name);
        }

        protected override void CreateChildNode()
        {
            ActionNode finish = new ActionNode("结束", this.Finish);
            this.AddChild(finish);

            ActionNode move = new ActionNode("移动去掩护(跑位)", this.MoveToCover);
            this.AddChild(move);

            ActionNode coverSuccess = new ActionNode("是否挡人成功", this.IsCoverSuccess);
            this.AddChild(coverSuccess);

            ActionNode standby = new ActionNode("待机", this.StandBy);
            this.AddChild(standby);
        }

        private BehaviourTreeStatus Finish(TimeData time)
        {
            Player targetPlayer = this.player.GetCurTask().TargetPlayer;
            if ( targetPlayer == null || !targetPlayer.IsInTask(TaskType.PlayerPositioning))
            {
                this.player.ClearTask();
                return BehaviourTreeStatus.Success;
            }
            return BehaviourTreeStatus.Failure;
        }

        /// <summary>
        /// 移动去掩护
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        private BehaviourTreeStatus MoveToCover(TimeData time)
        {
            //没到掩护位置就去位置
            if (Formula.IsCloseOverlap(this.player.Pos, this.player.GetCurTask().RecordPos))
            {
                return BehaviourTreeStatus.Failure;
            }

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = this.player.GetCurTask().RecordPos;
            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(player, this.gameInfo.RandomSpeed());
            double speed = this.player.GetSpeedByLevel(speedLevel);
            gt.SpeedLevel = speedLevel;

            gt.FinishFrame = gt.CalcTimeBySpeed(speed);
            gt.NextTask = TaskType.PlayerCoverPaowei;
            gt.RecordPos = this.player.GetCurTask().RecordPos.Clone();
            gt.TargetPlayer = this.player.GetCurTask().TargetPlayer;
             
            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }

        /// <summary>
        /// 挡人是否成功
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        private BehaviourTreeStatus IsCoverSuccess(TimeData time)
        {
            Player paoweiPlayer = this.player.GetCurTask().TargetPlayer;
            List<Player> defPlayers = paoweiPlayer.GetAllMyPosDefPlayers();
            double maxDis = ParameterManager.Instance.GetValueD(ParameterEnum.PlayerArea);

            bool success = false;
            Player coveredPlayer = null;
            for (int i = 0; i < defPlayers.Count; i++)
            {
                Player defPlayer = defPlayers[i];
                double dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, defPlayer, this.player);
                //double dis = defPlayer.Pos.DistanceActualLength(this.player.Pos);
                if (Formula.IsDisInPermissibleError(dis, maxDis))
                {
                    success = true;
                    coveredPlayer = defPlayer;
                    break;
                }
            }
            if (!success)
            {
                return BehaviourTreeStatus.Failure;
            }
            //挡人成功，进行判断
            //犯规
            if (this.tacFoul.IsFoul(EFoulType.CoverPaoweiAtkFoul, this.player, coveredPlayer))
            {
                this.gameInfo.AddPersoanlBoxScore(this.player, BoxScoreType.AtkFoulOnCoverPaowei, 1);

                GameEvent ge = new GameEvent(GameEventType.Foul);
                ge.Param1 = (int)FoulType.AttackFoul;
                ge.Param2 = 2;
                ge.Param4 = coveredPlayer;
                ge.Param5 = this.player;
                this.gameInfo.AddGameEvent(ge);
                
            }
            else if (this.tacFoul.IsFoul(EFoulType.CoverPaowei, this.player, coveredPlayer))
            {
                this.gameInfo.AddPersoanlBoxScore(coveredPlayer, BoxScoreType.FoulOnCoverPaowei, 1);

                GameEvent ge = new GameEvent(GameEventType.Foul);
                ge.Param1 = (int)FoulType.Normal;
                ge.Param2 = 2;
                ge.Param4 = this.player;
                ge.Param5 = coveredPlayer;
                this.gameInfo.AddGameEvent(ge);
            }
            else
            {
                //上debuff，其实就是被挡的人慢走
                //被挡的人
                GameTask taskOld = coveredPlayer.GetCurTask();
                double seconds = ParameterManager.Instance.GetValueD(ParameterEnum.CoverPaoweiMoveTime) / 1000;
                int speedLevel = ParameterManager.Instance.GetValue(ParameterEnum.CoveredPaoweiMoveSpeedLevel);
                int deltaX = coveredPlayer.Pos.X - taskOld.StartPos.X;
                int deltaY = coveredPlayer.Pos.Y - taskOld.StartPos.Y;
                Position target = new Position(taskOld.TargetPos.X + deltaX, taskOld.TargetPos.Y + deltaY);
                double speedInPixel = coveredPlayer.GetSpeedInPixelByLevel(speedLevel);


                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.PlayerMoveTo;
                gt.StartPos = coveredPlayer.Pos;
                gt.TargetPos = target;
                gt.SpeedLevel = speedLevel;
                gt.FinishFrame =  gt.CalcRealTargetByTimeSpeed(seconds, speedInPixel);
                coveredPlayer.SetCurrentTask(gt);

                //自己原地移动
                this.tacStandby.DoMoveInSituBySeconds(this.player, seconds);
            }

            return BehaviourTreeStatus.Success;
        }

        /// <summary>
        /// 原地移动
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        private BehaviourTreeStatus StandBy(TimeData time)
        {
            Player targetPlayer = this.player.GetCurTask().TargetPlayer;
            Position record = this.player.GetCurTask().RecordPos.Clone();

            this.tacStandby.DoMoveInSituBySeconds(this.player, this.standByTime);
            this.player.GetCurTask().NextTask = TaskType.PlayerCoverPaowei;
            this.player.GetCurTask().RecordPos = record;
            this.player.GetCurTask().TargetPlayer = targetPlayer;

            return BehaviourTreeStatus.Success;
        }
    }
}
