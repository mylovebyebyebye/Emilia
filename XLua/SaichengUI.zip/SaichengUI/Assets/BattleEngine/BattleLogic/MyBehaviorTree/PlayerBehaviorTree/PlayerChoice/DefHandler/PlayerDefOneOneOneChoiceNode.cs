﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerDefOneOneOneChoiceNode : PlayerDefHanlderChoiceBaseNode
    {
        public PlayerDefOneOneOneChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            ConditionNode isOneOneOne = new ConditionNode("是否跟防", this.IsOneOneOne);
            this.AddChild(isOneOneOne);

            ActionNode defOneOneOne = new ActionNode("跟防策略", this.DefOneOneOne);
            this.AddChild(defOneOneOne);
        }

        protected virtual bool IsOneOneOne(TimeData time)
        {
            return true;
        }

        protected virtual BehaviourTreeStatus DefOneOneOne(TimeData time)
        {
            Player attacker = this.player.GetMyPosAttacker();
           
            //见文档防守。 盯人
            //先计算Radius

            //跟防，站在篮筐跟进攻球员之间
            this.SetDefTask(this.player, attacker);  
            return BehaviourTreeStatus.Success;
        }

        protected void SetDefTask(Player defPlayer,Player attacker)
        {
            Field attackField = this.gameInfo.AttackTeam.AttackField;

            Position p1 = this.GetTargetPos(attackField, attacker);
            if (p1 == Position.Empty)
            {
                return;
            }

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerOneOneOneDef;
            if (this.IsNeedDelay(attacker))
            {
                gt.DelayStart = this.GetDelayFrame();
            }
            gt.StartPos = this.player.Pos;
            gt.TargetPos = p1;
            gt.TargetPlayer = attacker;

            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(player, this.gameInfo.RandomSpeed());
            double speedInPixel = defPlayer.GetSpeedInPixelByLevel(speedLevel);
            gt.FinishFrame = gt.CalcRealTargetBySpeedMaxSeconds(ref speedInPixel, Player.MaxDefRelationTime);
            gt.SpeedLevel = defPlayer.GetSpeedLevelByRealSpeed(speedInPixel);

            defPlayer.SetCurrentTask(gt);
        }

        /// <summary>
        /// 获取防守目标位置
        /// 由于有多人防守同一个人，为了不重叠，增加了几个位置
        /// </summary>
        /// <param name="attackField"></param>
        /// <param name="atkPlayer"></param>
        /// <returns></returns>
        private Position GetTargetPos(Field attackField, Player atkPlayer )
        {
            Position p1 = Position.Empty;
            Position basket = attackField.GetBasketPos();
            double defDis = this.GetDefDistance(atkPlayer, attackField);


            List<Player> lstDefPlayer = atkPlayer.GetAllMyPosDefPlayers();
            if (lstDefPlayer.Count == 1 || 
                (lstDefPlayer.Count > 1 && this.player.IsSamePlayer(lstDefPlayer[0]) ) )
            {
                //只有一个防守球员 或者 我是第一个防守球员
                //处于默认防守位置
                p1 = Formula.ClosestIntersection(attackField.GetBasketPos(), defDis, atkPlayer.Pos, basket);
            }
            else if(lstDefPlayer.Count > 1)
            {
                double disAtkToBasket = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, attackField, atkPlayer);
                //double disAtkToBasket = atkPlayer.Pos.Distance(basket);
                defDis = (double)disAtkToBasket - defDis;

                //大于1个，且不是第一个
                for (int i = 1; i < lstDefPlayer.Count; i++)
                {
                    if(this.player.IsSamePlayer(lstDefPlayer[i]))
                    {
                        int offAngle = this.GetOffAngle(i);
                        Vector2D v = new Vector2D(atkPlayer.Pos, basket);
                        double slopeAngle = v.GetSlopeAngle();

                        double realAngle = slopeAngle + offAngle;

                        p1 = atkPlayer.Pos.GetPosByAngleRadius(realAngle, (int)(defDis * Position.ActualLengthPerPoint));
                    }
                }
            }
            return p1;
        }

        /// <summary>
        /// 获取偏移角度
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        private int GetOffAngle(int index)
        {
            int angle = 0;
            switch (index)
            {
                case 1:
                    {
                        angle = ParameterManager.Instance.GetValue(ParameterEnum.DefAngleOffset1);
                    }
                    break;
                case 2:
                    {
                        angle = ParameterManager.Instance.GetValue(ParameterEnum.DefAngleOffset2);
                    }
                    break;
                case 3:
                    {
                        angle = ParameterManager.Instance.GetValue(ParameterEnum.DefAngleOffset3);
                    }
                    break;
                case 4:
                    {
                        angle = ParameterManager.Instance.GetValue(ParameterEnum.DefAngleOffset1);
                    }
                    break;
            }
            return angle;
        }
    }
}
