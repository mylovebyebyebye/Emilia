﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerOutsideSingleAtkNoBallNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerOutsideSingleAtkNoBallNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            Player singleAtker = this.gameInfo.AttackTeam.SingleAttacker;
            if (!this.player.IsSamePlayer(singleAtker) )
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerOutsideSingleAtkNoBallChoice("外线单打无球人", this.gameInfo);
        }
    }
}
