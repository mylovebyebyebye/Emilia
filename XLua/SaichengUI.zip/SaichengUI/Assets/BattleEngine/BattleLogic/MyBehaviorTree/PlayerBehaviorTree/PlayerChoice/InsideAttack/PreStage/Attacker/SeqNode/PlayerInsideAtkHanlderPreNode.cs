﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 内线进攻人
    /// 准备阶段
    /// </summary>
    public class PlayerInsideAtkHanlderPreNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerInsideAtkHanlderPreNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.gameInfo.Ball.Owner == this.player &&
                this.player.IsInTask( TaskType.PlayerInsideAttackPrepare ))
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerInsideAtkHandlerPreChoice("背打准备阶段进攻人", this.gameInfo);
        }
    }
}
