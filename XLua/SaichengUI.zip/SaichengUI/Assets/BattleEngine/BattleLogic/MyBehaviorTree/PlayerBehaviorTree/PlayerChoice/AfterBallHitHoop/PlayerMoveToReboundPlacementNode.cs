﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    /// <summary>
    /// 向篮板落点移动
    /// </summary>
    public class PlayerMoveToReboundPlacementNode : PlayerBaseChoiceNode
    {
        TacMoveToReboundPlacement tac;

        public PlayerMoveToReboundPlacementNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacMoveToReboundPlacement(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            int count = 0;
            for (int i = 0; i < this.player.OwnerTeam.PlayerCount; i++)
            {
                Player player = this.player.OwnerTeam.Players[i];
                if (player.IsInTask( TaskType.PlayerAfterBallHitMoveToBall))
                {
                    count++;
                }
            }
            //最多三名
            if (count >= 3)
            {
                return false;
            }

            //在落点143范围内有50%的几率
            int Radius = ParameterManager.Instance.GetValue(ParameterEnum.ReboundPlacement);
            double dis = this.player.Pos.DistanceActualLength(this.gameInfo.Ball.GetCurTask().TargetPos);
            if (Radius >= dis)
            {
                int random = this.gameInfo.RandomNext();
                if (random <= 5000)
                {
                    return true;
                }
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.tac.SetGetReboundTask(this.player, false);
            return BehaviourTreeStatus.Success;
        }
    }
}
