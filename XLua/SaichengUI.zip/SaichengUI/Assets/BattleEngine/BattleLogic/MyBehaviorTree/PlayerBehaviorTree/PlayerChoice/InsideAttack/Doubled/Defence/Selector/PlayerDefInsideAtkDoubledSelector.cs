﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class PlayerDefInsideAtkDoubledSelector : PlayerChoiceBaseSelector
    {
        private TacStandby tac;
        public PlayerDefInsideAtkDoubledSelector(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacStandby(this.gameInfo, this.name);
        }

        protected override void CreateChildNode()
        {
            //取消该状态
            ActionNode cancel = new ActionNode("取消该状态", this.Cancel);
            this.AddChild(cancel);

            ActionNode standBy = new ActionNode("待机", this.StandBy);
            this.AddChild(standBy);
        }

        private BehaviourTreeStatus Cancel(TimeData time)
        {
            Player attacker = this.player.GetCurTask().TargetPlayer;
            if (attacker == null || this.gameInfo.Ball.Owner != attacker)
            {
                //如果背打人已经不在背打了，就不在进行这个事情
                this.player.ClearTask();

                //待机一段再去选择做其他的事
                double standbyTime = this.player.GetAttribute(PlayerAttribute.React) / 1000;
                this.tac.DoMoveInSituBySeconds(this.player, standbyTime);

                return BehaviourTreeStatus.Success;
            }
            return BehaviourTreeStatus.Failure;
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            double seconds = ParameterManager.Instance.GetValueD(ParameterEnum.InsideAtkDoubledStandbyTime) / 1000;
            Player attacker = this.player.GetCurTask().TargetPlayer;

            //待机
            this.tac.Do(this.player, TimeFrameConverter.GetFrame(seconds));

            //待机之后继续这个
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerInsideAttackDoubled;
            gt.TargetPlayer = attacker;
            gt.DelayStart = 0;
            gt.FinishFrame = 0;

            this.player.NextTask.Add(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
