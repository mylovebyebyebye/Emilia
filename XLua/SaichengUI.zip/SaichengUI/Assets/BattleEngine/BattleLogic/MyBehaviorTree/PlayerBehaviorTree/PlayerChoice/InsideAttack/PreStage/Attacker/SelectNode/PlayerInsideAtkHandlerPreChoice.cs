﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerInsideAtkHandlerPreChoice : PlayerChoiceBaseSelector
    {
        private TacInsideAttack tac;

        public PlayerInsideAtkHandlerPreChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacInsideAttack(this.gameInfo, this.name);
        }

        protected override void CreateChildNode()
        {
            //上篮
            PlayerInsideAtkHandlerPreLayUp layup = new PlayerInsideAtkHandlerPreLayUp("上篮", this.gameInfo);
            this.AddChild(layup);

            //向篮筐移动
            PlayerInsideAtkHandlerPreMoveToBasket moveToBasket = new PlayerInsideAtkHandlerPreMoveToBasket("向篮筐移动", this.gameInfo);
            this.AddChild(moveToBasket);

            //待机
            PlayerInsideAtkHanlderPreStandby standby = new PlayerInsideAtkHanlderPreStandby("待机", this.gameInfo);
            this.AddChild(standby);

            //进入背打
            ActionNode insideAttack = new ActionNode("进入背打流程", this.InsideAttack);
            this.AddChild(insideAttack);
        }

        protected BehaviourTreeStatus InsideAttack(TimeData time)
        {
            this.tac.Do(this.player);

            return BehaviourTreeStatus.Success;
        }


    }
}
