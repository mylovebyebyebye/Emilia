﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    /// <summary>
    /// 向落位位置移动
    /// </summary>
    public class PlayerInsideAtkDefPreMoveToLuoWei : PlayerBaseChoiceNode
    {
        private Position targetPos;

        public PlayerInsideAtkDefPreMoveToLuoWei(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            this.targetPos = Position.Empty;
            Player attacker = this.player.GetMyPosAttacker();
            //落位位置，进攻人与篮筐连线 , 与以进攻人为圆心，圆柱体为半径的圆的交点
            double radius = ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea) * 1.0f;
            Position p1 = Formula.ClosestIntersection(attacker.Pos, Position.GetPix(radius), this.gameInfo.AttackTeam.AttackBasket, attacker.Pos);
            if (p1 != Position.Empty && !p1.IsInPermissibleError(this.player.Pos))
            {
                this.targetPos = p1;
                return true;
            }

            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            double seconds = ParameterManager.Instance.GetValueD(ParameterEnum.InsideAttackDefMoveTime) / 1000;

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = this.targetPos;
            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(player, this.gameInfo.RandomSpeed());
            double speed = player.GetSpeedInPixelByLevel(speedLevel);
            gt.FinishFrame = gt.CalcRealTargetBySpeedMaxSeconds(ref speed, seconds);
            gt.SpeedLevel = this.player.GetSpeedLevelByRealSpeed(speed);
            gt.NextTask = TaskType.PlayerInsideAttackPrepare;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
