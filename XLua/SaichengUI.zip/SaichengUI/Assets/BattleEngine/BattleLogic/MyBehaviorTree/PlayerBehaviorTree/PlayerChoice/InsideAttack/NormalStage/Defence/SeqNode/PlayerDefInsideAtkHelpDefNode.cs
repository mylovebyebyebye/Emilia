﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 背打协防
    /// 协防人
    /// </summary>
    public class PlayerDefInsideAtkHelpDefNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerDefInsideAtkHelpDefNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.player.IsInTask( TaskType.PlayerInsideAttackHelpDefence))
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerDefInsideAtkHelpDefSelector("协防人选择", this.gameInfo);
        }
    }
}
