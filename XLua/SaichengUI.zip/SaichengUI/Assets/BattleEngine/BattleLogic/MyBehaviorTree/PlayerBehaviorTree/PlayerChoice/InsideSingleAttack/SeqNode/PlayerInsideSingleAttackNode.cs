﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerInsideSingleAttackNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerInsideSingleAttackNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }


        protected override bool IsMyCharge(TimeData time)
        {
            if (this.player.IsInTask( TaskType.PlayerInsideSingleAttack) &&
                this.player.OwnerTeam.SingleAttacker != null)
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerInsideSingleAttackChoice("内线单打角色", this.gameInfo);
        }
    }
}
