﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerTakePosMove : PlayerBaseUpdateNode
    {
        TacStandby tac;

        public PlayerTakePosMove(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacStandby(this.gameInfo,this.name);
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerTakePosMove;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            TaskMoveTo.Do(this.player);
            //抢位后的移动，最后一帧变成静止
            if (this.player.GetCurTask().FinishFrame == 1)
            {
                this.tac.Do(this.player, this.tac.GetMaxStandbyFrame());
            }
            return BehaviourTreeStatus.Success;
        }
    }
}
