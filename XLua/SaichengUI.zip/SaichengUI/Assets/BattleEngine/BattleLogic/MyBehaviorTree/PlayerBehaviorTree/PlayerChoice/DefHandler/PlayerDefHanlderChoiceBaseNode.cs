﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.ZDB;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDefHanlderChoiceBaseNode : PlayerBaseChoiceNode
    {
        public PlayerDefHanlderChoiceBaseNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected bool IsNeedDelay(Player player)
        {
            List<TaskType> lstNeedDelay = new List<TaskType>();
            lstNeedDelay.Add(TaskType.PlayerDriveToTheBasket);
            lstNeedDelay.Add(TaskType.PlayerShot);

            GameTask gt = player.GetCurTask();
            if (gt != null && lstNeedDelay.Contains(gt.TaskType))
            {
                return true;
            }
            return false;
        }

        protected int GetDelayFrame()
        {
            return TimeFrameConverter.GetFrame(this.GetDelaySeconds());  
        }

        protected double GetDelaySeconds()
        {
            return ParameterManager.Instance.GetValue(ParameterEnum.CrossOverReactionTime) * 1.0f / 1000;
        }

        protected double GetDefDistance(Player attacker, Field field)
        {
            //计算防守调整随机值，这个每个24秒算一次
            this.CalcDefDistanceRandom();
            
            double defDis = 0f;
            double distance = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, field, attacker);
            double distanceCM = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, field, attacker);
            //double distance = basket.Distance(attackPos);
            //double distanceCM = basket.DistanceActualLength(attackPos);
            if (attacker.OwnerTeam.AttackField.Is3P(attacker.Pos, distance))
            {
                if (attacker.DefParam.IsNeedDef3P)
                {
                    //3分线外，看是否要防3分
                    defDis = this.Get3PDefDistance(attacker, distanceCM);
                }
                else if (attacker.DefParam.IsNeedDef2P)
                {
                    //3分线外，看是否防2分
                    defDis = this.Get2PDefDistance(attacker, distanceCM);
                }
                else
                {
                    //直接放篮下
                    defDis = this.Get3SLineDistance(attacker, distanceCM);
                }
            }
            else if (distanceCM >= 424)
            {
                if (attacker.DefParam.IsNeedDef2P)
                {
                    //看是否防2分
                    defDis = this.Get2PDefDistance(attacker, distanceCM);
                }
                else
                {
                    //直接放篮下
                    defDis = this.Get3SLineDistance(attacker, distanceCM);
                }
            }
            else
            { 
                //篮下防守
                defDis = this.Get3SLineDistance(attacker, distanceCM);
            }
            defDis = Position.GetPix(defDis);
            return defDis;
        }

        private void CalcDefDistanceRandom()
        {
            if (this.player.CalcDefDisRound != this.gameInfo.CurRound.StartFrame)
            {
                this.player.DefDis = Formula.GetDefDistanceRandom(this.player, this.gameInfo);
                this.player.CalcDefDisRound = this.gameInfo.CurRound.StartFrame;
            }
        }

        private double Get3PDefDistance(Player attacker, double distanceToBasket)
        {
            //S - 150+r
            double S = attacker.DefParam.Def3PDistance;
            if (S > distanceToBasket)
            {
                S = distanceToBasket;
            }
            double dis = S - 150 + this.player.DefDis;
            return dis;
        }

        private double Get2PDefDistance(Player attaker, double distanceToBasket)
        {
            //S - 150+r
            double S = attaker.DefParam.Def2PDistance;
            if (S > distanceToBasket)
            {
                S = (double)distanceToBasket;
            }
            double dis = S - 100 + this.player.DefDis;
            return dis;
        }

        private double Get3SLineDistance(Player attaker, double distanceToBasket)
        {
            //324 + r 或者S
            double S = attaker.DefParam.Def3SecondLineDistance + this.player.DefDis;
            if (S > distanceToBasket)
            {
                S = (double)distanceToBasket - 50f;
            }
            return S;
        }

        protected override bool IsMyCharge(TimeData time)
        {
            throw new NotImplementedException();
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            throw new NotImplementedException();
        }
    }
}
