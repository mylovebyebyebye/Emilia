﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    /// <summary>
    /// 出三秒
    /// </summary>
    public class PlayerHandlerOutOf3SChoice : PlayerBaseChoiceNode
    {
        TacMoveOut3SArea tac;
        public PlayerHandlerOutOf3SChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacMoveOut3SArea(this.gameInfo, this.name);
        }


        protected override bool IsMyCharge(TimeData time)
        {
            return this.player.IsNeedOut3S();
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.tac.Do(this.player);
            return BehaviourTreeStatus.Success;
        }
    }
}
