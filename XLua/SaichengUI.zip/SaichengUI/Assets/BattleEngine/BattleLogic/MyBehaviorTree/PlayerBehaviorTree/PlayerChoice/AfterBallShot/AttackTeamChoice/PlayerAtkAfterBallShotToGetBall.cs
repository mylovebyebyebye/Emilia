﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 原地要球
    /// </summary>
    public class PlayerAtkAfterBallShotToGetBall : PlayerBaseChoiceNode
    {
        public PlayerAtkAfterBallShotToGetBall(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }


        protected override bool IsMyCharge(TimeData time)
        {
            //这个接在移动要球之后，所以只要判是PG就行了
            //是攻方PG
            if (this.player.Role == (int)PlayerRole.PG)
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandToGetBall;
            gt.FinishFrame = TimeFrameConverter.GetFrame(Player.MaxDefRelationTime);

            player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
