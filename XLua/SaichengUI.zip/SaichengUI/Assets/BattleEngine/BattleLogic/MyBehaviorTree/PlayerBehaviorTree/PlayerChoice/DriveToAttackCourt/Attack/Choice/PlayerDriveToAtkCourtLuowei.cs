﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    /// <summary>
    /// 落位
    /// </summary>
    public class PlayerDriveToAtkCourtLuowei : PlayerBaseChoiceNode
    {
        TacDriveToAtkCourt tacDrive;
        TacLuowei tacLuowei;
        public PlayerDriveToAtkCourtLuowei(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacDrive = new TacDriveToAtkCourt(this.gameInfo, this.name);
            this.tacLuowei = new TacLuowei(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {

            Player handler = this.gameInfo.Ball.Owner;
            if (handler == null)
            {
                handler = this.gameInfo.Ball.GetCurTask().TargetPlayer;
            }

            if (this.tacDrive.GetPro(this.player) <= 0)
            {
                //不具备过半场能力，直接落位
                return true;
            }
            if ( !handler.IsInTask(TaskType.PlayerStandby) &&
                !handler.IsInTask( TaskType.PlayerDriveToAttackField))
            {
                //持球人不在待机，直接落位
                return true;
            }
            double dis = this.gameInfo.DisManager.GetDistanceInPixelToSameTeamPlayer(this.gameInfo.Frame, handler, this.player);
            for (int i = 0; i < this.gameInfo.AttackTeam.PlayerCount; i++)
            {
                Player other = this.gameInfo.AttackTeam.Players[i];
                if (!other.IsSamePlayer(this.player)
                    && !other.IsSamePlayer(handler)
                    && this.tacDrive.GetPro(other) > 0)
                {
                    double disOther = this.gameInfo.DisManager.GetDistanceInPixelToSameTeamPlayer(this.gameInfo.Frame, handler, other);
                    //有人比我离持球人近，那我也去落位
                    if (disOther < dis)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            //如果已在落位区域就待机，没在落位区域就去落位
            this.MoveToPresetArea();
            return BehaviourTreeStatus.Success;
        }


        private void MoveToPresetArea()
        {
            this.tacLuowei.Do(this.player);
        }
    }
}
