﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 什么也不做
    /// </summary>
    public class PlayerOutsideSingleAtkerDoNothing : PlayerBaseChoiceNode
    {
        public PlayerOutsideSingleAtkerDoNothing(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }


        protected override bool IsMyCharge(TimeData time)
        {
            bool res = false;
            //除了自己之外，只要有一个人没选择就符合
            for (int i = 0; i < this.player.OwnerTeam.PlayerCount; i++)
            {
                Player player = this.player.OwnerTeam.Players[i];
                if (!player.IsSamePlayer(this.player))
                {
                    if (player.IsInTask( TaskType.PlayerOutsideSingleAttack))
                    {
                        res = true;
                        break;
                    }
                }
            }
            return res;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            return BehaviourTreeStatus.Success;
        }
    }
}
