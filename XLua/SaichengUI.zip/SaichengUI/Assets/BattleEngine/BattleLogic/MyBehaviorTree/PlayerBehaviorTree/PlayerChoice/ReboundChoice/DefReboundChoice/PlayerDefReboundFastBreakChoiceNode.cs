﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDefReboundFastBreakChoiceNode : PlayerReboundChoiceNode
    {
        private TacFastBreak tac;
        public PlayerDefReboundFastBreakChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacFastBreak(this.gameInfo, this.name);
        }

        protected override void CreateChildNode()
        {
            ConditionNode isFastBreak = new ConditionNode("是否快下", this.IsToFastBreak);
            this.AddChild(isFastBreak);

            ActionNode toFastBreak = new ActionNode("快下", this.ToFastBreak);
            this.AddChild(toFastBreak);
        }

        private bool IsToFastBreak(TimeData time)
        {
            //这里有个隐藏东西， 离篮筐最近的三人才有可能下快攻
            if (this.player.GetCurTask().Param1 == 1)
            {
                if (this.tac.IsNeedFastBreak(this.player))
                {
                    return true;
                }
            }
            return false;
        }

        protected BehaviourTreeStatus ToFastBreak(TimeData time)
        {
            this.tac.Do(this.player);
            return BehaviourTreeStatus.Success;
        }
    }
}
