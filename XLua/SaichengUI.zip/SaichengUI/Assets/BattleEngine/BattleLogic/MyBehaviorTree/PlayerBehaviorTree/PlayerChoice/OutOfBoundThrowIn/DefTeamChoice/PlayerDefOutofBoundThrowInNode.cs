﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BattleLogic
{
    public class PlayerDefOutofBoundThrowInNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerDefOutofBoundThrowInNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(FluentBehaviourTree.TimeData time)
        {
            if ( this.player.IsInTask( TaskType.PlayerToThrowIn))
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerDefOutOfBoundThrowInChoice("界外球防守", this.gameInfo);
        }
    }
}
