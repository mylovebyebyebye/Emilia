﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerInsideSingleAttackChoice : PlayerChoiceBaseSelector
    {
        public PlayerInsideSingleAttackChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            PlayerInsideSingleAtkNoBallNode noball = new PlayerInsideSingleAtkNoBallNode("内线单打无球人", this.gameInfo);
            noball.SetPlayer(this.player);
            this.AddChild(noball);

            PlayerInsideSingleAtkerNode attacker = new PlayerInsideSingleAtkerNode("内线单打人", this.gameInfo);
            attacker.SetPlayer(this.player);
            this.AddChild(attacker);

            ActionNode standBy = new ActionNode("待机", this.StandBy);
            this.AddChild(standBy);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            gt.FinishFrame = TimeFrameConverter.GetFrame(Player.MaxDefRelationTime); 
            //gt.NextTask = TaskType.PlayerInsideSingleAttack; 

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
