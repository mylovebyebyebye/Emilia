﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerOutsideSingleAtkerCrossOver : PlayerBaseChoiceNode
    {
        TacAttackBasket tac;
        private TacInsideAttack tacInside;
        public PlayerOutsideSingleAtkerCrossOver(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacAttackBasket(this.gameInfo, this.name);
            this.tacInside = new TacInsideAttack(this.gameInfo, this.name);
        }


        protected override bool IsMyCharge(TimeData time)
        {
            //是否进行突破
            //处于持球状态， 且其他人都处于待机
            if (this.gameInfo.Ball.Owner == this.player)
            {
                for (int i = 0; i < this.player.OwnerTeam.PlayerCount; i++)
                {
                    Player player = this.player.OwnerTeam.Players[i];
                    if (!player.IsSamePlayer(this.player))
                    {
                        if (!player.IsInTask(TaskType.PlayerStandby))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.player.OwnerTeam.ClearSingleAttacker();
            //增加距离判断，距离小于param31 进行背打
            double param31 = ParameterManager.Instance.GetValueD(ParameterEnum.CrossOverMinDis);
            double disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, this.player.OwnerTeam.AttackField, this.player);
            if (disToBasket >= param31)
            {
                this.tac.Do(this.player);
            }
            else
            {
                this.tacInside.StartInsideAttack(this.player);
            }
            return BehaviourTreeStatus.Success;
        }
    }
}
