﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerFastBreakNode : PlayerBaseUpdateNode
    {
        private int lastCalcAskBall;
        private int calcAskBallInterval;
        private TacAskBall tac;

        public PlayerFastBreakNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.lastCalcAskBall = 0;
            this.calcAskBallInterval = TimeFrameConverter.GetFrame(Player.MaxDefRelationTime) + 1;
            this.tac = new TacAskBall(this.gameInfo, this.name);
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerFastBreak;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            Player handler = this.gameInfo.Ball.Owner;
            if (handler != null &&
                handler.OwnerTeam != this.player.OwnerTeam)
            {
                this.player.ClearTask();
                return BehaviourTreeStatus.Success;
            }

            TaskMoveTo.Do(this.player);


            if (handler != null &&
                !handler.IsSamePlayer(this.player) && 
                this.player.OwnerTeam.AskBallPlayer == null)
            {
                int startFrame = this.player.GetCurTask().Param3;
                if ( this.gameInfo.IsFramePassed(startFrame, this.calcAskBallInterval) &&
                     this.gameInfo.IsFramePassed(this.lastCalcAskBall, this.calcAskBallInterval) )
                {
                    //要跑了0.2秒以后，才每0.2秒开始算
                    this.lastCalcAskBall = this.gameInfo.GameFrame;

                    this.player.ForceCalcScoringExpect(this.gameInfo);
                    handler.ForceCalcScoringExpect(this.gameInfo);

                    if (this.tac.IsAskBall(this.player, handler))
                    {
                        this.tac.Do(this.player);
                    }
                }
            }

            return BehaviourTreeStatus.Success;
        }
    }
}
