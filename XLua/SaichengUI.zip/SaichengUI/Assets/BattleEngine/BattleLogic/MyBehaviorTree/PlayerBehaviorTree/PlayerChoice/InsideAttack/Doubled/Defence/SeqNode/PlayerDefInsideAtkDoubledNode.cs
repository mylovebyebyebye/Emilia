﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 背打包夹
    /// </summary>
    public class PlayerDefInsideAtkDoubledNode : PlayerChoiceBaseSequenceNode
    {
        public PlayerDefInsideAtkDoubledNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.player.IsInTask( TaskType.PlayerInsideAttackDoubled))
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerDefInsideAtkDoubledSelector("背打包夹选择", this.gameInfo);
        }
    }
}
