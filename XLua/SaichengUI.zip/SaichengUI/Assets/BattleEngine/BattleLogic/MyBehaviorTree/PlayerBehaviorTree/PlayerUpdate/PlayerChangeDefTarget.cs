﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerChangeDefTarget : PlayerBaseUpdateNode
    {

        public PlayerChangeDefTarget(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {

        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerChangeDefTarget;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            GameTask gt = this.player.GetCurTask();
            this.player.SetMyPosAttacker(gt.TargetPlayer);
            return BehaviourTreeStatus.Success;
        }
    }
}
