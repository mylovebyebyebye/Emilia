﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerSlumDunkDefChoice : PlayerChoiceBaseSelector
    {
        private TacStandby tac;
        public PlayerSlumDunkDefChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacStandby(this.gameInfo,this.name);
        }

        protected override void CreateChildNode()
        {
            PlayerSlumDunkDefMoveToDunkPos move = new PlayerSlumDunkDefMoveToDunkPos("向扣篮点移动", this.gameInfo);
            this.AddChild(move);

            ActionNode standBy = new ActionNode("待机", this.StandBy);
            this.AddChild(standBy);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            this.tac.Do(this.player, int.MaxValue);
            return BehaviourTreeStatus.Success;
        }
    }
}
