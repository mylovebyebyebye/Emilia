﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerLayupNode : PlayerBaseUpdateNode
    {
        public PlayerLayupNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerLayup;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            TaskMoveTo.Do(this.player);
            if (this.player.GetCurTask().FinishFrame == 1)
            {
                GameEvent gameEvent = new GameEvent(GameEventType.Layup);
                gameEvent.Param4 = this.player;
                gameInfo.AddGameEvent(gameEvent);
            }
            return BehaviourTreeStatus.Success;
        }
    }
}
