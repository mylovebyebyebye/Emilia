﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerNoBallAtkerMoveToPresetChoice : PlayerBaseChoiceNode
    {
        private TacLuowei tac;
        public PlayerNoBallAtkerMoveToPresetChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacLuowei(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            //在界外
            if (!this.gameInfo.IsInBounds(this.player.Pos))
            {
                return true;
            }
            //double dis = this.player.Pos.DistanceActualLength(this.player.OwnerTeam.AttackBasket);
            double dis = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, this.player.OwnerTeam.AttackField, this.player);
            if (dis > 900)
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.tac.Do(this.player);

            return BehaviourTreeStatus.Success;
        }
    }
}
