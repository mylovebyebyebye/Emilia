﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerCoverMove : PlayerBaseChoiceNode
    {
        private TacPickRoll tac;
        public PlayerCoverMove(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacPickRoll(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            //1.持球人防守人必须待机
            //2.24秒计时小于挡拆参数
            //3. （1）结束时间大于120秒 （2）进攻方落后 （3）进攻时间小于6秒 三者满足其中之一
            //1.2.3取交集

            Player handler = this.gameInfo.Ball.Owner;
            //1.持球人防守人必须待机
            if (handler == null)
            {
                return false;
            }
            List<Player> defPlayers = handler.GetAllMyPosDefPlayers();
            for (int i = 0; i < defPlayers.Count; i++)
            {
                Player defPlayer = defPlayers[i];
                if (defPlayer.GetCurTask().SpeedLevel > 0)
                {
                    return false;
                }
            }
            //2.24秒计时小于挡拆参数
            ZDBTable tacOffTable = ZDataManager.Instance.GetTacticOffecnsiveTable();
            ZDB_Row_Data tacOffRow = tacOffTable.getDataByID((int)ETacticOff.BaseOff);
            int pickRoll = tacOffRow.getCol((int)tactic_offensiveFields.PickRoll).getValueInt();
            if (this.gameInfo.CurRoundRemaingTime > pickRoll)
            {
                return false;
            }

            //3. 满足其中任何一个都可以

            //结束时间大于120秒 
            int param485 = ParameterManager.Instance.GetValue(ParameterEnum.PickRollTime1);
            if (this.gameInfo.QuarterTime > param485)
            {
                return true;
            }

            //进攻方落后
            int pointAtk = this.gameInfo.GetTotalPoint(this.gameInfo.AttackTeam.TeamType);
            int pointDef = this.gameInfo.GetTotalPoint(this.gameInfo.DefTeam.TeamType);
            if (pointAtk < pointDef)
            {
                return true;
            }
            //进攻时间小于6秒
            int param486 = ParameterManager.Instance.GetValue(ParameterEnum.PickRollTime2);

            if (this.gameInfo.CurRoundRemaingTime < param486)
            {
                return true;
            }

            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            Position target = this.GetPickRollTarget(this.gameInfo.Ball.Owner);
            if (Formula.IsCloseOverlap(this.player.Pos, target))
            {
                //触发挡拆
                //持球人、持球人防守人、掩护人、掩护人防守人，这4个人进入挡拆
                this.EnterPickRoll();
            }
            else
            {
                //向挡拆点移动
                double seconds = ParameterManager.Instance.GetValueD(ParameterEnum.PickRollMoveTime) / 1000;

                GameTask gt = new GameTask(this.name);
                gt.TaskType = TaskType.PlayerMoveTo;
                gt.StartPos = this.player.Pos;
                gt.TargetPos = target;

                int speedLevel = SpeedManager.Instance.GetSpeedNormal(this.player, this.gameInfo.RandomSpeed());
                double speedInPixel = this.player.GetSpeedInPixelByLevel(speedLevel);

                gt.FinishFrame = gt.CalcRealTargetTryMyBest(speedInPixel, seconds);
                gt.NextTask = TaskType.PlayerCover;

                this.player.SetCurrentTask(gt);
            }

            return BehaviourTreeStatus.Success;
        }

        /// <summary>
        /// 获取挡拆点
        /// </summary>
        /// <param name="handler"></param>
        /// <returns></returns>
        private Position GetPickRollTarget(Player handler)
        {
            //以持球人防守人为圆心跟 持球人防守人与篮筐连线的垂线， 半径为param454的交点
            //离我更近的那个
            Player defPlayer = handler.GetMyPosDefPlayer();
            Vector2D v = new Vector2D(handler.OwnerTeam.AttackBasket, defPlayer.Pos);
            double angle = v.GetSlopeAngle();

            double angle1 = angle + 90;
            double angle2 = angle - 90;

            int radius = ParameterManager.Instance.GetValue(ParameterEnum.PickRollArea);

            Position p1 = defPlayer.Pos.GetPosByAngleRadius((int)angle1, radius);
            Position p2 = defPlayer.Pos.GetPosByAngleRadius((int)angle2, radius);

            double dis1 = p1.Distance(this.player.Pos);
            double dis2 = p2.Distance(this.player.Pos);

            if (dis1 > dis2)
            {
                return p2;
            }
            return p1;
        }

        /// <summary>
        /// 进入挡拆阶段
        /// </summary>
        private void EnterPickRoll()
        {
            //清掉单打人
            this.player.OwnerTeam.ClearSingleAttacker();

            //持球人
            Player handler = this.gameInfo.Ball.Owner;

            //持球人防守人
            Player defHandler = handler.GetMyPosDefPlayer();

            //当前人
            this.player.SetCurrentTask(this.GetPickRollTask());

            //自己的防守人，有多个就取一个
            Player defMe = this.player.GetMyPosDefPlayer();

            this.tac.Do(handler, this.player, defHandler, defMe);
        }

        private GameTask GetPickRollTask()
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerPickRoll;
            gt.DelayStart = 0;

            return gt;
        }
    }
}
