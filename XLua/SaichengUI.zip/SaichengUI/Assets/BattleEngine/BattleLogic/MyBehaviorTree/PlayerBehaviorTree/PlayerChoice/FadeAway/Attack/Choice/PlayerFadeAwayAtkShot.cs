﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;
using Entity;

namespace BattleLogic
{
    public class PlayerFadeAwayAtkShot : PlayerBaseChoiceNode
    {
        public PlayerFadeAwayAtkShot(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {

        }

        protected override bool IsMyCharge(TimeData time)
        {
            //计算出手点
            double moveTime = (ParameterManager.Instance.GetValue(ParameterEnum.FadeAwayMoveTimeParam1) * 1.0f +
                             this.player.GetAttribute(PlayerAttribute.FadeAway) * ParameterManager.Instance.GetValue(ParameterEnum.FadeAwayMoveTimeParam2)) / 1000;
            double moveSpeed = ParameterManager.Instance.GetValue(ParameterEnum.FadeAwayMoveSpeed) * 1.0f;

            double dis = moveTime * moveSpeed;
            
            //移动距离已经大于等于这个了，可以出手
            double disMove = this.player.Pos.DistanceActualLength(this.player.GetCurTask().RecordPos);
            if (Formula.IsDisInPermissibleError(dis, disMove))
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.gameInfo.AddPersoanlBoxScore(this.player, BoxScoreType.FadeAways, 1);

            GameEvent ge = new GameEvent(GameEventType.ShotNew);
            ge.Param1 = (int)ShotType.FadeAway;
            ge.Pos = this.player.Pos;
            ge.Param4 = this.player;

            this.gameInfo.AddGameEvent(ge);

            return BehaviourTreeStatus.Success;
        }
    }
}
