﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 要球
    /// </summary>
    public class PlayerOutsideSingleAtkerAskBall : PlayerBaseChoiceNode
    {
        private TacAskBall tacAskBall;
        public PlayerOutsideSingleAtkerAskBall(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacAskBall = new TacAskBall(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            //球有所属人，且不在我手上
            if (this.gameInfo.Ball.Owner != null &&
                !this.gameInfo.Ball.Owner.IsSamePlayer(this.player))
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.tacAskBall.Do(this.player);
            this.player.GetCurTask().NextTask = TaskType.PlayerOutsideSingleAttack;

            return BehaviourTreeStatus.Success;
        }
    }
}
