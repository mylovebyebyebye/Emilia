﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerShotChoiceNode : PlayerBaseChoiceNode
    {
        private TacToShot tacToShot;

        public PlayerShotChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacToShot = new TacToShot(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            //投篮预期
            double expect = this.gameInfo.GetPlayerExpectHanlder( this.player);
            if (this.player.ShotScoringExpect > expect)
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            ShotType shotType = ShotType.JumpShot2P;
            double disToBasket = this.gameInfo.DisManager.GetDistanceInPixelToFieldBasket(this.gameInfo.Frame, this.player.OwnerTeam.AttackField, this.player);
            if (this.player.OwnerTeam.AttackField.Is3P(this.player.Pos, disToBasket))
            {
                shotType = ShotType.JumpShot3P;
            }

            this.tacToShot.DoToShot(shotType, this.player);
            //GameTask gt = new GameTask(this.name);
            //gt.TaskType = TaskType.PlayerShot;
            //gt.DelayStart = TimeFrameConverter.GetFrame(this.player.GetAttribute(PlayerAttribute.ShootTime) / 1000);
            //gt.FinishFrame = 1;
            //this.player.SetCurrentTask(gt);
            return BehaviourTreeStatus.Success;
        }
    }
}
