﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 移动到要球点
    /// </summary>
    public class PlayerInsideSingleAtkerMoveToAskBallPos : PlayerBaseChoiceNode
    {
        public PlayerInsideSingleAtkerMoveToAskBallPos(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }


        protected override bool IsMyCharge(TimeData time)
        {
            //没人在拉开，且不在要球点
            for (int i = 0; i < this.player.OwnerTeam.PlayerCount; i++)
            {
                Player player = this.player.OwnerTeam.Players[i];
                if (player.IsInTask( TaskType.PlayerMoveToSpaceOut))
                {
                    return false;
                }
            }
            if (this.player.Pos == this.player.GetCurTask().RecordPos)
            {
                return false;
            }
            return true;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            int speedLevel = SpeedManager.Instance.GetSpeedNormal(this.player, this.gameInfo.RandomSpeed());

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = this.player.GetCurTask().RecordPos;
            gt.RecordPos = this.player.GetCurTask().RecordPos;
            gt.SpeedLevel = speedLevel;
            gt.FinishFrame = gt.CalcTimeBySpeed( this.player.GetSpeedByLevel(speedLevel) );
            gt.NextTask = TaskType.PlayerInsideSingleAttack;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
