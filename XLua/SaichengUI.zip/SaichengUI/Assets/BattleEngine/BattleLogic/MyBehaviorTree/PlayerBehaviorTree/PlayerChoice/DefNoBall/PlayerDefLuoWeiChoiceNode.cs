﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerDefLuoWeiChoiceNode : PlayerDefHanlderChoiceBaseNode
    {

        private int lastCalcFrame;
        private Position lastTargetPos;

        public PlayerDefLuoWeiChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.lastCalcFrame = -1;
            this.lastTargetPos = Position.Empty;
        }

        protected override void CreateChildNode()
        {
            ConditionNode isLuoWei = new ConditionNode("是否落位盯人", this.IsLuoWei);
            this.AddChild(isLuoWei);

            ActionNode defLuoWei = new ActionNode("执行落位盯人", this.DefLuoWei);
            this.AddChild(defLuoWei);
        }

        private bool IsLuoWei(TimeData time)
        {
            Team attackTeam = this.gameInfo.AttackTeam;
            if (attackTeam == null)
            {
                attackTeam = this.gameInfo.LastAttackTeam;
            }
            Field attackField = attackTeam.AttackField;
            Player attacker = this.player.GetMyPosAttacker();
            double minDis = ParameterManager.Instance.GetValueD(ParameterEnum.DefHandlerLuoWeiDis);

            double dis = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, attackField, this.player);
            double disAtk = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, attackField, attacker);
            //double dis = attackField.GetBasketPos().DistanceActualLength(this.player.Pos);
            //double disAtk = basketPos.DistanceActualLength(attacker.Pos);
            //无球防守人距离己方篮筐para201 范围外
            //防守目标不在param201范围内
            //防守目标离篮筐更远
            if (disAtk < dis)
            {
                return false;
            }
            if (dis >= minDis && disAtk >= minDis)
            {
                return true;
            }
            double shotExpect = 0f;
            if (attacker != null)
            {
                shotExpect = attacker.ShotScoringExpect;
            }
            double minExpect = ParameterManager.Instance.GetValueD(ParameterEnum.LuoweiMinShotExpect) / 1000;
            if (shotExpect < minExpect)
            {
                if (attacker == null || this.IsNeedLuowei(attacker))
                {
                    return true;
                }
            }

            return false;
        }

        private bool IsNeedLuowei(Player attacker)
        {
            //double disToAtker = this.player.Pos.DistanceActualLength(attacker.Pos);
            double disToAtker = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, this.player, attacker);
            double param119 = ParameterManager.Instance.GetValue(ParameterEnum.DefRangeRadius);
            double param364 = ParameterManager.Instance.GetValue(ParameterEnum.LuoweiDefDisAdd);
            if (disToAtker > (param119 + param364))
            {
                return true;
            }
            return false;
        }

        protected BehaviourTreeStatus DefLuoWei(TimeData time)
        {

            //落位盯人，位置选择
            Player attacker = this.player.GetMyPosAttacker();
            Field attackField = this.gameInfo.GetAnotherTeam(this.player.OwnerTeam).AttackField;
            Position basketPos = attackField.GetBasketPos();
            Position target = this.GetPresetPos(attackField);
            Position p1 = Position.Empty;
            int speedLevel = ParameterManager.Instance.GetValue(ParameterEnum.LuoweiMinSpeedLevel);
            if (attacker != null)
            {
                if (attacker.GetCurTask().SpeedLevel > speedLevel)
                {
                    speedLevel = attacker.GetCurTask().SpeedLevel;
                }
                //以篮筐圆心， target到篮筐距离为半径， 进攻人与篮筐连线交点
                double radius = (double)target.Distance(basketPos);
                p1 = Formula.ClosestIntersection(basketPos, radius, attacker.Pos, basketPos);
                //如果在篮筐后面，就把X坐标改成跟篮筐一样
                if (attackField.IsBehindRebound(p1))
                {
                    p1.X = basketPos.X;
                }
            }
            else
            {
                p1 = target;
            }

            if (p1 == Position.Empty)
            {
                p1 = target;
            }

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = this.player.Pos;
            gt.TargetPos = p1;
            double speedInPixel = this.player.GetSpeedInPixelByLevel(speedLevel);
            gt.FinishFrame = gt.CalcRealTargetBySpeedMaxSeconds(ref speedInPixel, Player.MaxDefRelationTime);
            gt.SpeedLevel = this.player.GetSpeedLevelByRealSpeed(speedInPixel);
            gt.TargetPlayer = attacker;

            this.player.SetCurrentTask(gt);
            return BehaviourTreeStatus.Success;
        }

        private Position GetPresetPos(Field attackField)
        {
            if (this.lastCalcFrame != this.gameInfo.CurRound.StartFrame)
            {
                this.lastCalcFrame = this.gameInfo.CurRound.StartFrame;
                this.lastTargetPos = attackField.GetDefPresetPosition(this.player, this.gameInfo.RandomNext());
            }
            return this.lastTargetPos;
        }
    }
}
