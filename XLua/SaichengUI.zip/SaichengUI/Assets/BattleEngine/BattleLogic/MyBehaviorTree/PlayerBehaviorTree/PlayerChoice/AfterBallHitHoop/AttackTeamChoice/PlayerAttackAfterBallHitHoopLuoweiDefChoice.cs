﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    /// <summary>
    /// 攻方转入落位防守
    /// </summary>
    public class PlayerAttackAfterBallHitHoopLuoweiDefChoice : PlayerDefLuoWeiChoiceNode
    {
        public PlayerAttackAfterBallHitHoopLuoweiDefChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {

        }

        protected override void CreateChildNode()
        {
            ConditionNode isLuoWei = new ConditionNode("是否退防", this.IsBackToDefence);
            this.AddChild(isLuoWei);

            ActionNode defLuoWei = new ActionNode("落位防守", this.DefLuoWei);
            this.AddChild(defLuoWei);
        }

        private bool IsBackToDefence(TimeData time)
        {
            int Radius = ParameterManager.Instance.GetValue(ParameterEnum.ReboundPlacement);
            double dis = this.player.Pos.DistanceActualLength(this.gameInfo.Ball.GetCurTask().TargetPos);
            if (Radius < dis)
            {
                return true;
            }
            return false;
        }
    }
}
