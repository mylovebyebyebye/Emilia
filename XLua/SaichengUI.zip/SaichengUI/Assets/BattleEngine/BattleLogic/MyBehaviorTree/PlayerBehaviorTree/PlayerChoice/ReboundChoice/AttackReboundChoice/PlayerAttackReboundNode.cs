﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerAttackReboundNode : PlayerChoiceBaseSequenceNode
    {

        public PlayerAttackReboundNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            if (this.player.IsInTask( TaskType.PlayerToGetRebound))
            {
                return true;
            }
            return false;
        }

        protected override PlayerChoiceBaseSelector GetMySelector()
        {
            return new PlayerAttackReboundChoice("攻方篮板人选择", this.gameInfo);
        }
    }
}
