﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerInsideSingleAtkerChoice : PlayerChoiceBaseSelector
    {
        public PlayerInsideSingleAtkerChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            //队友全部选择完才能进选择流程
            //没选择的话什么事也不干
            PlayerInsideSingleAtkerDoNothing doNothing = new PlayerInsideSingleAtkerDoNothing("什么也不做", this.gameInfo);
            this.AddChild(doNothing);

            //内线进攻
            PlayerInsideSingleAtkStart startAtk = new PlayerInsideSingleAtkStart("内线进攻", this.gameInfo);
            this.AddChild(startAtk);

            //向篮筐移动
            PlayerInsideSingleAtkMoveToBasket moveToBasket = new PlayerInsideSingleAtkMoveToBasket("向篮筐靠近", this.gameInfo);
            this.AddChild(moveToBasket);

            PlayerInsideSingleAtkerMoveToReadyPos moveToReadyPos = new PlayerInsideSingleAtkerMoveToReadyPos("移动到准备点", this.gameInfo);
            this.AddChild(moveToReadyPos);

            PlayerInsideSingleAtkerMoveToAskBallPos moveToAskBallPos = new PlayerInsideSingleAtkerMoveToAskBallPos("移动到要球点", this.gameInfo);
            this.AddChild(moveToAskBallPos);

            PlayerInsideSingleAtkerAskBall askBall = new PlayerInsideSingleAtkerAskBall("要球", this.gameInfo);
            this.AddChild(askBall);

            //待机等跑位完成
            ActionNode standby = new ActionNode("待机", this.StandBy);
            this.AddChild(standby);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            gt.FinishFrame = TimeFrameConverter.GetFrame(Player.MaxDefRelationTime);
            gt.NextTask = TaskType.PlayerInsideSingleAttack;
            gt.RecordPos = this.player.GetCurTask().RecordPos;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
