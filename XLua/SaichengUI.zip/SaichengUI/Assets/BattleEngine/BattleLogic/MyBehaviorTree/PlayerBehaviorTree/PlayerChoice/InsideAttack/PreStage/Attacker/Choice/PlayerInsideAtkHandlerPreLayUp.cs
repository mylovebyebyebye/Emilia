﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    /// <summary>
    /// 上篮
    /// </summary>
    public class PlayerInsideAtkHandlerPreLayUp : PlayerBaseChoiceNode
    {
        public PlayerInsideAtkHandlerPreLayUp(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override bool IsMyCharge(TimeData time)
        {
            Player defPlayer = this.player.GetMyPosDefPlayer();
            //double disToBasket = this.player.OwnerTeam.AttackBasket.DistanceActualLength(this.player.Pos);
            double disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, this.player.OwnerTeam.AttackField, this.player);
            //不在防守人范围内，且到达上篮位置
            if (disToBasket <= ParameterManager.Instance.GetValue(ParameterEnum.LayupDistance))
            {
                if (defPlayer == null)
                {
                    return true;
                }
                double disToDef = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, this.player, defPlayer);
                //double disToDef = defPlayer.Pos.DistanceActualLength(this.player.Pos);
                if (disToDef > ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea))
                {
                    return true;
                }
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerLayup;
            gt.StartPos = this.player.Pos;
            gt.FinishFrame = 1;
            gt.TargetPos = this.player.Pos;

            this.player.SetCurrentTask(gt);
            this.gameInfo.Ball.GetCurTask().TaskType = TaskType.BallOnThePlayer;
            this.gameInfo.Ball.GetCurTask().FinishFrame = int.MaxValue;

            return BehaviourTreeStatus.Success;
        }
    }
}
