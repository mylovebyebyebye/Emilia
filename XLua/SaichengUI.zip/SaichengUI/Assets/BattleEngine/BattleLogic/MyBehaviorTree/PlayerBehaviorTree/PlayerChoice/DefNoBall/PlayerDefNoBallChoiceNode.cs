﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDefNoBallChoiceNode : PlayerChoiceBaseSelector
    {
        private TacMoveOut3SArea TacOutOf3S;
        public PlayerDefNoBallChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.TacOutOf3S = new TacMoveOut3SArea(this.gameInfo, this.name);
        }

        protected override void CreateChildNode()
        {
            ActionNode outOf3Second = new ActionNode("防守出3秒", this.OutOf3SArea);
            this.AddChild(outOf3Second);

            PlayerDefLuoWeiChoiceNode defLuoWei = new PlayerDefLuoWeiChoiceNode("落位盯人", this.gameInfo);
            this.AddChild(defLuoWei);

            PlayerDefOneOneOneChoiceNode defOneOneOne = new PlayerDefOneOneOneChoiceNode("盯人", this.gameInfo);
            this.AddChild(defOneOneOne);



            //ActionNode standby = new ActionNode("待机", this.StandBy);
            //this.AddChild(standby);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            gt.FinishFrame = TimeFrameConverter.GetFrame(Player.MaxDefRelationTime);
            this.player.SetCurrentTask(gt);
            return BehaviourTreeStatus.Success;
        }

        private BehaviourTreeStatus OutOf3SArea(TimeData time)
        {
            if (this.TacOutOf3S.IsNeedOutDef3S(this.player))
            {
                Player myPosAtker = this.player.GetMyPosAttacker();
                this.TacOutOf3S.DefPlayerDo(this.player, myPosAtker);
                return BehaviourTreeStatus.Success;
            }
            return BehaviourTreeStatus.Failure;
        }
    }
}
