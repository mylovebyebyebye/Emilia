﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerToShotChoice : PlayerChoiceBaseSelector
    {

        private TacToShot tacToShot;
        private TacStandby tacStandBy;

        public PlayerToShotChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacToShot = new TacToShot(this.gameInfo, this.name);
            this.tacStandBy = new TacStandby(this.gameInfo, this.name);
        }

        protected override void CreateChildNode()
        {
            ActionNode fakeAction = new ActionNode("是否做假动作", this.FakeAction);
            this.AddChild(fakeAction);

            ActionNode shot = new ActionNode("出手", this.Shot);
            this.AddChild(shot);
        }

        private BehaviourTreeStatus FakeAction(TimeData time)
        {
            ShotType shotType = (ShotType)this.player.GetCurTask().Param1;
            if (!this.tacToShot.IsNeedFakeAction(shotType))
            {
                //这种投篮方式肯定不做假动作
                return BehaviourTreeStatus.Failure;
            }

            int frame = this.gameInfo.Frame;
            double minDis = ParameterManager.Instance.GetValueD(ParameterEnum.DefRangeRadius);
            List<Player> defPlayers = new List<Player>();
            //防守范围内，是否有能防守的人
            for (int i = 0; i < this.gameInfo.DefTeam.PlayerCount; i++)
            {
                Player defPlayer = this.gameInfo.DefTeam.Players[i];
                double dis = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, this.player, defPlayer);
                if (dis < minDis && defPlayer.DefShotCD < frame)
                {
                    defPlayers.Add(defPlayer);
                }
            }
            if (defPlayers.Count > 0)
            {
                //计算假动作概率
                if (this.tacToShot.IsDoFakeAction(shotType, this.player))
                {
                    PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.FakeAction, this.player.Id);
                    this.gameInfo.AddGameInfo(pc);

                    //进行假动作
                    for (int i = 0; i < defPlayers.Count; i++)
                    {
                        Player defPlayer = defPlayers[i];
                        //一个一个晃，看他们会不会动
                        this.tacToShot.DoFakeAction(shotType, this.player, defPlayer);
                    }
                    //做完假动作，强制待机
                    double seconds = ParameterManager.Instance.GetValueD(ParameterEnum.FakeActionInterval) / 1000;
                    this.tacStandBy.DoForceStandby(this.player, seconds);
                    //下个动作还是进入准备投篮
                    this.player.NextTask.Add(this.tacToShot.GetToShotTask(shotType));
                    return BehaviourTreeStatus.Success;
                }
            }

            return BehaviourTreeStatus.Failure;
        }

        private BehaviourTreeStatus Shot(TimeData time)
        {
            ShotType shotType = (ShotType)this.player.GetCurTask().Param1;
            //出手，会经过出手时间的延迟
            this.tacToShot.Shot(shotType, this.player);

            return BehaviourTreeStatus.Success;
        }
    }
}
