﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerMoveToAreaNode : PlayerBaseUpdateNode
    {
        private TacPaoWei tac;
        public PlayerMoveToAreaNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacPaoWei(this.gameInfo, this.name);
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerMoveToArea;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            TaskMoveTo.Do(this.player);

            //如果攻方落位结束
            if (this.player.GetCurTask().FinishFrame == 1 &&
                this.player.NextTask.Count == 0)
            {
                if (this.player.OwnerTeam == this.gameInfo.AttackTeam)
                {
                    for (int i = 0; i < this.gameInfo.AttackTeam.PlayerCount; i++)
                    {
                        Player atkPlayer = this.gameInfo.AttackTeam.Players[i];
                        if (!atkPlayer.IsSamePlayer(this.player))
                        {
                            if (this.tac.IsNeedPaoWei(atkPlayer))
                            {
                                this.tac.Do(atkPlayer);
                            }
                        }
                    }
                }
            }

            return BehaviourTreeStatus.Success;
        }
    }
}
