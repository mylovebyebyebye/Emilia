﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerDriveToAtkHanlderWait : PlayerBaseChoiceNode
    {
        private double minInterval = 1f;
        private int lastProcessFrame = 0;
        private double waitTime = 0.3f;
        private int minIntervalFrame = 0;

        TacStandby tac;
        public PlayerDriveToAtkHanlderWait(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacStandby(this.gameInfo, this.name);
            this.minIntervalFrame = TimeFrameConverter.GetFrame(this.minInterval);
        }

        protected override bool IsMyCharge(FluentBehaviourTree.TimeData time)
        {
            //1秒内没干过这事
            if ( this.gameInfo.IsFramePassed(this.lastProcessFrame, this.minIntervalFrame) )
            {
                this.lastProcessFrame = this.gameInfo.GameFrame;
                return true;
            }
            return false; 
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.tac.DoMoveInSituBySeconds(this.player, this.waitTime);
            this.player.GetCurTask().NextTask = TaskType.PlayerDriveToAttackField;

            return BehaviourTreeStatus.Success;
        }
    }
}
