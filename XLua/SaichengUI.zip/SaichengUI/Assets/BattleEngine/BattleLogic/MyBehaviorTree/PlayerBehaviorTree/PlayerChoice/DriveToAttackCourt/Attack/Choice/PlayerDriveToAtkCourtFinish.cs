﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    /// <summary>
    /// 过半场结束
    /// </summary>
    public class PlayerDriveToAtkCourtFinish : PlayerBaseChoiceNode
    {
        TacStandby tac;

        public PlayerDriveToAtkCourtFinish(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacStandby(this.gameInfo, this.name);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            //球已经到了进攻半场，过半场结束
            Field atkField = this.gameInfo.AttackTeam.AttackField;
            if (atkField.IsOnMyEffectiveArea(this.gameInfo.Ball.Pos))
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            //待机0.2秒
            this.tac.Do(this.player, TimeFrameConverter.GetFrame(Player.MaxDefRelationTime));

            return BehaviourTreeStatus.Success;
        }
    }
}
