﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerStandbyNode : PlayerBaseUpdateNode
    {
        public PlayerStandbyNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void SetTaskType()
        {
            this.taskType = TaskType.PlayerStandby;
        }

        protected override BehaviourTreeStatus Process(TimeData time)
        {
            return BehaviourTreeStatus.Success;
        }
    }
}
