﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerSlumDunkAtkDunk : PlayerBaseChoiceNode
    {
        public PlayerSlumDunkAtkDunk(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {

        }

        protected override bool IsMyCharge(TimeData time)
        {
            //double disToBasket = this.player.Pos.DistanceActualLength(this.gameInfo.AttackTeam.AttackBasket);
            double disToBasket = this.gameInfo.DisManager.GetDistanceInCMToFieldBasket(this.gameInfo.Frame, this.gameInfo.AttackTeam.AttackField, this.player);
            double minDis = ParameterManager.Instance.GetValue(ParameterEnum.PlayerArea) * 1.0f;
            if (Formula.IsDisInPermissibleError(disToBasket, minDis))
            {
                return true;
            }
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            GameEvent ge = new GameEvent(GameEventType.ShotNew);
            ge.Param1 = (int)ShotType.SlumDunk;
            ge.Param4 = this.player;

            this.gameInfo.AddGameEvent(ge);

            return BehaviourTreeStatus.Success;
        }
    }
}
