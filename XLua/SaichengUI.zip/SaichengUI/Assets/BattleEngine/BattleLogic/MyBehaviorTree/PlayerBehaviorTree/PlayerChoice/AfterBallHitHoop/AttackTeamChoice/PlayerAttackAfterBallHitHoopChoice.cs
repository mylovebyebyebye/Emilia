﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerAttackAfterBallHitHoopChoice : PlayerChoiceBaseSelector
    {
        public PlayerAttackAfterBallHitHoopChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        protected override void CreateChildNode()
        {
            PlayerMoveToReboundPlacementNode moveTo = new PlayerMoveToReboundPlacementNode("向落点移动", this.gameInfo);
            this.AddChild(moveTo);

            PlayerAttackAfterBallHitHoopLuoweiDefChoice def = new PlayerAttackAfterBallHitHoopLuoweiDefChoice("退防", this.gameInfo);
            this.AddChild(def);

            ActionNode standBy = new ActionNode("待机", this.StandBy);
            this.AddChild(standBy);
        }

        private BehaviourTreeStatus StandBy(TimeData time)
        {
            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerStandby;
            gt.DelayStart = this.gameInfo.Ball.GetCurTask().DelayStart;
            gt.FinishFrame = this.gameInfo.Ball.GetCurTask().FinishFrame;

            this.player.SetCurrentTask(gt);

            return BehaviourTreeStatus.Success;
        }
    }
}
