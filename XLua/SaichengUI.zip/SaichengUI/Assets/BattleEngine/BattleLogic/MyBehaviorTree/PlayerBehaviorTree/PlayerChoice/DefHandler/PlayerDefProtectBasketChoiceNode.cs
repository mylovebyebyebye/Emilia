﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    public class PlayerDefProtectBasketChoiceNode : PlayerDefHanlderChoiceBaseNode
    {
        private int lastFillFrame;
        private TacFillIn tacFillIn;
        private int fillInCD;
        public PlayerDefProtectBasketChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tacFillIn = new TacFillIn(this.gameInfo, this.name);
            this.lastFillFrame = 0;
            this.fillInCD = TimeFrameConverter.GetFrame(ParameterManager.Instance.GetValueD(ParameterEnum.FillInCoolDown) / 1000);
        }

        protected override void CreateChildNode()
        {
            ConditionNode isProtectBasket = new ConditionNode("是否护筐", this.IsProtectBasket);
            this.AddChild(isProtectBasket);

            ActionNode protectBasket = new ActionNode("护筐", this.ProtectBasket);
            this.AddChild(protectBasket);
        }

        private bool IsProtectBasket(TimeData time)
        {
            Player attacker = this.player.GetMyPosAttacker();
            Field attackField = this.gameInfo.AttackTeam.AttackField;
            int minDisToBasketX = ParameterManager.Instance.GetValue(ParameterEnum.ProtectBasketMinX);
            double minDisToBasketXInPixel = Position.GetPix(minDisToBasketX);
            if (attackField.GetDistanceToBasketX(attacker.Pos) > minDisToBasketXInPixel)
            {
                double defDis = ParameterManager.Instance.GetValue(ParameterEnum.DefRangeRadius);
                double disToAtker = this.gameInfo.DisManager.GetDistanceInCMToOtherTeamPlayer(this.gameInfo.Frame, attacker, this.player);
                //double disToAtker = this.player.Pos.DistanceActualLength(attacker.Pos);
                //攻方离篮筐更近
                if (!Formula.IsDisInPermissibleError(disToAtker, defDis) && 
                    Math.Abs(attackField.GetDistanceToBasketX(attacker.Pos)) < Math.Abs(attackField.GetDistanceToBasketX(this.player.Pos)))
                {
                    return true;
                }
            }
            return false;
        }

        private BehaviourTreeStatus ProtectBasket(TimeData time)
        {
            Player attacker = this.player.GetMyPosAttacker();

            if ( this.gameInfo.IsFramePassed(this.lastFillFrame, this.fillInCD) ) 
            {
                //触发补防
                this.tacFillIn.Do(EFillInType.ProtectBasket, attacker);
                this.lastFillFrame = this.gameInfo.GameFrame;
            }

            //追击的移动线路修改
            Position target = attacker.GetCurTask().TargetPos;
            if (target == Position.Empty)
            {
                target = attacker.Pos;
            }

            GameTask gt = new GameTask(this.name);
            gt.TaskType = TaskType.PlayerMoveTo;
            gt.StartPos = this.player.Pos;
            if (this.IsNeedDelay(attacker))
            {
                gt.DelayStart = this.GetDelayFrame();
            }
            gt.TargetPos = target;
            int speedLevel = SpeedManager.Instance.GetSpeedAccelerate(player, this.gameInfo.RandomSpeed());

            gt.FinishFrame = gt.CalcRealTargetByTimeSpeed(Player.MaxDefRelationTime, this.player.GetSpeedInPixelByLevel(speedLevel));
            gt.SpeedLevel = speedLevel;

            this.player.SetCurrentTask(gt);
            return BehaviourTreeStatus.Success;
        }
    }
}
