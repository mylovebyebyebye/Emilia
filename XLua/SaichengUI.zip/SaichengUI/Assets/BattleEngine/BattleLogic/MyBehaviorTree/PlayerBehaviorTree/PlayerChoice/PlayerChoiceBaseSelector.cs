﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public class PlayerChoiceBaseSelector : SelectorNode
    {
        protected Player player;

        protected PlayerChoiceBaseSelector()
        {
            throw new Exception("this constructor is illegal");
        }

        public PlayerChoiceBaseSelector(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        public void SetPlayer(Player player)
        {
            this.player = player;
            for (int i = 0; i < this.ChildCount; i++)
            {
                IBehaviourTreeNode node = this.children[i];
                PlayerBaseChoiceNode choiceNode = node as PlayerBaseChoiceNode;
                if (choiceNode != null)
                {
                    choiceNode.SetPlayer(this.player);
                }
                else
                {
                    PlayerChoiceBaseSequenceNode baseNode = node as PlayerChoiceBaseSequenceNode;
                    if (baseNode != null)
                    {
                        baseNode.SetPlayer(this.player);
                    }
                }
            }
        }
    }
}
