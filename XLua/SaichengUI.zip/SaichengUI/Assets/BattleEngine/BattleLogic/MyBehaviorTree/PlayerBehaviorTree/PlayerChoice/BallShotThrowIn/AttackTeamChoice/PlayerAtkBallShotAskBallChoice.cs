﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using Common.ZDB;

namespace BattleLogic
{
    /// <summary>
    /// 要球
    /// </summary>
    public class PlayerAtkBallShotAskBallChoice : PlayerBaseChoiceNode
    {
        TacThrowIn tac;
        private TacAskBall tacAskBall;
        private int askBallFrame;
        public PlayerAtkBallShotAskBallChoice(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
            this.tac = new TacThrowIn(this.gameInfo, this.name);
            this.tacAskBall = new TacAskBall(this.gameInfo, this.name);
            this.askBallFrame = TimeFrameConverter.GetFrame(ParameterManager.Instance.GetValueD(ParameterEnum.ThrowInMaxSeconds) / 1000);
        }

        protected override bool IsMyCharge(TimeData time)
        {
            //是攻方PG
            if (this.player.Role != (int)PlayerRole.PG)
            {
                return false;
            }
            //在接球区域内 或者 在接球安全区域内
            //在接球区域内
            Player owner = this.gameInfo.Ball.Owner;
            Position throwInPos = this.gameInfo.Ball.GetCurTask().TargetPos;
            if (owner != null &&
                owner.GetCurTask().TaskType == TaskType.PlayerToThrowIn)
            {
                if (this.tac.IsInSafeArea(this.player, throwInPos))
                {
                    return true;
                }
                //剩余时间不足多少，且离发球人最近
                if (owner.GetCurTask().FinishFrame <= this.askBallFrame)
                {
                    double dis = this.gameInfo.DisManager.GetDistanceInCMToSameTeamPlayer(this.gameInfo.Frame, this.player, owner);
                    for (int i = 0; i < this.gameInfo.AttackTeam.PlayerCount; i++)
                    {
                        Player atkPlayer = this.gameInfo.AttackTeam.Players[i];
                        if (!atkPlayer.IsSamePlayer(owner) &&
                             !atkPlayer.IsSamePlayer(this.player))
                        {
                            double disOther = this.gameInfo.DisManager.GetDistanceInCMToSameTeamPlayer(this.gameInfo.Frame, atkPlayer, owner);
                            if (disOther < dis)
                            {
                                return false;
                            }
                        }                      
                    }
                    return true;  
                }
            }   
            return false;
        }

        protected override BehaviourTreeStatus Do(TimeData time)
        {
            this.tacAskBall.Do(this.player);

            return BehaviourTreeStatus.Success;
        }
    }
}
