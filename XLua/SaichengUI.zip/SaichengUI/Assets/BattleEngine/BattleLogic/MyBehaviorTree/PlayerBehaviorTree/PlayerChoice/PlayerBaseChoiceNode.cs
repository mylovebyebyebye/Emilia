﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;

namespace BattleLogic
{
    public abstract class PlayerBaseChoiceNode : SequenceNode
    {
        protected Player player;

        protected abstract bool IsMyCharge(TimeData time);
        protected abstract BehaviourTreeStatus Do(TimeData time);

        protected PlayerBaseChoiceNode()
        {
            throw new Exception("this constructor is illegal");
        }

        public PlayerBaseChoiceNode(string name, GameInfo gameInfo)
            : base(name, gameInfo)
        {
        }

        public void SetPlayer(Player player)
        {
            this.player = player;
        }

        protected override void CreateChildNode()
        {
            ConditionNode isMyCharge = new ConditionNode("是否是我处理", this.IsMyCharge);
            this.AddChild(isMyCharge);

            ActionNode process = new ActionNode("处理", this.Do);
            this.AddChild(process);
        }
    }
}
