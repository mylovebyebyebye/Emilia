﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentBehaviourTree;
using BattleLogic.Tactical;

namespace BattleLogic
{
    public class IsQuarterOverNode : SequenceNode
    {
        private TacJumpball tacJumpBall;

        private double RestBetweenQuarter;
        private double RestHalfTime;

        public IsQuarterOverNode(string name, GameInfo gameInfo)
            :base(name, gameInfo)
        {
            this.tacJumpBall = new TacJumpball(this.gameInfo, this.name);
            this.RestBetweenQuarter = 120.0;
            this.RestHalfTime = 900.0;
        }

        protected override void CreateChildNode()
        {
            ConditionNode isQuarterOver = new ConditionNode("本节是否结束", this.IsQuarterOver);
            this.AddChild(isQuarterOver);

            ActionNode quarterOver = new ActionNode("换节", this.QuarterOver);
            this.AddChild(quarterOver);
        }

        private bool IsQuarterOver(TimeData time)
        {
            if (this.gameInfo.QuarterTime <= 0 && 
                !this.gameInfo.CurRound.IsPause && 
                !this.gameInfo.IsNotOver() )
            {
                return true;
            }
            return false;
        }

        private BehaviourTreeStatus QuarterOver(TimeData time)
        {
            this.gameInfo.ClearEvent();
            this.gameInfo.ClearBallOwner();
            this.gameInfo.ClearAllPlayerTask();
            this.gameInfo.HomeTeam.ClearAllPlayerThisQuarterPlayeFrame();
            this.gameInfo.AwayTeam.ClearAllPlayerThisQuarterPlayeFrame();
            //停表
            this.gameInfo.Pause();
            this.gameInfo.StartNewRound();

            //恢复体力
            if (this.gameInfo.Quarter == 2)
            {
                this.gameInfo.RestoreAllPlayerStaminaOnBench(this.RestHalfTime);
            }
            else
            {
                this.gameInfo.RestoreAllPlayerStaminaOnBench(this.RestBetweenQuarter);
            }

            if (this.gameInfo.Quarter <= 3)
            {
                PlayByPlayContent pc = PlayByPlayManager.Instance.GetContent(this.gameInfo, EPlayeByPlayType.QuarterEnd, this.gameInfo.Quarter);
                this.gameInfo.AddGameInfo(pc);
                //半场交换场地
                if (this.gameInfo.Quarter == 2)
                {
                    Field homeAtk = this.gameInfo.HomeTeam.AttackField;
                    Field awayAtk = this.gameInfo.AwayTeam.AttackField;
                    this.gameInfo.HomeTeam.AttackField = awayAtk;
                    this.gameInfo.AwayTeam.AttackField = homeAtk;
                }
                //Player playerToThrowIn = null;
                ////第2、3节发球方为开场跳球失败的一方，第4节为开场跳球成功的一方
                //if (this.gameInfo.Quarter == 3)
                //{
                //    playerToThrowIn = this.gameInfo.StartGameJumpWinTeam.Players[(int)PlayerRole.C - 1];
                //}
                //else
                //{
                //    playerToThrowIn = this.gameInfo.GetAnotherTeam(this.gameInfo.StartGameJumpWinTeam).Players[(int)PlayerRole.C - 1];
                //}

                //发界外球事件
                GameEvent ge = new GameEvent(GameEventType.QuarterStartThrowIn);
                ge.Param1 = this.gameInfo.Quarter + 1;
                //ge.Param4 = playerToThrowIn;
                this.gameInfo.ClearEvent();
                this.gameInfo.AddGameEvent(ge);
            }
            else
            {
                //看是不是打平
                if (this.gameInfo.GetTotalPoint(TeamType.Home) == this.gameInfo.GetTotalPoint(TeamType.Away))
                {
                    //打平就来个加时赛事件
                    this.StartOverTimeQuarter();
                }
                else
                {
                    //比赛结束
                    this.gameInfo.SetOver();
                }
            }

            return BehaviourTreeStatus.Success;
        }

        private void StartOverTimeQuarter()
        {
            this.gameInfo.Quarter += 1;
            this.gameInfo.StartNewRound();

            this.tacJumpBall.Do(this.gameInfo.HomeTeam);
            this.tacJumpBall.Do(this.gameInfo.AwayTeam);
            this.SetBasketBallPos();


            GameEvent gameEvent = new GameEvent(GameEventType.JumpBall);
            //中圈跳球
            gameEvent.Param1 = 1;
            gameEvent.Param2 = (long)EJumpBallType.OverTimeStart;
            //gameEvent.Param4 = this.gameInfo.HomeTeam.Players[this.gameInfo.HomeTeam.Players.Count - 1];
            //gameEvent.Param5 = this.gameInfo.AwayTeam.Players[this.gameInfo.AwayTeam.Players.Count - 1];
            this.gameInfo.AddGameEvent(gameEvent);

            this.gameInfo.Pause();
        }

        private void SetBasketBallPos()
        {
            GameTask task = new GameTask(this.name);
            task.TargetPos = new Position(506, 300);
            task.TaskType = TaskType.BallLocation;
            task.DelayStart = 0;
            this.gameInfo.Ball.SetCurrentTask(task);

        }
    }
}
