﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.BattleLogic
{
    /// <summary>
    /// 阵容
    /// </summary>
    [Serializable]
    public class Roster
    {
        public List<long> AllPlayers;
        /// <summary>
        /// 先发
        /// </summary>
        public long[] Starters;
        /// <summary>
        /// 替补阵容
        /// </summary>
        public long[] BenchPlayers;
        /// <summary>
        /// 最强阵容
        /// </summary>
        public long[] MaxAbilityPlayers;
        /// <summary>
        /// 换人方针
        /// 是严格根据正选/替补之类
        /// </summary>
        public int Strategy = 0;
        /// <summary>
        /// 关键时刻使用最强阵容
        /// </summary>
        public bool CrutchTimeStrategy = false;

        public Roster()
        {
            this.AllPlayers = new List<long>();
            this.Starters = new long[5];
            this.BenchPlayers = new long[5];
            this.MaxAbilityPlayers = new long[5];

            for (int i = 0; i < 5; i++)
            {
                this.Starters[i] = 0;
                this.BenchPlayers[i] = 0;
                this.MaxAbilityPlayers[i] = 0;
            }
        }

        public void ClearMaxAbilityPlayers()
        {
            for (int i = 0; i < 5; i++)
            {
                this.MaxAbilityPlayers[i] = 0;
            }
        }
    }
}
