﻿using System.Collections.Generic;

namespace Entity.DBEntity
{
    public class DBPlayer
    {
        public long _id;
        /// <summary>
        /// 国籍ID
        /// </summary>
        public int Country;
        public string Name;
        /// <summary>
        /// 头像ID
        /// </summary>
        public int Photo;
        /// <summary>
        /// 年龄 20~30岁随机
        /// </summary>
        public int Age;
        /// <summary>
        /// 出生赛季
        /// </summary>
        public int BirthSeason;
        /// <summary>
        /// 号码 1~41随机生成
        /// </summary>
        public int Number;
        /// <summary>
        /// 惯用手 1~2随机
        /// </summary>
        public int MainHand;
        /// <summary>
        /// 身高公制
        /// </summary>
        public int HeightMS;
        /// <summary>
        /// 身高英制
        /// </summary>
        public string HeightIS;
        /// <summary>
        /// 偏好区域
        /// </summary>
        public string PreferredZone;

        public double[] szAttribute = new double[(int)PlayerAttribute.End];

    }


}
